@echo off
title Lyuex Development - Discord Bot Altyapisi
color 0B
echo ========================================
echo    LYUEX DEVELOPMENT
echo    Discord Bot Altyapisi v2.0
echo    (c) 2024-2026 Lyuex Development
echo ========================================
echo.
echo Bot baslatiliyor...
:loop
node lyuex.js
echo.
echo [LYUEX] Bot durdu veya kapandi. %time% zamaninda durdu.
echo [LYUEX] 5 saniye sonra yeniden baslatilacak.
echo [LYUEX] Pencereyi kapatarak donguyu durdurabilirsiniz.
timeout /t 5 /nobreak >nul
goto loop
