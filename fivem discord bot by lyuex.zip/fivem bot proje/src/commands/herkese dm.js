// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('herkese-dm')
    .setDescription('🚀 Gelişmiş toplu DM sistemi - Rol bazlı ve özel şablonlar')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(subcommand =>
      subcommand
        .setName('yetkili-toplanti')
        .setDescription('👥 Yetkili toplantısı için DM gönder')
        .addStringOption(option =>
          option.setName('tarih')
            .setDescription('📅 Toplantı tarihi (örn: 2025-10-05 20:00)')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('konu')
            .setDescription('📋 Toplantı konusu')
            .setRequired(true))
        .addChannelOption(option =>
          option.setName('kanal')
            .setDescription('📍 Toplantı kanalı')
            .setRequired(false))
        .addStringOption(option =>
          option.setName('aciliyet')
            .setDescription('⚠️ Aciliyet seviyesi')
            .setRequired(false)
            .addChoices(
              { name: '🟢 Normal', value: 'normal' },
              { name: '🟡 Önemli', value: 'important' },
              { name: '🔴 Acil', value: 'urgent' },
              { name: '💀 Kritik', value: 'critical' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('rol-duyuru')
        .setDescription('🎯 Belirli role sahip üyelere duyuru gönder')
        .addRoleOption(option =>
          option.setName('hedef_rol')
            .setDescription('🎭 Hedef rol')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('baslik')
            .setDescription('📋 Duyuru başlığı')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('mesaj')
            .setDescription('📝 Duyuru mesajı')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('tip')
            .setDescription('🎨 Duyuru tipi')
            .setRequired(false)
            .addChoices(
              { name: '📢 Genel Duyuru', value: 'general' },
              { name: '⚠️ Uyarı', value: 'warning' },
              { name: '🎉 Etkinlik', value: 'event' },
              { name: '📊 Günceleme', value: 'update' },
              { name: '🚨 Acil Durum', value: 'emergency' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('ozel-mesaj')
        .setDescription('✨ Özelleştirilmiş toplu DM gönder')
        .addRoleOption(option =>
          option.setName('hedef_rol')
            .setDescription('🎯 Hedef rol (opsiyonel)')
            .setRequired(false))
        .addStringOption(option =>
          option.setName('sablon')
            .setDescription('📋 Hazır şablon seç')
            .setRequired(false)
            .addChoices(
              { name: '🎮 Oyun Etkinliği', value: 'game_event' },
              { name: '🏆 Turnuva Duyurusu', value: 'tournament' },
              { name: '⭐ Sunucu Güncellemesi', value: 'server_update' },
              { name: '🎁 Ödül Dağıtımı', value: 'reward' },
              { name: '🔧 Bakım Bildirimi', value: 'maintenance' },
              { name: '👑 Yönetim Değişikliği', value: 'management' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('istatistik')
        .setDescription('📊 DM gönderim istatistiklerini görüntüle')),

  async execute(interaction) {
    // Yetki kontrolü
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator) && 
        !interaction.member.roles.cache.has(lyuex.yetkili.kurucu)) {
      return await interaction.reply({
        content: '❌ **Yetersiz Yetki!** Bu komutu sadece yöneticiler ve kurucular kullanabilir.',
        ephemeral: true
      });
    }

    const subcommand = interaction.options.getSubcommand();

    try {
      switch (subcommand) {
        case 'yetkili-toplanti':
          await handleYetkiliToplanti(interaction);
          break;
        case 'rol-duyuru':
          await handleRolDuyuru(interaction);
          break;
        case 'ozel-mesaj':
          await handleOzelMesaj(interaction);
          break;
        case 'istatistik':
          await handleIstatistik(interaction);
          break;
      }
    } catch (error) {
      console.error('Herkese DM komut hatası:', error);
      
      const errorContent = '❌ Bir hata oluştu. Lütfen tekrar deneyin.';
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorContent }).catch(() => {});
      } else {
        await interaction.reply({ content: errorContent, ephemeral: true }).catch(() => {});
      }
    }
  }
};

// Yetkili toplantısı fonksiyonu
async function handleYetkiliToplanti(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const tarih = interaction.options.getString('tarih');
  const konu = interaction.options.getString('konu');
  const kanal = interaction.options.getChannel('kanal');
  const aciliyet = interaction.options.getString('aciliyet') || 'normal';

  // Yetkili rollerini al
  const yetkiliRoller = [
    lyuex.yetkili.kurucu,
    lyuex.yetkili.kayit,
    ...lyuex.yetkili.rol
  ].flat().filter(Boolean);

  // Yetkili üyeleri topla
  await interaction.guild.members.fetch();
  const yetkiliUyeler = interaction.guild.members.cache.filter(member => 
    yetkiliRoller.some(roleId => member.roles.cache.has(roleId)) && !member.user.bot
  );

  if (yetkiliUyeler.size === 0) {
    return await interaction.editReply({
      content: '❌ **Yetkili bulunamadı!** Hiç yetkili üye bulunamadı.'
    });
  }

  // Aciliyet seviyesine göre renk ve emoji
  const aciliyetConfig = {
    normal: { color: '#5865F2', emoji: '🟢', title: 'Normal' },
    important: { color: '#FFA500', emoji: '🟡', title: 'Önemli' },
    urgent: { color: '#FF6B6B', emoji: '🔴', title: 'Acil' },
    critical: { color: '#8B0000', emoji: '💀', title: 'KRİTİK' }
  };

  const config = aciliyetConfig[aciliyet];

  // Onay mesajı
  const confirmEmbed = new EmbedBuilder()
    .setTitle(`${config.emoji} Yetkili Toplantısı - ${config.title}`)
    .setColor(config.color)
    .setDescription(`**${yetkiliUyeler.size}** yetkili üyeye toplantı daveti gönderilecek.`)
    .addFields(
      { name: '📅 Tarih', value: tarih, inline: true },
      { name: '📋 Konu', value: konu, inline: true },
      { name: '📍 Kanal', value: kanal ? kanal.toString() : 'Belirtilmedi', inline: true },
      { name: '⚠️ Aciliyet', value: `${config.emoji} ${config.title}`, inline: true },
      { name: '👥 Hedef', value: `${yetkiliUyeler.size} yetkili üye`, inline: true }
    )
    .setFooter({ text: 'Devam etmek için onaylayın...' })
    .setTimestamp();

  const confirmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_meeting')
        .setLabel('✅ Onayla ve Gönder')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cancel_meeting')
        .setLabel('❌ İptal Et')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.editReply({
    embeds: [confirmEmbed],
    components: [confirmRow]
  });

  // Button collector
  const collector = interaction.channel.createMessageComponentCollector({
    filter: i => i.user.id === interaction.user.id,
    time: 30000
  });

  collector.on('collect', async (buttonInteraction) => {
    if (buttonInteraction.customId === 'confirm_meeting') {
      await buttonInteraction.update({
        content: '🚀 **Toplantı davetiyeleri gönderiliyor...**',
        embeds: [],
        components: []
      });

      // DM gönderme işlemi
      let basarili = 0;
      let basarisiz = 0;

      const meetingEmbed = new EmbedBuilder()
        .setTitle(`${config.emoji} YETKİLİ TOPLANTISI - ${config.title}`)
        .setColor(config.color)
        .setDescription(`**${interaction.guild.name}** sunucusunda yetkili toplantısı düzenleniyor!`)
        .addFields(
          { name: '📅 Tarih & Saat', value: tarih, inline: false },
          { name: '📋 Toplantı Konusu', value: konu, inline: false },
          { name: '📍 Toplantı Yeri', value: kanal ? `${kanal}` : 'Discord Sesli Kanal', inline: false },
          { name: '⚠️ Aciliyet Seviyesi', value: `${config.emoji} **${config.title}**`, inline: false },
          { name: '👑 Toplantıyı Düzenleyen', value: interaction.user.tag, inline: false }
        )
        .setFooter({ 
          text: `${interaction.guild.name} • Yetkili Toplantısı`,
          iconURL: interaction.guild.iconURL()
        })
        .setTimestamp();

      if (aciliyet === 'critical' || aciliyet === 'urgent') {
        meetingEmbed.addFields({
          name: '🚨 DİKKAT!',
          value: 'Bu toplantı zorunludur! Mazeretiniz yoksa mutlaka katılmanız gerekmektedir.',
          inline: false
        });
      }

      for (const [, member] of yetkiliUyeler) {
        try {
          await member.send({ embeds: [meetingEmbed] });
          basarili++;
        } catch (error) {
          basarisiz++;
        }
        
        // Rate limit koruması
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      // Sonuç raporu
      const resultEmbed = new EmbedBuilder()
        .setTitle('📤 Toplantı Davetiyeleri Gönderildi!')
        .setColor(0x00FF88)
        .addFields(
          { name: '✅ Başarılı', value: `${basarili} yetkili`, inline: true },
          { name: '❌ Başarısız', value: `${basarisiz} yetkili`, inline: true },
          { name: '📊 Başarı Oranı', value: `%${Math.round((basarili / yetkiliUyeler.size) * 100)}`, inline: true }
        )
        .setTimestamp();

      await interaction.editReply({
        content: null,
        embeds: [resultEmbed]
      });

      // Log kanalına bildirim
      const logChannel = interaction.guild.channels.cache.get(lyuex.botSettings.LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('📅 Yetkili Toplantısı Düzenlendi')
          .setColor(config.color)
          .addFields(
            { name: '👑 Düzenleyen', value: `${interaction.user.tag}`, inline: true },
            { name: '📅 Tarih', value: tarih, inline: true },
            { name: '⚠️ Aciliyet', value: `${config.emoji} ${config.title}`, inline: true },
            { name: '📋 Konu', value: konu, inline: false },
            { name: '📊 Gönderim', value: `${basarili}/${yetkiliUyeler.size} başarılı`, inline: true }
          )
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
      }

    } else if (buttonInteraction.customId === 'cancel_meeting') {
      await buttonInteraction.update({
        content: '❌ **Toplantı daveti iptal edildi.**',
        embeds: [],
        components: []
      });
    }
  });

  collector.on('end', collected => {
    if (collected.size === 0) {
      interaction.editReply({
        content: '⏰ **Zaman aşımı!** Toplantı daveti iptal edildi.',
        embeds: [],
        components: []
      }).catch(() => {});
    }
  });
}

// Rol duyurusu fonksiyonu
async function handleRolDuyuru(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const hedefRol = interaction.options.getRole('hedef_rol');
  const baslik = interaction.options.getString('baslik');
  const mesaj = interaction.options.getString('mesaj');
  const tip = interaction.options.getString('tip') || 'general';

  // Rol üyelerini al
  await interaction.guild.members.fetch();
  const rolUyeleri = hedefRol.members.filter(member => !member.user.bot);

  if (rolUyeleri.size === 0) {
    return await interaction.editReply({
      content: `❌ **Üye bulunamadı!** ${hedefRol} rolünde hiç üye yok.`
    });
  }

  // Tip konfigürasyonu
  const tipConfig = {
    general: { color: '#5865F2', emoji: '📢', title: 'Genel Duyuru' },
    warning: { color: '#FFA500', emoji: '⚠️', title: 'Uyarı' },
    event: { color: '#00FF88', emoji: '🎉', title: 'Etkinlik' },
    update: { color: '#8B5CF6', emoji: '📊', title: 'Güncelleme' },
    emergency: { color: '#FF0000', emoji: '🚨', title: 'ACİL DURUM' }
  };

  const config = tipConfig[tip];

  // Onay embed'i
  const confirmEmbed = new EmbedBuilder()
    .setTitle(`${config.emoji} ${config.title}`)
    .setColor(config.color)
    .setDescription(`**${rolUyeleri.size}** ${hedefRol} üyesine duyuru gönderilecek.`)
    .addFields(
      { name: '📋 Başlık', value: baslik, inline: false },
      { name: '📝 Mesaj', value: mesaj.slice(0, 500) + (mesaj.length > 500 ? '...' : ''), inline: false },
      { name: '🎭 Hedef Rol', value: hedefRol.toString(), inline: true },
      { name: '👥 Üye Sayısı', value: rolUyeleri.size.toString(), inline: true }
    )
    .setTimestamp();

  const confirmRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm_announce')
        .setLabel('✅ Duyuru Gönder')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cancel_announce')
        .setLabel('❌ İptal Et')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.editReply({
    embeds: [confirmEmbed],
    components: [confirmRow]
  });

  // Collector
  const collector = interaction.channel.createMessageComponentCollector({
    filter: i => i.user.id === interaction.user.id,
    time: 30000
  });

  collector.on('collect', async (buttonInteraction) => {
    if (buttonInteraction.customId === 'confirm_announce') {
      await buttonInteraction.update({
        content: '📤 **Duyuru gönderiliyor...**',
        embeds: [],
        components: []
      });

      let basarili = 0;
      let basarisiz = 0;

      const announceEmbed = new EmbedBuilder()
        .setTitle(`${config.emoji} ${baslik}`)
        .setDescription(mesaj)
        .setColor(config.color)
        .addFields(
          { name: '🎭 Hedef Rol', value: hedefRol.name, inline: true },
          { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
        )
        .setFooter({ 
          text: `${interaction.guild.name} • ${config.title}`,
          iconURL: interaction.guild.iconURL()
        })
        .setTimestamp();

      for (const [, member] of rolUyeleri) {
        try {
          await member.send({ embeds: [announceEmbed] });
          basarili++;
        } catch (error) {
          basarisiz++;
        }
        
        await new Promise(resolve => setTimeout(resolve, 300));
      }

      const resultEmbed = new EmbedBuilder()
        .setTitle('📤 Duyuru Gönderildi!')
        .setColor(0x00FF88)
        .addFields(
          { name: '✅ Başarılı', value: basarili.toString(), inline: true },
          { name: '❌ Başarısız', value: basarisiz.toString(), inline: true },
          { name: '📊 Oran', value: `%${Math.round((basarili / rolUyeleri.size) * 100)}`, inline: true }
        )
        .setTimestamp();

      await interaction.editReply({ embeds: [resultEmbed] });

    } else {
      await buttonInteraction.update({
        content: '❌ **Duyuru iptal edildi.**',
        embeds: [],
        components: []
      });
    }
  });
}

// Özel mesaj fonksiyonu
async function handleOzelMesaj(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const hedefRol = interaction.options.getRole('hedef_rol');
  const sablon = interaction.options.getString('sablon');

  if (sablon) {
    // Şablon sistemini başlat
    await handleSablonSecimi(interaction, hedefRol, sablon);
  } else {
    // Manuel mesaj modal'ı aç
    await handleManuelMesaj(interaction, hedefRol);
  }
}

// Şablon seçimi
async function handleSablonSecimi(interaction, hedefRol, sablon) {
  const sablonlar = {
    game_event: {
      title: '🎮 Oyun Etkinliği',
      description: 'Sunucumuzda yeni bir oyun etkinliği düzenleniyor! Herkesi bekliyoruz.',
      color: '#00FF88',
      fields: [
        { name: '🎯 Etkinlik', value: 'Belirtilecek', inline: true },
        { name: '📅 Tarih', value: 'Belirtilecek', inline: true },
        { name: '🏆 Ödüller', value: 'Sürpriz ödüller!', inline: false }
      ]
    },
    tournament: {
      title: '🏆 Turnuva Duyurusu',
      description: 'Yeni turnuva başlıyor! Kayıtlar açıldı.',
      color: '#FFD700',
      fields: [
        { name: '🎮 Oyun', value: 'Belirtilecek', inline: true },
        { name: '📅 Başlangıç', value: 'Belirtilecek', inline: true },
        { name: '💰 Ödül Havuzu', value: 'Açıklanacak', inline: false }
      ]
    },
    server_update: {
      title: '⭐ Sunucu Güncellemesi',
      description: 'Sunucumuzda yeni güncellemeler yapıldı!',
      color: '#8B5CF6',
      fields: [
        { name: '🆕 Yenilikler', value: 'Belirtilecek', inline: false },
        { name: '🔧 Düzeltmeler', value: 'Belirtilecek', inline: false }
      ]
    },
    reward: {
      title: '🎁 Ödül Dağıtımı',
      description: 'Ödüllerinizi almayı unutmayın!',
      color: '#FF69B4',
      fields: [
        { name: '🎁 Ödül Türü', value: 'Belirtilecek', inline: true },
        { name: '⏰ Son Tarih', value: 'Belirtilecek', inline: true }
      ]
    },
    maintenance: {
      title: '🔧 Bakım Bildirimi',
      description: 'Sunucu bakımı gerçekleştirilecek.',
      color: '#FFA500',
      fields: [
        { name: '⏰ Başlangıç', value: 'Belirtilecek', inline: true },
        { name: '📊 Süre', value: 'Yaklaşık 2 saat', inline: true }
      ]
    },
    management: {
      title: '👑 Yönetim Değişikliği',
      description: 'Sunucu yönetiminde değişiklikler yapıldı.',
      color: '#DC143C',
      fields: [
        { name: '📋 Değişiklikler', value: 'Belirtilecek', inline: false }
      ]
    }
  };

  const secilenSablon = sablonlar[sablon];
  
  const sablonEmbed = new EmbedBuilder()
    .setTitle('📋 Şablon Önizleme')
    .setDescription(`**${secilenSablon.title}** şablonu seçildi.`)
    .addFields(
      { name: 'Başlık', value: secilenSablon.title, inline: true },
      { name: 'Açıklama', value: secilenSablon.description, inline: false }
    )
    .setColor(secilenSablon.color)
    .setTimestamp();

  const customizeRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('customize_template')
        .setLabel('✏️ Özelleştir')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('send_template')
        .setLabel('📤 Gönder')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cancel_template')
        .setLabel('❌ İptal')
        .setStyle(ButtonStyle.Danger)
    );

  await interaction.editReply({
    embeds: [sablonEmbed],
    components: [customizeRow]
  });

  // Template handling devamı...
}

// Manuel mesaj
async function handleManuelMesaj(interaction, hedefRol) {
  const modal = new ModalBuilder()
    .setCustomId('manual_message_modal')
    .setTitle('✨ Özel Mesaj Oluştur');

  const titleInput = new TextInputBuilder()
    .setCustomId('message_title')
    .setLabel('📋 Mesaj Başlığı')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(256);

  const descriptionInput = new TextInputBuilder()
    .setCustomId('message_description')
    .setLabel('📝 Mesaj İçeriği')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(2000);

  const colorInput = new TextInputBuilder()
    .setCustomId('message_color')
    .setLabel('🎨 Renk (hex kodu, örn: #FF0000)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setValue('#5865F2');

  modal.addComponents(
    new ActionRowBuilder().addComponents(titleInput),
    new ActionRowBuilder().addComponents(descriptionInput),
    new ActionRowBuilder().addComponents(colorInput)
  );

  await interaction.showModal(modal);
}

// İstatistik fonksiyonu
async function handleIstatistik(interaction) {
  await interaction.deferReply({ ephemeral: true });

  // Basit istatistik (gerçek veriler için veritabanı gerekir)
  const statsEmbed = new EmbedBuilder()
    .setTitle('📊 DM Gönderim İstatistikleri')
    .setColor(0x5865F2)
    .setDescription('Son 30 günlük DM gönderim raporu')
    .addFields(
      { name: '📤 Toplam Gönderim', value: 'Veri yok', inline: true },
      { name: '✅ Başarılı', value: 'Veri yok', inline: true },
      { name: '❌ Başarısız', value: 'Veri yok', inline: true },
      { name: '👥 En Çok Gönderilen Rol', value: 'Veri yok', inline: false },
      { name: '📅 Son Gönderim', value: 'Veri yok', inline: false }
    )
    .setFooter({ text: 'İstatistikler için veritabanı bağlantısı gerekli' })
    .setTimestamp();

  await interaction.editReply({ embeds: [statsEmbed] });
}

module.exports.handleYetkiliToplanti = handleYetkiliToplanti;
module.exports.handleRolDuyuru = handleRolDuyuru;
module.exports.handleOzelMesaj = handleOzelMesaj;
module.exports.handleIstatistik = handleIstatistik;





