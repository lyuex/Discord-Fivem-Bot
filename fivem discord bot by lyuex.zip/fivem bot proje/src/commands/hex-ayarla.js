// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('hex-ayarla')
        .setDescription('🎨 Hex onay sistemini ayarla')
        .addChannelOption(option =>
            option
                .setName('kanal')
                .setDescription('Hex kodların gönderileceği kanal')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option
                .setName('rol')
                .setDescription('Onaylanan hex kodlar için verilecek rol')
                .setRequired(true)
        )
        .addChannelOption(option =>
            option
                .setName('log-kanal')
                .setDescription('Log kanalı (opsiyonel)')
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        // Yetki kontrolü
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Yetkisiz Erişim')
                    .setDescription('Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!')
                    .setTimestamp()
                ],
                ephemeral: true
            });
        }

        const hexKanal = interaction.options.getChannel('kanal');
        const hexRol = interaction.options.getRole('rol');
        const logKanal = interaction.options.getChannel('log-kanal');

        try {
            // lyuex.json dosyasını oku
            const lyuexPath = path.join(__dirname, '../../lyuex.json');
            const lyuexData = JSON.parse(fs.readFileSync(lyuexPath, 'utf8'));

            // Hex sistem ayarlarını güncelle
            lyuexData.hex_sistem = {
                kanal: hexKanal.id,
                log_kanal: logKanal ? logKanal.id : lyuexData.hex_sistem?.log_kanal || '',
                yetkili_rol: lyuexData.hex_sistem?.yetkili_rol || []
            };

            // Hex onay rolünü güncelle
            lyuexData.rol.hex_onay = hexRol.id;

            // Dosyayı kaydet
            fs.writeFileSync(lyuexPath, JSON.stringify(lyuexData, null, 4));

            // Başarı mesajı
            const embed = new EmbedBuilder()
                .setColor(0x00FF88)
                .setTitle('✅ Hex Sistemi Başarıyla Ayarlandı!')
                .setDescription('Hex onay sistemi konfigürasyonu tamamlandı!')
                .addFields(
                    { name: '🎨 Hex Kanalı', value: `${hexKanal} (${hexKanal.name})`, inline: true },
                    { name: '🏷️ Onay Rolü', value: `${hexRol} (${hexRol.name})`, inline: true },
                    { name: '📋 Log Kanalı', value: logKanal ? `${logKanal} (${logKanal.name})` : 'Belirtilmedi', inline: true },
                    { name: '⚙️ Sistem Durumu', value: '🟢 **AKTİF**', inline: true },
                    { name: '👮 Yetkili Roller', value: lyuexData.hex_sistem.yetkili_rol.length > 0 ? 
                        lyuexData.hex_sistem.yetkili_rol.map(id => `<@&${id}>`).join(', ') : 
                        'Henüz ayarlanmamış', inline: true },
                    { name: '📊 Özellikler', value: '• 6 haneli hex doğrulama\n• Renk önizleme\n• 4 onay seçeneği\n• Otomatik rol verme', inline: false }
                )
                .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 256 }))
                .setFooter({ 
                    text: `Ayarlayan: ${interaction.user.tag} • ZYM CİTY`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            // Hex kanalına bilgilendirme mesajı gönder
            try {
                const infoEmbed = new EmbedBuilder()
                    .setColor(0x5865F2)
                    .setTitle('🎨 Hex Onay Sistemi Aktif!')
                    .setDescription('Bu kanala hex kodlarınızı gönderebilirsiniz!')
                    .addFields(
                        { name: '📝 Nasıl Kullanılır?', value: '6 haneli hex kodunuzu yazın (örn: `FF0000`)', inline: false },
                        { name: '✅ Geçerli Format', value: '`FF0000` `00FF00` `0000FF` `FFFFFF`', inline: true },
                        { name: '❌ Geçersiz Format', value: '`#FF0000` `red` `255,0,0` `rgb(255,0,0)`', inline: true },
                        { name: '🎯 Onay Süreci', value: 'Hex kodunuz gönderildikten sonra yetkililer tarafından değerlendirilecek', inline: false },
                        { name: '🏷️ Onay Rolü', value: `Onaylandığında **${hexRol.name}** rolünü alacaksınız`, inline: false }
                    )
                    .setFooter({ text: 'ZYM CİTY • Hex Onay Sistemi' })
                    .setTimestamp();

                await hexKanal.send({ embeds: [infoEmbed] });
            } catch (channelError) {
                console.error('Hex kanal bilgilendirme hatası:', channelError);
            }

        } catch (error) {
            console.error('Hex ayarlama hatası:', error);
            
            await interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Ayarlama Hatası')
                    .setDescription('Hex sistemi ayarlanırken bir hata oluştu!')
                    .addFields(
                        { name: '💥 Hata', value: error.message || 'Bilinmeyen hata', inline: false }
                    )
                    .setTimestamp()
                ],
                ephemeral: true
            });
        }
    },
};





