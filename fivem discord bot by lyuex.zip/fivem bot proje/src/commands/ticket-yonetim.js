// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, 
       ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelType } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket-yonetim')
        .setDescription('🎫 Ticket sistemi yönetimi - Tüm ticket işlemleri')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false),

    async execute(interaction) {
        // Önce config dosyasını kontrol et
        const config = ticketUtil.getConfig();
        if (!config) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF6B6B)
                        .setTitle('❌ Ticket Sistemi Kapalı')
                        .setDescription('Ticket sistemi henüz ayarlanmamış.')
                ],
                ephemeral: true
            });
        }
        
        try {
            await showMainMenu(interaction, config);
        } catch (error) {
            console.error('Ticket yönetim hatası:', error);
            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF6B6B)
                        .setTitle('❌ Hata')
                        .setDescription('İşlem sırasında bir hata oluştu.')
                ],
                ephemeral: true
            });
        }
    }
};

// Ana ticket yönetim menüsü
async function showMainMenu(interaction, config) {
    await interaction.deferReply({ ephemeral: true });

    const member = interaction.guild.members.cache.get(interaction.user.id);
    const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);
    const isSupportStaff = config.supportRoleId ? member.roles.cache.has(config.supportRoleId) : false;
    const hasPermission = isAdmin || isSupportStaff;

    // Ana menü embed'i
    const mainEmbed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle('🎫 Ticket Yönetim Merkezi')
        .setDescription('Aşağıdaki seçeneklerden yapmak istediğiniz işlemi seçin.')
        .setFooter({ text: 'Ticket sistemi yönetimi' })
        .setTimestamp();

    // Kullanıcının yetkisine göre alanlar ekle
    if (hasPermission) {
        const guild = interaction.guild;
        const activeTickets = guild.channels.cache.filter(ch => 
            ch.name.includes('ticket-') && ch.type === ChannelType.GuildText
        );

        mainEmbed.addFields(
            { name: '📊 Durum', value: config.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
            { name: '🎫 Aktif Ticketlar', value: `${activeTickets.size} adet`, inline: true },
            { name: '⚡ Yetkiniz', value: isAdmin ? 'Adlyuexstrator' : 'Destek Ekibi', inline: true }
        );
    }

    // Butonları oluştur
    const buttonRows = [];

    // İlk sıra - Genel işlemler
    const firstRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('ticket_list')
            .setLabel('Ticket Listesi')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('📋'),
        new ButtonBuilder()
            .setCustomId('ticket_my_tickets')
            .setLabel('Benim Ticketlarım')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('👤')
    );

    // Eğer ticket kanalındaysak, kanal işlemleri ekle
    if (interaction.channel.name.includes('ticket-')) {
        firstRow.addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_channel_actions')
                .setLabel('Bu Ticket\'ı Yönet')
                .setStyle(ButtonStyle.Success)
                .setEmoji('⚙️')
        );
    }

    buttonRows.push(firstRow);

    // İkinci sıra - Yönetici işlemleri (sadece yetkili kullanıcılar için)
    if (hasPermission) {
        const secondRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_settings')
                .setLabel('Sistem Ayarları')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('⚙️'),
            new ButtonBuilder()
                .setCustomId('ticket_stats')
                .setLabel('İstatistikler')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('📊')
        );

        if (isAdmin) {
            secondRow.addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_admin_tools')
                    .setLabel('Admin Araçları')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🛠️')
            );
        }

        buttonRows.push(secondRow);
    }

    const response = await interaction.editReply({
        embeds: [mainEmbed],
        components: buttonRows
    });

    // Ana menü buton collector'ı
    const collector = response.createMessageComponentCollector({ 
        time: 300000 // 5 dakika
    });

    collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
            return i.reply({ content: 'Bu menüyü sadece komutu kullanan kişi kullanabilir.', ephemeral: true });
        }

        switch (i.customId) {
            case 'ticket_list':
                await handleList(i);
                break;
            case 'ticket_my_tickets':
                await handleMyTickets(i);
                break;
            case 'ticket_channel_actions':
                await handleChannelActions(i);
                break;
            case 'ticket_settings':
                if (hasPermission) {
                    await handleSettings(i, config);
                } else {
                    await i.reply({ content: '❌ Bu özellik için yetkiniz yok!', ephemeral: true });
                }
                break;
            case 'ticket_stats':
                if (hasPermission) {
                    await handleStats(i);
                } else {
                    await i.reply({ content: '❌ Bu özellik için yetkiniz yok!', ephemeral: true });
                }
                break;
            case 'ticket_admin_tools':
                if (isAdmin) {
                    await handleAdminTools(i);
                } else {
                    await i.reply({ content: '❌ Bu özellik sadece adminler için!', ephemeral: true });
                }
                break;
            case 'back_to_main':
                await showMainMenu(i, ticketUtil.getConfig() || config);
                break;
        }
    });
}
// Kullanıcının kendi ticketlarını göster
async function handleMyTickets(interaction) {
    await interaction.deferUpdate();
    const { guild, user } = interaction;
    
    // Kullanıcının aktif ticketlarını bul
    const userTickets = guild.channels.cache.filter(ch => 
        ch.name.includes('ticket-') && 
        ch.permissionOverwrites.cache.has(user.id) &&
        ch.type === ChannelType.GuildText
    );
    
    if (userTickets.size === 0) {
        const noTicketsEmbed = new EmbedBuilder()
            .setColor(0x95A5A6)
            .setTitle('📋 Benim Ticketlarım')
            .setDescription('Henüz açık ticket\'ınız bulunmuyor.')
            .addFields(
                { name: '💡 Yeni Ticket Açmak İçin', value: '`/ticket` komutunu kullanabilirsiniz.' }
            );

        return interaction.editReply({
            embeds: [noTicketsEmbed],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('back_to_main')
                        .setLabel('Ana Menüye Dön')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🔙')
                )
            ]
        });
    }

    // Ticketları listele
    const ticketsDb = ticketUtil.getTicketsDb();
    const ticketInfo = [];
    
    userTickets.forEach(channel => {
        const ticketData = ticketsDb.find(t => t.channelId === channel.id || t.id === channel.id);
        const createdAt = ticketData?.createdAt 
            ? new Date(ticketData.createdAt).toLocaleDateString('tr-TR')
            : channel.createdAt.toLocaleDateString('tr-TR');
        
        ticketInfo.push({
            id: channel.id,
            name: channel.name,
            createdAt,
            subject: ticketData?.subject || 'Genel',
            age: Math.floor((Date.now() - (ticketData?.createdAt || channel.createdTimestamp)) / (1000 * 60 * 60 * 24))
        });
    });

    const myTicketsEmbed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle(`📋 Benim Ticketlarım (${userTickets.size})`)
        .setDescription(
            ticketInfo.map(ticket => 
                `🎫 <#${ticket.id}> - ${ticket.subject}\n📅 ${ticket.createdAt} (${ticket.age} gün önce)`
            ).join('\n\n')
        )
        .setFooter({ text: 'Yönetmek için bir ticket seçin' });

    if (ticketInfo.length > 0) {
        const selectMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('my_ticket_select')
                .setPlaceholder('Yönetmek için ticket seçin...')
                .addOptions(
                    ticketInfo.map(ticket => ({
                        label: `${ticket.name} (${ticket.age} gün)`,
                        value: ticket.id,
                        description: ticket.subject
                    }))
                )
        );

        const backButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('back_to_main')
                .setLabel('Ana Menüye Dön')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('🔙')
        );

        await interaction.editReply({
            embeds: [myTicketsEmbed],
            components: [selectMenu, backButton]
        });
    }
}

// Mevcut kanal ticket işlemleri
async function handleChannelActions(interaction) {
    await interaction.deferUpdate();
    const channel = interaction.channel;
    
    if (!channel.name.includes('ticket-')) {
        return interaction.editReply({
            content: '❌ Bu özellik sadece ticket kanallarında kullanılabilir!',
            components: []
        });
    }

    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);
    const isSupportStaff = config.supportRoleId ? member.roles.cache.has(config.supportRoleId) : false;
    const isTicketOwner = channel.permissionOverwrites.cache.has(interaction.user.id);

    // Ticket verilerini al
    const ticketsDb = ticketUtil.getTicketsDb();
    const ticketData = ticketsDb.find(t => t.channelId === channel.id || t.id === channel.id);

    const channelEmbed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle(`🎫 ${channel.name} Yönetimi`)
        .setDescription('Bu ticket için yapmak istediğiniz işlemi seçin.')
        .addFields(
            { name: '📝 Ticket Bilgileri', value: `Kanal: ${channel}\nKonu: ${ticketData?.subject || 'Genel'}\nOluşturulma: ${new Date(ticketData?.createdAt || channel.createdTimestamp).toLocaleDateString('tr-TR')}` }
        );

    const actionButtons = [];

    // Birinci sıra - Temel işlemler
    const firstRow = new ActionRowBuilder();
    
    if (isTicketOwner || isSupportStaff || isAdmin) {
        firstRow.addComponents(
            new ButtonBuilder()
                .setCustomId(`close_ticket_${channel.id}`)
                .setLabel('Ticket\'ı Kapat')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒')
        );
    }

    if (isSupportStaff || isAdmin) {
        firstRow.addComponents(
            new ButtonBuilder()
                .setCustomId(`add_user_${channel.id}`)
                .setLabel('Kullanıcı Ekle')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('➕'),
            new ButtonBuilder()
                .setCustomId(`remove_user_${channel.id}`)
                .setLabel('Kullanıcı Çıkar')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('➖')
        );
    }

    if (firstRow.components.length > 0) {
        actionButtons.push(firstRow);
    }

    // İkinci sıra - Gelişmiş işlemler (sadece yetkili personel)
    if (isSupportStaff || isAdmin) {
        const secondRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`priority_${channel.id}`)
                .setLabel('Öncelik Ayarla')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('⚡'),
            new ButtonBuilder()
                .setCustomId(`claim_${channel.id}`)
                .setLabel('Ticket\'ı Üstlen')
                .setStyle(ButtonStyle.Success)
                .setEmoji('👋'),
            new ButtonBuilder()
                .setCustomId(`transcript_${channel.id}`)
                .setLabel('Sohbet Geçmişi')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('📄')
        );
        actionButtons.push(secondRow);
    }

    // Üçüncü sıra - Geri dön
    const thirdRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('back_to_main')
            .setLabel('Ana Menüye Dön')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('🔙')
    );
    actionButtons.push(thirdRow);

    await interaction.editReply({
        embeds: [channelEmbed],
        components: actionButtons
    });
}

// İstatistikler
async function handleStats(interaction) {
    await interaction.deferUpdate();
    
    try {
        const guild = interaction.guild;
        const ticketsDb = ticketUtil.getTicketsDb();
        
        // Aktif ticket sayısı
        const activeTickets = guild.channels.cache.filter(ch => 
            ch.name.includes('ticket-') && ch.type === ChannelType.GuildText
        );
        
        // Toplam ticket sayısı
        const totalTickets = ticketsDb.length;
        
        // Bu ayki ticketlar
        const thisMonth = new Date();
        thisMonth.setDate(1);
        thisMonth.setHours(0, 0, 0, 0);
        
        const monthlyTickets = ticketsDb.filter(t => 
            t.createdAt && t.createdAt >= thisMonth.getTime()
        );
        
        // Bu haftaki ticketlar
        const thisWeek = new Date();
        thisWeek.setDate(thisWeek.getDate() - thisWeek.getDay());
        thisWeek.setHours(0, 0, 0, 0);
        
        const weeklyTickets = ticketsDb.filter(t => 
            t.createdAt && t.createdAt >= thisWeek.getTime()
        );
        
        // Kategori bazlı istatistikler
        const categories = {};
        ticketsDb.forEach(ticket => {
            const cat = ticket.subject || 'Diğer';
            categories[cat] = (categories[cat] || 0) + 1;
        });
        
        const topCategories = Object.entries(categories)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([cat, count]) => `${cat}: ${count}`)
            .join('\n') || 'Veri yok';

        const statsEmbed = new EmbedBuilder()
            .setColor(0x3498DB)
            .setTitle('📊 Ticket İstatistikleri')
            .addFields(
                { name: '🎫 Aktif Ticketlar', value: `${activeTickets.size}`, inline: true },
                { name: '📈 Toplam Ticket', value: `${totalTickets}`, inline: true },
                { name: '📅 Bu Ay', value: `${monthlyTickets.length}`, inline: true },
                { name: '📆 Bu Hafta', value: `${weeklyTickets.length}`, inline: true },
                { name: '⏱️ Ortalama Yanıt Süresi', value: 'Hesaplanıyor...', inline: true },
                { name: '✅ Çözümlenme Oranı', value: 'Hesaplanıyor...', inline: true },
                { name: '🏷️ En Çok Kullanılan Kategoriler', value: topCategories, inline: false }
            )
            .setFooter({ text: 'Ticket sistem istatistikleri' })
            .setTimestamp();

        await interaction.editReply({
            embeds: [statsEmbed],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('back_to_main')
                        .setLabel('Ana Menüye Dön')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🔙')
                )
            ]
        });
        
    } catch (error) {
        console.error('İstatistik gösterme hatası:', error);
        await interaction.editReply({
            content: '❌ İstatistikler yüklenirken bir hata oluştu.',
            components: []
        });
    }
}

// Admin araçları
async function handleAdminTools(interaction) {
    await interaction.deferUpdate();
    
    const adminEmbed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('🛠️ Adlyuexstrator Araçları')
        .setDescription('⚠️ Bu araçlar dikkatli kullanılmalıdır!')
        .addFields(
            { name: '🗑️ Toplu İşlemler', value: 'Çoklu ticket kapatma ve temizleme' },
            { name: '🔧 Sistem Bakımı', value: 'Veritabanı temizliği ve onarımı' },
            { name: '📊 Detaylı Raporlar', value: 'Kapsamlı analiz ve raporlama' }
        );

    const adminButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('admin_close_all')
            .setLabel('Tüm Ticketları Kapat')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🗑️'),
        new ButtonBuilder()
            .setCustomId('admin_cleanup')
            .setLabel('Sistem Temizliği')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🧹'),
        new ButtonBuilder()
            .setCustomId('admin_backup')
            .setLabel('Veri Yedekleme')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('💾')
    );

    const backButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('back_to_main')
            .setLabel('Ana Menüye Dön')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('🔙')
    );

    await interaction.editReply({
        embeds: [adminEmbed],
        components: [adminButtons, backButton]
    });
}

// Ticket ayarlarını yönet
async function handleSettings(interaction, config) {
    await interaction.deferReply();

    // Ana ayarlar embed'i
    const settingsEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle('🛠️ Ticket Sistemi Ayarları')
        .setDescription('Aşağıdaki butonları kullanarak ticket sistemi ayarlarını düzenleyebilirsiniz.')
        .addFields(
            { name: '📊 Durum', value: config.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
            { name: '📁 Kategori', value: config.categoryId ? `<#${config.categoryId}>` : 'Ayarlanmamış', inline: true },
            { name: '👮 Yetkili Rolü', value: config.supportRoleId ? `<@&${config.supportRoleId}>` : 'Ayarlanmamış', inline: true },
            { name: '⏱️ Cooldown', value: `${config.cooldownMinutes || 0} dakika`, inline: true },
            { name: '🔒 Otomatik Kapanma', value: config.autoCloseHours ? `${config.autoCloseHours} saat` : 'Devre dışı', inline: true }
        )
        .setFooter({ text: 'Ticket sistemi yönetimi' })
        .setTimestamp();
        
    // Ana ayar butonları
    const settingsButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('ticket_toggle_system')
            .setLabel(config.enabled ? 'Sistemi Kapat' : 'Sistemi Aç')
            .setStyle(config.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
            .setEmoji(config.enabled ? '🔴' : '🟢'),
        new ButtonBuilder()
            .setCustomId('ticket_set_category')
            .setLabel('Kategori Ayarla')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('📁'),
        new ButtonBuilder()
            .setCustomId('ticket_set_role')
            .setLabel('Yetkili Rolü')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('👮')
    );
    
    const secondRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('ticket_autoclose')
            .setLabel('Otomatik Kapanma')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('⏱️'),
        new ButtonBuilder()
            .setCustomId('ticket_create_panel')
            .setLabel('Panel Oluştur')
            .setStyle(ButtonStyle.Success)
            .setEmoji('📋')
    );
    
    const response = await interaction.editReply({
        embeds: [settingsEmbed],
        components: [settingsButtons, secondRow]
    });
    
    // Buton tıklamaları için collector
    const collector = response.createMessageComponentCollector({ 
        time: 300000 // 5 dakika
    });
    
    collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
            return i.reply({ content: 'Bu butonları sadece komutu kullanan kişi kullanabilir.', ephemeral: true });
        }
        
        // Güncel config'i yeniden yükle
        const updatedConfig = ticketUtil.getConfig();
        
        switch (i.customId) {
            case 'ticket_toggle_system':
                // Sistemi aç/kapat
                updatedConfig.enabled = !updatedConfig.enabled;
                ticketUtil.updateConfig(updatedConfig);
                
                await i.update({
                    embeds: [
                        settingsEmbed
                            .setFields(
                                { name: '📊 Durum', value: updatedConfig.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
                                { name: '📁 Kategori', value: updatedConfig.categoryId ? `<#${updatedConfig.categoryId}>` : 'Ayarlanmamış', inline: true },
                                { name: '👮 Yetkili Rolü', value: updatedConfig.supportRoleId ? `<@&${updatedConfig.supportRoleId}>` : 'Ayarlanmamış', inline: true },
                                { name: '⏱️ Cooldown', value: `${updatedConfig.cooldownMinutes || 0} dakika`, inline: true },
                                { name: '🔒 Otomatik Kapanma', value: updatedConfig.autoCloseHours ? `${updatedConfig.autoCloseHours} saat` : 'Devre dışı', inline: true }
                            )
                    ],
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('ticket_toggle_system')
                                .setLabel(updatedConfig.enabled ? 'Sistemi Kapat' : 'Sistemi Aç')
                                .setStyle(updatedConfig.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
                                .setEmoji(updatedConfig.enabled ? '🔴' : '🟢'),
                            settingsButtons.components[1],
                            settingsButtons.components[2]
                        ),
                        secondRow
                    ]
                });
                break;
                
            case 'ticket_set_category':
                // Kategori seçim menüsünü göster
                const allCategories = interaction.guild.channels.cache
                    .filter(c => c.type === ChannelType.GuildCategory)
                    .map(c => ({
                        label: c.name.substring(0, 25),
                        value: c.id,
                        description: `ID: ${c.id}`
                    }));
                
                if (allCategories.length === 0) {
                    return i.reply({ content: 'Sunucuda hiç kategori bulunamadı!', ephemeral: true });
                }
                
                // Discord.js maksimum 25 option destekler
                const categories = allCategories.slice(0, 25);
                
                const categoryMenu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('ticket_system_category_select')
                        .setPlaceholder('Ticket kategorisini seçin...')
                        .addOptions(categories)
                );
                
                await i.reply({
                    content: 'Ticket kanallarının oluşturulacağı kategoriyi seçin:',
                    components: [categoryMenu],
                    ephemeral: true
                });
                
                // Kategori seçimi için collector
                const categoryCollector = i.channel.createMessageComponentCollector({
                    filter: j => j.customId === 'ticket_system_category_select' && j.user.id === interaction.user.id,
                    time: 60000,
                    max: 1
                });
                
                categoryCollector.on('collect', async (j) => {
                    const selectedCategoryId = j.values[0];
                    updatedConfig.categoryId = selectedCategoryId;
                    ticketUtil.updateConfig(updatedConfig);
                    
                    await j.update({
                        content: `✅ Ticket kategorisi <#${selectedCategoryId}> olarak ayarlandı!`,
                        components: []
                    });
                    
                    // Ana menüyü güncelle
                    await response.edit({
                        embeds: [
                            settingsEmbed.setFields(
                                { name: '📊 Durum', value: updatedConfig.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
                                { name: '📁 Kategori', value: `<#${selectedCategoryId}>`, inline: true },
                                { name: '👮 Yetkili Rolü', value: updatedConfig.supportRoleId ? `<@&${updatedConfig.supportRoleId}>` : 'Ayarlanmamış', inline: true },
                                { name: '⏱️ Cooldown', value: `${updatedConfig.cooldownMinutes || 0} dakika`, inline: true },
                                { name: '🔒 Otomatik Kapanma', value: updatedConfig.autoCloseHours ? `${updatedConfig.autoCloseHours} saat` : 'Devre dışı', inline: true }
                            )
                        ]
                    });
                });
                break;
                
            case 'ticket_set_role':
                // Rol seçim menüsünü göster
                const roles = interaction.guild.roles.cache
                    .filter(r => !r.managed && r.id !== interaction.guild.id)
                    .map(r => ({
                        label: r.name.substring(0, 25),
                        value: r.id,
                        description: `${r.members.size} üye`
                    }));
                
                if (roles.length === 0) {
                    return i.reply({ content: 'Sunucuda hiç rol bulunamadı!', ephemeral: true });
                }
                
                const roleMenu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('ticket_role_select')
                        .setPlaceholder('Destek ekibi rolünü seçin...')
                        .addOptions(roles.slice(0, 25)) // Discord maksimum 25 option destekler
                );
                
                await i.reply({
                    content: 'Destek ekibi rolünü seçin:',
                    components: [roleMenu],
                    ephemeral: true
                });
                
                // Rol seçimi için collector
                const roleCollector = i.channel.createMessageComponentCollector({
                    filter: j => j.customId === 'ticket_role_select' && j.user.id === interaction.user.id,
                    time: 60000,
                    max: 1
                });
                
                roleCollector.on('collect', async (j) => {
                    const selectedRoleId = j.values[0];
                    updatedConfig.supportRoleId = selectedRoleId;
                    ticketUtil.updateConfig(updatedConfig);
                    
                    await j.update({
                        content: `✅ Destek ekibi rolü <@&${selectedRoleId}> olarak ayarlandı!`,
                        components: []
                    });
                    
                    // Ana menüyü güncelle
                    await response.edit({
                        embeds: [
                            settingsEmbed.setFields(
                                { name: '📊 Durum', value: updatedConfig.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
                                { name: '📁 Kategori', value: updatedConfig.categoryId ? `<#${updatedConfig.categoryId}>` : 'Ayarlanmamış', inline: true },
                                { name: '👮 Yetkili Rolü', value: `<@&${selectedRoleId}>`, inline: true },
                                { name: '⏱️ Cooldown', value: `${updatedConfig.cooldownMinutes || 0} dakika`, inline: true },
                                { name: '🔒 Otomatik Kapanma', value: updatedConfig.autoCloseHours ? `${updatedConfig.autoCloseHours} saat` : 'Devre dışı', inline: true }
                            )
                        ]
                    });
                });
                break;
                
            case 'ticket_autoclose':
                // Otomatik kapanma ayarları
                const autoCloseOptions = [
                    { label: 'Devre Dışı', value: '0', description: 'Otomatik kapanma kapalı' },
                    { label: '24 Saat', value: '24', description: '1 gün sonra' },
                    { label: '48 Saat', value: '48', description: '2 gün sonra' },
                    { label: '72 Saat', value: '72', description: '3 gün sonra' },
                    { label: '7 Gün', value: '168', description: '1 hafta sonra' }
                ];
                
                const autoCloseMenu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('ticket_autoclose_select')
                        .setPlaceholder('Otomatik kapanma süresini seçin...')
                        .addOptions(autoCloseOptions)
                );
                
                await i.reply({
                    content: 'İnaktif ticket\'lar için otomatik kapanma süresini seçin:',
                    components: [autoCloseMenu],
                    ephemeral: true
                });
                
                // Süre seçimi için collector
                const autoCloseCollector = i.channel.createMessageComponentCollector({
                    filter: j => j.customId === 'ticket_autoclose_select' && j.user.id === interaction.user.id,
                    time: 60000,
                    max: 1
                });
                
                autoCloseCollector.on('collect', async (j) => {
                    const hours = parseInt(j.values[0]);
                    updatedConfig.autoCloseHours = hours;
                    ticketUtil.updateConfig(updatedConfig);
                    
                    await j.update({
                        content: hours > 0 
                            ? `✅ Ticket otomatik kapanma süresi ${hours} saat olarak ayarlandı!` 
                            : '✅ Ticket otomatik kapanma devre dışı bırakıldı!',
                        components: []
                    });
                    
                    // Ana menüyü güncelle
                    await response.edit({
                        embeds: [
                            settingsEmbed.setFields(
                                { name: '📊 Durum', value: updatedConfig.enabled ? '🟢 Aktif' : '🔴 Devre dışı', inline: true },
                                { name: '📁 Kategori', value: updatedConfig.categoryId ? `<#${updatedConfig.categoryId}>` : 'Ayarlanmamış', inline: true },
                                { name: '👮 Yetkili Rolü', value: updatedConfig.supportRoleId ? `<@&${updatedConfig.supportRoleId}>` : 'Ayarlanmamış', inline: true },
                                { name: '⏱️ Cooldown', value: `${updatedConfig.cooldownMinutes || 0} dakika`, inline: true },
                                { name: '🔒 Otomatik Kapanma', value: hours > 0 ? `${hours} saat` : 'Devre dışı', inline: true }
                            )
                        ]
                    });
                });
                break;
                
            case 'ticket_create_panel':
                // Ticket paneli oluştur - Tüm kanalları göster
                
                const allChannels = interaction.guild.channels.cache
                    .filter(c => c.type === ChannelType.GuildText)
                    .map(c => ({
                        label: c.name.substring(0, 25),
                        value: c.id,
                        description: `#${c.name}`.substring(0, 50)
                    }));

                if (allChannels.length === 0) {
                    return await i.reply({ content: '❌ Sunucuda metin kanalı bulunamadı!', components: [], ephemeral: true }).catch(() => {});
                }

                // Discord maksimum 25 seçenek destekler, daha fazla varsa split edelim
                const channelChunks = [];
                for (let j = 0; j < allChannels.length; j += 25) {
                    channelChunks.push(allChannels.slice(j, j + 25));
                }

                const channelMenus = channelChunks.map((chunk, index) => {
                    return new ActionRowBuilder().addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId(`ticket_panel_channel_${index}`)
                            .setPlaceholder(`Kanal seçin... (${index + 1}/${channelChunks.length})`)
                            .addOptions(chunk)
                    );
                });

                const panelSelectEmbed = new EmbedBuilder()
                    .setColor(0x3498DB)
                    .setTitle('📁 Kanal Seçin')
                    .setDescription(`Ticket panelini oluşturmak istediğiniz kanalı seçin (${allChannels.length} kanal mevcut)`);

                const editedResponse = await i.reply({
                    embeds: [panelSelectEmbed],
                    content: '',
                    components: channelMenus,
                    ephemeral: true
                }).catch(() => {});

                // Kanal seçimi için collector - channel'dan oluştur
                const panelChannelCollector = i.channel.createMessageComponentCollector({
                    filter: j => j.customId.startsWith('ticket_panel_channel_') && j.user.id === interaction.user.id,
                    time: 30000, // 30 saniye (interaction timeout'dan kısa)
                    max: 1
                });

                panelChannelCollector.on('collect', async (j) => {
                    try {
                        // DeferUpdate'i hemen yap, hata varsa catch et
                        await j.deferUpdate().catch(() => {
                            console.warn('[Panel] Interaction zaten expire oldu');
                        });
                    } catch (err) {
                        console.warn('[Panel] Defer error:', err.message);
                    }
                    
                    const selectedChannelId = j.values[0];
                    const targetChannel = interaction.guild.channels.cache.get(selectedChannelId);

                    if (!targetChannel) {
                        try {
                            return j.editReply({ content: '❌ Kanal bulunamadı!', components: [] }).catch(() => {});
                        } catch {
                            return;
                        }
                    }

                    // Ticket panelini oluştur (select menülü) - gelişmiş görünüm
                    const cfg = ticketUtil.getConfig() || {};
                    const guildIcon = interaction.guild.iconURL({ dynamic: true, size: 256 }) || undefined;
                    const panelEmbed = new EmbedBuilder()
                        .setColor(0x1E88E5)
                        .setAuthor({ name: `${interaction.guild.name} • Destek Merkezi`, iconURL: guildIcon })
                        .setTitle('🎫 Ticket Aç')
                        .setDescription([
                            'Aşağıdaki menüden talep türünü seçerek ticket açabilirsiniz.',
                            '',
                            '• Seçimden sonra sizden kısa bir açıklama istenir',
                            '• Destek ekibi en kısa sürede dönüş yapacaktır'
                        ].join('\n'))
                        .addFields(
                            { name: 'ℹ️ Not', value: 'Kurallara uymayan talepler reddedilebilir.', inline: false }
                        )
                        .setImage('https://cdn.discordapp.com/attachments/1432060322163851265/1432741855455350954/lyuex.png?ex=69022855&is=6900d6d5&hm=3b88eaafd8da882d4a98236b3217388e52df5151ff288f29b90776fd51c9b660&')
                        .setThumbnail(guildIcon)
                        .setFooter({ text: `${interaction.guild.name} • Ticket Sistemi`, iconURL: guildIcon })
                        .setTimestamp();

                    // Kategori seçenekleri
                    const categories = ticketUtil.getCategories();
                    let options;
                    if (categories && categories.length > 0) {
                        options = categories.slice(0, 25).map(cat => {
                            // Emoji ve isim için güvenli label oluştur
                            const emoji = cat.emoji || '🎫';
                            const maxNameLength = 22; // Emoji + boşluk için yer bırak
                            const truncatedName = cat.name.length > maxNameLength ? 
                                cat.name.substring(0, maxNameLength - 1) + '…' : cat.name;
                            const label = `${emoji} ${truncatedName}`;
                            
                            return {
                                label: label.substring(0, 25), // Discord.js limiti
                                value: cat.id,
                                description: cat.description ? cat.description.substring(0, 100) : `Kategori: ${cat.name}`
                            };
                        });
                    } else {
                        options = [
                            { label: '🎮 Oyun İçi Destek', value: 'oyun_ici_destek', description: 'Oyun içi problemler ve yardım' },
                            { label: '🖥️ Oyun Dışı Destek', value: 'oyun_disi_destek', description: 'Launcher, Discord vb.' },
                            { label: '🐛 Hata Bildirimi', value: 'hata_raporla', description: 'Hata ve bug raporu' },

                            { label: '🔐 Hesap Destek', value: 'hesap_destek', description: 'Şifre, giriş, hesap sorunları' }
                        ];
                    }

                    const selectRow = new ActionRowBuilder().addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('ticket_panel_category_select')
                            .setPlaceholder('Kategori seçin...')
                            .addOptions(options)
                    );

                    try {
                        await targetChannel.send({ embeds: [panelEmbed], components: [selectRow] });
                        
                        // EditReply'i hata kontrolü ile yap
                        await j.editReply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(0x4CAF50)
                                    .setTitle('✅ Panel Oluşturuldu')
                                    .setDescription(`Ticket paneli ${targetChannel} kanalına başarıyla oluşturuldu!`)
                            ],
                            components: []
                        }).catch(() => {
                            console.warn('[Panel] EditReply failed - interaction likely expired');
                        });
                    } catch (error) {
                        console.error('Panel oluşturma hatası:', error);
                        try {
                            await j.editReply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor(0xFF6B6B)
                                        .setTitle('❌ Hata')
                                        .setDescription(`Panel oluşturulurken hata oluştu: ${error.message}`)
                                ],
                                components: []
                            }).catch(() => {});
                        } catch {
                            // Interaction expired, ignore
                        }
                    }
                });
                break;
        }
    });
}

// Ticket listesini göster
async function handleList(interaction) {
    await interaction.deferReply();
    const { guild } = interaction;
    
    // Aktif ticket'ları bul
    const activeTickets = guild.channels.cache.filter(ch => 
        ch.name.includes('ticket-') && 
        ch.type === ChannelType.GuildText
    );
    
    if (activeTickets.size === 0) {
        return interaction.editReply({
            embeds: [
                new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('📋 Ticket Listesi')
                    .setDescription('Aktif ticket bulunamadı.')
            ]
        });
    }
    
    // Ticketları verilere göre sırala
    const ticketsDb = ticketUtil.getTicketsDb();
    const ticketInfo = [];
    
    activeTickets.forEach(channel => {
        const ticketData = ticketsDb.find(t => t.channelId === channel.id || t.id === channel.id);
        let owner = 'Bilinmiyor';
        
        if (ticketData?.userId) {
            try {
                const user = guild.members.cache.get(ticketData.userId);
                owner = user ? user.user.tag : `<@${ticketData.userId}>`;
            } catch {
                owner = `<@${ticketData.userId}>`;
            }
        }
        
        const createdAt = ticketData?.createdAt 
            ? new Date(ticketData.createdAt).toLocaleDateString('tr-TR')
            : channel.createdAt.toLocaleDateString('tr-TR');
        
        ticketInfo.push({
            id: channel.id,
            name: channel.name,
            owner,
            createdAt,
            subject: ticketData?.subject || 'Genel',
            age: Math.floor((Date.now() - (ticketData?.createdAt || channel.createdTimestamp)) / (1000 * 60 * 60 * 24)) // Gün olarak
        });
    });
    
    // En eski ticketlar önce gösterilsin
    ticketInfo.sort((a, b) => a.age - b.age);
    
    // Listede göster
    const ticketsEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle(`📋 Aktif Ticket Listesi (${activeTickets.size})`)
        .setDescription(
            ticketInfo.map(ticket => 
                `🎫 <#${ticket.id}> - ${ticket.subject} | ${ticket.owner} | ${ticket.createdAt} (${ticket.age} gün)`
            ).join('\n')
        )
        .setFooter({ text: 'Detaylı işlemler için bir ticket seçin' })
        .setTimestamp();
        
    const selectMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('ticket_select_manage')
            .setPlaceholder('Yönetmek için ticket seçin...')
            .addOptions(
                ticketInfo.map(ticket => ({
                    label: `${ticket.name} (${ticket.age} gün)`,
                    value: ticket.id,
                    description: `${ticket.subject} | ${ticket.owner.substring(0, 25)}`
                }))
            )
    );
    
    const response = await interaction.editReply({
        embeds: [ticketsEmbed],
        components: [selectMenu]
    });
    
    // Ticket yönetim seçimi için collector
    const collector = response.createMessageComponentCollector({ 
        time: 300000 // 5 dakika
    });
    
    collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
            return i.reply({ content: 'Bu menüyü sadece komutu kullanan kişi kullanabilir.', ephemeral: true });
        }
        
        if (i.customId === 'ticket_select_manage') {
            const ticketChannelId = i.values[0];
            const ticketChannel = guild.channels.cache.get(ticketChannelId);
            
            if (!ticketChannel) {
                return i.reply({ content: '❌ Kanal bulunamadı! Ticket silinmiş olabilir.', ephemeral: true });
            }
            
            // Ticket yönetim seçenekleri
            const manageEmbed = new EmbedBuilder()
                .setColor(0x3498DB)
                .setTitle(`🎫 ${ticketChannel.name} Yönetimi`)
                .setDescription(`${ticketChannel} kanalı için yapmak istediğiniz işlemi seçin.`)
                .addFields(
                    { name: '📝 Bilgiler', value: `Kanal: ${ticketChannel}\nOluşturulma: ${new Date(ticketChannel.createdTimestamp).toLocaleDateString('tr-TR')}` }
                );
                
            const manageButtons = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`view_${ticketChannelId}`)
                    .setLabel('Görüntüle')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('👁️'),
                new ButtonBuilder()
                    .setCustomId(`close_${ticketChannelId}`)
                    .setLabel('Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId(`back_to_list`)
                    .setLabel('Listeye Dön')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📋')
            );
            
            await i.update({
                embeds: [manageEmbed],
                components: [manageButtons]
            });
            
            // Buton tıklamaları için collector
            const buttonCollector = response.createMessageComponentCollector({ 
                time: 60000 // 1 dakika
            });
            
            buttonCollector.on('collect', async (j) => {
                if (j.user.id !== interaction.user.id) {
                    return j.reply({ content: 'Bu butonları sadece komutu kullanan kişi kullanabilir.', ephemeral: true });
                }
                
                if (j.customId === `view_${ticketChannelId}`) {
                    await j.reply({ content: `✅ ${ticketChannel} kanalını görüntüleyebilirsiniz.` });
                    
                    // Kanalı görüntüle butonuna tıklayınca kanalı görüntüle yetkisi ver
                    try {
                        await ticketChannel.permissionOverwrites.edit(j.user.id, { ViewChannel: true });
                    } catch (error) {
                        console.error('Kanal görüntüleme yetkisi verme hatası:', error);
                        await j.followUp({ content: '❌ Kanal görüntüleme yetkisi verilirken bir hata oluştu.', ephemeral: true });
                    }
                }
                else if (j.customId === `close_${ticketChannelId}`) {
                    await j.reply({ content: `🔒 ${ticketChannel} kanalı kapatılıyor...` });
                    
                    // Kanalı kapat
                    try {
                        setTimeout(() => {
                            ticketChannel.delete().catch(console.error);
                        }, 3000);
                    } catch (error) {
                        console.error('Ticket kapatma hatası:', error);
                        await j.followUp({ content: '❌ Ticket kapatılırken bir hata oluştu.', ephemeral: true });
                    }
                }
                else if (j.customId === 'back_to_list') {
                    // Listeye dön
                    await j.update({
                        embeds: [ticketsEmbed],
                        components: [selectMenu]
                    });
                }
            });
        }
    });
}

// Tüm ticket'ları kapat
async function handleCloseAll(interaction) {
    await interaction.deferReply();
    const { guild } = interaction;
    const reason = interaction.options.getString('sebep') || 'Yönetici tarafından toplu kapatma';
    
    // Aktif ticket'ları bul
    const activeTickets = guild.channels.cache.filter(ch => 
        ch.name.includes('ticket-') && 
        ch.type === ChannelType.GuildText
    );
    
    if (activeTickets.size === 0) {
        return interaction.editReply({
            embeds: [
                new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('❌ Ticket Bulunamadı')
                    .setDescription('Kapatılacak aktif ticket bulunamadı.')
            ]
        });
    }
    
    // Onay iste
    const confirmEmbed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('⚠️ Dikkat: Toplu Ticket Kapatma')
        .setDescription(`**${activeTickets.size} adet** aktif ticket'ı kapatmak üzeresiniz. Bu işlem geri alınamaz!`)
        .addFields(
            { name: '📝 Sebep', value: reason },
            { name: '⚠️ Uyarı', value: 'Tüm ticket kanalları silinecek ve ilgili veriler güncellenecektir.' }
        )
        .setFooter({ text: 'Onaylamak için aşağıdaki butona tıklayın' });
        
    const confirmButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('confirm_close_all')
            .setLabel('Onayla ve Tümünü Kapat')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('⚠️'),
        new ButtonBuilder()
            .setCustomId('cancel_close_all')
            .setLabel('İptal')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('✖️')
    );
    
    const response = await interaction.editReply({
        embeds: [confirmEmbed],
        components: [confirmButtons]
    });
    
    // Onay butonları için collector
    const collector = response.createMessageComponentCollector({ 
        time: 30000 // 30 saniye
    });
    
    collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
            return i.reply({ content: 'Bu butonları sadece komutu kullanan kişi kullanabilir.', ephemeral: true });
        }
        
        if (i.customId === 'confirm_close_all') {
            // Onaylandı, tüm ticketları kapat
            await i.update({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xF39C12)
                        .setTitle('🔄 İşleniyor')
                        .setDescription(`${activeTickets.size} adet ticket kapatılıyor...`)
                ],
                components: []
            });
            
            // Tüm ticket kanallarını sil
            let closedCount = 0;
            const errors = [];
            
            for (const [_, channel] of activeTickets) {
                try {
                    // İlgili ticket verisini güncelle
                    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
                    if (ticketData) {
                        ticketData.status = 'closed';
                        ticketData.closedAt = Date.now();
                        ticketData.closedReason = reason;
                        ticketUtil.updateTicket(ticketData.id, ticketData);
                    }
                    
                    // Kanalı sil
                    await channel.delete(`Toplu kapama: ${reason}`);
                    closedCount++;
                } catch (error) {
                    console.error(`Ticket kapatma hatası (${channel.id}):`, error);
                    errors.push(channel.name);
                }
            }
            
            // Sonuç bilgisini göster
            await interaction.followUp({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0x4CAF50)
                        .setTitle('✅ İşlem Tamamlandı')
                        .setDescription(`${closedCount} adet ticket başarıyla kapatıldı.`)
                        .addFields(
                            errors.length > 0
                                ? { name: '❌ Hatalar', value: `${errors.length} adet ticket kapatılamadı:\n${errors.join('\n')}` }
                                : { name: '📝 Durum', value: 'Tüm ticketlar başarıyla kapatıldı.' }
                        )
                ]
            });
        }
        else if (i.customId === 'cancel_close_all') {
            // İptal edildi
            await i.update({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0x3498DB)
                        .setTitle('❌ İptal Edildi')
                        .setDescription('Toplu ticket kapatma işlemi iptal edildi.')
                ],
                components: []
            });
        }
    });
    
    collector.on('end', async (_, reason) => {
        if (reason === 'time') {
            // Süre doldu
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0x95A5A6)
                        .setTitle('⏱️ Süre Doldu')
                        .setDescription('İşlem süresi dolduğu için iptal edildi.')
                ],
                components: []
            });
        }
    });
}






