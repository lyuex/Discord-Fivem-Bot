// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, UserSelectMenuBuilder, RoleSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');
const path = require('path');

// Uyarı veritabanı dosyası
const uyariDB = path.join(__dirname, '../../db/uyarilar.json');
// Uyarı yetki veritabanı dosyası
const uyariYetkiDB = path.join(__dirname, '../../db/uyariYetkileri.json');

// Veritabanı dosyasını oluştur
if (!fs.existsSync(uyariDB)) {
    if (!fs.existsSync(path.dirname(uyariDB))) {
        fs.mkdirSync(path.dirname(uyariDB), { recursive: true });
    }
    fs.writeFileSync(uyariDB, JSON.stringify({}));
}

// Veritabanı okuma/yazma fonksiyonları
function getUyariData() {
    try {
        const data = fs.readFileSync(uyariDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveUyariData(data) {
    fs.writeFileSync(uyariDB, JSON.stringify(data, null, 2));
}

// Uyarı yetki veritabanı fonksiyonları
function getUyariYetkiData() {
    try {
        const data = fs.readFileSync(uyariYetkiDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

// Yetki kontrolü fonksiyonu
function checkUyariPermission(member, guildId) {
    // Yönetici kontrolü
    if (member.permissions.has(PermissionFlagsBits.Administrator)) {
        return true;
    }
    
    // Eski yetki sistemi (lyuex.json)
    const yetkiliRoller = lyuex.yetkili.yasaklama;
    const hasOldPermission = (typeof yetkiliRoller === 'string' && member.roles.cache.has(yetkiliRoller)) ||
                           (Array.isArray(yetkiliRoller) && yetkiliRoller.some(roleId => member.roles.cache.has(roleId)));
    
    // Yeni yetki sistemi (uyariYetkileri.json)
    const uyariYetkiData = getUyariYetkiData();
    const hasNewPermission = uyariYetkiData[guildId]?.roller?.some(roleId => member.roles.cache.has(roleId));
    
    return hasOldPermission || hasNewPermission;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uyarı')
        .setDescription('⚠️ Kullanıcıya uyarı ver - Gelişmiş uyarı sistemi')
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    
    async execute(interaction) {
        const guildId = interaction.guild.id;
        
        // Yetki kontrolü
        if (!checkUyariPermission(interaction.member, guildId)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('❌ **YETERSİZ YETKİ**')
                        .setDescription('Bu komutu kullanmak için yeterli yetkiniz yok!')
                        .addFields(
                            { name: '🔑 Gerekli Yetkiler', value: '• Yönetici yetkisi\n• Uyarı yetkili rolü', inline: false },
                            { name: '⚙️ Yetki Ayarlama', value: '`/uyarı-yetki ayarla` komutu ile rolleri ayarlayabilirsiniz.', inline: false }
                        )
                        .setColor(0xF44336)
                        .setTimestamp()
                ]
            });
        }

        // Kullanıcı seçim menüsü oluştur
        const userSelectMenu = new UserSelectMenuBuilder()
            .setCustomId(`uyari_user_select_${interaction.user.id}`)
            .setPlaceholder('👤 Uyarılacak kullanıcıyı seçin...')
            .setMinValues(1)
            .setMaxValues(1);

        const userRow = new ActionRowBuilder().addComponents(userSelectMenu);

        const baslangicEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Uyarı Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('⚠️ **UYARI SİSTEMİ**')
            .setDescription(`
╭─────────────────────────────────╮
│  🎯 **UYARI VERME PANELİ**       │
│  Adım adım uyarı işlemi          │
╰─────────────────────────────────╯

🔹 **ADIM 1:** Kullanıcı seçin
🔹 **ADIM 2:** Rol seçin (opsiyonel)  
🔹 **ADIM 3:** Uyarı detayları girin`)
            .addFields(
                { 
                    name: '� **İŞLEM BİLGİLERİ**', 
                    value: `
**Yetkili:** ${interaction.user.tag}
**İşlem Türü:** Uyarı Verme
**Zaman:** <t:${Math.floor(Date.now() / 1000)}:F>
                    `, 
                    inline: true 
                },
                { 
                    name: 'ℹ️ **HATIRLATMA**', 
                    value: `
🔸 Kullanıcı seçtikten sonra rol seçimi
🔸 Rol seçimi opsiyonel
🔸 Tüm işlemler loglanır
                    `, 
                    inline: true 
                }
            )
            .setColor(0x2196F3)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ 
                text: 'Uyarı Sistemi • Kullanıcı Seçin', 
                iconURL: interaction.user.displayAvatarURL() 
            })
            .setTimestamp();

        await interaction.reply({
            embeds: [baslangicEmbed],
            components: [userRow],
            ephemeral: true
        });
    },
};

// Uyarı log fonksiyonu
async function sendUyariLog(client, logData) {
    try {
        // lyuex.json'dan log kanalını al
        const logChannelId = lyuex.uyari_sistemi?.log_kanal;
        
        if (!logChannelId) {
            console.log('Uyarı log kanalı bulunamadı (lyuex.json)');
            return;
        }

        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) {
            console.log(`Uyarı log kanalı bulunamadı: ${logChannelId}`);
            return;
        }

        // Log embed oluştur
        const logEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${logData.guild.name} • Uyarı Log`, 
                iconURL: logData.guild.iconURL({ dynamic: true }) 
            })
            .setTitle(`⚠️ **UYARI VERİLDİ**`)
            .addFields(
                { name: '👤 **UYARILAN**', value: `<@${logData.hedef.id}>\n\`${logData.hedef.tag}\``, inline: true },
                { name: '👮 **UYARI VEREN**', value: `<@${logData.yetkili.id}>\n\`${logData.yetkili.tag}\``, inline: true },
                { name: '📋 **UYARI SEBEBİ**', value: logData.sebep, inline: true },
                { name: '📊 **UYARI SAYISI**', value: logData.uyariSayisi?.toString() || 'Bilinmiyor', inline: true },
                { name: '📅 **TARİH**', value: `<t:${logData.timestamp}:F>`, inline: true },
                { name: '🆔 **UYARI ID**', value: `\`${logData.uyariId}\``, inline: true }
            )
            .setColor(0xFF5722)
            .setTimestamp()
            .setFooter({ 
                text: `Uyarı Sistemi • ID: ${logData.uyariId}`, 
                iconURL: logData.yetkili.avatar 
            });

        // Eğer rol atandıysa bunu da ekle
        if (logData.atananRol) {
            logEmbed.addFields({
                name: '🎭 **ATANAN ROL**', 
                value: `<@&${logData.atananRol.id}> (\`${logData.atananRol.name}\`)`, 
                inline: false
            });
        }

        // Log kanalına gönder
        await logChannel.send({ embeds: [logEmbed] });
        console.log(`Uyarı logu gönderildi: ${logData.hedef.tag} - ${logData.uyariId}`);

    } catch (error) {
        console.error('Uyarı log gönderme hatası:', error);
    }
}

// Export et
module.exports.sendUyariLog = sendUyariLog;





