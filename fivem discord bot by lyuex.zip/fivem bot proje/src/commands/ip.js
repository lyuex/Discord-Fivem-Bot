// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ip')
    .setDescription('🌐 Sunucu IP bilgilerini görüntüler ve paylaş'),
    
  async execute(interaction) {
    try {
      await interaction.deferReply();

      const member = interaction.member;
      const user = interaction.user;
      const serverInfo = lyuex.server;
      
      // Sunucu bilgileri
      const serverIP = serverInfo.ip || 'IP bilgisi henüz ayarlanmamış';
      const serverName = serverInfo.serverismi || 'Sunucu Adı';
      const cfxLink = serverInfo.cfxlink || '';
      const tsInfo = serverInfo.tsip || 'Sunucumuzda voice-chat aktiftir.';
      
      // Avatar ve sunucu ikonu
      const avatarURL = user.displayAvatarURL({ dynamic: true, size: 256 });
      const guildIcon = interaction.guild.iconURL({ dynamic: true, size: 256 });
      
      // Ana embed
      const embed = new EmbedBuilder()
        .setTitle(`🌐 ${serverName} - Sunucu Bilgileri`)
        .setDescription('```ansi\n\u001b[36m▶ SUNUCU BAĞLANTI BİLGİLERİ\u001b[0m\n```')
        .setColor(0x00D4FF)
        .setThumbnail(guildIcon)
        .setAuthor({ 
          name: `${user.tag} tarafından istendi`,
          iconURL: avatarURL 
        })
        .addFields(
          {
            name: '🎮 FiveM IP Adresi',
            value: `\`\`\`fix\n${serverIP}\`\`\``,
            inline: false
          },
          {
            name: '🔗 CFX.re Linki', 
            value: cfxLink && cfxLink.startsWith('http') ? 
                   `[🚀 Sunucuya Katıl](${cfxLink})` : 
                   '❌ Link ayarlanmamış',
            inline: false
          },
          {
            name: '🎧 Voice Chat',
            value: `\`\`\`${tsInfo}\`\`\``,
            inline: false
          },
          {
            name: '\u200b',
            value: '**� Sunucu Durumu:** 🟢 Aktif - Oyuncular bekleniyor!\n**👥 Discord Üyeleri:** ' + interaction.guild.memberCount + ' üye\n**📅 Kuruluş:** <t:' + Math.floor(interaction.guild.createdTimestamp / 1000) + ':R>',
            inline: false
          },
          {
            name: '🎯 Özellikler',
            value: '• 🔒 Whitelist Sistemi\n• 👑 Aktif Yönetim\n• 🎮 Günlük Etkinlikler\n• 🎭 Profesyonel Roleplay',
            inline: false
          },
          {
            name: '📝 Gereksinimler',
            value: '• FiveM Client\n• Discord Hesabı\n• Mikrofon (Tavsiye)\n• Roleplay Deneyimi',
            inline: false
          }
        )
        .setFooter({ 
          text: `${serverName} • Sunucu Bilgileri`,
          iconURL: guildIcon
        })
        .setTimestamp();

      // Sunucu resmi varsa ekle
      if (serverInfo.aktiftasarim && serverInfo.aktiftasarim.startsWith('http')) {
        embed.setImage(serverInfo.aktiftasarim);
      }

      // Butonlar
      const buttonRow = new ActionRowBuilder();
      
      // CFX linki varsa buton ekle
      if (cfxLink && cfxLink.startsWith('http')) {
        buttonRow.addComponents(
          new ButtonBuilder()
            .setLabel('🚀 Sunucuya Katıl')
            .setURL(cfxLink)
            .setStyle(ButtonStyle.Link)
            .setEmoji('🚀')
        );
      }

      // IP kopyalama butonu
      buttonRow.addComponents(
        new ButtonBuilder()
          .setCustomId('copy_ip')
          .setLabel('📋 IP Kopyala')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('📋')
      );

      // Detay butonu
      buttonRow.addComponents(
        new ButtonBuilder()
          .setCustomId('server_details')
          .setLabel('ℹ️ Detaylar')
          .setStyle(ButtonStyle.Primary)
          .setEmoji('ℹ️')
      );

      const components = buttonRow.components.length > 0 ? [buttonRow] : [];

      await interaction.editReply({
        embeds: [embed],
        components: components
      });

      // Button collector
      const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id,
        time: 300000 // 5 dakika
      });

      collector.on('collect', async (buttonInteraction) => {
        try {
          if (buttonInteraction.customId === 'copy_ip') {
            const copyEmbed = new EmbedBuilder()
              .setTitle('📋 IP Adresi Kopyalandı!')
              .setDescription(`**FiveM IP:** \`${serverIP}\`\n\n**Nasıl Bağlanır:**\n1. FiveM'i açın\n2. F8 tuşuna basarak konsolu açın\n3. \`connect ${serverIP}\` yazın\n4. Enter'a basın`)
              .setColor(0x00FF88)
              .addFields(
                {
                  name: '💡 İpucu',
                  value: 'IP adresini kopyalayıp doğrudan FiveM\'e yapıştırabilirsiniz.',
                  inline: false
                }
              )
              .setFooter({ text: 'IP başarıyla kopyalandı!' })
              .setTimestamp();

            await buttonInteraction.reply({
              embeds: [copyEmbed],
              ephemeral: true
            });

          } else if (buttonInteraction.customId === 'server_details') {
            const detailEmbed = new EmbedBuilder()
              .setTitle(`📊 ${serverName} - Detaylı Sunucu Bilgileri`)
              .setColor(0x5865F2)
              .setThumbnail(guildIcon)
              .addFields(
                {
                  name: '🎮 Oyun Modu',
                  value: 'FiveM Roleplay Sunucusu',
                  inline: true
                },
                {
                  name: '🗺️ Harita',
                  value: 'Los Santos (Özelleştirilmiş)',
                  inline: true
                },
                {
                  name: '🌍 Sunucu Lokasyonu',
                  value: 'Türkiye',
                  inline: true
                },
                {
                  name: '💾 Maksimum Slot',
                  value: 'Dinamik (İhtiyaca göre)',
                  inline: true
                },
                {
                  name: '🔧 Mod Paketi',
                  value: 'Custom Scripts & MLO',
                  inline: true
                },
                {
                  name: '⚡ Uptime',
                  value: '7/24 Aktif',
                  inline: true
                },
                {
                  name: '🏪 Ekonomi Sistemi',
                  value: '• Gerçekçi Ekonomi\n• İş İmkanları\n• Emlak Sistemi\n• Araç Galerisi',
                  inline: true
                },
                {
                  name: '👮‍♂️ Devlet Kurumları',
                  value: '• Polis Departmanı\n• EMS/Hastane\n• Belediye\n• Adliye',
                  inline: true
                },
                {
                  name: '🎭 Roleplay Kuralları',
                  value: '• IC/OOC Ayrımı\n• Metagaming Yasak\n• RDM/VDM Yasak\n• Gerçekçi Roleplay',
                  inline: true
                },
                {
                  name: '📞 Destek',
                  value: 'Herhangi bir sorun için Discord sunucumuzdan ticket açabilirsiniz.',
                  inline: false
                }
              )
              .setFooter({ 
                text: 'Daha fazla bilgi için Discord sunucumuzu ziyaret edin!',
                iconURL: guildIcon
              })
              .setTimestamp();

            await buttonInteraction.reply({
              embeds: [detailEmbed],
              ephemeral: true
            });
          }
        } catch (error) {
          console.error('Button interaction hatası:', error);
          
          await buttonInteraction.reply({
            content: '❌ Bir hata oluştu. Lütfen tekrar deneyin.',
            ephemeral: true
          }).catch(() => {});
        }
      });

      collector.on('end', () => {
        // Butonları deaktif et
        const disabledComponents = buttonRow.components.map(button => {
          if (button.data.style !== ButtonStyle.Link) {
            return ButtonBuilder.from(button.data).setDisabled(true);
          }
          return button;
        });

        if (disabledComponents.length > 0) {
          const disabledRow = new ActionRowBuilder().addComponents(disabledComponents);
          interaction.editReply({
            components: [disabledRow]
          }).catch(() => {});
        }
      });

    } catch (error) {
      console.error('IP komut hatası:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setTitle('❌ Hata Oluştu')
        .setDescription('Sunucu bilgileri alınırken bir hata oluştu.')
        .setColor(0xFF6B6B)
        .addFields(
          {
            name: '🔧 Çözüm Önerileri',
            value: '• Sunucu yöneticisi ile iletişime geçin\n• Bot izinlerini kontrol edin\n• Birkaç dakika sonra tekrar deneyin',
            inline: false
          }
        )
        .setFooter({ text: 'Hata Raporu' })
        .setTimestamp();

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({
          embeds: [errorEmbed]
        }).catch(() => {});
      } else {
        await interaction.reply({
          embeds: [errorEmbed],
          ephemeral: true
        }).catch(() => {});
      }
    }
  },
};





