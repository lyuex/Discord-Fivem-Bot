// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const uyarilarPath = path.join(__dirname, '../../db/uyarilar.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uyarilar')
    .setDescription('📋 Kullanıcının tüm uyarılarını gösterir')
    .addUserOption(option =>
      option.setName('kullanici')
        .setDescription('Uyarıları görüntülenecek kullanıcı')
        .setRequired(true)
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: false });

      const targetUser = interaction.options.getUser('kullanici');
      
      // Uyarı verilerini oku
      let uyariData = {};
      try {
        if (fs.existsSync(uyarilarPath)) {
          const rawData = fs.readFileSync(uyarilarPath, 'utf8');
          uyariData = JSON.parse(rawData);
        }
      } catch (error) {
        console.error('Uyarı dosyası okuma hatası:', error);
      }

      // Kullanıcının uyarılarını al
      const kullaniciUyarilar = uyariData[targetUser.id];

      if (!kullaniciUyarilar || !kullaniciUyarilar.uyarilar || kullaniciUyarilar.uyarilar.length === 0) {
        const bosEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Temiz Kayıt')
          .setDescription(`**${targetUser.tag}** kullanıcısının hiç uyarısı bulunmuyor.`)
          .addFields(
            { name: '👤 Kullanıcı', value: `${targetUser}`, inline: true },
            { name: '📊 Toplam Uyarı', value: '0', inline: true },
            { name: '📅 Durum', value: '✅ Temiz', inline: true }
          )
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
          .setFooter({ 
            text: `${interaction.guild.name} • Uyarı Sistemi`,
            iconURL: interaction.guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        return await interaction.editReply({ embeds: [bosEmbed] });
      }

      const uyarilar = kullaniciUyarilar.uyarilar;
      const toplamUyari = uyarilar.length;

      // Ana embed
      const mainEmbed = new EmbedBuilder()
        .setColor(toplamUyari >= 5 ? 0xFF0000 : toplamUyari >= 3 ? 0xFF9800 : 0xFFEB3B)
        .setTitle('📋 Uyarı Geçmişi')
        .setDescription(`**${targetUser.tag}** kullanıcısının tüm uyarıları:`)
        .addFields(
          { name: '👤 Kullanıcı', value: `${targetUser}\n\`${targetUser.id}\``, inline: true },
          { name: '📊 Toplam Uyarı', value: `**${toplamUyari}** uyarı`, inline: true },
          { name: '⚠️ Durum', value: toplamUyari >= 5 ? '🔴 Kritik' : toplamUyari >= 3 ? '🟡 Riskli' : '🟢 Normal', inline: true }
        )
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
        .setFooter({ 
          text: `${interaction.guild.name} • Uyarı Sistemi • Toplam: ${toplamUyari} uyarı`,
          iconURL: interaction.guild.iconURL({ dynamic: true })
        })
        .setTimestamp();

      // Uyarıları sırala (en yeniden en eskiye)
      const sortedUyarilar = [...uyarilar].sort((a, b) => b.timestamp - a.timestamp);

      // İlk 10 uyarıyı göster
      const displayUyarilar = sortedUyarilar.slice(0, 10);

      displayUyarilar.forEach((uyari, index) => {
        const tarih = new Date(uyari.tarih);
        const tarihStr = `<t:${uyari.timestamp}:D>`;
        const saatStr = `<t:${uyari.timestamp}:T>`;
        
        const uyariText = 
          `**Sebep:** ${uyari.sebep}\n` +
          `**Ceza:** ${uyari.ceza}\n` +
          `**Yetkili:** ${uyari.yetkili.tag}\n` +
          `**Tarih:** ${tarihStr} ${saatStr}\n` +
          `**Rol:** ${uyari.rol?.name || 'Bilinmiyor'}`;

        mainEmbed.addFields({
          name: `${index + 1}. Uyarı - ID: ${uyari.id}`,
          value: uyariText,
          inline: false
        });
      });

      // Eğer 10'dan fazla uyarı varsa uyarı ekle
      if (toplamUyari > 10) {
        mainEmbed.addFields({
          name: '📌 Not',
          value: `*Sadece son 10 uyarı gösteriliyor. Toplam **${toplamUyari}** uyarı var.*`,
          inline: false
        });
      }

      await interaction.editReply({ embeds: [mainEmbed] });

    } catch (error) {
      console.error('Uyarılar komutu hatası:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('❌ Hata!')
        .setDescription('Uyarılar görüntülenirken bir hata oluştu.')
        .addFields({
          name: '🔧 Hata Detayı',
          value: `\`${error.message}\``
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }
};
