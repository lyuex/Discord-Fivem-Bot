// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
const BackupManager = require('../utils/backupManager');
const BackupScheduler = require('../utils/backupScheduler');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('backup')
        .setDescription('Backup yönetim sistemi')
        .setDefaultMemberPermissions(null) // Herkes görebilir ama kullanamaz
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Manuel backup oluştur'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('Mevcut backupları listele'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('status')
                .setDescription('Backup sistemi durumunu göster'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('schedule')
                .setDescription('Backup zamanlamasını ayarla')
                .addStringOption(option =>
                    option.setName('interval')
                        .setDescription('Backup aralığı')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Saatlik', value: 'hourly' },
                            { name: 'Günlük', value: 'daily' },
                            { name: 'Haftalık', value: 'weekly' },
                            { name: 'Aylık', value: 'monthly' }
                        ))
                .addStringOption(option =>
                    option.setName('time')
                        .setDescription('Backup zamanı (HH:MM formatında)')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('toggle')
                .setDescription('Otomatik backup\'ı aç/kapat'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('Backup sil')
                .addStringOption(option =>
                    option.setName('backup_name')
                        .setDescription('Silinecek backup adı')
                        .setRequired(true)
                        .setAutocomplete(true))),

    async execute(interaction) {
        // Autocomplete desteği
        if (interaction.isAutocomplete()) {
            return await this.handleAutocomplete(interaction);
        }

        // Yetki kontrolü - Sadece sunucu sahibi ve bot developer'ı
        const config = require('../../lyuex.json');
        const isOwner = interaction.guild.ownerId === interaction.user.id;
        const isDeveloper = interaction.user.id === '1423320414284943420'; // Bot developer ID
        
        if (!isOwner && !isDeveloper) {
            return await interaction.reply({
                content: '❌ **Bu komutu sadece sunucu sahibi ve bot developer\'ı kullanabilir!**',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();
        
        try {
            switch (subcommand) {
                case 'create':
                    await this.handleCreate(interaction);
                    break;
                case 'list':
                    await this.handleList(interaction);
                    break;
                case 'status':
                    await this.handleStatus(interaction);
                    break;
                case 'schedule':
                    await this.handleSchedule(interaction);
                    break;
                case 'toggle':
                    await this.handleToggle(interaction);
                    break;
                case 'delete':
                    await this.handleDelete(interaction);
                    break;
            }
        } catch (error) {
            console.error('Backup komut hatası:', error);
            
            // Eğer interaction zaten defer edilmişse editReply kullan
            const replyMethod = interaction.deferred ? 'editReply' : 'reply';
            await interaction[replyMethod]({
                content: `❌ Hata oluştu: ${error.message}`,
                ephemeral: !interaction.deferred
            });
        }
    },

    async handleAutocomplete(interaction) {
        const focusedOption = interaction.options.getFocused(true);
        
        if (focusedOption.name === 'backup_name') {
            try {
                const backupManager = new BackupManager(interaction.client);
                const backups = backupManager.listBackups();
                
                console.log(`📋 Autocomplete: ${backups.length} backup bulundu`);
                
                if (backups.length === 0) {
                    await interaction.respond([{
                        name: 'Henüz hiç backup yok. Önce /backup create ile backup oluşturun.',
                        value: 'no_backups'
                    }]);
                    return;
                }
                
                // Backup'ları tarihe göre sırala (en yeni önce)
                const sortedBackups = backups.sort((a, b) => b.created.getTime() - a.created.getTime());
                
                let filtered;
                
                if (focusedOption.value === '') {
                    // Hiç input yoksa en son 10 backup'ı göster
                    filtered = sortedBackups
                        .slice(0, 10)
                        .map(backup => {
                            const timeDiff = Date.now() - backup.created.getTime();
                            const daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
                            const hoursAgo = Math.floor(timeDiff / (1000 * 60 * 60));
                            
                            let timeText;
                            if (daysDiff > 0) {
                                timeText = `${daysDiff} gün önce`;
                            } else if (hoursAgo > 0) {
                                timeText = `${hoursAgo} saat önce`;
                            } else {
                                timeText = 'Az önce';
                            }
                            
                            return {
                                name: `${backup.name.substring(0, 60)} (${timeText} - ${backup.size})`,
                                value: backup.name
                            };
                        });
                } else {
                    // Input varsa filtrele
                    filtered = sortedBackups
                        .filter(backup => 
                            backup.name.toLowerCase().includes(focusedOption.value.toLowerCase()) ||
                            backup.created.toLocaleDateString('tr-TR').includes(focusedOption.value)
                        )
                        .slice(0, 25)
                        .map(backup => ({
                            name: `${backup.name.substring(0, 60)} (${backup.created.toLocaleDateString('tr-TR')})`,
                            value: backup.name
                        }));
                }

                console.log(`📋 Autocomplete: ${filtered.length} seçenek gönderiliyor`);
                await interaction.respond(filtered);
                
            } catch (error) {
                console.error('Autocomplete hatası:', error);
                await interaction.respond([{
                    name: 'Backup listesi yüklenemedi. Hata: ' + error.message.substring(0, 80),
                    value: 'error'
                }]);
            }
        }
    },

    async handleCreate(interaction) {
        await interaction.deferReply();
        
        const backupManager = new BackupManager(interaction.client);
        const result = await backupManager.createBackup(true);
        
        if (result.success) {
            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('✅ Manuel Backup Tamamlandı')
                .setDescription('Backup başarıyla oluşturuldu!')
                .addFields(
                    { name: '📁 Backup Adı', value: result.backupName, inline: true },
                    { name: '📍 Konum', value: result.path, inline: false }
                )
                .setTimestamp();
            
            await interaction.editReply({ embeds: [embed] });
        } else {
            await interaction.editReply({
                content: `❌ Backup oluşturma başarısız: ${result.error}`
            });
        }
    },

    async handleList(interaction) {
        await interaction.deferReply();
        
        const backupManager = new BackupManager(interaction.client);
        const backups = backupManager.listBackups();
        
        if (backups.length === 0) {
            await interaction.editReply({
                content: '📭 Henüz hiç backup bulunmuyor.'
            });
            return;
        }

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('📁 Mevcut Backuplar')
            .setDescription(`Toplam ${backups.length} backup bulundu:\n\n🔄 **Backup geri yüklemek için aşağıdaki menüden seçin:**`)
            .setTimestamp();

        // İlk 10 backup'ı göster
        const displayBackups = backups.slice(0, 10);
        
        for (let i = 0; i < displayBackups.length; i++) {
            const backup = displayBackups[i];
            const dateStr = backup.created.toLocaleString('tr-TR');
            const compressionIcon = backup.isCompressed ? '📦' : '📁';
            
            embed.addFields({
                name: `${compressionIcon} ${backup.name}`,
                value: `**Boyut:** ${backup.size}\n**Tarih:** ${dateStr}`,
                inline: true
            });
        }

        if (backups.length > 10) {
            embed.setFooter({ text: `... ve ${backups.length - 10} backup daha (menüde hepsi görünür)` });
        }

        // Select menu oluştur
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('backup_restore_select')
            .setPlaceholder('🔄 Geri yüklenecek backup\'ı seçin...')
            .setMaxValues(1);

        // Tüm backup'ları select menu'ye ekle (25 limit var)
        const menuBackups = backups.slice(0, 25);
        
        for (const backup of menuBackups) {
            const timeDiff = Date.now() - backup.created.getTime();
            const daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
            const hoursAgo = Math.floor(timeDiff / (1000 * 60 * 60));
            
            let timeText;
            if (daysDiff > 0) {
                timeText = `${daysDiff} gün önce`;
            } else if (hoursAgo > 0) {
                timeText = `${hoursAgo} saat önce`;
            } else {
                timeText = 'Az önce';
            }

            const optionName = backup.name.length > 90 ? backup.name.substring(0, 87) + '...' : backup.name;
            const optionDescription = `${timeText} • ${backup.size}`;

            selectMenu.addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel(optionName)
                    .setDescription(optionDescription)
                    .setValue(backup.name)
                    .setEmoji('📦')
            );
        }

        const row = new ActionRowBuilder()
            .addComponents(selectMenu);

        await interaction.editReply({ 
            embeds: [embed], 
            components: [row] 
        });
    },

    async handleStatus(interaction) {
        await interaction.deferReply();
        
        const backupScheduler = new BackupScheduler(interaction.client);
        const status = backupScheduler.getStatus();
        
        const statusIcon = status.enabled ? '🟢' : '🔴';
        const statusText = status.enabled ? 'Aktif' : 'Devre Dışı';
        const runningIcon = status.isRunning ? '▶️' : '⏸️';
        const runningText = status.isRunning ? 'Çalışıyor' : 'Durdurulmuş';
        
        const embed = new EmbedBuilder()
            .setColor(status.enabled ? '#00ff00' : '#ff0000')
            .setTitle('📊 Backup Sistemi Durumu')
            .addFields(
                { name: '🔧 Durum', value: `${statusIcon} ${statusText}`, inline: true },
                { name: '⚙️ Scheduler', value: `${runningIcon} ${runningText}`, inline: true },
                { name: '⏰ Aralık', value: this.getIntervalText(status.interval), inline: true },
                { name: '🕐 Zaman', value: status.time, inline: true },
                { name: '📦 Sıkıştırma', value: status.compression ? '✅ Aktif' : '❌ Devre Dışı', inline: true },
                { name: '🗃️ Maksimum Backup', value: status.maxBackups.toString(), inline: true }
            )
            .setTimestamp();

        if (status.nextBackup) {
            const nextBackupTimestamp = Math.floor(status.nextBackup.getTime() / 1000);
            embed.addFields({
                name: '⏭️ Sonraki Backup',
                value: `<t:${nextBackupTimestamp}:F>`,
                inline: false
            });
        }

        await interaction.editReply({ embeds: [embed] });
    },

    async handleSchedule(interaction) {
        await interaction.deferReply();
        
        const interval = interaction.options.getString('interval');
        const time = interaction.options.getString('time');
        
        // Zaman formatını kontrol et
        if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
            await interaction.editReply({
                content: '❌ Geçersiz zaman formatı! HH:MM formatında giriniz (örn: 03:00)'
            });
            return;
        }

        // Konfigürasyonu güncelle (Bu örnekte sadece runtime'da değişiyor)
        const backupScheduler = new BackupScheduler(interaction.client);
        backupScheduler.updateSchedule(interval, time);
        
        const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ Backup Zamanlaması Güncellendi')
            .addFields(
                { name: '⏰ Yeni Aralık', value: this.getIntervalText(interval), inline: true },
                { name: '🕐 Yeni Zaman', value: time, inline: true }
            )
            .setDescription('Backup zamanlaması başarıyla güncellendi!')
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async handleToggle(interaction) {
        await interaction.deferReply();
        
        const backupScheduler = global.backupScheduler || new BackupScheduler(interaction.client);
        const newStatus = backupScheduler.toggleScheduler();
        
        const statusIcon = newStatus ? '▶️' : '⏸️';
        const statusText = newStatus ? 'başlatıldı' : 'durduruldu';
        
        await interaction.editReply({
            content: `${statusIcon} Otomatik backup ${statusText}.`
        });
    },

    getIntervalText(interval) {
        const intervals = {
            'hourly': 'Saatlik',
            'daily': 'Günlük',
            'weekly': 'Haftalık',
            'monthly': 'Aylık'
        };
        return intervals[interval] || 'Bilinmiyor';
    },

    async handleRestore(interaction) {
        await interaction.deferReply();

        const backupName = interaction.options.getString('backup_name');
        const confirm = interaction.options.getBoolean('confirm');

        if (!confirm) {
            await interaction.editReply({
                content: '⚠️ Geri yükleme işlemini onaylamadınız. İşlem iptal edildi.\n' +
                        '**DİKKAT:** Backup geri yüklemesi mevcut tüm verileri silecek ve seçilen backup ile değiştirecektir!'
            });
            return;
        }

        const backupManager = new BackupManager(interaction.client);
        
        // Backup'ın varlığını kontrol et
        const backups = backupManager.listBackups();
        const targetBackup = backups.find(backup => backup.name === backupName);
        
        if (!targetBackup) {
            await interaction.editReply({
                content: `❌ **${backupName}** adlı backup bulunamadı!\n\n` +
                        '📋 Mevcut backup\'ları görmek için `/backup list` komutunu kullanın.'
            });
            return;
        }

        // Güvenlik uyarısı embed'i
        const warningEmbed = new EmbedBuilder()
            .setColor(0xFF6B00)
            .setTitle('⚠️ Backup Geri Yükleme Başlatılıyor')
            .setDescription('**DİKKAT:** Bu işlem geri alınamaz!')
            .addFields(
                { name: '📦 Geri Yüklenecek Backup', value: `\`${backupName}\``, inline: true },
                { name: '📅 Backup Tarihi', value: targetBackup.created.toLocaleString('tr-TR'), inline: true },
                { name: '💾 Backup Boyutu', value: targetBackup.size, inline: true },
                { name: '⚠️ Uyarı', value: 'Mevcut tüm veriler silinecek ve backup ile değiştirilecek!', inline: false }
            )
            .setTimestamp();

        await interaction.editReply({ embeds: [warningEmbed] });

        try {
            // Backup geri yükleme işlemini başlat
            const result = await backupManager.restoreBackup(backupName);
            
            const successEmbed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('✅ Backup Başarıyla Geri Yüklendi')
                .addFields(
                    { name: '📦 Geri Yüklenen Backup', value: `\`${backupName}\``, inline: true },
                    { name: '📊 Geri Yüklenen Dosyalar', value: `${result.restoredFiles} dosya`, inline: true },
                    { name: '⏱️ İşlem Süresi', value: `${result.duration}ms`, inline: true }
                )
                .setDescription(`**${result.restoredFiles}** dosya başarıyla geri yüklendi!`)
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // Log kanalına bildirim gönder
            const logChannel = interaction.client.channels.cache.get(require('../../lyuex.json').botSettings.LOG_CHANNEL_ID);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(0xFF6B00)
                    .setTitle('🔄 Backup Geri Yüklendi')
                    .addFields(
                        { name: '👤 İşlemi Yapan', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '📦 Backup', value: `\`${backupName}\``, inline: true },
                        { name: '📊 Geri Yüklenen Dosyalar', value: `${result.restoredFiles} dosya`, inline: true }
                    )
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

        } catch (error) {
            console.error('Backup geri yükleme hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Backup Geri Yükleme Hatası')
                .setDescription(`Backup geri yüklenirken bir hata oluştu:\n\`\`\`${error.message}\`\`\``)
                .addFields(
                    { name: '📦 Backup', value: `\`${backupName}\``, inline: true },
                    { name: '⚠️ Durum', value: 'Başarısız', inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [errorEmbed] });
        }
    },

    async handleDelete(interaction) {
        await interaction.deferReply();

        const backupName = interaction.options.getString('backup_name');
        const backupManager = new BackupManager(interaction.client);

        // Backup'ın varlığını kontrol et
        const backups = backupManager.listBackups();
        const targetBackup = backups.find(backup => backup.name === backupName);

        if (!targetBackup) {
            await interaction.editReply({
                content: `❌ **${backupName}** adlı backup bulunamadı!\n\n` +
                        '📋 Mevcut backup\'ları görmek için `/backup list` komutunu kullanın.'
            });
            return;
        }

        try {
            const result = await backupManager.deleteBackup(backupName);

            const successEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('🗑️ Backup Silindi')
                .addFields(
                    { name: '📦 Silinen Backup', value: `\`${backupName}\``, inline: true },
                    { name: '📅 Backup Tarihi', value: targetBackup.created.toLocaleString('tr-TR'), inline: true },
                    { name: '💾 Kurtarılan Alan', value: targetBackup.size, inline: true }
                )
                .setDescription('Backup başarıyla silindi.')
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // Log kanalına bildirim gönder
            const logChannel = interaction.client.channels.cache.get(require('../../lyuex.json').botSettings.LOG_CHANNEL_ID);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('🗑️ Backup Silindi')
                    .addFields(
                        { name: '👤 İşlemi Yapan', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '📦 Backup', value: `\`${backupName}\``, inline: true },
                        { name: '💾 Kurtarılan Alan', value: targetBackup.size, inline: true }
                    )
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

        } catch (error) {
            console.error('Backup silme hatası:', error);
            
            await interaction.editReply({
                content: `❌ Backup silinirken bir hata oluştu:\n\`\`\`${error.message}\`\`\``
            });
        }
    }
};




