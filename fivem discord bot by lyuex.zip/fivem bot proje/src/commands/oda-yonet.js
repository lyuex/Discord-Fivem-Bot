// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const config = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('oda-yonet')
        .setDescription('Özel odanızı yönetin')
        .addSubcommand(subcommand =>
            subcommand
                .setName('isim')
                .setDescription('Oda ismini değiştir')
                .addStringOption(option =>
                    option.setName('yeni-isim')
                        .setDescription('Yeni oda ismi')
                        .setRequired(true)
                        .setMaxLength(50)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('limit')
                .setDescription('Oda limitini değiştir')
                .addIntegerOption(option =>
                    option.setName('yeni-limit')
                        .setDescription('Yeni kullanıcı limiti (0 = limitsiz)')
                        .setRequired(true)
                        .setMinValue(0)
                        .setMaxValue(99)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('kilitle')
                .setDescription('Odayı kilitle/kilidi aç'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('gizle')
                .setDescription('Odayı gizle/görünür yap'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('yetkiver')
                .setDescription('Kullanıcıya oda yetkisi ver')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Yetki verilecek kullanıcı')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('yetkial')
                .setDescription('Kullanıcıdan oda yetkisini al')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Yetkisi alınacak kullanıcı')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('at')
                .setDescription('Kullanıcıyı odadan at')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Atılacak kullanıcı')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('engelle')
                .setDescription('Kullanıcıyı odaya girmekten engelle')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Engellenecek kullanıcı')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('engel-kaldir')
                .setDescription('Kullanıcının engelini kaldır')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Engeli kaldırılacak kullanıcı')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const member = interaction.member;
        const voiceChannel = member.voice.channel;

        // Kullanıcının sesli kanalda olup olmadığını kontrol et
        if (!voiceChannel) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Hata')
                .setDescription('Bu komutu kullanmak için sesli bir kanalda olmalısınız!')
                .setColor(0xff0000)
                .setTimestamp();
            
            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Özel oda kategorisinde olup olmadığını kontrol et
        if (voiceChannel.parentId !== config.ozel_oda.kategori_id) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Hata')
                .setDescription('Bu komutu sadece özel odalarda kullanabilirsiniz!')
                .setColor(0xff0000)
                .setTimestamp();
            
            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Oda sahibi kontrolü
        const channelName = voiceChannel.name;
        const ownerMatch = channelName.match(/👤 (.+?)'s/);
        if (!ownerMatch || ownerMatch[1] !== member.displayName) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Hata')
                .setDescription('Bu odanın sahibi değilsiniz!')
                .setColor(0xff0000)
                .setTimestamp();
            
            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        try {
            let embed;
            
            switch (subcommand) {
                case 'isim':
                    const yeniIsim = interaction.options.getString('yeni-isim');
                    await voiceChannel.edit({ name: `👤 ${member.displayName}'s ${yeniIsim}` });
                    
                    embed = new EmbedBuilder()
                        .setTitle('✅ Oda İsmi Değiştirildi')
                        .setDescription(`Oda ismi **${yeniIsim}** olarak değiştirildi.`)
                        .setColor(0x00ff00)
                        .setTimestamp();
                    break;

                case 'limit':
                    const yeniLimit = interaction.options.getInteger('yeni-limit');
                    await voiceChannel.edit({ userLimit: yeniLimit });
                    
                    embed = new EmbedBuilder()
                        .setTitle('✅ Oda Limiti Değiştirildi')
                        .setDescription(`Oda limiti **${yeniLimit === 0 ? 'Limitsiz' : yeniLimit}** olarak ayarlandı.`)
                        .setColor(0x00ff00)
                        .setTimestamp();
                    break;

                case 'kilitle':
                    const isLocked = voiceChannel.permissionOverwrites.cache.some(overwrite => 
                        overwrite.id === interaction.guild.id && overwrite.deny.has('Connect')
                    );

                    if (isLocked) {
                        await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
                            Connect: null
                        });
                        embed = new EmbedBuilder()
                            .setTitle('🔓 Oda Kilidi Açıldı')
                            .setDescription('Oda artık herkese açık.')
                            .setColor(0x00ff00)
                            .setTimestamp();
                    } else {
                        await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
                            Connect: false
                        });
                        embed = new EmbedBuilder()
                            .setTitle('🔒 Oda Kilitlendi')
                            .setDescription('Oda artık sadece yetkili kişiler girebilir.')
                            .setColor(0xff9900)
                            .setTimestamp();
                    }
                    break;

                case 'gizle':
                    const isHidden = voiceChannel.permissionOverwrites.cache.some(overwrite => 
                        overwrite.id === interaction.guild.id && overwrite.deny.has('ViewChannel')
                    );

                    if (isHidden) {
                        await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
                            ViewChannel: null
                        });
                        embed = new EmbedBuilder()
                            .setTitle('👁️ Oda Görünür Yapıldı')
                            .setDescription('Oda artık herkese görünür.')
                            .setColor(0x00ff00)
                            .setTimestamp();
                    } else {
                        await voiceChannel.permissionOverwrites.edit(interaction.guild.id, {
                            ViewChannel: false
                        });
                        embed = new EmbedBuilder()
                            .setTitle('🙈 Oda Gizlendi')
                            .setDescription('Oda artık sadece içerideki kişilere görünür.')
                            .setColor(0xff9900)
                            .setTimestamp();
                    }
                    break;

                case 'yetkiver':
                    const yetkiVerilecek = interaction.options.getUser('kullanici');
                    await voiceChannel.permissionOverwrites.edit(yetkiVerilecek.id, {
                        Connect: true,
                        Speak: true,
                        ViewChannel: true
                    });
                    
                    embed = new EmbedBuilder()
                        .setTitle('✅ Yetki Verildi')
                        .setDescription(`${yetkiVerilecek} kullanıcısına oda yetkisi verildi.`)
                        .setColor(0x00ff00)
                        .setTimestamp();
                    break;

                case 'yetkial':
                    const yetkiAlinacak = interaction.options.getUser('kullanici');
                    await voiceChannel.permissionOverwrites.delete(yetkiAlinacak.id);
                    
                    embed = new EmbedBuilder()
                        .setTitle('✅ Yetki Alındı')
                        .setDescription(`${yetkiAlinacak} kullanıcısının oda yetkisi alındı.`)
                        .setColor(0x00ff00)
                        .setTimestamp();
                    break;

                case 'at':
                    const atilacak = interaction.options.getUser('kullanici');
                    const atilacakMember = interaction.guild.members.cache.get(atilacak.id);
                    
                    if (atilacakMember.voice.channel === voiceChannel) {
                        await atilacakMember.voice.disconnect();
                        embed = new EmbedBuilder()
                            .setTitle('✅ Kullanıcı Atıldı')
                            .setDescription(`${atilacak} odadan atıldı.`)
                            .setColor(0x00ff00)
                            .setTimestamp();
                    } else {
                        embed = new EmbedBuilder()
                            .setTitle('❌ Hata')
                            .setDescription('Bu kullanıcı odada değil!')
                            .setColor(0xff0000)
                            .setTimestamp();
                    }
                    break;

                case 'engelle':
                    const engellenecek = interaction.options.getUser('kullanici');
                    await voiceChannel.permissionOverwrites.edit(engellenecek.id, {
                        Connect: false
                    });
                    
                    embed = new EmbedBuilder()
                        .setTitle('🚫 Kullanıcı Engellendi')
                        .setDescription(`${engellenecek} odaya girmekten engellendi.`)
                        .setColor(0xff0000)
                        .setTimestamp();
                    break;

                case 'engel-kaldir':
                    const engelKaldirilacak = interaction.options.getUser('kullanici');
                    await voiceChannel.permissionOverwrites.delete(engelKaldirilacak.id);
                    
                    embed = new EmbedBuilder()
                        .setTitle('✅ Engel Kaldırıldı')
                        .setDescription(`${engelKaldirilacak} kullanıcısının engeli kaldırıldı.`)
                        .setColor(0x00ff00)
                        .setTimestamp();
                    break;
            }

            await interaction.reply({ embeds: [embed] });

            // Log gönder
            if (config.ozel_oda.log_kanal) {
                const logChannel = interaction.guild.channels.cache.get(config.ozel_oda.log_kanal);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('📝 Özel Oda Yönetimi')
                        .setDescription(`
                        **👤 Kullanıcı:** ${member}
                        **🎵 Oda:** ${voiceChannel}
                        **⚙️ İşlem:** ${subcommand}
                        **📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>
                        `)
                        .setColor(0x0099ff)
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

        } catch (error) {
            console.error('Oda yönetim hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Hata Oluştu')
                .setDescription('İşlem gerçekleştirilirken bir hata oluştu.')
                .setColor(0xff0000)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};