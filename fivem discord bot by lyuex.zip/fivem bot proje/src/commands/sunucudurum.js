// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

const config = {
  announcementChannelId: '1418690618107891789',
  footerText: 'ZYM CİTY',
  ipAddress: '179.61.147.231',
  status: {
    bakim: {
      color: 0xE74C3C,
      title: 'ZYM CİTY',
      description: '🔧 Sunucu şu anda **BAKIM MODUNDA**.\nLütfen kısa bir süre sonra tekrar deneyiniz.',
      statusText: '🟠 BAKIMDA',
      image: 'https://cdn.discordapp.com/attachments/1432060322163851265/1432800748793499698/banner.png?ex=690307ee&is=6901b66e&hm=9af070fc9466064e30ac90c0264d2ef525131b33cbd4d0678bda97379e0f94b8&',
      buttonLabel: '🔗 Durum Sayfası',
      buttonUrl: 'https://cfx.re/join/bjxmyb'
    },
  aktif: {
  color: 0x2ECC71,
  title: 'ZYM CİTY',
  description:
    '**Sunucu AKTİF**, giriş yapabilirsiniz;\n' +
    'Gerekli kurulum, kurallar ve bilgi odalarını ziyaret edebilirsiniz.\n\n' +
    '📌 Herhangi bir konuda destek almak için: <#1418690617399054385>\n' +
    '📨 Discord davet bağlantımız: https://discord.gg/wakHbNZcmY\n\n' +
    '**Hızlı bağlanmak için bu bağlantıyı kopyalayıp tarayıcıya yapıştırın:**\n' +
    '`fivem://connect/179.61.147.231`',
  statusText: '🟢 ONLINE',
  image: 'https://cdn.discordapp.com/attachments/1432060322163851265/1432800748793499698/banner.png?ex=690307ee&is=6901b66e&hm=9af070fc9466064e30ac90c0264d2ef525131b33cbd4d0678bda97379e0f94b8&',
  buttonLabel: '📨 Destek Sunucusu',
  buttonUrl: 'https://discord.gg/wakHbNZcmY' // Geçerli bir HTTP/HTTPS bağlantı
}
,
    restart: {
      color: 0xF1C40F,
      title: 'ZYM CİTY',
      description: '🔄 **Sunucu yeniden başlatılıyor...**\nLütfen birkaç saniye sonra tekrar bağlanmayı deneyin.',
      statusText: '🔁 YENİDEN BAŞLIYOR',
      image: 'https://cdn.discordapp.com/attachments/1432060322163851265/1432800748793499698/banner.png?ex=690307ee&is=6901b66e&hm=9af070fc9466064e30ac90c0264d2ef525131b33cbd4d0678bda97379e0f94b8&',
      buttonLabel: '📨 Destek Sunucusu',
      buttonUrl: 'https://discord.gg/wakHbNZcmY'
    }
  }
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sunucu')
    .setDescription('Sunucu durumunu yönetmek için alt komutları kullanın.')
    .addSubcommand(sub => sub.setName('bakim').setDescription('Sunucuyu bakım moduna alır.'))
    .addSubcommand(sub => sub.setName('aktif').setDescription('Sunucuyu aktif konuma getirir.'))
    .addSubcommand(sub => sub.setName('restart').setDescription('Sunucuyu yeniden başlatır.')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const cfg = config.status[sub];

    const channel = interaction.guild.channels.cache.get(config.announcementChannelId);
    if (!channel) {
      return interaction.reply({ content: '⚠️ Duyuru kanalı bulunamadı!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(cfg.color)
      .setTitle(`✨ ${cfg.title}`)
      .setDescription(cfg.description)
      .addFields(
        { name: '📶 DURUM', value: `\u0060\u0060\u0060${cfg.statusText}\u0060\u0060\u0060`, inline: true },
        { name: '🌐 SUNUCU IP', value: `\u0060\u0060\u0060${config.ipAddress}\u0060\u0060\u0060`, inline: true }
      )
      .setImage(cfg.image)
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: config.footerText, iconURL: interaction.guild.iconURL() });

    const button = new ButtonBuilder()
      .setLabel(cfg.buttonLabel)
      .setStyle(ButtonStyle.Link)
      .setURL(cfg.buttonUrl);

    const row = new ActionRowBuilder().addComponents(button);

    await channel.send({ embeds: [embed], components: [row] });
    await interaction.reply({ content: `✅ \`${sub}\` durumu başarıyla duyuruldu.`, ephemeral: true });
  }
};




