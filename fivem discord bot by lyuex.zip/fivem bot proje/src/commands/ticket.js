// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('🎫 Ticket açma menüsünü gösterir')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false),

    async execute(interaction) {
        // Developer ID kontrolü - sadece belirtilen ID'ye sahip kişi kullanabilir
        const DEVELOPER_ID = '384385365815066624';
        
        if (interaction.user.id !== DEVELOPER_ID) {
            return interaction.reply({
                content: '❌ Bu komutu kullanmaya yetkiniz yok! Sadece developer bu komutu kullanabilir.',
                ephemeral: true
            });
        }

        const config = ticketUtil.getConfig();

        if (!config?.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setColor(0xFF6B6B).setTitle('❌ Ticket sistemi kapalı').setDescription('Ticket sistemi henüz ayarlanmamış.')],
                ephemeral: true
            });
        }

        try {
            // Kategorileri hazırla (config varsa ordan, yoksa varsayılanlar)
            const categories = ticketUtil.getCategories();
            let options;
            if (categories && categories.length > 0) {
                options = categories.slice(0, 25).map(cat => {
                    // Emoji ve isim için güvenli label oluştur
                    const emoji = cat.emoji || '🎫';
                    const maxNameLength = 22; // Emoji + boşluk için yer bırak
                    const truncatedName = cat.name.length > maxNameLength ? 
                        cat.name.substring(0, maxNameLength - 1) + '…' : cat.name;
                    const label = `${emoji} ${truncatedName}`;
                    
                    return {
                        label: label.substring(0, 25), // Discord.js limiti
                        value: cat.id,
                        description: cat.description ? cat.description.substring(0, 100) : `Kategori: ${cat.name}`
                    };
                });
            } else {
                options = [
                    { label: '🎮 Oyun İçi Destek', value: 'oyun_ici_destek', description: 'Oyun içi problemler ve yardım' },
                    { label: '🖥️ Oyun Dışı Destek', value: 'oyun_disi_destek', description: 'Launcher, Discord vb.' },
                    { label: '🐛 Hata Bildirimi', value: 'hata_raporla', description: 'Hata ve bug raporu' },

                    { label: '🔐 Hesap Destek', value: 'hesap_destek', description: 'Şifre, giriş, hesap sorunları' }
                ];
            }

            const guildIcon = interaction.guild.iconURL({ dynamic: true, size: 256 }) || undefined;
            const embed = new EmbedBuilder()
                .setColor(0x1E88E5)
                .setTitle('🎫 Destek Merkezi')
                .setDescription(
                    [
                        'Merhaba! Aşağıdaki menüden talep türünü seçerek ticket açabilirsiniz.',
                        '',
                        '• Seçim sonrası sizden kısa bir açıklama istenir.',
                        '• Destek ekibimiz en kısa sürede yanıt verecektir.'
                    ].join('\n')
                )
                .addFields(
                    { name: 'ℹ️ Not', value: 'Kurallara uygun olmayan talepler reddedilebilir.', inline: false }
                )
                .setImage('https://cdn.discordapp.com/attachments/1432060322163851265/1432741855455350954/lyuex.png?ex=69022855&is=6900d6d5&hm=3b88eaafd8da882d4a98236b3217388e52df5151ff288f29b90776fd51c9b660&')
                .setThumbnail(guildIcon)
                .setFooter({ text: `${interaction.guild.name} • Ticket Sistemi`, iconURL: guildIcon })
                .setTimestamp();

            const select = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('ticket_category_select')
                    .setPlaceholder('Kategori seçin...')
                    .addOptions(options)
            );

            await interaction.reply({ embeds: [embed], components: [select] });
        } catch (error) {
            console.error('❌ Ticket menüsü hatası:', error);
            if (!interaction.replied) {
                await interaction.reply({ content: '❌ Ticket menüsü gösterilemedi', ephemeral: true });
            }
        }
    }
};







