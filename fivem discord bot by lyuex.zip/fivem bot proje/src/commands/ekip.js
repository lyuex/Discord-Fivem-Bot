// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ekip')
        .setDescription('Ekip yÃ¶netim panelini oluÅŸtur')
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Ekip yÃ¶netim panelini belirtilen kanala gÃ¶nderir')
                .addChannelOption(option =>
                    option
                        .setName('kanal')
                        .setDescription('Panel gÃ¶nderilecek kanal')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('temizle')
                .setDescription('TÃ¼m ekip verilerini ve ticket kanallarÄ±nÄ± siler (GERÄ° ALINAMAZ!)')
        ),

    async execute(interaction) {
        try {
            // Yetkili kontrolü
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return await interaction.reply({
                    content: '❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısınız!',
                    ephemeral: true
                });
            }

            // Temizle subcommand
            if (interaction.options.getSubcommand() === 'temizle') {
                return await this.handleTemizle(interaction);
            }

            // Panel subcommand
            const kanal = interaction.options.getChannel('kanal');

            await interaction.deferReply({ ephemeral: true });

            // GÃ¶rsel ve detaylÄ± embed oluÅŸtur
            const embed = new EmbedBuilder()
                .setColor('#2F3136')
                .setTitle('ğŸ¢ â”‚ EKÄ°P YÃ–NETÄ°M SÄ°STEMÄ°')
                .setDescription(
                    '```ansi\n' +
                    '\u001b[2;36mâ•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—\n' +
                    '\u001b[2;36mâ•‘     EKÄ°P YÃ–NETÄ°M KONTROL PANELÄ°      â•‘\n' +
                    '\u001b[2;36mâ•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                    '```\n' +
                    '> **HoÅŸ Geldiniz!** ğŸ‘‹\n' +
                    '> Bu panel Ã¼zerinden tÃ¼m ekip iÅŸlemlerinizi kolayca yÃ¶netebilirsiniz.\n' +
                    '> AÅŸaÄŸÄ±daki menÃ¼den yapmak istediÄŸiniz iÅŸlemi seÃ§in.\n\n' +
                    'â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”\n\n' +
                    '### ğŸ“‹ **Ekip Ä°ÅŸlemleri**\n' +
                    '```yaml\n' +
                    'â• Ekip Kur      : Yeni bir ekip oluÅŸturun\n' +
                    'ğŸ“‹ Ekip Listesi  : TÃ¼m ekipleri gÃ¶rÃ¼ntÃ¼leyin\n' +
                    'ğŸ‘¥ Ekip Profil   : DetaylÄ± ekip profili\n' +
                    'â„¹ï¸  Ekip Bilgi    : Ekip detaylarÄ±nÄ± inceleyin\n' +
                    '```\n' +
                    '### ğŸ‘¥ **Ãœye YÃ¶netimi**\n' +
                    '```yaml\n' +
                    'ğŸ‘¤ Ãœye Ekle      : Ekibe yeni Ã¼ye ekleyin\n' +
                    'ğŸ‘‹ Ãœye Ã‡Ä±kar     : Ekipten Ã¼ye Ã§Ä±karÄ±n\n' +
                    'âš ï¸  UyarÄ± Ver     : Ãœyeye uyarÄ± verin\n' +
                    'ğŸ“ UyarÄ± Listesi : UyarÄ± geÃ§miÅŸi\n' +
                    '```\n' +
                    '### âš™ï¸ **GeliÅŸmiÅŸ Ayarlar**\n' +
                    '```yaml\n' +
                    'ğŸ­ Rol YÃ¶netimi  : Rol atama/kaldÄ±rma\n' +
                    'ğŸ’¾ Yedekleme     : Veri yedekleme sistemi\n' +
                    'ğŸ“Š Ä°statistikler : Ekip analizi\n' +
                    'ğŸ—‘ï¸  Ekip Sil      : Ekip silme iÅŸlemi\n' +
                    '```\n' +
                    'â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”\n'
                )
                .addFields(
                    {
                        name: 'ğŸ¯ NasÄ±l KullanÄ±lÄ±r?',
                        value: '```\n1ï¸âƒ£ AÅŸaÄŸÄ±daki menÃ¼den iÅŸlem seÃ§in\n2ï¸âƒ£ AÃ§Ä±lan formlarÄ± doldurun\n3ï¸âƒ£ Ä°ÅŸleminiz anÄ±nda tamamlanÄ±r\n```',
                        inline: false
                    },
                    {
                        name: 'ï¿½ GÃ¼venlik',
                        value: '```\nTÃ¼m iÅŸlemler loglanÄ±r ve\nyetkili kontrolÃ¼nden geÃ§er\n```',
                        inline: true
                    },
                    {
                        name: 'âš¡ HÄ±z',
                        value: '```\nAnlÄ±k iÅŸlem gerÃ§ekleÅŸtirme\nve otomatik kayÄ±t sistemi\n```',
                        inline: true
                    },
                    {
                        name: 'ï¿½ Yedekleme',
                        value: '```\nOtomatik yedekleme ile\nverileriniz her zaman gÃ¼vende\n```',
                        inline: true
                    }
                )
                .setImage('https://cdn.discordapp.com/attachments/1432827105514885192/1433028128812433458/lyuexdev_banner.jpg?ex=690332f2&is=6901e172&hm=0463e24693b117708889e11e8e844cb186c720b341a6b9b55f41b1cc85c4f1b1&') // GÃ¼zel bir banner ekleyebilirsiniz
                .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 256 }))
                .setFooter({ 
                    text: `${interaction.guild.name} â€¢ Ekip YÃ¶netim Sistemi`,
                    iconURL: interaction.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            // Select menu oluÅŸtur
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('ekip_menu')
                .setPlaceholder('ğŸ¯ Bir iÅŸlem seÃ§in...')
                .addOptions([
                    {
                        label: 'Ekip Kur',
                        description: 'Yeni bir ekip oluÅŸturun',
                        value: 'ekip_kur',
                        emoji: 'â•'
                    },
                    {
                        label: 'Ekip Listesi',
                        description: 'TÃ¼m ekipleri gÃ¶rÃ¼ntÃ¼le',
                        value: 'ekip_liste',
                        emoji: 'ğŸ“‹'
                    },
                    {
                        label: 'Ekip Bilgi',
                        description: 'Bir ekibin detaylarÄ±nÄ± gÃ¶rÃ¼ntÃ¼le',
                        value: 'ekip_bilgi',
                        emoji: 'â„¹ï¸'
                    },
                    {
                        label: 'Ãœye Ekle',
                        description: 'Ekibe yeni Ã¼ye ekle',
                        value: 'uye_ekle',
                        emoji: 'ğŸ‘¤'
                    },
                    {
                        label: 'Ãœye Ã‡Ä±kar',
                        description: 'Ekipten Ã¼ye Ã§Ä±kar',
                        value: 'uye_cikar',
                        emoji: 'ğŸ‘‹'
                    },
                    {
                        label: 'Ekip UyarÄ± Ver',
                        description: 'Ekip Ã¼yesine uyarÄ± ver',
                        value: 'ekip_uyari_ver',
                        emoji: 'âš ï¸'
                    },
                    {
                        label: 'UyarÄ± Listesi',
                        description: 'Ãœye uyarÄ±larÄ±nÄ± gÃ¶rÃ¼ntÃ¼le',
                        value: 'uyari_liste',
                        emoji: 'ğŸ“'
                    },
                    {
                        label: 'Ekip Profil',
                        description: 'Ekip profil bilgilerini gÃ¶rÃ¼ntÃ¼le',
                        value: 'ekip_profil',
                        emoji: 'ğŸ‘¥'
                    },
                    {
                        label: 'Rol YÃ¶netimi',
                        description: 'Ekip rol atama/kaldÄ±rma',
                        value: 'ekip_rol',
                        emoji: 'ğŸ­'
                    },
                    {
                        label: 'Yedek Al',
                        description: 'Ekip verilerini yedekle',
                        value: 'ekip_yedek_al',
                        emoji: 'ğŸ’¾'
                    },
                    {
                        label: 'Yedek Listesi',
                        description: 'Mevcut yedekleri listele',
                        value: 'yedek_liste',
                        emoji: 'ğŸ“‚'
                    },
                    {
                        label: 'Yedek YÃ¼kle',
                        description: 'Yedekten geri yÃ¼kle',
                        value: 'yedek_yukle',
                        emoji: 'ğŸ”„'
                    },
                    {
                        label: 'Ä°statistikler',
                        description: 'Ekip istatistiklerini gÃ¶rÃ¼ntÃ¼le',
                        value: 'ekip_istatistik',
                        emoji: 'ğŸ“Š'
                    },
                    {
                        label: 'Ekip Sil',
                        description: 'Bir ekibi tamamen kaldÄ±r',
                        value: 'ekip_sil',
                        emoji: 'ğŸ—‘ï¸'
                    },
                    {
                        label: 'SeÃ§enekleri SÄ±fÄ±rla',
                        description: 'Select menÃ¼yÃ¼ varsayÄ±lana dÃ¶ndÃ¼r',
                        value: 'secenekleri_sifirla',
                        emoji: 'ğŸ”„'
                    }
                ]);

            const row = new ActionRowBuilder()
                .addComponents(selectMenu);

            // Paneli kanala gÃ¶nder
            const message = await kanal.send({
                embeds: [embed],
                components: [row]
            });

            // MesajÄ± sabitle
            try {
                await message.pin();
            } catch (error) {
                console.log('Mesaj sabitlenemedi:', error.message);
            }

            // BaÅŸarÄ± mesajÄ±
            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('âœ… Panel OluÅŸturuldu')
                .setDescription(`Ekip yÃ¶netim paneli ${kanal} kanalÄ±na baÅŸarÄ±yla gÃ¶nderildi!`)
                .addFields(
                    { name: 'ğŸ“ Kanal', value: `${kanal}`, inline: true },
                    { name: 'ğŸ“¨ Mesaj ID', value: `\`${message.id}\``, inline: true },
                    { name: 'ğŸ“Œ Durum', value: 'Sabitlendi', inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Ekip komut hatasÄ±:', error);
            await interaction.editReply({
                content: 'âŒ Panel oluÅŸturulurken bir hata oluÅŸtu! LÃ¼tfen tekrar deneyin.',
            }).catch(() => {});
        }
    },

    async handleTemizle(interaction) {
        const { Ekip, EkipUyari, EkipYedek } = require('../Schemas/EkipSchema');
        const { ButtonBuilder, ButtonStyle } = require('discord.js');
        
        try {
            // IMMEDIATELY defer to prevent timeout
            await interaction.deferReply({ ephemeral: true });
            
            const confirmButton = new ButtonBuilder()
                .setCustomId('ekip_temizle_onayla')
                .setLabel('EVET, HEPSİNİ SİL')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('⚠️');
                
            const cancelButton = new ButtonBuilder()
                .setCustomId('ekip_temizle_iptal')
                .setLabel('İptal Et')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('❌');
                
            const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);
            
            const warningEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('⚠️ UYARI: TÜM EKİP VERİLERİ SİLİNECEK!')
                .setDescription(
                    '**Bu işlem GERİ ALINAMAZ!**\n\n' +
                    'Aşağıdaki veriler **KALICI OLARAK** silinecektir:\n\n' +
                    '```diff\n' +
                    '- Tüm ekip bilgileri\n' +
                    '- Tüm ekip üyeleri\n' +
                    '- Tüm ekip uyarıları\n' +
                    '- Tüm ekip yedekleri\n' +
                    '- Tüm ticket kanalları\n' +
                    '```\n\n' +
                    '⚠️ **Devam etmek istediğinizden emin misiniz?**'
                )
                .setFooter({ text: 'Bu işlem geri alınamaz!' })
                .setTimestamp();
            const response = await interaction.editReply({ embeds: [warningEmbed], components: [row] });
            const collector = response.createMessageComponentCollector({ time: 30000 });
            collector.on('collect', async (buttonInteraction) => {
                if (buttonInteraction.user.id !== interaction.user.id) return buttonInteraction.reply({ content: ' Bu butonu sadece komutu kullanan kişi kullanabilir!', ephemeral: true });
                if (buttonInteraction.customId === 'ekip_temizle_iptal') {
                    collector.stop('cancelled');
                    await buttonInteraction.update({ embeds: [new EmbedBuilder().setColor(0x00FF00).setTitle(' İşlem İptal Edildi').setDescription('Ekip verileri silinmedi.').setTimestamp()], components: [] });
                    return;
                }
                if (buttonInteraction.customId === 'ekip_temizle_onayla') {
                    await buttonInteraction.deferUpdate();
                    try {
                        const ekipler = await Ekip.find({ guildId: interaction.guild.id });
                        let silinenKanallar = 0;
                        let silinenRoller = 0;
                        
                        // Kanalları ve rolleri sil
                        for (const ekip of ekipler) {
                            // Ticket kanalını sil
                            if (ekip.ticketKanalId) {
                                try {
                                    const channel = await interaction.guild.channels.fetch(ekip.ticketKanalId);
                                    if (channel) { 
                                        await channel.delete(); 
                                        silinenKanallar++; 
                                    }
                                } catch (error) { 
                                    console.log(`Kanal silinemedi: ${ekip.ticketKanalId}`, error.message); 
                                }
                            }
                            
                            // Ekip rolünü sil
                            if (ekip.rolId) {
                                try {
                                    const role = await interaction.guild.roles.fetch(ekip.rolId);
                                    if (role) {
                                        await role.delete();
                                        silinenRoller++;
                                    }
                                } catch (error) {
                                    console.log(`Rol silinemedi: ${ekip.rolId}`, error.message);
                                }
                            }
                        }
                        const ekipSayisi = await Ekip.countDocuments({ guildId: interaction.guild.id });
                        const uyariSayisi = await EkipUyari.countDocuments({ guildId: interaction.guild.id });
                        const yedekSayisi = await EkipYedek.countDocuments({ guildId: interaction.guild.id });
                        await Ekip.deleteMany({ guildId: interaction.guild.id });
                        await EkipUyari.deleteMany({ guildId: interaction.guild.id });
                        await EkipYedek.deleteMany({ guildId: interaction.guild.id });
                        const successEmbed = new EmbedBuilder().setColor(0x00FF00).setTitle('✅ Tüm Ekip Verileri Silindi!').setDescription(`**Temizleme işlemi başarıyla tamamlandı!**\n\n` + '```yaml\n' + `Silinen Ekipler: ${ekipSayisi}\n` + `Silinen Uyarılar: ${uyariSayisi}\n` + `Silinen Yedekler: ${yedekSayisi}\n` + `Silinen Kanallar: ${silinenKanallar}\n` + `Silinen Roller: ${silinenRoller}\n` + '```\n\n' + '✅ Sistem tamamen temizlendi ve sıfırlandı!').setFooter({ text: `İşlemi yapan: ${interaction.user.tag}` }).setTimestamp();
                        await interaction.editReply({ embeds: [successEmbed], components: [] });
                        console.log(`[EKİP TEMİZLE] ${interaction.user.tag} tüm ekip verilerini sildi. (${ekipSayisi} ekip, ${silinenKanallar} kanal, ${silinenRoller} rol)`);
                    } catch (error) {
                        console.error('Temizleme hatası:', error);
                        await interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xFF0000).setTitle('❌ Hata!').setDescription('Temizleme sırasında bir hata oluştu!').setTimestamp()], components: [] }).catch(() => {});
                    }
                    collector.stop('confirmed');
                }
            });
            collector.on('end', (collected, reason) => {
                if (reason === 'time') {
                    interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xFF9900).setTitle(' Süre Doldu').setDescription('İşlem zaman aşımına uğradı. Ekip verileri silinmedi.').setTimestamp()], components: [] }).catch(() => {});
                }
            });
        } catch (error) {
            console.error('Ekip temizle hatası:', error);
            await interaction.editReply({ content: ' İşlem sırasında bir hata oluştu!', components: [] }).catch(() => {});
        }
    }
};
