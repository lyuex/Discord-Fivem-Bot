// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const { Moderation } = require('../Schemas/ModerationSchema');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('case-yönetim')
    .setDescription('📁 Moderasyon vaka yönetimi')
    .addSubcommand(subcommand =>
      subcommand
        .setName('görüntüle')
        .setDescription('👁️ Vaka detaylarını görüntüle')
        .addStringOption(option =>
          option.setName('vaka_id')
            .setDescription('🔢 Vaka ID numarası')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('düzenle')
        .setDescription('✏️ Vaka sebep ve notlarını düzenle')
        .addStringOption(option =>
          option.setName('vaka_id')
            .setDescription('🔢 Vaka ID numarası')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('yeni_sebep')
            .setDescription('📝 Yeni sebep açıklaması')
            .setRequired(false)
            .setMaxLength(500))
        .addStringOption(option =>
          option.setName('not_ekle')
            .setDescription('📋 Vakaya eklenecek not')
            .setRequired(false)
            .setMaxLength(300)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('sil')
        .setDescription('🗑️ Vakayı sistemden sil')
        .addStringOption(option =>
          option.setName('vaka_id')
            .setDescription('🔢 Vaka ID numarası')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('sil_sebebi')
            .setDescription('📝 Silme sebebi')
            .setRequired(true)
            .setMaxLength(200)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('iptal')
        .setDescription('❌ Aktif cezayı iptal et')
        .addStringOption(option =>
          option.setName('vaka_id')
            .setDescription('🔢 Vaka ID numarası')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('iptal_sebebi')
            .setDescription('📝 İptal sebebi')
            .setRequired(true)
            .setMaxLength(200)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('ara')
        .setDescription('🔍 Vaka arama')
        .addUserOption(option =>
          option.setName('kullanıcı')
            .setDescription('👤 Hedef kullanıcı')
            .setRequired(false))
        .addUserOption(option =>
          option.setName('moderatör')
            .setDescription('👮 Moderatör')
            .setRequired(false))
        .addStringOption(option =>
          option.setName('tür')
            .setDescription('⚖️ Vaka türü')
            .setRequired(false)
            .addChoices(
              { name: '🔨 Ban', value: 'ban' },
              { name: '👢 Kick', value: 'kick' },
              { name: '🔇 Mute', value: 'mute' },
              { name: '⚠️ Uyarı', value: 'warn' },
              { name: '🔄 Unban', value: 'unban' },
              { name: '🔊 Unmute', value: 'unmute' }
            ))
        .addBooleanOption(option =>
          option.setName('sadece_aktif')
            .setDescription('✅ Sadece aktif vakaları göster')
            .setRequired(false))
        .addIntegerOption(option =>
          option.setName('sayfa')
            .setDescription('📄 Sayfa numarası')
            .setRequired(false)
            .setMinValue(1)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('istatistik')
        .setDescription('📊 Vaka istatistikleri')
        .addStringOption(option =>
          option.setName('süre')
            .setDescription('📅 İstatistik süresi')
            .setRequired(false)
            .addChoices(
              { name: '📅 Bugün', value: 'today' },
              { name: '📅 Bu Hafta', value: 'week' },
              { name: '📅 Bu Ay', value: 'month' },
              { name: '📅 Tüm Zamanlar', value: 'all' }
            )))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();
      
      const subcommand = interaction.options.getSubcommand();

      switch (subcommand) {
        case 'görüntüle':
          await this.handleView(interaction);
          break;
        case 'düzenle':
          await this.handleEdit(interaction);
          break;
        case 'sil':
          await this.handleDelete(interaction);
          break;
        case 'iptal':
          await this.handleCancel(interaction);
          break;
        case 'ara':
          await this.handleSearch(interaction);
          break;
        case 'istatistik':
          await this.handleStats(interaction);
          break;
      }
    } catch (error) {
      console.error('Case yönetim hatası:', error);
      
      const errorMessage = `❌ **Vaka Yönetim Hatası!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  },

  async handleView(interaction) {
    const caseId = interaction.options.getString('vaka_id');
    const guild = interaction.guild;

    const moderationCase = await Moderation.findOne({ 
      guildId: guild.id, 
      caseId: caseId 
    });

    if (!moderationCase) {
      return await interaction.editReply({
        content: `❌ **Vaka Bulunamadı!** \`${caseId}\` ID'li vaka mevcut değil.`
      });
    }

    const typeEmojis = {
      'ban': '🔨',
      'kick': '👢',
      'mute': '🔇',
      'warn': '⚠️',
      'unban': '🔄',
      'unmute': '🔊'
    };

    const typeNames = {
      'ban': 'Ban',
      'kick': 'Kick',
      'mute': 'Mute',
      'warn': 'Uyarı',
      'unban': 'Unban',
      'unmute': 'Unmute'
    };

    const embed = new EmbedBuilder()
      .setColor(moderationCase.active ? '#FF4444' : '#808080')
      .setTitle(`${typeEmojis[moderationCase.type]} Vaka Detayları - ${caseId}`)
      .addFields(
        { name: '⚖️ İşlem Türü', value: `${typeEmojis[moderationCase.type]} ${typeNames[moderationCase.type]}`, inline: true },
        { name: '✅ Durum', value: moderationCase.active ? '🔴 Aktif' : '🔘 Pasif', inline: true },
        { name: '🆔 Vaka ID', value: moderationCase.caseId, inline: true },
        { name: '👤 Kullanıcı', value: `${moderationCase.userTag}\n\`${moderationCase.userId}\``, inline: true },
        { name: '👮 Moderatör', value: `${moderationCase.moderatorTag}\n\`${moderationCase.moderatorId}\``, inline: true },
        { name: '📅 Tarih', value: `<t:${Math.floor(moderationCase.createdAt.getTime() / 1000)}:F>`, inline: true },
        { name: '📝 Sebep', value: moderationCase.reason || 'Belirtilmemiş', inline: false }
      );

    // Süre bilgisi (mute/tempban için)
    if (moderationCase.duration) {
      const endTime = new Date(moderationCase.createdAt.getTime() + moderationCase.duration * 60000);
      embed.addFields({
        name: '⏰ Süre Bilgisi',
        value: `**Süre:** ${ModerationManager.formatDuration(moderationCase.duration)}\n**Bitiş:** <t:${Math.floor(endTime.getTime() / 1000)}:F>`,
        inline: false
      });
    }

    // Notlar
    if (moderationCase.notes && moderationCase.notes.length > 0) {
      const notesText = moderationCase.notes
        .slice(0, 3)
        .map((note, index) => `**${index + 1}.** ${note.content}\n*${note.moderator} - <t:${Math.floor(note.timestamp.getTime() / 1000)}:R>*`)
        .join('\n\n');
      
      embed.addFields({
        name: `📋 Notlar (${moderationCase.notes.length})`,
        value: notesText,
        inline: false
      });
    }

    // İlgili vakalar
    const relatedCases = await Moderation.find({
      guildId: guild.id,
      userId: moderationCase.userId,
      caseId: { $ne: caseId }
    }).limit(5).sort({ createdAt: -1 });

    if (relatedCases.length > 0) {
      const relatedText = relatedCases
        .map(c => `\`${c.caseId}\` ${typeEmojis[c.type]} ${typeNames[c.type]} - <t:${Math.floor(c.createdAt.getTime() / 1000)}:R>`)
        .join('\n');
      
      embed.addFields({
        name: '🔗 İlgili Vakalar',
        value: relatedText,
        inline: false
      });
    }

    embed.setFooter({ 
      text: `${guild.name} • Vaka Detayları`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    // Vaka yönetim butonları
    const editButton = new ButtonBuilder()
      .setCustomId(`case_edit_${caseId}`)
      .setLabel('✏️ Düzenle')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(!moderationCase.active);

    const deleteButton = new ButtonBuilder()
      .setCustomId(`case_delete_${caseId}`)
      .setLabel('🗑️ Sil')
      .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
      .setCustomId(`case_cancel_${caseId}`)
      .setLabel('❌ İptal Et')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(!moderationCase.active);

    const row = new ActionRowBuilder()
      .addComponents(editButton, deleteButton, cancelButton);

    await interaction.editReply({ embeds: [embed], components: [row] });
  },

  async handleEdit(interaction) {
    const caseId = interaction.options.getString('vaka_id');
    const newReason = interaction.options.getString('yeni_sebep');
    const addNote = interaction.options.getString('not_ekle');
    const guild = interaction.guild;
    const moderator = interaction.user;

    const moderationCase = await Moderation.findOne({ 
      guildId: guild.id, 
      caseId: caseId 
    });

    if (!moderationCase) {
      return await interaction.editReply({
        content: `❌ **Vaka Bulunamadı!** \`${caseId}\` ID'li vaka mevcut değil.`
      });
    }

    let changes = [];

    // Sebep güncelleme
    if (newReason) {
      const oldReason = moderationCase.reason;
      moderationCase.reason = newReason;
      changes.push(`**Sebep:** "${oldReason}" → "${newReason}"`);
    }

    // Not ekleme
    if (addNote) {
      if (!moderationCase.notes) moderationCase.notes = [];
      
      moderationCase.notes.push({
        content: addNote,
        moderator: moderator.tag,
        moderatorId: moderator.id,
        timestamp: new Date()
      });
      
      changes.push(`**Not Eklendi:** "${addNote}"`);
    }

    if (changes.length === 0) {
      return await interaction.editReply({
        content: '❌ **Değişiklik Yok!** En az bir alan güncellenmeli.'
      });
    }

    // Güncelleme kaydı
    moderationCase.lastModified = new Date();
    moderationCase.lastModifiedBy = moderator.id;
    await moderationCase.save();

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✅ Vaka Güncellendi')
      .addFields(
        { name: '🆔 Vaka ID', value: caseId, inline: true },
        { name: '👮 Düzenleyen', value: moderator.tag, inline: true },
        { name: '🕐 Güncelleme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
        { name: '📝 Yapılan Değişiklikler', value: changes.join('\n'), inline: false }
      )
      .setFooter({ 
        text: `${guild.name} • Vaka Güncelleme`,
        iconURL: guild.iconURL({ dynamic: true })
      })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    // Log kaydı
    const logEmbed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('✏️ Vaka Düzenleme')
      .addFields(
        { name: '👮 Moderatör', value: moderator.tag, inline: true },
        { name: '🆔 Vaka ID', value: caseId, inline: true },
        { name: '📝 Değişiklikler', value: changes.join('\n'), inline: false }
      )
      .setTimestamp();

    await ModerationManager.sendToLogChannel(guild, logEmbed);
  },

  async handleDelete(interaction) {
    const caseId = interaction.options.getString('vaka_id');
    const deleteReason = interaction.options.getString('sil_sebebi');
    const guild = interaction.guild;
    const moderator = interaction.user;

    const moderationCase = await Moderation.findOne({ 
      guildId: guild.id, 
      caseId: caseId 
    });

    if (!moderationCase) {
      return await interaction.editReply({
        content: `❌ **Vaka Bulunamadı!** \`${caseId}\` ID'li vaka mevcut değil.`
      });
    }

    // Yüksek yetkili kontrolü (sadece admin veya vaka sahibi)
    const member = interaction.member;
    const isAdmin = member.permissions.has(PermissionFlagsBits.Administrator);
    const isCaseOwner = moderationCase.moderatorId === moderator.id;

    if (!isAdmin && !isCaseOwner) {
      return await interaction.editReply({
        content: '❌ **Yetersiz Yetki!** Sadece Adlyuexstrator veya vaka sahibi silebilir.'
      });
    }

    // Onay embed'i
    const confirmEmbed = new EmbedBuilder()
      .setColor(0xFF4444)
      .setTitle('🗑️ Vaka Silme Onayı')
      .setDescription(
        `⚠️ **UYARI: Bu işlem geri alınamaz!**\n\n` +
        `**🆔 Vaka ID:** ${caseId}\n` +
        `**👤 Kullanıcı:** ${moderationCase.userTag}\n` +
        `**⚖️ İşlem:** ${moderationCase.type}\n` +
        `**📝 Silme Sebebi:** ${deleteReason}\n\n` +
        `Bu vakayı kalıcı olarak silmek istediğinizden emin misiniz?`
      );

    const confirmButton = new ButtonBuilder()
      .setCustomId('case_delete_confirm')
      .setLabel('✅ EVET, SİL')
      .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
      .setCustomId('case_delete_cancel')
      .setLabel('❌ İptal Et')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder()
      .addComponents(confirmButton, cancelButton);

    const response = await interaction.editReply({
      embeds: [confirmEmbed],
      components: [row]
    });

    const collector = response.createMessageComponentCollector({ time: 30000 });

    collector.on('collect', async (buttonInteraction) => {
      if (buttonInteraction.user.id !== moderator.id) {
        return await buttonInteraction.reply({
          content: '❌ Bu onayı sadece komutu kullanan kişi verebilir!',
          ephemeral: true
        });
      }

      await buttonInteraction.deferUpdate();

      if (buttonInteraction.customId === 'case_delete_cancel') {
        const cancelEmbed = new EmbedBuilder()
          .setColor(0x808080)
          .setTitle('❌ Silme İşlemi İptal Edildi')
          .setDescription('Vaka silinmedi.')
          .setTimestamp();

        await interaction.editReply({
          embeds: [cancelEmbed],
          components: []
        });
        return;
      }

      if (buttonInteraction.customId === 'case_delete_confirm') {
        // Vaka silme işlemi
        await Moderation.deleteOne({ _id: moderationCase._id });

        const deleteEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('🗑️ Vaka Silindi')
          .addFields(
            { name: '🆔 Silinen Vaka', value: caseId, inline: true },
            { name: '👮 Silen Moderatör', value: moderator.tag, inline: true },
            { name: '📝 Silme Sebebi', value: deleteReason, inline: false }
          )
          .setTimestamp();

        await interaction.editReply({
          embeds: [deleteEmbed],
          components: []
        });

        // Log kaydı
        const logEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('🗑️ Vaka Silme İşlemi')
          .addFields(
            { name: '👮 Moderatör', value: moderator.tag, inline: true },
            { name: '🆔 Silinen Vaka', value: caseId, inline: true },
            { name: '👤 Kullanıcı', value: moderationCase.userTag, inline: true },
            { name: '📝 Sebep', value: deleteReason, inline: false }
          )
          .setTimestamp();

        await ModerationManager.sendToLogChannel(guild, logEmbed);
      }
    });

    collector.on('end', async (collected) => {
      if (collected.size === 0) {
        const timeoutEmbed = new EmbedBuilder()
          .setColor(0x808080)
          .setTitle('⏰ Zaman Aşımı')
          .setDescription('30 saniye içinde yanıt verilmediği için işlem iptal edildi.')
          .setTimestamp();

        await interaction.editReply({
          embeds: [timeoutEmbed],
          components: []
        });
      }
    });
  },

  async handleCancel(interaction) {
    const caseId = interaction.options.getString('vaka_id');
    const cancelReason = interaction.options.getString('iptal_sebebi');
    const guild = interaction.guild;
    const moderator = interaction.user;

    const moderationCase = await Moderation.findOne({ 
      guildId: guild.id, 
      caseId: caseId,
      active: true
    });

    if (!moderationCase) {
      return await interaction.editReply({
        content: `❌ **Aktif Vaka Bulunamadı!** \`${caseId}\` ID'li aktif vaka mevcut değil.`
      });
    }

    // Cezayı iptal et
    let cancelResult = null;
    
    try {
      const user = await interaction.client.users.fetch(moderationCase.userId);
      
      switch (moderationCase.type) {
        case 'ban':
        case 'tempban':
          cancelResult = await ModerationManager.unbanUser({
            guild,
            user,
            moderator,
            reason: `Vaka iptal: ${cancelReason}`
          });
          break;
          
        case 'mute':
          const member = await guild.members.fetch(moderationCase.userId);
          cancelResult = await ModerationManager.unmuteUser({
            guild,
            member,
            moderator,
            reason: `Vaka iptal: ${cancelReason}`
          });
          break;
          
        default:
          // Warn gibi cezalar sadece pasif hale getirilir
          moderationCase.active = false;
          moderationCase.cancelledAt = new Date();
          moderationCase.cancelledBy = moderator.id;
          moderationCase.cancelReason = cancelReason;
          await moderationCase.save();
          cancelResult = { success: true };
      }

      if (cancelResult && cancelResult.success) {
        const embed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Vaka İptal Edildi')
          .addFields(
            { name: '🆔 Vaka ID', value: caseId, inline: true },
            { name: '⚖️ İşlem Türü', value: moderationCase.type, inline: true },
            { name: '👮 İptal Eden', value: moderator.tag, inline: true },
            { name: '👤 Kullanıcı', value: moderationCase.userTag, inline: true },
            { name: '📝 İptal Sebebi', value: cancelReason, inline: false }
          )
          .setFooter({ 
            text: `${guild.name} • Vaka İptal`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kaydı
        const logEmbed = new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle('❌ Vaka İptal Edildi')
          .addFields(
            { name: '👮 Moderatör', value: moderator.tag, inline: true },
            { name: '🆔 Vaka ID', value: caseId, inline: true },
            { name: '👤 Kullanıcı', value: moderationCase.userTag, inline: true },
            { name: '📝 Sebep', value: cancelReason, inline: false }
          )
          .setTimestamp();

        await ModerationManager.sendToLogChannel(guild, logEmbed);
      } else {
        throw new Error('Vaka iptal edilemedi');
      }

    } catch (error) {
      await interaction.editReply({
        content: `❌ **Vaka İptal Hatası!** ${error.message}`
      });
    }
  },

  async handleSearch(interaction) {
    const user = interaction.options.getUser('kullanıcı');
    const moderator = interaction.options.getUser('moderatör');
    const type = interaction.options.getString('tür');
    const activeOnly = interaction.options.getBoolean('sadece_aktif') || false;
    const page = interaction.options.getInteger('sayfa') || 1;
    const guild = interaction.guild;

    // Arama filtreleri oluştur
    const filters = { guildId: guild.id };
    
    if (user) filters.userId = user.id;
    if (moderator) filters.moderatorId = moderator.id;
    if (type) filters.type = type;
    if (activeOnly) filters.active = true;

    // Toplam sayı ve sayfalama
    const totalCases = await Moderation.countDocuments(filters);
    const perPage = 10;
    const totalPages = Math.ceil(totalCases / perPage);
    
    if (page > totalPages && totalPages > 0) {
      return await interaction.editReply({
        content: `❌ **Geçersiz Sayfa!** Toplam ${totalPages} sayfa var.`
      });
    }

    // Vakaları getir
    const cases = await Moderation.find(filters)
      .sort({ createdAt: -1 })
      .skip((page - 1) * perPage)
      .limit(perPage);

    if (cases.length === 0) {
      return await interaction.editReply({
        content: '❌ **Vaka Bulunamadı!** Belirtilen kriterlere uygun vaka yok.'
      });
    }

    const typeEmojis = {
      'ban': '🔨',
      'kick': '👢',
      'mute': '🔇',
      'warn': '⚠️',
      'unban': '🔄',
      'unmute': '🔊'
    };

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('🔍 Vaka Arama Sonuçları')
      .setDescription(
        `**📊 Toplam:** ${totalCases} vaka\n` +
        `**📄 Sayfa:** ${page}/${totalPages}\n` +
        `**🔍 Filtreler:** ${this.formatFilters(filters)}`
      );

    // Vakaları listele
    const caseList = cases.map((c, index) => {
      const emoji = typeEmojis[c.type] || '❓';
      const status = c.active ? '🔴' : '🔘';
      const timeText = `<t:${Math.floor(c.createdAt.getTime() / 1000)}:R>`;
      
      return `${status} \`${c.caseId}\` ${emoji} **${c.type}** - ${c.userTag}\n` +
             `   👮 ${c.moderatorTag} • ${timeText}`;
    }).join('\n\n');

    embed.addFields({
      name: `📋 Vakalar (${(page - 1) * perPage + 1}-${Math.min(page * perPage, totalCases)})`,
      value: caseList,
      inline: false
    });

    embed.setFooter({ 
      text: `${guild.name} • Vaka Arama`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    // Sayfa navigasyon butonları
    const prevButton = new ButtonBuilder()
      .setCustomId(`case_search_prev_${page}`)
      .setLabel('⬅️ Önceki')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page <= 1);

    const nextButton = new ButtonBuilder()
      .setCustomId(`case_search_next_${page}`)
      .setLabel('Sonraki ➡️')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page >= totalPages);

    const row = new ActionRowBuilder()
      .addComponents(prevButton, nextButton);

    await interaction.editReply({ embeds: [embed], components: [row] });
  },

  async handleStats(interaction) {
    const period = interaction.options.getString('süre') || 'week';
    const guild = interaction.guild;

    // Tarih aralığı hesapla
    const now = new Date();
    let startDate;

    switch (period) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'all':
        startDate = new Date(0);
        break;
    }

    // İstatistikleri hesapla
    const stats = await this.calculateCaseStats(guild.id, startDate);

    const periodNames = {
      'today': '📅 Bugün',
      'week': '📅 Bu Hafta',
      'month': '📅 Bu Ay',
      'all': '📅 Tüm Zamanlar'
    };

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('📊 Vaka İstatistikleri')
      .setDescription(`**📊 Dönem:** ${periodNames[period]}\n**🕐 Tarih:** ${startDate.toLocaleDateString('tr-TR')} - ${now.toLocaleDateString('tr-TR')}`);

    // Genel istatistikler
    embed.addFields(
      { name: '📊 Toplam Vaka', value: stats.total.toString(), inline: true },
      { name: '🔴 Aktif Ceza', value: stats.active.toString(), inline: true },
      { name: '📈 Günlük Ortalama', value: stats.dailyAverage.toFixed(1), inline: true }
    );

    // Tür bazlı istatistikler
    const typeStats = Object.entries(stats.byType)
      .filter(([type, count]) => count > 0)
      .map(([type, count]) => {
        const emoji = {
          'ban': '🔨',
          'kick': '👢',
          'mute': '🔇',
          'warn': '⚠️',
          'unban': '🔄',
          'unmute': '🔊'
        }[type] || '❓';
        
        return `${emoji} **${type}:** ${count}`;
      }).join('\n');

    if (typeStats) {
      embed.addFields({
        name: '⚖️ İşlem Türleri',
        value: typeStats,
        inline: true
      });
    }

    // Top moderatörler
    if (stats.topModerators.length > 0) {
      const modStats = stats.topModerators
        .slice(0, 5)
        .map((mod, index) => `${index + 1}. ${mod.tag}: ${mod.count}`)
        .join('\n');
      
      embed.addFields({
        name: '👮 En Aktif Moderatörler',
        value: modStats,
        inline: true
      });
    }

    embed.setFooter({ 
      text: `${guild.name} • Vaka İstatistikleri`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  // Yardımcı fonksiyonlar
  formatFilters(filters) {
    const filterTexts = [];
    
    if (filters.userId) filterTexts.push('👤 Kullanıcı');
    if (filters.moderatorId) filterTexts.push('👮 Moderatör');
    if (filters.type) filterTexts.push(`⚖️ ${filters.type}`);
    if (filters.active) filterTexts.push('🔴 Aktif');
    
    return filterTexts.length > 0 ? filterTexts.join(', ') : 'Yok';
  },

  async calculateCaseStats(guildId, startDate) {
    const pipeline = [
      {
        $match: {
          guildId: guildId,
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          active: { 
            $sum: { 
              $cond: [{ $eq: ['$active', true] }, 1, 0] 
            } 
          },
          byType: {
            $push: '$type'
          },
          moderators: {
            $push: {
              id: '$moderatorId',
              tag: '$moderatorTag'
            }
          }
        }
      }
    ];

    const result = await Moderation.aggregate(pipeline);
    const data = result[0] || { total: 0, active: 0, byType: [], moderators: [] };

    // Tür bazlı sayılar
    const typeCount = {};
    data.byType.forEach(type => {
      typeCount[type] = (typeCount[type] || 0) + 1;
    });

    // Moderatör istatistikleri
    const modCount = {};
    data.moderators.forEach(mod => {
      const key = `${mod.id}-${mod.tag}`;
      modCount[key] = (modCount[key] || 0) + 1;
    });

    const topModerators = Object.entries(modCount)
      .map(([key, count]) => {
        const [id, tag] = key.split('-');
        return { id, tag, count };
      })
      .sort((a, b) => b.count - a.count);

    // Günlük ortalama
    const daysDiff = Math.max(1, Math.ceil((new Date() - startDate) / (1000 * 60 * 60 * 24)));
    const dailyAverage = data.total / daysDiff;

    return {
      total: data.total,
      active: data.active,
      byType: typeCount,
      topModerators,
      dailyAverage
    };
  }
};





