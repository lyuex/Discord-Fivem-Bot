// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');
const config = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ozel-oda-kur')
        .setDescription('Özel oda sistemini kurar')
        .addChannelOption(option =>
            option.setName('kanal')
                .setDescription('Özel oda oluşturmak için tıklanacak kanal')
                .addChannelTypes(ChannelType.GuildVoice)
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('kategori')
                .setDescription('Özel odaların oluşturulacağı kategori')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const kanal = interaction.options.getChannel('kanal');
        const kategori = interaction.options.getChannel('kategori');

        try {
            // Konfigürasyonu güncelle
            const fs = require('fs');
            const configPath = './lyuex.json';
            const currentConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            
            currentConfig.ozel_oda.kanal_id = kanal.id;
            currentConfig.ozel_oda.kategori_id = kategori.id;
            
            fs.writeFileSync(configPath, JSON.stringify(currentConfig, null, 4));

            // Ana kanala özel isim ve açıklama ekle
            await kanal.edit({
                name: '🎵 Özel Oda Oluştur',
                topic: 'Bu kanala girerek özel odanızı oluşturabilirsiniz!'
            });

            const embed = new EmbedBuilder()
                .setTitle('✅ Özel Oda Sistemi Kuruldu')
                .setDescription(`
                **📍 Ana Kanal:** ${kanal}
                **📁 Kategori:** ${kategori}
                
                **📋 Sistem Özellikleri:**
                • Otomatik oda oluşturma
                • Kullanıcı ayrılınca otomatik silme
                • Maksimum ${config.ozel_oda.max_oda_sayisi} oda limiti
                • ${config.ozel_oda.bos_kalma_suresi / 1000} saniye boş kalma süresi
                • Rastgele oda isimleri
                • Detaylı log sistemi
                `)
                .setColor(0x00ff00)
                .setTimestamp()
                .setFooter({ text: 'ZYM CİTY Özel Oda Sistemi' });

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Özel oda kurulum hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Hata Oluştu')
                .setDescription('Özel oda sistemi kurulurken bir hata oluştu.')
                .setColor(0xff0000)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};