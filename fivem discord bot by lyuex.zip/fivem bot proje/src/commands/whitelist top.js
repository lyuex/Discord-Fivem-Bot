// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const logPath = path.join(__dirname, '../../db/whitelistLogs.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wl-top')
    .setDescription('Bu ay en çok whitelist yapan yetkilileri gösterir.'),

  async execute(interaction) {
  // Klasör + dosya yoksa oluştur
  const dir = path.dirname(logPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(logPath)) fs.writeFileSync(logPath, JSON.stringify({}));

  const rawData = fs.readFileSync(logPath);
  const data = JSON.parse(rawData);

  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  if (!data[currentMonth] || Object.keys(data[currentMonth]).length === 0) {
    return interaction.reply('Bu ay için whitelist kaydı bulunmamaktadır.');
  }

    const sorted = Object.entries(data[currentMonth])
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);

    const list = sorted.map(
      ([userId, count], index) => `${index + 1}. <@${userId}> • Kayıt: \`${count}\``
    ).join('\n');

    const embed = new EmbedBuilder()
      .setTitle(`📊 ${currentMonth} Ayı En Çok Whitelist Yapanlar`)
      .setDescription(list)
      .setColor(0x00AEEF)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};








