// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits,
    ComponentType 
} = require('discord.js');
const lyuex = require('../../lyuex.json');

// Rate limiting için Map
const cooldowns = new Map();
const COOLDOWN_TIME = 10000; // 10 saniye

// Rol yedekleme sistemi
const roleBackups = new Map();

// İşlem sayaçları
const processingStats = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kayitsiz')
        .setDescription('🚫 Üyeleri kayıtsız yapar - rolleri alır ve kayıtsız rolü verir')
        .addStringOption(option =>
            option.setName('sebep')
            .setDescription('📝 Kayıtsıza atma sebebi (zorunlu)')
            .setRequired(true)
            .setMaxLength(200))
        .addBooleanOption(option =>
            option.setName('yedekle')
            .setDescription('💾 Rolleri yedekle (geri verme için)')
            .setRequired(false))
        .addBooleanOption(option =>
            option.setName('onaysiz')
            .setDescription('⚡ Onay almadan direkt işlem yap')
            .setRequired(false))
        .addUserOption(option =>
            option.setName('hedef_uye')
            .setDescription('👤 Tek bir üyeyi hızlıca kayıtsıza at')
            .setRequired(false))
        .addBooleanOption(option =>
            option.setName('geri_al')
            .setDescription('🔄 Son kayıtsıza atma işlemini geri al')
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        try {
            // Cooldown kontrolü
            const userId = interaction.user.id;
            const now = Date.now();
            const cooldownAmount = cooldowns.get(userId);

            if (cooldownAmount && (now < cooldownAmount + COOLDOWN_TIME)) {
                const timeLeft = Math.ceil((cooldownAmount + COOLDOWN_TIME - now) / 1000);
                const cooldownEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('⏱️ Yavaş Ol!')
                    .setDescription(`Bu komutu tekrar kullanabilmek için **${timeLeft}** saniye beklemelisin.`)
                    .addFields(
                        { name: '🔄 Cooldown Süresi', value: `${COOLDOWN_TIME / 1000} saniye`, inline: true },
                        { name: '⏰ Kalan Süre', value: `${timeLeft} saniye`, inline: true }
                    )
                    .setFooter({ text: 'Anti-Spam Koruması', iconURL: interaction.user.displayAvatarURL() });
                return await interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
            }

            const reason = interaction.options.getString('sebep');
            const shouldBackup = interaction.options.getBoolean('yedekle') ?? true;
            const skipConfirmation = interaction.options.getBoolean('onaysiz') ?? false;
            const targetUser = interaction.options.getUser('hedef_uye');
            const undoOperation = interaction.options.getBoolean('geri_al') ?? false;

            // Geri alma işlemi
            if (undoOperation) {
                return await handleUndoOperation(interaction);
            }

            // Tek üye hızlı işlemi
            if (targetUser) {
                return await handleSingleMember(interaction, targetUser, reason, shouldBackup);
            }

            // Yetki kontrolü
            const hasManageRoles = interaction.member.permissions.has(PermissionFlagsBits.ManageRoles);
            const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
            const authorizedRoles = lyuex.yetkili.rol || [];
            const hasAuthorizedRole = authorizedRoles.some(roleId => interaction.member.roles.cache.has(roleId));

            // Sebep validasyonu
            if (!reason || reason.trim().length < 3) {
                const reasonEmbed = new EmbedBuilder()
                    .setColor(0xFF9F43)
                    .setTitle('📝 Geçersiz Sebep')
                    .setDescription('Kayıtsıza atma sebebi en az 3 karakter olmalıdır.')
                    .addFields(
                        { name: '✅ Doğru Örnekler', value: '• Spam yapıyor\n• Sunucu kurallarını ihlal\n• Uygunsuz davranış', inline: false },
                        { name: '❌ Yanlış Örnekler', value: '• ...\n• test\n• -', inline: false }
                    )
                    .setFooter({ text: 'Lütfen açık ve anlaşılır bir sebep yazın', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [reasonEmbed], ephemeral: true });
            }

            if (!hasManageRoles && !isAdmin && !hasAuthorizedRole) {
                const permEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('🔒 Yetersiz Yetki')
                    .setDescription('Bu komutu kullanmak için gerekli yetkilere sahip değilsin.')
                    .addFields(
                        { name: '📋 Gerekli Yetkiler', value: '• Rolleri Yönet\n• Yönetici\n• Yetkili Rolleri', inline: false },
                        { name: '👤 Mevcut Yetkilerin', value: interaction.member.permissions.toArray().slice(0, 5).join(', ') || 'Temel yetkiler', inline: false }
                    )
                    .setFooter({ text: 'Yetki Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [permEmbed], ephemeral: true });
            }

            // Kayıtsız rolü kontrolü
            const kayitsizRoleId = lyuex.rol.kayıtsız;
            if (!kayitsizRoleId) {
                const configEmbed = new EmbedBuilder()
                    .setColor(0xFF9F43)
                    .setTitle('⚙️ Yapılandırma Hatası')
                    .setDescription('Kayıtsız rol ID\'si tanımlanmamış.')
                    .addFields(
                        { name: '🔧 Düzeltme', value: '`lyuex.json` dosyasında `rol.kayıtsız` değerini ayarlayın', inline: false }
                    )
                    .setFooter({ text: 'Yapılandırma Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [configEmbed], ephemeral: true });
            }

            const kayitsizRole = interaction.guild.roles.cache.get(kayitsizRoleId);
            if (!kayitsizRole) {
                const roleEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('❌ Rol Bulunamadı')
                    .setDescription(`Kayıtsız rolü (ID: \`${kayitsizRoleId}\`) sunucuda bulunamadı.`)
                    .addFields(
                        { name: '🔧 Çözüm', value: '• Rolün silinip silinmediğini kontrol edin\n• ID\'nin doğru olduğunu kontrol edin', inline: false }
                    )
                    .setFooter({ text: 'Rol Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [roleEmbed], ephemeral: true });
            }

            await interaction.deferReply({ ephemeral: true });

            // Üyeleri getir (sayfalama ile)
            const allMembers = await interaction.guild.members.fetch();
            const eligibleMembers = allMembers
                .filter(member => 
                    !member.user.bot && 
                    !member.roles.cache.has(kayitsizRoleId) && // Zaten kayıtsız değil
                    member.id !== interaction.guild.ownerId && // Sunucu sahibi değil
                    !member.permissions.has(PermissionFlagsBits.Administrator) // Yönetici değil (güvenlik)
                )
                .sort((a, b) => a.user.username.localeCompare(b.user.username));

            if (eligibleMembers.size === 0) {
                const noMembersEmbed = new EmbedBuilder()
                    .setColor(0x95AFC0)
                    .setTitle('👥 Üye Bulunamadı')
                    .setDescription('Kayıtsıza atılabilecek üye bulunamadı.')
                    .addFields(
                        { name: '📊 Filtreleme Kuralları', value: '• Bot hesapları hariç\n• Zaten kayıtsız olanlar hariç\n• Sunucu sahibi hariç\n• Yöneticiler hariç', inline: false },
                        { name: '👥 Toplam Üye', value: allMembers.size.toString(), inline: true },
                        { name: '🤖 Bot Sayısı', value: allMembers.filter(m => m.user.bot).size.toString(), inline: true }
                    )
                    .setFooter({ text: 'Üye Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.editReply({ embeds: [noMembersEmbed] });
            }

            // Sayfalama sistemi
            const ITEMS_PER_PAGE = 25;
            const pages = Math.ceil(eligibleMembers.size / ITEMS_PER_PAGE);
            let currentPage = 0;

            const generateMemberOptions = (page) => {
                const start = page * ITEMS_PER_PAGE;
                const end = start + ITEMS_PER_PAGE;
                return eligibleMembers
                    .map(member => member)
                    .slice(start, end)
                    .map(member => ({
                        label: `${member.user.username} (${member.roles.cache.size - 1} rol)`,
                        description: `ID: ${member.id}`,
                        value: member.id
                    }));
            };

            const generateEmbed = (page) => {
                const start = page * ITEMS_PER_PAGE;
                const end = Math.min(start + ITEMS_PER_PAGE, eligibleMembers.size);
                
                return new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('🚫 Kayıtsıza Atma Sistemi')
                    .setDescription(`Kayıtsıza atılacak üyeleri seçin. Seçtiğiniz üyelerin **tüm rolleri alınacak** ve kayıtsız rolü verilecek.`)
                    .addFields(
                        { name: '👥 Toplam Üye', value: `${eligibleMembers.size} üye`, inline: true },
                        { name: '📄 Sayfa', value: `${page + 1}/${pages}`, inline: true },
                        { name: '📊 Bu Sayfa', value: `${start + 1}-${end} arası`, inline: true },
                        { name: '📝 Sebep', value: reason, inline: false },
                        { name: '💾 Rol Yedekleme', value: shouldBackup ? '✅ Aktif' : '❌ Pasif', inline: true },
                        { name: '⚡ Onay Sistemi', value: skipConfirmation ? '❌ Atlandı' : '✅ Aktif', inline: true }
                    )
                    .setFooter({ text: `Kayıtsız Sistemi • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp();
            };

            const generateComponents = (page) => {
                const components = [];
                
                // Select menu
                const options = generateMemberOptions(page);
                if (options.length > 0) {
                    const selectMenu = new StringSelectMenuBuilder()
                        .setCustomId('select_members')
                        .setPlaceholder(`📋 ${options.length} üye arasından seçin`)
                        .setMinValues(1)
                        .setMaxValues(options.length)
                        .addOptions(options);
                    components.push(new ActionRowBuilder().addComponents(selectMenu));
                }

                // Navigation and action buttons
                const navigationRow = new ActionRowBuilder();
                
                if (pages > 1) {
                    navigationRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId('prev_page')
                            .setLabel('◀️ Önceki')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(page === 0),
                        new ButtonBuilder()
                            .setCustomId('next_page')
                            .setLabel('▶️ Sonraki')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(page === pages - 1)
                    );
                }

                navigationRow.addComponents(
                    new ButtonBuilder()
                        .setCustomId('select_all')
                        .setLabel('👥 Tümünü Seç')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('cancel_operation')
                        .setLabel('❌ İptal')
                        .setStyle(ButtonStyle.Danger)
                );

                components.push(navigationRow);
                return components;
            };

            const response = await interaction.editReply({
                embeds: [generateEmbed(currentPage)],
                components: generateComponents(currentPage)
            });

            const collector = response.createMessageComponentCollector({
                filter: i => i.user.id === interaction.user.id,
                time: 300000 // 5 dakika
            });

            let selectedMembers = new Set();

            collector.on('collect', async i => {
                try {
                    if (i.componentType === ComponentType.StringSelect) {
                        if (i.customId === 'select_members') {
                            selectedMembers = new Set(i.values);
                            await i.deferUpdate();
                            
                            // Seçilen üyeleri göster
                            const selectedEmbed = new EmbedBuilder()
                                .setColor(0x54A0FF)
                                .setTitle('✅ Üyeler Seçildi')
                                .setDescription(`**${selectedMembers.size}** üye kayıtsıza atılmak için seçildi.`)
                                .addFields(
                                    { name: '👥 Seçilen Üyeler', value: Array.from(selectedMembers).map(id => `<@${id}>`).join('\n').slice(0, 1024), inline: false },
                                    { name: '📝 Sebep', value: reason, inline: true },
                                    { name: '💾 Yedekleme', value: shouldBackup ? '✅ Aktif' : '❌ Pasif', inline: true }
                                )
                                .setFooter({ text: 'Devam etmek için Onayla butonuna basın', iconURL: interaction.user.displayAvatarURL() });

                            const confirmRow = new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId('confirm_kayitsiz')
                                        .setLabel('✅ Onayla ve Uygula')
                                        .setStyle(ButtonStyle.Success),
                                    new ButtonBuilder()
                                        .setCustomId('back_to_selection')
                                        .setLabel('🔙 Geri Dön')
                                        .setStyle(ButtonStyle.Secondary),
                                    new ButtonBuilder()
                                        .setCustomId('cancel_operation')
                                        .setLabel('❌ İptal')
                                        .setStyle(ButtonStyle.Danger)
                                );

                            await interaction.editReply({
                                embeds: [selectedEmbed],
                                components: [confirmRow]
                            });
                        }
                    } else if (i.componentType === ComponentType.Button) {
                        if (i.customId === 'prev_page') {
                            currentPage = Math.max(0, currentPage - 1);
                            await i.update({
                                embeds: [generateEmbed(currentPage)],
                                components: generateComponents(currentPage)
                            });
                        } else if (i.customId === 'next_page') {
                            currentPage = Math.min(pages - 1, currentPage + 1);
                            await i.update({
                                embeds: [generateEmbed(currentPage)],
                                components: generateComponents(currentPage)
                            });
                        } else if (i.customId === 'select_all') {
                            selectedMembers = new Set(eligibleMembers.map(m => m.id));
                            await i.deferUpdate();
                            
                            const allSelectedEmbed = new EmbedBuilder()
                                .setColor(0xFF9F43)
                                .setTitle('⚠️ Tüm Üyeler Seçildi')
                                .setDescription(`**${selectedMembers.size}** üyenin **TÜMÜ** kayıtsıza atılacak!`)
                                .addFields(
                                    { name: '🚨 Uyarı', value: 'Bu işlem geri alınamaz (yedekleme aktif değilse)', inline: false },
                                    { name: '👥 Toplam Üye', value: selectedMembers.size.toString(), inline: true },
                                    { name: '💾 Yedekleme', value: shouldBackup ? '✅ Aktif' : '❌ Pasif', inline: true },
                                    { name: '📝 Sebep', value: reason, inline: true }
                                )
                                .setFooter({ text: 'Bu kritik bir işlemdir, dikkatli olun!', iconURL: interaction.guild.iconURL() });

                            const confirmRow = new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder()
                                        .setCustomId('confirm_kayitsiz')
                                        .setLabel(`✅ ${selectedMembers.size} Üyeyi Kayıtsıza At`)
                                        .setStyle(ButtonStyle.Danger),
                                    new ButtonBuilder()
                                        .setCustomId('back_to_selection')
                                        .setLabel('🔙 Geri Dön')
                                        .setStyle(ButtonStyle.Secondary)
                                );

                            await interaction.editReply({
                                embeds: [allSelectedEmbed],
                                components: [confirmRow]
                            });
                        } else if (i.customId === 'back_to_selection') {
                            await i.update({
                                embeds: [generateEmbed(currentPage)],
                                components: generateComponents(currentPage)
                            });
                        } else if (i.customId === 'confirm_kayitsiz') {
                            await performKayitsizOperation(i, selectedMembers, reason, shouldBackup, interaction);
                            cooldowns.set(userId, now);
                            collector.stop();
                        } else if (i.customId === 'cancel_operation') {
                            const cancelEmbed = new EmbedBuilder()
                                .setColor(0x95AFC0)
                                .setTitle('❌ İşlem İptal Edildi')
                                .setDescription('Kayıtsıza atma işlemi iptal edildi.')
                                .setFooter({ text: 'İptal Edildi', iconURL: interaction.user.displayAvatarURL() });
                            await i.update({ embeds: [cancelEmbed], components: [] });
                            collector.stop();
                        }
                    }
                } catch (error) {
                    console.error('Collector hata:', error);
                    await i.reply({ content: '❌ Bir hata oluştu, lütfen tekrar deneyin.', ephemeral: true }).catch(() => {});
                }
            });

            collector.on('end', async collected => {
                if (collected.size === 0) {
                    const timeoutEmbed = new EmbedBuilder()
                        .setColor(0xFF6B6B)
                        .setTitle('⏰ Zaman Aşımı')
                        .setDescription('Kayıtsıza atma işlemi zaman aşımına uğradı.')
                        .setFooter({ text: 'İşlem İptal Edildi', iconURL: interaction.user.displayAvatarURL() });
                    try {
                        await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
                    } catch (error) {
                        console.error('Timeout mesajı güncellenemedi:', error);
                    }
                }
            });

        } catch (error) {
            console.error('Kayıtsız komutunda hata:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF6B6B)
                .setTitle('❌ Sistem Hatası')
                .setDescription('Kayıtsıza atma işlemi sırasında bir hata oluştu.')
                .addFields(
                    { name: '🔧 Hata Kodu', value: error.code || 'Bilinmiyor', inline: true },
                    { name: '📝 Hata Mesajı', value: error.message || 'Detay yok', inline: true }
                )
                .setFooter({ text: 'Hata Sistemi', iconURL: interaction.user.displayAvatarURL() });
            
            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed], components: [] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },
};

async function performKayitsizOperation(interaction, selectedMembers, reason, shouldBackup, originalInteraction) {
    try {
        const kayitsizRoleId = lyuex.rol.kayıtsız;
        const memberArray = Array.from(selectedMembers);
        
        // Progress tracking
        let processedCount = 0;
        let successCount = 0;
        let errorCount = 0;
        const errors = [];

        // İşlem başlangıç embed'i
        const progressEmbed = new EmbedBuilder()
            .setColor(0xFECA57)
            .setTitle('⏳ İşlem Başlatıldı')
            .setDescription(`**${memberArray.length}** üye için kayıtsıza atma işlemi başlatıldı...`)
            .addFields(
                { name: '📊 İlerleme', value: `0/${memberArray.length}`, inline: true },
                { name: '✅ Başarılı', value: '0', inline: true },
                { name: '❌ Hatalı', value: '0', inline: true }
            )
            .setFooter({ text: 'İşlem devam ediyor...', iconURL: originalInteraction.guild.iconURL() });

        await interaction.update({ embeds: [progressEmbed], components: [] });

        const startTime = Date.now();

        // Her üye için işlem
        for (const memberId of memberArray) {
            try {
                const member = originalInteraction.guild.members.cache.get(memberId);
                if (!member) {
                    errorCount++;
                    errors.push({ memberId, error: 'Üye bulunamadı' });
                    continue;
                }

                // Rol yedekleme
                if (shouldBackup) {
                    const currentRoles = member.roles.cache
                        .filter(role => role.id !== originalInteraction.guild.id) // @everyone hariç
                        .map(role => role.id);
                    
                    if (currentRoles.length > 0) {
                        roleBackups.set(memberId, {
                            roles: currentRoles,
                            backupDate: Date.now(),
                            backupBy: originalInteraction.user.id,
                            reason: reason
                        });
                    }
                }

                // Mevcut rolleri kaldır
                const rolesToRemove = member.roles.cache.filter(role => role.id !== originalInteraction.guild.id);
                if (rolesToRemove.size > 0) {
                    await member.roles.remove(rolesToRemove, `Kayıtsıza atıldı: ${reason}`);
                }

                // Kayıtsız rolü ver
                await member.roles.add(kayitsizRoleId, `Kayıtsıza atıldı: ${reason}`);
                
                successCount++;
                
                // Her 5 üyede bir progress güncelle
                if ((processedCount + 1) % 5 === 0 || processedCount === memberArray.length - 1) {
                    const currentProgress = Math.round(((processedCount + 1) / memberArray.length) * 100);
                    const progressBar = '█'.repeat(Math.floor(currentProgress / 10)) + '░'.repeat(10 - Math.floor(currentProgress / 10));
                    
                    const updateEmbed = new EmbedBuilder()
                        .setColor(0xFECA57)
                        .setTitle('⏳ İşlem Devam Ediyor')
                        .setDescription(`\`\`\`${progressBar} ${currentProgress}%\`\`\``)
                        .addFields(
                            { name: '📊 İlerleme', value: `${processedCount + 1}/${memberArray.length}`, inline: true },
                            { name: '✅ Başarılı', value: successCount.toString(), inline: true },
                            { name: '❌ Hatalı', value: errorCount.toString(), inline: true }
                        )
                        .setFooter({ text: `Son işlenen: ${member.user.tag}`, iconURL: originalInteraction.guild.iconURL() });

                    await interaction.editReply({ embeds: [updateEmbed] }).catch(() => {});
                }

            } catch (error) {
                console.error(`${memberId} için kayıtsız hatası:`, error);
                errorCount++;
                errors.push({ memberId, error: error.message });
            }
            
            processedCount++;
        }

        const endTime = Date.now();
        const duration = Math.round((endTime - startTime) / 1000);

        // Final sonuç embed'i
        const resultEmbed = new EmbedBuilder()
            .setColor(errorCount > 0 ? '#ff9f43' : '#2ed573')
            .setTitle('✅ İşlem Tamamlandı')
            .setDescription(`Kayıtsıza atma işlemi **${duration}** saniyede tamamlandı.`)
            .addFields(
                { name: '👥 Toplam İşlem', value: memberArray.length.toString(), inline: true },
                { name: '✅ Başarılı', value: successCount.toString(), inline: true },
                { name: '❌ Hatalı', value: errorCount.toString(), inline: true },
                { name: '📝 Sebep', value: reason, inline: false },
                { name: '💾 Yedekleme', value: shouldBackup ? `✅ ${successCount} üyenin rolleri yedeklendi` : '❌ Yedekleme yapılmadı', inline: false },
                { name: '⏱️ Süre', value: `${duration} saniye`, inline: true }
            )
            .setFooter({ text: `Kayıtsız Sistemi • ${originalInteraction.guild.name}`, iconURL: originalInteraction.guild.iconURL() })
            .setTimestamp();

        if (errors.length > 0 && errors.length <= 5) {
            const errorText = errors.map(e => `• <@${e.memberId}>: ${e.error}`).join('\n');
            resultEmbed.addFields({ name: '❌ Hatalar', value: errorText.slice(0, 1024), inline: false });
        }

        await interaction.editReply({ embeds: [resultEmbed], components: [] });

        // Log kanalına gönder
        const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
        if (logChannelId && successCount > 0) {
            const logChannel = originalInteraction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('🚫 Kayıtsıza Atma Logu')
                    .setDescription(`**${successCount}** üye kayıtsıza atıldı.`)
                    .addFields(
                        { name: '👮 İşlemi Yapan', value: `${originalInteraction.user.tag}\n<@${originalInteraction.user.id}>\n\`${originalInteraction.user.id}\``, inline: true },
                        { name: '📊 İstatistikler', value: `**Toplam:** ${memberArray.length}\n**Başarılı:** ${successCount}\n**Hatalı:** ${errorCount}`, inline: true },
                        { name: '📝 Sebep', value: reason, inline: false },
                        { name: '💾 Rol Yedekleme', value: shouldBackup ? '✅ Aktif' : '❌ Pasif', inline: true },
                        { name: '⏱️ İşlem Süresi', value: `${duration} saniye`, inline: true },
                        { name: '📍 Kanal', value: `<#${originalInteraction.channel.id}>`, inline: true }
                    )
                    .setThumbnail(originalInteraction.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: `Kayıtsız Sistemi • ${originalInteraction.guild.name}`, iconURL: originalInteraction.guild.iconURL() })
                    .setTimestamp();

                if (successCount <= 20) {
                    const memberList = memberArray
                        .slice(0, successCount)
                        .map(id => `<@${id}>`)
                        .join(', ');
                    logEmbed.addFields({ name: '👥 Kayıtsıza Atılan Üyeler', value: memberList.slice(0, 1024), inline: false });
                }

                await logChannel.send({ embeds: [logEmbed] }).catch(console.error);
            }
        }

        // İstatistik güncelle
        updateKayitsizStats(originalInteraction.guild.id, successCount, errorCount, originalInteraction.user.id);

        // Webhook bildirimi (varsa)
        await sendWebhookNotification(originalInteraction, memberArray, successCount, reason);

    } catch (error) {
        console.error('Kayıtsız işlemi sırasında hata:', error);
        const errorEmbed = new EmbedBuilder()
            .setColor(0xFF6B6B)
            .setTitle('❌ İşlem Hatası')
            .setDescription('Kayıtsıza atma işlemi sırasında kritik bir hata oluştu.')
            .addFields(
                { name: '🔧 Hata Detayı', value: error.message || 'Bilinmeyen hata', inline: false }
            )
            .setFooter({ text: 'Hata Sistemi', iconURL: originalInteraction.user.displayAvatarURL() });

        await interaction.editReply({ embeds: [errorEmbed], components: [] }).catch(() => {});
    }
}

// Tek üye hızlı işlemi
async function handleSingleMember(interaction, targetUser, reason, shouldBackup) {
    try {
        await interaction.deferReply({ ephemeral: true });
        
        const member = interaction.guild.members.cache.get(targetUser.id);
        if (!member) {
            const notFoundEmbed = new EmbedBuilder()
                .setColor(0xFF6B6B)
                .setTitle('❌ Üye Bulunamadı')
                .setDescription(`<@${targetUser.id}> bu sunucuda bulunamadı.`)
                .setFooter({ text: 'Hızlı Kayıtsız Sistemi', iconURL: interaction.guild.iconURL() });
            return await interaction.editReply({ embeds: [notFoundEmbed] });
        }

        const kayitsizRoleId = lyuex.rol.kayıtsız;
        if (member.roles.cache.has(kayitsizRoleId)) {
            const alreadyEmbed = new EmbedBuilder()
                .setColor(0xFF9F43)
                .setTitle('⚠️ Zaten Kayıtsız')
                .setDescription(`**${member.user.tag}** zaten kayıtsız durumda.`)
                .setFooter({ text: 'Hızlı Kayıtsız Sistemi', iconURL: interaction.guild.iconURL() });
            return await interaction.editReply({ embeds: [alreadyEmbed] });
        }

        // Rol yedekleme
        if (shouldBackup) {
            const currentRoles = member.roles.cache
                .filter(role => role.id !== interaction.guild.id)
                .map(role => role.id);
            
            if (currentRoles.length > 0) {
                roleBackups.set(member.id, {
                    roles: currentRoles,
                    backupDate: Date.now(),
                    backupBy: interaction.user.id,
                    reason: reason
                });
            }
        }

        // İşlem
        const rolesToRemove = member.roles.cache.filter(role => role.id !== interaction.guild.id);
        await member.roles.remove(rolesToRemove, `Hızlı kayıtsız: ${reason}`);
        await member.roles.add(kayitsizRoleId, `Hızlı kayıtsız: ${reason}`);

        const successEmbed = new EmbedBuilder()
            .setColor(0x2ED573)
            .setTitle('⚡ Hızlı Kayıtsız Tamamlandı')
            .setDescription(`**${member.user.tag}** başarıyla kayıtsıza atıldı!`)
            .addFields(
                { name: '👤 Üye', value: `<@${member.id}>`, inline: true },
                { name: '📝 Sebep', value: reason, inline: true },
                { name: '💾 Yedekleme', value: shouldBackup ? '✅ Aktif' : '❌ Pasif', inline: true },
                { name: '⏱️ İşlem Süresi', value: '< 1 saniye', inline: true }
            )
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'Hızlı Kayıtsız Sistemi', iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        await interaction.editReply({ embeds: [successEmbed] });

        // Log
        const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
        if (logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('⚡ Hızlı Kayıtsız Logu')
                    .setDescription('Tek üye hızlı kayıtsıza atıldı.')
                    .addFields(
                        { name: '👮 İşlemi Yapan', value: `${interaction.user.tag}\n<@${interaction.user.id}>`, inline: true },
                        { name: '👤 Kayıtsıza Atılan', value: `${member.user.tag}\n<@${member.id}>`, inline: true },
                        { name: '📝 Sebep', value: reason, inline: false }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp();
                await logChannel.send({ embeds: [logEmbed] });
            }
        }

    } catch (error) {
        console.error('Hızlı kayıtsız hatası:', error);
        const errorEmbed = new EmbedBuilder()
            .setColor(0xFF6B6B)
            .setTitle('❌ Hızlı İşlem Hatası')
            .setDescription('Hızlı kayıtsız işlemi başarısız.')
            .setFooter({ text: 'Hata Sistemi', iconURL: interaction.user.displayAvatarURL() });
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Geri alma işlemi
async function handleUndoOperation(interaction) {
    try {
        await interaction.deferReply({ ephemeral: true });

        if (roleBackups.size === 0) {
            const noBackupEmbed = new EmbedBuilder()
                .setColor(0x95AFC0)
                .setTitle('📦 Yedek Bulunamadı')
                .setDescription('Geri alınabilecek kayıtsız işlemi bulunamadı.')
                .addFields(
                    { name: '💡 İpucu', value: 'Sadece rol yedekleme aktifken yapılan işlemler geri alınabilir', inline: false }
                )
                .setFooter({ text: 'Geri Alma Sistemi', iconURL: interaction.guild.iconURL() });
            return await interaction.editReply({ embeds: [noBackupEmbed] });
        }

        // Son 10 yedeği listele
        const recentBackups = Array.from(roleBackups.entries())
            .sort((a, b) => b[1].backupDate - a[1].backupDate)
            .slice(0, 10);

        const backupOptions = recentBackups.map((backup, index) => {
            const [userId, data] = backup;
            const member = interaction.guild.members.cache.get(userId);
            const timeAgo = Math.floor((Date.now() - data.backupDate) / 1000 / 60);
            return {
                label: `${member?.user.username || 'Bilinmeyen Üye'} (${timeAgo}dk önce)`,
                description: `Sebep: ${data.reason.slice(0, 50)}`,
                value: userId
            };
        });

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('select_undo_member')
            .setPlaceholder('🔄 Geri alınacak üyeyi seçin')
            .addOptions(backupOptions);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const undoEmbed = new EmbedBuilder()
            .setColor(0x54A0FF)
            .setTitle('🔄 Geri Alma Sistemi')
            .setDescription(`**${recentBackups.length}** adet geri alınabilir işlem bulundu.`)
            .addFields(
                { name: '📊 Toplam Yedek', value: roleBackups.size.toString(), inline: true },
                { name: '⏱️ Son 10 İşlem', value: 'Aşağıdan seçin', inline: true }
            )
            .setFooter({ text: 'Geri almak istediğiniz üyeyi seçin', iconURL: interaction.guild.iconURL() });

        const response = await interaction.editReply({ embeds: [undoEmbed], components: [row] });

        const collector = response.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id,
            time: 60000
        });

        collector.on('collect', async i => {
            const selectedUserId = i.values[0];
            const backup = roleBackups.get(selectedUserId);
            const member = interaction.guild.members.cache.get(selectedUserId);

            if (!member || !backup) {
                await i.reply({ content: '❌ Üye veya yedek bulunamadı.', ephemeral: true });
                return;
            }

            try {
                // Kayıtsız rolünü kaldır
                const kayitsizRoleId = lyuex.rol.kayıtsız;
                await member.roles.remove(kayitsizRoleId);

                // Eski rolleri geri ver
                const validRoles = backup.roles.filter(roleId => 
                    interaction.guild.roles.cache.has(roleId)
                );
                
                if (validRoles.length > 0) {
                    await member.roles.add(validRoles);
                }

                roleBackups.delete(selectedUserId);

                const successEmbed = new EmbedBuilder()
                    .setColor(0x2ED573)
                    .setTitle('✅ Geri Alma Başarılı')
                    .setDescription(`**${member.user.tag}** için kayıtsız işlemi geri alındı!`)
                    .addFields(
                        { name: '👤 Üye', value: `<@${member.id}>`, inline: true },
                        { name: '🔄 Geri Verilen Rol', value: `${validRoles.length} adet`, inline: true },
                        { name: '📅 Yedek Tarihi', value: `<t:${Math.floor(backup.backupDate / 1000)}:R>`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp();

                await i.update({ embeds: [successEmbed], components: [] });

            } catch (error) {
                console.error('Geri alma hatası:', error);
                await i.reply({ content: '❌ Geri alma işlemi başarısız.', ephemeral: true });
            }
        });

        collector.on('end', async collected => {
            if (collected.size === 0) {
                const timeoutEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('⏰ Zaman Aşımı')
                    .setDescription('Geri alma işlemi zaman aşımına uğradı.');
                try {
                    await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
                } catch (error) {
                    console.error('Timeout mesajı güncellenemedi:', error);
                }
            }
        });

    } catch (error) {
        console.error('Geri alma işlemi hatası:', error);
        const errorEmbed = new EmbedBuilder()
            .setColor(0xFF6B6B)
            .setTitle('❌ Geri Alma Hatası')
            .setDescription('Geri alma işlemi sırasında bir hata oluştu.');
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// İstatistik güncelleme
function updateKayitsizStats(guildId, successCount, errorCount, userId) {
    try {
        if (!processingStats.has(guildId)) {
            processingStats.set(guildId, {
                totalOperations: 0,
                totalSuccess: 0,
                totalErrors: 0,
                lastOperation: null,
                topUsers: new Map()
            });
        }

        const stats = processingStats.get(guildId);
        stats.totalOperations++;
        stats.totalSuccess += successCount;
        stats.totalErrors += errorCount;
        stats.lastOperation = Date.now();

        // Kullanıcı istatistikleri
        if (!stats.topUsers.has(userId)) {
            stats.topUsers.set(userId, { operations: 0, success: 0 });
        }
        const userStats = stats.topUsers.get(userId);
        userStats.operations++;
        userStats.success += successCount;

        processingStats.set(guildId, stats);
    } catch (error) {
        console.error('İstatistik güncelleme hatası:', error);
    }
}

// Webhook bildirimi
async function sendWebhookNotification(interaction, memberArray, successCount, reason) {
    try {
        // Webhook URL'si varsa (lyuex.json'da tanımlanmışsa)
        if (lyuex.webhook?.kayitsiz_url) {
            const webhookData = {
                embeds: [{
                    title: "🚫 Kayıtsız İşlemi",
                    description: `**${successCount}** üye kayıtsıza atıldı`,
                    color: 0xe74c3c,
                    fields: [
                        { name: "👮 Yetkili", value: interaction.user.tag, inline: true },
                        { name: "📊 Toplam", value: memberArray.length.toString(), inline: true },
                        { name: "📝 Sebep", value: reason, inline: false }
                    ],
                    timestamp: new Date().toISOString(),
                    footer: { text: interaction.guild.name }
                }]
            };

            // Webhook çağrısı burada yapılabilir
            // await fetch(lyuex.webhook.kayitsiz_url, { ... });
        }
    } catch (error) {
        console.error('Webhook bildirimi hatası:', error);
    }
}





