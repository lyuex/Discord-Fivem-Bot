// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rol-ver')
        .setDescription('👑 Kullanıcıya rol ver (Yetkili/Bot sahipleri)')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false)
        .addUserOption(option =>
            option
                .setName('kullanıcı')
                .setDescription('Rol verilecek kullanıcı')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option
                .setName('rol')
                .setDescription('Verilecek rol')
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName('sebep')
                .setDescription('Rol verme sebebi')
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName('nick')
                .setDescription('Kullanıcının nick\'ini değiştir (opsiyonel)')
                .setRequired(false)
        ),

    async execute(interaction) {
        // Sadece belirtilen role sahip kullanıcılar kullanabilir
        const allowedRoleId = '1424063580340490351';

        if (!interaction.member.roles.cache.has(allowedRoleId)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('❌ Yetkisiz Erişim')
                        .setDescription('Bu komut sadece belirtilen yetkili role sahip kullanıcılar tarafından kullanılabilir!')
                        .addFields(
                            { name: '🔒 Gerekli Rol', value: `<@&${allowedRoleId}>`, inline: false },
                            { name: '👤 Sen', value: `${interaction.user} (${interaction.user.tag})`, inline: true }
                        )
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }

        const targetUser = interaction.options.getUser('kullanıcı');
        const targetRole = interaction.options.getRole('rol');
        const sebep = interaction.options.getString('sebep') || 'Sebep belirtilmedi';
        const yeniNick = interaction.options.getString('nick');

        try {
            // Hedef kullanıcıyı sunucuda bul
            const targetMember = await interaction.guild.members.fetch(targetUser.id);
            
            if (!targetMember) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFF4444)
                        .setTitle('❌ Kullanıcı Bulunamadı')
                        .setDescription(`**${targetUser.tag}** bu sunucuda bulunamadı!`)
                        .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            // Bot'un rol yetkisini kontrol et
            const botMember = interaction.guild.members.me;
            if (targetRole.position >= botMember.roles.highest.position) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFF4444)
                        .setTitle('❌ Yetkisiz Rol')
                        .setDescription('Bu rol botun en yüksek rolünden daha yüksek konumda!')
                        .addFields(
                            { name: '🤖 Bot En Yüksek Rol', value: `**${botMember.roles.highest.name}** (Pozisyon: ${botMember.roles.highest.position})`, inline: true },
                            { name: '🎯 Hedef Rol', value: `**${targetRole.name}** (Pozisyon: ${targetRole.position})`, inline: true }
                        )
                        .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            // Kullanıcının zaten bu role sahip olup olmadığını kontrol et
            if (targetMember.roles.cache.has(targetRole.id)) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFFA500)
                        .setTitle('⚠️ Rol Zaten Mevcut')
                        .setDescription(`**${targetUser.tag}** zaten **${targetRole.name}** rolüne sahip!`)
                        .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            await interaction.deferReply();

            // Rolü ver
            await targetMember.roles.add(targetRole, `Rol verme komutu | Yetkili: ${interaction.user.tag} | Sebep: ${sebep}`);

            // Nick değiştirme (eğer belirtilmişse)
            let nickDegisti = false;
            if (yeniNick) {
                try {
                    await targetMember.setNickname(yeniNick, `Rol verme komutu ile isim değişikliği | Yetkili: ${interaction.user.tag}`);
                    nickDegisti = true;
                } catch (nickError) {
                    console.error('Nick değiştirme hatası:', nickError);
                    nickDegisti = false;
                }
            }

            // Başarı mesajı
            const successEmbed = new EmbedBuilder()
                .setColor(0x00FF88)
                .setTitle('✅ Rol Başarıyla Verildi!')
                .setDescription(`**${targetUser.tag}** kullanıcısına **${targetRole.name}** rolü verildi!`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '🎭 Verilen Rol', value: `${targetRole} (${targetRole.name})`, inline: true },
                    { name: '👮 Yetkili', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '📝 Sebep', value: sebep, inline: false },
                    { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '📊 Yeni Rol Sayısı', value: `${targetMember.roles.cache.size} rol`, inline: true }
                );

            // Nick değişikliği bilgisini ekle
            if (yeniNick) {
                successEmbed.addFields({
                    name: '🏷️ Nick Değişikliği',
                    value: nickDegisti ? `✅ **${yeniNick}** olarak güncellendi` : `❌ Nick değiştirilemedi`,
                    inline: true
                });
            }

            successEmbed
                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ 
                    text: `Yetkili: ${interaction.user.tag} • ZYM CİTY`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // Log kanalına gönder
            const logChannelId = lyuex.botSettings?.LOG_CHANNEL_ID;
            if (logChannelId) {
                const logChannel = interaction.guild.channels.cache.get(logChannelId);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(0x00FF88)
                        .setTitle('📋 Rol Verme İşlemi')
                        .setDescription('Yeni bir rol verme işlemi gerçekleştirildi.')
                        .addFields(
                            { name: '👤 Hedef', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                            { name: '🎭 Rol', value: `${targetRole.name} (${targetRole.id})`, inline: true },
                            { name: '👮 Yetkili', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                            { name: '📝 Sebep', value: sebep, inline: false }
                        )
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

        } catch (error) {
            console.error('Rol verme hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Rol Verme Hatası')
                .setDescription('Rol verilirken bir hata oluştu!')
                .addFields(
                    { name: '💥 Hata', value: error.message || 'Bilinmeyen hata', inline: false },
                    { name: '🔧 Olası Çözümler', value: '• Bot yetkilerini kontrol edin\n• Rolün konumunu kontrol edin\n• Kullanıcının sunucuda olduğunu kontrol edin', inline: false }
                )
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },
};




