// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { Moderation } = require('../Schemas/ModerationSchema');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('🔊 Kullanıcının susturmasını kaldırır')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Susturması kaldırılacak kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Unmute sebebi')
        .setRequired(false)
        .setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const reason = interaction.options.getString('sebep') || 'Manuel unmute';
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Moderate Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Bot izin kontrolü
      if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return await interaction.editReply({
          content: '❌ **Bot Yetki Hatası!** Botun rol yönetme yetkisi yok!'
        });
      }

      // Üye kontrolü
      let targetMember = null;
      try {
        targetMember = await guild.members.fetch(targetUser.id);
        
        if (!targetMember) {
          return await interaction.editReply({
            content: '❌ **Hata!** Bu kullanıcı sunucuda bulunmuyor!'
          });
        }

      } catch (fetchError) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kullanıcı sunucuda bulunamadı veya erişilemez!'
        });
      }

      // Mute durumu kontrolü
      try {
        const muteRecord = await Mute.findOne({
          userId: targetUser.id,
          guildId: guild.id,
          active: true
        });

        if (!muteRecord) {
          return await interaction.editReply({
            content: `❌ **Zaten Susturulmamış!** ${targetUser.tag} kullanıcısı susturulmamış durumda.`
          });
        }

        // Mute bilgilerini göster
        const muteInfoEmbed = new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle('🔍 Mevcut Mute Bilgileri')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
            { name: '📋 Case ID', value: muteRecord.caseId, inline: true },
            { name: '📝 Mute Sebebi', value: muteRecord.reason, inline: false },
            { name: '📅 Başlangıç', value: `<t:${Math.floor(muteRecord.startTime.getTime() / 1000)}:F>`, inline: true },
            { name: '🏁 Bitiş', value: muteRecord.endTime ? `<t:${Math.floor(muteRecord.endTime.getTime() / 1000)}:F>` : 'Kalıcı', inline: true },
            { name: '👮 Mute Eden', value: `<@${muteRecord.moderatorId}>`, inline: true },
            { name: '🔓 Unmute Sebebi', value: reason, inline: false }
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({
          content: '⚠️ **Unmute işlemini onaylayın:**',
          embeds: [muteInfoEmbed]
        });

        // Unmute işlemini gerçekleştir
        const result = await ModerationManager.unmuteUser({
          guild,
          member: targetMember,
          moderator,
          reason
        });

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Unmute İşlemi Başarılı')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**📋 Yeni Case ID:** ${result.caseId}\n` +
            `**📝 Sebep:** ${reason}\n` +
            `**📱 DM Durumu:** ${result.dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
            `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
            `🔊 **Durum:** Kullanıcı artık mesaj gönderebilir ve reaksiyon ekleyebilir.`
          )
          .addFields(
            { name: '🔄 Orijinal Case', value: muteRecord.caseId, inline: true },
            { name: '⏰ Mute Süresi', value: muteRecord.endTime ? ModerationManager.formatDuration(Math.floor((muteRecord.endTime - muteRecord.startTime) / 60000)) : 'Kalıcı', inline: true }
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [successEmbed]
        });

        // Başarı logu
        console.log(`🔊 Unmute başarılı: ${targetUser.tag} (${result.caseId}) - Moderatör: ${moderator.tag} - Orijinal Case: ${muteRecord.caseId}`);

      } catch (unmuteError) {
        console.error('Unmute işlemi hatası:', unmuteError);
        
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Unmute İşlemi Başarısız')
          .setDescription(
            `**Hata:** ${unmuteError.message}\n\n` +
            `**Olası Sebepler:**\n` +
            `• Bot rol yönetme yetkisi yok\n` +
            `• Kullanıcının orijinal rolleri bulunamadı\n` +
            `• Mute rolü silinemedi\n` +
            `• Discord API hatası\n` +
            `• Veritabanı bağlantı sorunu\n` +
            `• Rol hiyerarşisi problemi`
          )
          .addFields(
            { 
              name: '🔧 Çözüm Önerileri', 
              value: '• Botun rol sırasını kontrol edin\n• Kullanıcının rollerini manuel kontrol edin\n• Mute rolünü manuel kaldırmayı deneyin', 
              inline: false 
            }
          )
          .setFooter({ text: 'Hatayı yöneticiye bildirin' })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [errorEmbed]
        });
      }

    } catch (error) {
      console.error('Unmute komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};





