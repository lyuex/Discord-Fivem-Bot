// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * İnteraktif Yardım Sistemi
 * Komutları kategoriye göre gruplayıp, detaylı bilgi sunan sistem
 */

const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('yardım-gelişmiş')
        .setDescription('📚 Gelişmiş Yardım Sistemi - Komutları keşfet')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false)
        .addStringOption(option =>
            option
                .setName('kategori')
                .setDescription('📂 Komut kategorisi')
                .setRequired(false)
                .addChoices(
                    { name: '⚖️ Moderasyon', value: 'moderasyon' },
                    { name: '👥 Ekip Yönetimi', value: 'ekip' },
                    { name: '🎫 Ticket Sistemi', value: 'ticket' },
                    { name: '👑 Rol Yönetimi', value: 'roller' },
                    { name: '📊 İstatistik', value: 'istatistik' },
                    { name: '🔧 Admin Araçları', value: 'admin' },
                    { name: '❓ Genel', value: 'genel' }
                ))
        .addStringOption(option =>
            option
                .setName('komut')
                .setDescription('🔍 Belirli komut hakkında bilgi')
                .setRequired(false)
                .setAutocomplete(true)),

    async execute(interaction) {
        try {
            const kategori = interaction.options.getString('kategori') || null;
            const komut = interaction.options.getString('komut') || null;

            // Eğer belirli bir komut sorulmuşsa
            if (komut) {
                return await this.showCommandDetail(interaction, komut);
            }

            // Eğer kategori seçilmişse
            if (kategori) {
                return await this.showCategoryHelp(interaction, kategori);
            }

            // Kategoriler menüsünü göster
            await this.showMainMenu(interaction);

        } catch (error) {
            console.error('Help command error:', error);
            await interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Hata')
                    .setDescription('Yardım sistemi yüklenirken hata oluştu.')
                ],
                ephemeral: true
            });
        }
    },

    async showMainMenu(interaction) {
        const categories = [
            { name: '⚖️ Moderasyon Komutları', value: 'moderasyon', description: 'Ban, kick, mute ve uyarı komutları' },
            { name: '👥 Ekip Yönetimi', value: 'ekip', description: 'Ekip oluşturma ve yönetme' },
            { name: '🎫 Ticket Sistemi', value: 'ticket', description: 'Destek ticket komutları' },
            { name: '👑 Rol Yönetimi', value: 'roller', description: 'Rol verme ve alma komutları' },
            { name: '📊 İstatistik', value: 'istatistik', description: 'Sunucu ve kullanıcı istatistikleri' },
            { name: '🔧 Admin Araçları', value: 'admin', description: 'Sunucu yönetimi komutları' },
            { name: '❓ Genel Komutlar', value: 'genel', description: 'Diğer komutlar' }
        ];

        const mainMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('help_category_select')
                .setPlaceholder('Bir kategori seçin...')
                .addOptions(categories.map(cat => ({
                    label: cat.name,
                    value: cat.value,
                    description: cat.description,
                    emoji: cat.name.substring(0, 1)
                })))
        );

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('📚 FiveM Bot - Yardım Merkezi')
            .setDescription(
                '**Hoş geldiniz!** 👋\n\n' +
                'Aşağıdan bir kategori seçerek komutlar hakkında bilgi alabilirsiniz.\n\n' +
                '**Özellikler:**\n' +
                '• 📖 Detaylı komut açıklamaları\n' +
                '• 💡 Kullanım örnekleri\n' +
                '• ⚡ Hızlı referans\n' +
                '• 🔗 İlişkili komutlar\n\n' +
                '**İpucu:** `/yardım-gelişmiş komut:komut_adı` yazarak belirli bir komut hakkında bilgi alabilirsiniz.'
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '🎯 Kategoriler', value: categories.length + ' kategori mevcut', inline: true },
                { name: '📝 Komutlar', value: 'Toplam 60+ komut', inline: true },
                { name: '⏱️ Güncelleme', value: new Date().toLocaleDateString('tr-TR'), inline: true }
            )
            .setFooter({ text: 'Yardıma ihtiyacınız mı? /yardım-gelişmiş kategori:genel' })
            .setTimestamp();

        await interaction.reply({
            embeds: [embed],
            components: [mainMenu],
            ephemeral: false
        });
    },

    async showCategoryHelp(interaction, category) {
        const categoryData = this.getCategoryData(category);

        if (!categoryData) {
            return await interaction.reply({
                content: '❌ Kategori bulunamadı!',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor(categoryData.color)
            .setTitle(`${categoryData.emoji} ${categoryData.name}`)
            .setDescription(categoryData.description);

        // Komutları listele
        const commands = categoryData.commands;
        const commandText = commands
            .map((cmd, i) => `**${i + 1}. \`/${cmd.name}\`** - ${cmd.description}`)
            .join('\n');

        embed.addFields(
            { name: '📋 Komutlar', value: commandText || 'Bu kategoride komut bulunmamaktadır.', inline: false },
            { name: '💡 İpucu', value: `Daha detaylı bilgi için \`/yardım-gelişmiş komut:komut_adı\` yazın.`, inline: false }
        );

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`help_back`)
                .setLabel('← Geri Dön')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`help_examples_${category}`)
                .setLabel('💡 Örnekler Göster')
                .setStyle(ButtonStyle.Primary)
        );

        await interaction.reply({
            embeds: [embed],
            components: [buttons],
            ephemeral: false
        });
    },

    async showCommandDetail(interaction, commandName) {
        const commandData = this.getCommandData(commandName);

        if (!commandData) {
            return await interaction.reply({
                content: `❌ \`${commandName}\` komutu bulunamadı!`,
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle(`📖 ${commandData.emoji} /${commandData.name}`)
            .setDescription(commandData.description)
            .addFields(
                { name: '📝 Açıklama', value: commandData.fullDescription || commandData.description, inline: false },
                { name: '⚙️ Kullanım', value: `\`${commandData.usage}\``, inline: false },
                { name: '📌 Örnek', value: `\`${commandData.example}\``, inline: false },
                { name: '👤 Gerekli Yetki', value: commandData.permission || 'Hiçbiri', inline: true },
                { name: '⏱️ Cooldown', value: commandData.cooldown || '3s', inline: true }
            )
            .setFooter({ text: 'Hizmetinizde olmaktan mutluyuz!' })
            .setTimestamp();

        if (commandData.options && commandData.options.length > 0) {
            const optionsText = commandData.options
                .map(opt => `• \`${opt.name}\` - ${opt.description}`)
                .join('\n');
            embed.addFields({ name: '🎛️ Seçenekler', value: optionsText, inline: false });
        }

        if (commandData.relatedCommands && commandData.relatedCommands.length > 0) {
            const relatedText = commandData.relatedCommands
                .map(cmd => `• \`/${cmd}\``)
                .join('\n');
            embed.addFields({ name: '🔗 İlişkili Komutlar', value: relatedText, inline: false });
        }

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`help_back`)
                .setLabel('← Geri Dön')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`help_feedback_${commandName}`)
                .setLabel('💬 Geri Bildirim Gönder')
                .setStyle(ButtonStyle.Primary)
        );

        await interaction.reply({
            embeds: [embed],
            components: [buttons],
            ephemeral: false
        });
    },

    getCategoryData(category) {
        const categories = {
            moderasyon: {
                name: 'Moderasyon Sistemi',
                emoji: '⚖️',
                color: 0xFF4444,
                description: 'Sunucuda düzen ve güvenliği sağlamak için kullanılan moderasyon komutları.',
                commands: [
                    { name: 'ban', description: 'Kullanıcıyı yasakla' },
                    { name: 'unban', description: 'Yasağı kaldır' },
                    { name: 'kick', description: 'Kullanıcıyı at' },
                    { name: 'mute', description: 'Kullanıcıyı sustur' },
                    { name: 'unmute', description: 'Susturma cezasını kaldır' },
                    { name: 'warn', description: 'Uyarı ver' },
                    { name: 'uyari', description: 'Gelişmiş uyarı sistemi' },
                    { name: 'sicil', description: 'Moderasyon geçmişi' }
                ]
            },
            ekip: {
                name: 'Ekip Yönetimi',
                emoji: '👥',
                color: 0x4CAF50,
                description: 'Discord sunucusunda ekip oluşturma ve yönetme komutları.',
                commands: [
                    { name: 'ekip', description: 'Ekip oluştur ve yönet' },
                    { name: 'ekip-sil', description: 'Ekibi sil' },
                    { name: 'ekip-yonetim', description: 'Ekip yönetimi' },
                    { name: 'ekip-profil', description: 'Ekip profili görüntüle' }
                ]
            },
            ticket: {
                name: 'Ticket Sistemi',
                emoji: '🎫',
                color: 0x1E88E5,
                description: 'Destek ve yardım isteme sistemi.',
                commands: [
                    { name: 'ticket', description: 'Ticket aç' },
                    { name: 'ticket-yonetim', description: 'Ticket yönetimi' },
                    { name: 'ticket-istatistik', description: 'Ticket istatistikleri' }
                ]
            },
            roller: {
                name: 'Rol Yönetimi',
                emoji: '👑',
                color: 0xFFD700,
                description: 'Rol verme ve alma komutları.',
                commands: [
                    { name: 'rol-ver', description: 'Kullanıcıya rol ver' },
                    { name: 'rol-al', description: 'Kullanıcıdan rol al' },
                    { name: 'rolbilgi', description: 'Rol bilgisi göster' },
                    { name: 'toplurol', description: 'Toplu rol işlemi' }
                ]
            },
            istatistik: {
                name: 'İstatistik ve Raporlar',
                emoji: '📊',
                color: 0x9C27B0,
                description: 'Sunucu ve komut istatistikleri.',
                commands: [
                    { name: 'sunucudurum', description: 'Sunucu durumu' },
                    { name: 'bot-durum', description: 'Bot durumu' },
                    { name: 'uyari-stats', description: 'Uyarı istatistikleri' },
                    { name: 'ekip-istatistik', description: 'Ekip istatistikleri' }
                ]
            },
            admin: {
                name: 'Admin Araçları',
                emoji: '🔧',
                color: 0xFF9800,
                description: 'Sunucu yönetimi ve admin araçları.',
                commands: [
                    { name: 'automod', description: 'Otomatik moderasyon' },
                    { name: 'backup', description: 'Sunucu yedekle' },
                    { name: 'log-ayarla', description: 'Log ayarları' },
                    { name: 'eval', description: 'Kod çalıştır (Developer)' }
                ]
            },
            genel: {
                name: 'Genel Komutlar',
                emoji: '❓',
                color: 0x2196F3,
                description: 'Diğer genel komutlar.',
                commands: [
                    { name: 'yardım', description: 'Temel yardım' },
                    { name: 'yardım-gelişmiş', description: 'Gelişmiş yardım' },
                    { name: 'ping', description: 'Bot gecikmesi' }
                ]
            }
        };

        return categories[category] || null;
    },

    getCommandData(commandName) {
        const commands = {
            ban: {
                name: 'ban',
                emoji: '🔨',
                description: 'Kullanıcıyı sunucudan yasakla',
                fullDescription: 'Kullanıcıyı sunucudan kalıcı veya geçici olarak yasaklar. Kalıcı ban kullanıcının sunucu ID\'sinden tekrar giremeyeceği anlamına gelir.',
                usage: '/ban <kullanıcı> [sebep] [süre]',
                example: '/ban @ToxicUser Spam ve trolling 7d',
                permission: 'Ban Members',
                cooldown: '5s',
                options: [
                    { name: 'kullanıcı', description: 'Yasaklanacak kullanıcı' },
                    { name: 'sebep', description: 'Ban sebebi (opsiyonel)' },
                    { name: 'süre', description: 'Ban süresi - mesela 7d, 24h, 30m' }
                ],
                relatedCommands: ['unban', 'kick', 'warn']
            },
            kick: {
                name: 'kick',
                emoji: '👢',
                description: 'Kullanıcıyı sunucudan at',
                fullDescription: 'Kullanıcıyı sunucudan atar. Ban\'dan farklı olarak kullanıcı tekrar sunucuya girebilir.',
                usage: '/kick <kullanıcı> [sebep]',
                example: '/kick @SpamUser Kuralları ihlal',
                permission: 'Kick Members',
                cooldown: '5s',
                options: [
                    { name: 'kullanıcı', description: 'Atılacak kullanıcı' },
                    { name: 'sebep', description: 'Kick sebebi (opsiyonel)' }
                ],
                relatedCommands: ['ban', 'warn', 'mute']
            },
            mute: {
                name: 'mute',
                emoji: '🔇',
                description: 'Kullanıcıyı sustur',
                fullDescription: 'Kullanıcının text ve voice kanallarında yazıp konuşmasını engeller. Discord\'ın yerleşik timeout özelliğini kullanır.',
                usage: '/mute <kullanıcı> <süre> [sebep]',
                example: '/mute @NoiseUser 1h Sesli kanalda gürültü',
                permission: 'Moderate Members',
                cooldown: '5s',
                options: [
                    { name: 'kullanıcı', description: 'Susturulacak kullanıcı' },
                    { name: 'süre', description: 'Susturma süresi' },
                    { name: 'sebep', description: 'Sebep (opsiyonel)' }
                ],
                relatedCommands: ['unmute', 'warn', 'ban']
            },
            warn: {
                name: 'warn',
                emoji: '⚠️',
                description: 'Kullanıcıya uyarı ver',
                fullDescription: 'Kullanıcıya uyarı verir. Belirli sayıda uyarı alındığında otomatik ceza sistemi devreye girer.',
                usage: '/warn <kullanıcı> <sebep>',
                example: '/warn @BadUser Küfür kullanımı',
                permission: 'Moderate Members',
                cooldown: '3s',
                options: [
                    { name: 'kullanıcı', description: 'Uyarı verilecek kullanıcı' },
                    { name: 'sebep', description: 'Uyarı sebebi' }
                ],
                relatedCommands: ['uyari', 'uyari-sil', 'sicil']
            },
            sicil: {
                name: 'sicil',
                emoji: '📋',
                description: 'Moderasyon geçmişi görüntüle',
                fullDescription: 'Bir kullanıcının moderasyon geçmişini (ban, kick, mute, uyarı, vb.) görüntüler. Ban ve mute cezalarının detaylarını da gösterir.',
                usage: '/sicil <kullanıcı> [sayfa] [tür]',
                example: '/sicil @User 1 ban',
                permission: 'Moderate Members',
                cooldown: '3s',
                options: [
                    { name: 'kullanıcı', description: 'Sicili görüntülenecek kullanıcı' },
                    { name: 'sayfa', description: 'Sayfa numarası' },
                    { name: 'tür', description: 'Filtre türü (ban, kick, mute, etc.)' }
                ],
                relatedCommands: ['warn', 'uyari-stats', 'case-yönetim']
            }
        };

        return commands[commandName] || null;
    }
};





