// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder } = require('@discordjs/builders');
const db = require('croxydb');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('af')
    .setDescription('Belirli bir kullanıcının limit verilerini sıfırlar.')
    .addUserOption(option => 
      option
        .setName('kullanıcı')
        .setDescription('Limitlerini sıfırlamak istediğiniz kullanıcıyı seçin')
        .setRequired(true)
    ),

  async execute(interaction) {
    // Seçilen kullanıcıyı al
    const targetUser = interaction.options.getUser('kullanıcı');
    const userId = targetUser.id;
    const guildId = interaction.guild.id;

    // Veritabanındaki limit anahtarlarını sil
    const keys = [
      'everyone_atma', 'send_everyone',
      'kanal_silme', 'delete_channels',
      'rol_oluşturma', 'create_roles',
      'kanal_oluşturma', 'create_channels',
      'üye_yasaklama', 'ban_members',
      'üye_atma', 'kick_members'
    ];

    for (const key of keys) {
      db.delete(`${key}_${guildId}_${userId}`);
    }

    // Başarı mesajı gönder
    await interaction.reply({ content: `Kullanıcı (${targetUser.tag}, \`${userId}\`) için limit verileri başarıyla sıfırlandı.`, ephemeral: true });
  }
};





