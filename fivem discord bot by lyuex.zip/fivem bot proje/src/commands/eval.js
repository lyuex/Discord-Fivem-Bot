// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, codeBlock } = require('discord.js');
const { inspect } = require('util');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('eval')
        .setDescription('🔧 JavaScript kodu çalıştır (Sadece bot sahipleri)')
        .addStringOption(option =>
            option
                .setName('kod')
                .setDescription('Çalıştırılacak JavaScript kodu')
                .setRequired(true)
        )
        .addBooleanOption(option =>
            option
                .setName('async')
                .setDescription('Asenkron kod mu? (await kullanımı için)')
                .setRequired(false)
        )
        .addBooleanOption(option =>
            option
                .setName('silent')
                .setDescription('Sonucu gizli göster (sadece sen görebilirsin)')
                .setRequired(false)
        ),

    async execute(interaction) {
        // Bot sahibi kontrolü
        const botSahipleri = lyuex.botSettings?.botOwners || ['384385365815066624'];
        
        if (!botSahipleri.includes(interaction.user.id)) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Yetkisiz Erişim')
                    .setDescription('Bu komut sadece **bot sahipleri** tarafından kullanılabilir!')
                    .addFields(
                        { name: '🔒 Yetkili Kişiler', value: botSahipleri.map(id => `<@${id}>`).join(', '), inline: false }
                    )
                    .setTimestamp()
                ],
                ephemeral: true
            });
        }

        const kod = interaction.options.getString('kod');
        const isAsync = interaction.options.getBoolean('async') || false;
        const isSilent = interaction.options.getBoolean('silent') || false;

        await interaction.deferReply({ ephemeral: isSilent });

        try {
            // Güvenlik önlemleri
            const yasak = [
                'token', 'env', 'process.env', 'require(', 'import(', 'fs', 'child_process', 'exec',
                'spawn', 'lyuex.botSettings.token', 'BOT_TOKEN', 'global.BOT_TOKEN',
                'process.exit', 'process.kill', 'setInterval', 'setTimeout',
                'eval(', 'Function(', '__dirname', '__filename'
            ];
            
            const kodLower = kod.toLowerCase();
            for (const kelime of yasak) {
                if (kodLower.includes(kelime.toLowerCase())) {
                    return interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setColor(0xFF4444)
                            .setTitle('🛡️ Güvenlik Uyarısı')
                            .setDescription(`Kod **"${kelime}"** içeriyor ve güvenlik nedeniyle çalıştırılamaz!`)
                            .addFields(
                                { name: '🚫 Yasaklı İçerikler', value: yasak.slice(0, 10).map(y => `\`${y}\``).join(', ') + '...', inline: false }
                            )
                            .setTimestamp()
                        ]
                    });
                }
            }

            const baslangic = Date.now();
            let sonuc;

            // Kullanışlı değişkenler
            const client = interaction.client;
            const guild = interaction.guild;
            const channel = interaction.channel;
            const user = interaction.user;
            const member = interaction.member;

            if (isAsync) {
                // Asenkron kod çalıştırma
                sonuc = await eval(`(async () => { ${kod} })()`);
            } else {
                // Senkron kod çalıştırma
                sonuc = eval(kod);
            }

            const sure = Date.now() - baslangic;

            // Sonucu formatla
            let formatliSonuc = inspect(sonuc, { depth: 1, maxArrayLength: 10 });
            
            // Çok uzun sonuçları kısalt
            if (formatliSonuc.length > 1900) {
                formatliSonuc = formatliSonuc.substring(0, 1900) + '...';
            }

            const embed = new EmbedBuilder()
                .setColor(0x00FF88)
                .setTitle('✅ Eval Başarılı')
                .setDescription('Kod başarıyla çalıştırıldı!')
                .addFields(
                    { name: '📝 Girdi', value: codeBlock('js', kod.length > 1000 ? kod.substring(0, 1000) + '...' : kod), inline: false },
                    { name: '📤 Çıktı', value: codeBlock('js', formatliSonuc || 'undefined'), inline: false },
                    { name: '⏱️ Süre', value: `${sure}ms`, inline: true },
                    { name: '🔧 Tip', value: typeof sonuc, inline: true },
                    { name: '🔄 Async', value: isAsync ? '✅' : '❌', inline: true }
                )
                .setFooter({ 
                    text: `Çalıştıran: ${interaction.user.tag}`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(0xFF4444)
                .setTitle('❌ Eval Hatası')
                .setDescription('Kod çalıştırılırken hata oluştu!')
                .addFields(
                    { name: '📝 Girdi', value: codeBlock('js', kod.length > 1000 ? kod.substring(0, 1000) + '...' : kod), inline: false },
                    { name: '💥 Hata', value: codeBlock('js', error.message || error.toString()), inline: false },
                    { name: '📍 Hata Türü', value: error.name || 'Unknown Error', inline: true },
                    { name: '🔄 Async', value: isAsync ? '✅' : '❌', inline: true }
                )
                .setFooter({ 
                    text: `Çalıştıran: ${interaction.user.tag}`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    },
};




