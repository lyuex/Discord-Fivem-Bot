// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

// Komut içi metinler ve renk
const texts = {
  logTitle: '📨 Yeni Yetkili Şikayeti',
  noChannel: '⚠️ `şikayet-log` adında bir kanal bulunamadı. Lütfen yöneticilere bildir.',
  success: '✅ Şikayetiniz başarıyla iletildi.',
  footer: 'Şikayet Sistemi',
  color: 0xE67E22 // Turuncu tonu
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('şikayet')
    .setDescription('Bir yetkili hakkında şikayet bildir.')
    .addUserOption(option =>
      option.setName('hedef')
        .setDescription('Şikayet edilen yetkili')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('neden')
        .setDescription('Şikayet sebebi')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('kanıt')
        .setDescription('Varsa kanıt linki veya açıklama')
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('hedef');
    const reason = interaction.options.getString('neden');
    const evidence = interaction.options.getString('kanıt') || 'Belirtilmedi';
    const author = interaction.user;

    // Log kanalı ID ile alınıyor
    const logChannel = interaction.guild.channels.cache.get('1372673276299706411');
    if (!logChannel) {
      return interaction.reply({ content: texts.noChannel, ephemeral: true });
    }

    // Log embed oluştur
    const logEmbed = new EmbedBuilder()
      .setColor(texts.color)
      .setAuthor({ name: `${author.tag}`, iconURL: author.displayAvatarURL({ dynamic: true }) })
      .setTitle(texts.logTitle)
      .addFields(
        { name: '🎯 Hedef Yetkili', value: `${target.tag} (${target.id})`, inline: true },
        { name: '👤 Şikayet Eden', value: `${author.tag} (${author.id})`, inline: true },
        { name: '📝 Sebep', value: reason },
        { name: '📎 Kanıt', value: evidence }
      )
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: texts.footer, iconURL: interaction.guild.iconURL() });

    await logChannel.send({ embeds: [logEmbed] });

    // Kullanıcıya onay embed
    const confirmEmbed = new EmbedBuilder()
      .setColor(texts.color)
      .setDescription(texts.success)
      .setTimestamp()
      .setFooter({ text: texts.footer });

    await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
  }
};





