// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Uyarı veritabanı dosyası
const uyariDB = path.join(__dirname, '../../db/uyarilar.json');

// Veritabanı okuma fonksiyonu
function getUyariData() {
    try {
        const data = fs.readFileSync(uyariDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uyarı-stats')
        .setDescription('Sunucu uyarı istatistiklerini görüntüle')
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    
    async execute(interaction) {
        await interaction.deferReply();
        
        const uyariData = getUyariData();
        const kullanicilar = Object.keys(uyariData);
        
        if (kullanicilar.length === 0) {
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('📊 Uyarı İstatistikleri')
                        .setDescription('Sunucuda henüz hiç uyarı verilmemiş!')
                        .setColor(0x4CAF50)
                        .setTimestamp()
                ]
            });
        }
        
        // İstatistikleri hesapla
        let toplamUyari = 0;
        let toplamKullanici = kullanicilar.length;
        const cezaStats = {};
        const yetkililerStats = {};
        const aylikStats = {};
        let enCokUyarilan = { userId: null, count: 0 };
        
        kullanicilar.forEach(userId => {
            const userData = uyariData[userId];
            const uyariSayisi = userData.uyarilar.length;
            toplamUyari += uyariSayisi;
            
            // En çok uyarılana bak
            if (uyariSayisi > enCokUyarilan.count) {
                enCokUyarilan = { userId, count: uyariSayisi };
            }
            
            userData.uyarilar.forEach(uyari => {
                // Ceza istatistikleri
                cezaStats[uyari.ceza] = (cezaStats[uyari.ceza] || 0) + 1;
                
                // Yetkili istatistikleri
                yetkililerStats[uyari.yetkili.id] = yetkililerStats[uyari.yetkili.id] || { 
                    tag: uyari.yetkili.tag, 
                    count: 0 
                };
                yetkililerStats[uyari.yetkili.id].count++;
                
                // Aylık istatistikler
                const ay = new Date(uyari.tarih).toLocaleDateString('tr-TR', { year: 'numeric', month: 'long' });
                aylikStats[ay] = (aylikStats[ay] || 0) + 1;
            });
        });
        
        // En aktif yetkili
        const enAktifYetkili = Object.entries(yetkililerStats)
            .sort(([,a], [,b]) => b.count - a.count)[0];
        
        // En son ay
        const sonAylar = Object.entries(aylikStats)
            .sort(([a], [b]) => new Date(a) - new Date(b))
            .slice(-3);
        
        const statsEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} - Uyarı İstatistikleri`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('📊 Sunucu Uyarı Raporu')
            .setDescription(`
📈 **Genel İstatistikler**
🔢 **Toplam Uyarı:** ${toplamUyari}
👥 **Uyarılı Kullanıcı:** ${toplamKullanici}
📊 **Ortalama Uyarı:** ${(toplamUyari / toplamKullanici).toFixed(1)}
            `)
            .addFields(
                {
                    name: '🏆 En Çok Uyarılan',
                    value: enCokUyarilan.userId ? 
                        `<@${enCokUyarilan.userId}>\n**${enCokUyarilan.count}** uyarı` : 
                        'Veri yok',
                    inline: true
                },
                {
                    name: '👮 En Aktif Yetkili',
                    value: enAktifYetkili ? 
                        `<@${enAktifYetkili[0]}>\n**${enAktifYetkili[1].count}** uyarı verdi` : 
                        'Veri yok',
                    inline: true
                },
                {
                    name: '📅 Güncel Durum',
                    value: `**Bu Ay:** ${aylikStats[Object.keys(aylikStats).pop()] || 0}\n**Toplam:** ${toplamUyari}`,
                    inline: true
                },
                {
                    name: '⚖️ Ceza Türleri',
                    value: Object.entries(cezaStats)
                        .sort(([,a], [,b]) => b - a)
                        .slice(0, 5)
                        .map(([ceza, sayi]) => `**${ceza}:** ${sayi}`)
                        .join('\n') || 'Veri yok',
                    inline: true
                },
                {
                    name: '📈 Son 3 Ay Trendi',
                    value: sonAylar
                        .map(([ay, sayi]) => `**${ay}:** ${sayi}`)
                        .join('\n') || 'Veri yok',
                    inline: true
                },
                {
                    name: '🎯 Risk Analizi',
                    value: (() => {
                        const riskli = kullanicilar.filter(id => uyariData[id].uyarilar.length > 5).length;
                        const orta = kullanicilar.filter(id => uyariData[id].uyarilar.length >= 3 && uyariData[id].uyarilar.length <= 5).length;
                        const dusuk = kullanicilar.filter(id => uyariData[id].uyarilar.length < 3).length;
                        
                        return `🔴 **Yüksek Risk:** ${riskli}\n🟡 **Orta Risk:** ${orta}\n🟢 **Düşük Risk:** ${dusuk}`;
                    })(),
                    inline: true
                }
            )
            .setColor(0x2196F3)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ 
                text: `Son Güncelleme | ${interaction.guild.name}`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();
        
        // Top 10 uyarılı kullanıcılar
        const top10 = kullanicilar
            .map(userId => ({
                userId,
                count: uyariData[userId].uyarilar.length,
                tag: uyariData[userId].kullanici.tag
            }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10);
        
        if (top10.length > 0) {
            const top10Embed = new EmbedBuilder()
                .setTitle('🏆 En Çok Uyarılan Kullanıcılar (Top 10)')
                .setDescription(
                    top10.map((user, index) => {
                        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
                        return `${medal} <@${user.userId}> - **${user.count}** uyarı`;
                    }).join('\n')
                )
                .setColor(0xFF9800)
                .setTimestamp();
            
            await interaction.editReply({ embeds: [statsEmbed, top10Embed] });
        } else {
            await interaction.editReply({ embeds: [statsEmbed] });
        }
    },
};




