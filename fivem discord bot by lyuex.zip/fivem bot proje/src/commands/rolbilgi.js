// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rolbilgi')
        .setDescription('Belirtilen rol hakkında bilgi alın.')
        .addRoleOption(option => 
            option.setName('rol')
            .setDescription('Bilgisi Alınıcak Rolü Seçin.')
            .setRequired(true)),
    async execute(interaction) {
        const lyuexinyetkilirolleri = interaction.member.roles.cache.some(r => lyuex.yetkili.rol.includes(r.id));
        if (!lyuexinyetkilirolleri) {
            return await interaction.reply({ content: `Bu komutu kullanmak için ${lyuex.yetkili.rol} rollerinden birine sahip olmanız gerekiyor.`, ephemeral: true});
        }
        const lyuexinrolü = interaction.options.getRole('rol');
        if (!lyuexinrolü) {
            return await interaction.reply({ content: `Bir rol seçmelisiniz.`, ephemeral: true});
        }

        const lyuexinrolündekiler = lyuexinrolü.members.map(member => {
            return `**${member.nickname} - ${member.user.tag}** - <@${member.id}>`;
        }).join('\n');

        const lyuexinrolbilgiembedi = new EmbedBuilder()
            .setColor(lyuexinrolü.hexColor)
            .setTitle(`Rol Bilgisi: ${lyuexinrolü.name}`)
            .setDescription(`Rol ID'si: ${lyuexinrolü.id}\nRol Rengi: ${lyuexinrolü.hexColor}\n Roldeki Kişi Sayısı: ${lyuexinrolü.members.size}\n\n${lyuexinrolündekiler}`);

        await interaction.reply({ embeds: [lyuexinrolbilgiembedi] });
    },
};





