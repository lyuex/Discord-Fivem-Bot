// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('çekiliş-liste')
    .setDescription('📋 Sunucudaki aktif çekilişleri listeler'),

  async execute(interaction) {
    try {
      await interaction.deferReply();
      
      const giveaways = [];
      let foundCount = 0;

      // Sunucudaki tüm kanalları dolaş
      await interaction.editReply({ content: '🔍 **Aktif çekilişler aranıyor...**' });
      
      const channels = await interaction.guild.channels.fetch();
      const textChannels = channels.filter(channel => channel.isTextBased() && !channel.isThread());
      
      for (const [_, channel] of textChannels) {
        try {
          // Son 100 mesajı kontrol et
          const messages = await channel.messages.fetch({ limit: 100 });
          
          // Bot'un mesajlarını filtrele
          const botMessages = messages.filter(m => 
            m.author.id === interaction.client.user.id && 
            m.embeds.length > 0 && 
            m.embeds[0].title && 
            m.embeds[0].title.includes('AKTİF ÇEKİLİŞ')
          );
          
          if (botMessages.size > 0) {
            for (const [_, msg] of botMessages) {
              // Mesaj içeriğinde "AKTİF ÇEKİLİŞ" içeren embedleri al
              const embed = msg.embeds[0];
              
              if (embed && embed.description) {
                // Embed içeriğinden çekiliş bilgilerini çıkar
                let prize = "Bilinmiyor";
                let endTime = null;
                let participantCount = 0;
                let winnerCount = 1;
                
                // Ödül bilgisini çıkar
                const prizeMatch = embed.description.match(/\*\*🎁 Ödül:\*\* (.*?)(?:\n|$)/);
                if (prizeMatch && prizeMatch[1]) {
                  prize = prizeMatch[1];
                }
                
                // Bitiş zamanı bilgisini çıkar
                const endTimeMatch = embed.description.match(/\*\*🏁 Bitiş:\*\* <t:(\d+):/);
                if (endTimeMatch && endTimeMatch[1]) {
                  const endTimestamp = parseInt(endTimeMatch[1]) * 1000;
                  endTime = endTimestamp;
                  
                  // Eğer çekiliş süresi dolmuşsa listeye ekleme
                  if (endTime < Date.now()) {
                    continue;
                  }
                }
                
                // Katılımcı sayısını çıkar
                const participantMatch = embed.description.match(/\*\*👥 Katılımcı:\*\* (\d+)/);
                if (participantMatch && participantMatch[1]) {
                  participantCount = parseInt(participantMatch[1]);
                }
                
                // Kazanan sayısını çıkar
                const winnerMatch = embed.description.match(/\*\*🏆 Kazanan Sayısı:\*\* (\d+)/);
                if (winnerMatch && winnerMatch[1]) {
                  winnerCount = parseInt(winnerMatch[1]);
                }
                
                // Tüm bilgileri giveaways dizisine ekle
                giveaways.push({
                  prize,
                  endTime,
                  channel: channel,
                  messageId: msg.id,
                  messageUrl: msg.url,
                  participantCount,
                  winnerCount
                });
                
                foundCount++;
              }
            }
          }
        } catch (channelError) {
          console.error(`Kanal kontrol hatası (${channel.name}):`, channelError);
          // Hata olsa bile diğer kanalları kontrol etmeye devam et
          continue;
        }
      }
      
      // Sonuçları sırala - bitiş zamanına göre
      giveaways.sort((a, b) => a.endTime - b.endTime);
      
      if (giveaways.length === 0) {
        return await interaction.editReply({ 
          content: '📋 **Çekiliş Listesi**\n\n❌ Sunucuda aktif çekiliş bulunamadı.' 
        });
      }
      
      // Sonuçları embed olarak göster
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('📋 AKTİF ÇEKİLİŞ LİSTESİ')
        .setDescription(`Sunucuda toplam **${giveaways.length}** aktif çekiliş bulundu.`)
        .setFooter({ 
          text: `${interaction.guild.name} • Toplam ${giveaways.length} çekiliş`,
          iconURL: interaction.guild.iconURL({ dynamic: true })
        })
        .setTimestamp();
      
      // Her çekiliş için ayrı bir alan ekle
      giveaways.forEach((giveaway, index) => {
        let timeRemaining;
        const remainingMs = giveaway.endTime - Date.now();
        const remainingSec = Math.floor(remainingMs / 1000);
        
        // Kalan süreyi formatla
        const hours = Math.floor(remainingSec / 3600);
        const mins = Math.floor((remainingSec % 3600) / 60);
        
        if (hours > 0) {
          timeRemaining = `${hours}s ${mins}d kaldı`;
        } else {
          timeRemaining = `${mins}d kaldı`;
        }
        
        embed.addFields({
          name: `${index + 1}. ${giveaway.prize}`,
          value: `🏆 **${giveaway.winnerCount}** kazanan\n` +
                `👥 **${giveaway.participantCount}** katılımcı\n` +
                `⏰ **${timeRemaining}** (<t:${Math.floor(giveaway.endTime / 1000)}:R>)\n` +
                `📍 ${giveaway.channel}\n` +
                `🔗 [Çekilişe Git](${giveaway.messageUrl})`,
          inline: true
        });
      });
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Çekiliş listesi hatası:', error);
      await interaction.editReply({ 
        content: `❌ **Hata!** Çekiliş listesi alınırken bir sorun oluştu: ${error.message}` 
      });
    }
  }
};




