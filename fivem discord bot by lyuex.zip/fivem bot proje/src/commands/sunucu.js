// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sunucu')
    .setDescription('LYUEX sunucu durumunu gösterir'),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      // ServerStatusManager'ı global'den al
      const serverStatus = global.serverStatusManager;
      
      if (!serverStatus) {
        const errorEmbed = new EmbedBuilder()
          .setColor('#ff0000')
          .setTitle('❌ Hata')
          .setDescription('Sunucu durum sistemi henüz başlatılmamış.')
          .setTimestamp();
        
        return await interaction.editReply({ embeds: [errorEmbed] });
      }

      // Sunucu durumunu al
      const serverData = await serverStatus.getServerStatus();
      
      // Embed oluştur
      const embed = serverStatus.createServerEmbed(serverData);
      
      await interaction.editReply({ embeds: [embed] });

    } catch (error) {
      console.error('[Sunucu Komutu] Hata:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle('❌ Hata')
        .setDescription('Sunucu durumu alınırken bir hata oluştu.')
        .addFields({
          name: 'Hata Detayı',
          value: error.message || 'Bilinmeyen hata',
          inline: false
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [errorEmbed] });
    }
  }
};