// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { Moderation, TempBan } = require('../Schemas/ModerationSchema');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('🔓 Kullanıcının yasağını kaldırır')
    .addStringOption(option =>
      option.setName('kullanıcı_id')
        .setDescription('🆔 Yasağı kaldırılacak kullanıcının ID\'si')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Unban sebebi')
        .setRequired(false)
        .setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const userId = interaction.options.getString('kullanıcı_id');
      const reason = interaction.options.getString('sebep') || 'Manuel unban';
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.BanMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Ban Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Bot izin kontrolü
      if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
        return await interaction.editReply({
          content: '❌ **Bot Yetki Hatası!** Botun ban kaldırma yetkisi yok!'
        });
      }

      // User ID format kontrolü
      if (!/^\d{17,19}$/.test(userId)) {
        return await interaction.editReply({
          content: '❌ **Geçersiz ID!** Lütfen geçerli bir kullanıcı ID\'si girin (17-19 haneli sayı).'
        });
      }

      // Ban durumu kontrolü
      let banInfo = null;
      let targetUser = null;
      
      try {
        banInfo = await guild.bans.fetch(userId);
        targetUser = banInfo.user;
      } catch (banCheckError) {
        return await interaction.editReply({
          content: '❌ **Kullanıcı Yasaklı Değil!** Bu kullanıcı yasaklı durumda değil veya ID hatalı.'
        });
      }

      // Mevcut ban kayıtlarını getir
      const banRecords = await Moderation.find({
        guildId: guild.id,
        userId: userId,
        type: { $in: ['ban', 'tempban'] },
        active: true
      }).sort({ createdAt: -1 });

      // Ban bilgilerini göster
      const banInfoEmbed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle('🔍 Mevcut Ban Bilgileri')
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: '📝 Discord Ban Sebebi', value: banInfo.reason || 'Sebep belirtilmedi', inline: true },
          { name: '🔓 Unban Sebebi', value: reason, inline: false }
        );

      if (banRecords.length > 0) {
        const latestBan = banRecords[0];
        banInfoEmbed.addFields(
          { name: '📋 Son Ban Case ID', value: latestBan.caseId, inline: true },
          { name: '👮 Ban Eden Moderatör', value: `<@${latestBan.moderatorId}>`, inline: true },
          { name: '📅 Ban Tarihi', value: `<t:${Math.floor(latestBan.createdAt.getTime() / 1000)}:F>`, inline: true }
        );

        if (latestBan.type === 'tempban' && latestBan.expiresAt) {
          banInfoEmbed.addFields(
            { name: '⏰ Orijinal Süre', value: ModerationManager.formatDuration(latestBan.duration), inline: true },
            { name: '🏁 Otomatik Bitiş', value: `<t:${Math.floor(latestBan.expiresAt.getTime() / 1000)}:F>`, inline: true }
          );
        }
      }

      banInfoEmbed.addFields({
        name: '📊 Toplam Ban Kaydı',
        value: `${banRecords.length} adet`,
        inline: true
      });

      banInfoEmbed.setFooter({ 
        text: `${guild.name} • Moderasyon Sistemi`,
        iconURL: guild.iconURL({ dynamic: true })
      }).setTimestamp();

      await interaction.editReply({
        content: '⚠️ **Unban işlemini onaylayın:**',
        embeds: [banInfoEmbed]
      });

      // Unban işlemini gerçekleştir
      try {
        // Discord'dan unban
        await guild.members.unban(userId, `${reason} | Moderatör: ${moderator.tag}`);

        // Veritabanında aktif ban kayıtlarını pasif yap
        await Moderation.updateMany(
          {
            guildId: guild.id,
            userId: userId,
            type: { $in: ['ban', 'tempban'] },
            active: true
          },
          {
            active: false,
            revokedBy: moderator.id,
            revokedAt: new Date(),
            revokedReason: reason
          }
        );

        // Aktif geçici ban kayıtlarını pasif yap
        await TempBan.updateMany(
          {
            guildId: guild.id,
            userId: userId,
            active: true
          },
          { active: false }
        );

        // Yeni unban kaydı oluştur
        const caseId = await ModerationManager.generateCaseId(guild.id);
        const unbanRecord = new Moderation({
          caseId,
          guildId: guild.id,
          type: 'unban',
          userId: userId,
          username: targetUser.username,
          userTag: targetUser.tag,
          moderatorId: moderator.id,
          moderatorTag: moderator.tag,
          reason,
          active: true
        });

        await unbanRecord.save();

        // Kullanıcıya DM göndermeyi dene
        let dmSent = false;
        try {
          const dmEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle(`🔓 ${guild.name} Sunucusunda Yasağınız Kaldırıldı`)
            .setDescription(
              `**Sebep:** ${reason}\n` +
              `**Moderatör:** ${moderator.tag}\n` +
              `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
              `**Case ID:** ${caseId}\n\n` +
              `🎉 Artık sunucuya tekrar katılabilirsiniz!`
            )
            .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
            .setTimestamp();

          await targetUser.send({ embeds: [dmEmbed] });
          dmSent = true;
        } catch (dmError) {
          console.error(`DM gönderilemedi (${targetUser.tag}):`, dmError.message);
        }

        if (dmSent) {
          unbanRecord.dmSent = true;
          await unbanRecord.save();
        }

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Unban İşlemi Başarılı')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**📋 Yeni Case ID:** ${caseId}\n` +
            `**📝 Sebep:** ${reason}\n` +
            `**📱 DM Durumu:** ${dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
            `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
            `🔓 **Durum:** Kullanıcı artık sunucuya katılabilir.\n` +
            `📊 **Pasif Yapılan:** ${banRecords.length} ban kaydı`
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [successEmbed]
        });

        // Log embed'i
        const logEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('🔓 Unban')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
            { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
            { name: '📋 Case ID', value: caseId, inline: true },
            { name: '📝 Sebep', value: reason, inline: false },
            { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true },
            { name: '📊 Pasif Kayıt', value: `${banRecords.length} ban kaydı`, inline: true }
          )
          .setFooter({ text: `${guild.name} • Moderasyon Log` })
          .setTimestamp();

        await ModerationManager.sendToLogChannel(guild, logEmbed);

        // Başarı logu
        console.log(`🔓 Unban başarılı: ${targetUser.tag} (${caseId}) - Moderatör: ${moderator.tag}`);

      } catch (unbanError) {
        console.error('Unban işlemi hatası:', unbanError);
        
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Unban İşlemi Başarısız')
          .setDescription(
            `**Hata:** ${unbanError.message}\n\n` +
            `**Olası Sebepler:**\n` +
            `• Bot ban kaldırma yetkisi yok\n` +
            `• Kullanıcı ID'si hatalı\n` +
            `• Discord API hatası\n` +
            `• Veritabanı bağlantı sorunu\n` +
            `• Kullanıcı zaten unban'lı`
          )
          .setFooter({ text: 'Hatayı yöneticiye bildirin' })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [errorEmbed]
        });
      }

    } catch (error) {
      console.error('Unban komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};





