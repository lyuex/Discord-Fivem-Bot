// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿// src/commands/koruma.js - Birleşik Güvenlik ve Koruma Sistemi
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const db = require('croxydb');
const fs = require('fs').promises;
const path = require('path');

const PROTECTION_FILE = path.join(__dirname, '..', 'data', 'protection.json');

// İhlal tracker'ı
const violationTracker = new Map();
const userActions = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('koruma')
        .setDescription('🛡️ Birleşik güvenlik ve koruma sistemi!')
        .addSubcommand(subcommand =>
            subcommand
                .setName('aç')
                .setDescription('🔐 Koruma sistemini aktif et')
                .addChannelOption(option =>
                    option
                        .setName('log-kanal')
                        .setDescription('Güvenlik loglarının gönderileceği kanal')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('kapat')
                .setDescription('🔓 Koruma sistemini deaktif et')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('güvenli-ekle')
                .setDescription('✅ Güvenli listeye ekle')
                .addRoleOption(option =>
                    option
                        .setName('rol')
                        .setDescription('Güvenli listeye eklenecek rol')
                        .setRequired(false)
                )
                .addUserOption(option =>
                    option
                        .setName('kullanıcı')
                        .setDescription('Güvenli listeye eklenecek kullanıcı')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('güvenli-çıkar')
                .setDescription('❌ Güvenli listeden çıkar')
                .addRoleOption(option =>
                    option
                        .setName('rol')
                        .setDescription('Güvenli listeden çıkarılacak rol')
                        .setRequired(false)
                )
                .addUserOption(option =>
                    option
                        .setName('kullanıcı')
                        .setDescription('Güvenli listeden çıkarılacak kullanıcı')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('liste')
                .setDescription('📋 Güvenli listeyi göster')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('ayarlar')
                .setDescription('⚙️ Koruma ayarlarını düzenle')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('durum')
                .setDescription('📊 Sistem durumunu göster')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        try {
            // Bot sahipleri kontrolü
            const lyuex = require('../../lyuex.json');
            const botOwners = lyuex.botSettings?.botOwners || [];
            const isBotOwner = botOwners.includes(interaction.user.id);

            if (!isBotOwner) {
                const yetkiEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('❌ Yetersiz Yetki!')
                    .setDescription('Bu komutu sadece **Bot Sahipleri** kullanabilir.')
                    .addFields(
                        { name: '🔒 Gerekli Yetki', value: 'Bot Sahibi', inline: true },
                        { name: '👤 Sizin Yetkiniz', value: 'Yetersiz', inline: true }
                    )
                    .setFooter({ text: 'Koruma Sistemi v4.0', iconURL: interaction.client.user.displayAvatarURL() })
                    .setTimestamp();

                return interaction.reply({ embeds: [yetkiEmbed], ephemeral: true });
            }

            const subcommand = interaction.options.getSubcommand();

            switch (subcommand) {
                case 'aç':
                    await this.handleActivate(interaction);
                    break;
                case 'kapat':
                    await this.handleDeactivate(interaction);
                    break;
                case 'güvenli-ekle':
                    await this.handleSafeAdd(interaction);
                    break;
                case 'güvenli-çıkar':
                    await this.handleSafeRemove(interaction);
                    break;
                case 'liste':
                    await this.handleList(interaction);
                    break;
                case 'ayarlar':
                    await this.handleSettings(interaction);
                    break;
                case 'durum':
                    await this.handleStatus(interaction);
                    break;
                default:
                    await this.handleStatus(interaction);
            }

        } catch (error) {
            console.error('Koruma komutu hatası:', error);

            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF4444)
                .setTitle('🚨 Sistem Hatası!')
                .setDescription(`Beklenmeyen bir hata oluştu: \`${error.message}\``)
                .setFooter({ text: 'Koruma Sistemi v4.0', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    },

    // Sistemi aktif et
    async handleActivate(interaction) {
        const logChannel = interaction.options.getChannel('log-kanal');
        const guildId = interaction.guild.id;

        // Guard sistemini aktif et
        db.set(`guard_${guildId}`, true);

        // Protection.json dosyasını güncelle
        const protectionData = await this.readProtectionData();
        protectionData[guildId] = {
            enabled: true,
            logChannel: logChannel.id,
            whitelistUsers: protectionData[guildId]?.whitelistUsers || [],
            settings: {
                antiChannel: true,
                antiRole: true,
                antiBan: true,
                antiBot: true,
                antiRaid: true,
                maxActions: 3
            }
        };
        await this.writeProtectionData(protectionData);

        const successEmbed = new EmbedBuilder()
            .setColor(0x4CAF50)
            .setTitle('✅ Koruma Sistemi Aktif!')
            .setDescription('Birleşik güvenlik sistemi başarıyla aktif edildi.')
            .addFields(
                { name: '📊 Sistem Durumu', value: '🟢 **AKTİF**', inline: true },
                { name: '📝 Log Kanalı', value: `${logChannel}`, inline: true },
                { name: '⚙️ Korunan İşlemler', value: '🏷️ Rol Yönetimi\n📢 Kanal Yönetimi\n🔨 Ban Koruması\n🤖 Bot Koruması\n🚨 Raid Koruması', inline: false }
            )
            .setFooter({ text: 'Koruma Sistemi v4.0 • Sistem Aktif', iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        const actionButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('koruma_ayarlar')
                    .setLabel('⚙️ Ayarları Düzenle')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('koruma_guvenli_ekle')
                    .setLabel('✅ Güvenli Ekle')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('koruma_durum')
                    .setLabel('📊 Durumu Gör')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [successEmbed], components: [actionButtons] });
    },

    // Sistemi deaktif et
    async handleDeactivate(interaction) {
        const guildId = interaction.guild.id;

        // Guard sistemini deaktif et
        db.delete(`guard_${guildId}`);

        // Protection.json dosyasını güncelle
        const protectionData = await this.readProtectionData();
        if (protectionData[guildId]) {
            protectionData[guildId].enabled = false;
            await this.writeProtectionData(protectionData);
        }

        const successEmbed = new EmbedBuilder()
            .setColor(0xFF9800)
            .setTitle('⚠️ Koruma Sistemi Deaktif!')
            .setDescription('Birleşik güvenlik sistemi deaktif edildi.')
            .addFields(
                { name: '📊 Sistem Durumu', value: '🔴 **KAPALI**', inline: true },
                { name: '⚠️ Uyarı', value: 'Sunucunuz artık otomatik koruma altında değil!', inline: false }
            )
            .setFooter({ text: 'Koruma Sistemi v4.0 • Sistem Kapalı', iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    },

    // Güvenli ekleme
    async handleSafeAdd(interaction) {
        // Bot sahipleri kontrolü
        const lyuex = require('../../lyuex.json');
        const botOwners = lyuex.botSettings?.botOwners || [];
        const isBotOwner = botOwners.includes(interaction.user.id);

        if (!isBotOwner) {
            return interaction.reply({ 
                content: '❌ **Yetkisiz İşlem!** Bu işlemi sadece bot sahipleri yapabilir.', 
                ephemeral: true 
            });
        }

        const rol = interaction.options.getRole('rol');
        const kullanıcı = interaction.options.getUser('kullanıcı');
        const guildId = interaction.guild.id;

        if (!rol && !kullanıcı) {
            return interaction.reply({ 
                content: '❌ Lütfen bir rol veya kullanıcı belirtin!', 
                ephemeral: true 
            });
        }

        if (rol) {
            // Rol ekleme
            const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
            if (safeRoles.includes(rol.id)) {
                return interaction.reply({ 
                    content: `❌ **${rol.name}** rolü zaten güvenli listede!`, 
                    ephemeral: true 
                });
            }

            safeRoles.push(rol.id);
            db.set(`güvenli_roller_${guildId}`, safeRoles);

            const successEmbed = new EmbedBuilder()
                .setColor(0x4CAF50)
                .setTitle('✅ Güvenli Rol Eklendi!')
                .setDescription(`**${rol.name}** rolü güvenli listeye eklendi.`)
                .addFields(
                    { name: '🏷️ Eklenen Rol', value: `${rol}`, inline: true },
                    { name: '👥 Üye Sayısı', value: `${rol.members.size}`, inline: true },
                    { name: '📊 Toplam Güvenli Rol', value: `${safeRoles.length}`, inline: true }
                )
                .setFooter({ text: 'Bu rol artık tüm işlemleri yapabilir', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });
        }

        if (kullanıcı) {
            // Kullanıcı ekleme
            const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
            if (safeUsers.includes(kullanıcı.id)) {
                return interaction.reply({ 
                    content: `❌ **${kullanıcı.tag}** kullanıcısı zaten güvenli listede!`, 
                    ephemeral: true 
                });
            }

            safeUsers.push(kullanıcı.id);
            db.set(`güvenli_kullanıcılar_${guildId}`, safeUsers);

            const successEmbed = new EmbedBuilder()
                .setColor(0x4CAF50)
                .setTitle('✅ Güvenli Kullanıcı Eklendi!')
                .setDescription(`**${kullanıcı.tag}** kullanıcısı güvenli listeye eklendi.`)
                .addFields(
                    { name: '👤 Eklenen Kullanıcı', value: `${kullanıcı}`, inline: true },
                    { name: '📊 Toplam Güvenli Kullanıcı', value: `${safeUsers.length}`, inline: true }
                )
                .setThumbnail(kullanıcı.displayAvatarURL({ dynamic: true }))
                .setFooter({ text: 'Bu kullanıcı artık tüm işlemleri yapabilir', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });
        }
    },

    // Güvenli çıkarma
    async handleSafeRemove(interaction) {
        // Bot sahipleri kontrolü
        const lyuex = require('../../lyuex.json');
        const botOwners = lyuex.botSettings?.botOwners || [];
        const isBotOwner = botOwners.includes(interaction.user.id);

        if (!isBotOwner) {
            return interaction.reply({ 
                content: '❌ **Yetkisiz İşlem!** Bu işlemi sadece bot sahipleri yapabilir.', 
                ephemeral: true 
            });
        }

        const rol = interaction.options.getRole('rol');
        const kullanıcı = interaction.options.getUser('kullanıcı');
        const guildId = interaction.guild.id;

        if (!rol && !kullanıcı) {
            return interaction.reply({ 
                content: '❌ Lütfen bir rol veya kullanıcı belirtin!', 
                ephemeral: true 
            });
        }

        if (rol) {
            // Rol çıkarma
            let safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
            if (!safeRoles.includes(rol.id)) {
                return interaction.reply({ 
                    content: `❌ **${rol.name}** rolü güvenli listede değil!`, 
                    ephemeral: true 
                });
            }

            safeRoles = safeRoles.filter(id => id !== rol.id);
            db.set(`güvenli_roller_${guildId}`, safeRoles);

            const successEmbed = new EmbedBuilder()
                .setColor(0xFF9800)
                .setTitle('⚠️ Güvenli Rol Çıkarıldı!')
                .setDescription(`**${rol.name}** rolü güvenli listeden çıkarıldı.`)
                .addFields(
                    { name: '🏷️ Çıkarılan Rol', value: `${rol}`, inline: true },
                    { name: '📊 Kalan Güvenli Rol', value: `${safeRoles.length}`, inline: true }
                )
                .setFooter({ text: 'Bu rol artık koruma altındadır', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });
        }

        if (kullanıcı) {
            // Kullanıcı çıkarma
            let safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
            if (!safeUsers.includes(kullanıcı.id)) {
                return interaction.reply({ 
                    content: `❌ **${kullanıcı.tag}** kullanıcısı güvenli listede değil!`, 
                    ephemeral: true 
                });
            }

            safeUsers = safeUsers.filter(id => id !== kullanıcı.id);
            db.set(`güvenli_kullanıcılar_${guildId}`, safeUsers);

            const successEmbed = new EmbedBuilder()
                .setColor(0xFF9800)
                .setTitle('⚠️ Güvenli Kullanıcı Çıkarıldı!')
                .setDescription(`**${kullanıcı.tag}** kullanıcısı güvenli listeden çıkarıldı.`)
                .addFields(
                    { name: '👤 Çıkarılan Kullanıcı', value: `${kullanıcı}`, inline: true },
                    { name: '📊 Kalan Güvenli Kullanıcı', value: `${safeUsers.length}`, inline: true }
                )
                .setFooter({ text: 'Bu kullanıcı artık koruma altındadır', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });
        }
    },

    // Liste göster
    async handleList(interaction) {
        const guildId = interaction.guild.id;
        const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
        const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];

        if (safeRoles.length === 0 && safeUsers.length === 0) {
            const emptyEmbed = new EmbedBuilder()
                .setColor(0x607D8B)
                .setTitle('📝 Güvenli Liste Boş')
                .setDescription('Henüz hiç güvenli rol veya kullanıcı eklenmemiş.')
                .addFields({
                    name: '🚀 Başlangıç',
                    value: '`/koruma güvenli-ekle` komutu ile başlayabilirsiniz.',
                    inline: false
                })
                .setFooter({ text: 'Koruma Sistemi v4.0', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            return interaction.reply({ embeds: [emptyEmbed], ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor(0x00D4FF)
            .setTitle('📋 Güvenli Liste')
            .setDescription('Aşağıdaki rol ve kullanıcılar güvenli listede bulunuyor:')
            .setFooter({ text: `Toplam: ${safeRoles.length + safeUsers.length} öğe`, iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        // Roller
        if (safeRoles.length > 0) {
            const roleText = safeRoles.slice(0, 10).map((roleId, i) => {
                const role = interaction.guild.roles.cache.get(roleId);
                return `${i + 1}. ${role ? role : `\`Silinmiş Rol\` (${roleId})`}`;
            }).join('\n');

            embed.addFields({
                name: `🏷️ Güvenli Roller (${safeRoles.length})`,
                value: roleText + (safeRoles.length > 10 ? `\n*... ve ${safeRoles.length - 10} rol daha*` : ''),
                inline: false
            });
        }

        // Kullanıcılar
        if (safeUsers.length > 0) {
            const userText = safeUsers.slice(0, 10).map((userId, i) => {
                const user = interaction.client.users.cache.get(userId);
                return `${i + 1}. ${user ? user.tag : `\`Bilinmeyen\` (${userId})`}`;
            }).join('\n');

            embed.addFields({
                name: `👥 Güvenli Kullanıcılar (${safeUsers.length})`,
                value: userText + (safeUsers.length > 10 ? `\n*... ve ${safeUsers.length - 10} kullanıcı daha*` : ''),
                inline: false
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    // Ayarlar
    async handleSettings(interaction) {
        const guildId = interaction.guild.id;
        const protectionData = await this.readProtectionData();
        const settings = protectionData[guildId]?.settings || {};

        const settingsEmbed = new EmbedBuilder()
            .setColor(0x9C27B0)
            .setTitle('⚙️ Koruma Ayarları')
            .setDescription('Aşağıdaki korumaları yönetebilirsiniz:')
            .addFields(
                { name: '🏷️ Rol Koruması', value: settings.antiRole ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '📢 Kanal Koruması', value: settings.antiChannel ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '🔨 Ban Koruması', value: settings.antiBan ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '🤖 Bot Koruması', value: settings.antiBot ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '🚨 Raid Koruması', value: settings.antiRaid ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '📊 Limit', value: `${settings.maxActions || 3} işlem/dakika`, inline: true }
            )
            .setFooter({ text: 'Koruma Sistemi v4.0', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const settingsButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('koruma_toggle_role')
                    .setLabel('🏷️ Rol Koruması')
                    .setStyle(settings.antiRole ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('koruma_toggle_channel')
                    .setLabel('📢 Kanal Koruması')
                    .setStyle(settings.antiChannel ? ButtonStyle.Success : ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('koruma_toggle_ban')
                    .setLabel('🔨 Ban Koruması')
                    .setStyle(settings.antiBan ? ButtonStyle.Success : ButtonStyle.Danger)
            );

        await interaction.reply({ embeds: [settingsEmbed], components: [settingsButtons], ephemeral: true });
    },

    // Durum göster
    async handleStatus(interaction) {
        const guildId = interaction.guild.id;
        const isGuardActive = db.get(`guard_${guildId}`) || false;
        const protectionData = await this.readProtectionData();
        const isProtectionActive = protectionData[guildId]?.enabled || false;
        const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
        const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];

        const systemStatus = (isGuardActive && isProtectionActive) ? '🟢 **FULL AKTİF**' : 
                           (isGuardActive || isProtectionActive) ? '🟡 **KISMEN AKTİF**' : '🔴 **KAPALI**';

        const statusEmbed = new EmbedBuilder()
            .setColor(systemStatus.includes('FULL') ? 0x4CAF50 : systemStatus.includes('KISMEN') ? 0xFF9800 : 0xF44336)
            .setTitle('📊 Sistem Durumu')
            .setDescription('Koruma sisteminin mevcut durumu:')
            .addFields(
                { name: '🛡️ Sistem Durumu', value: systemStatus, inline: true },
                { name: '⚙️ Guard Sistemi', value: isGuardActive ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '🔒 Protection Sistemi', value: isProtectionActive ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                { name: '🏷️ Güvenli Rol', value: `${safeRoles.length} rol`, inline: true },
                { name: '👥 Güvenli Kullanıcı', value: `${safeUsers.length} kullanıcı`, inline: true },
                { name: '📝 Log Kanalı', value: protectionData[guildId]?.logChannel ? `<#${protectionData[guildId].logChannel}>` : 'Belirlenmemiş', inline: true }
            )
            .setFooter({ text: 'Koruma Sistemi v4.0', iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        const statusButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('koruma_liste')
                    .setLabel('📋 Güvenli Liste')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('koruma_ayarlar')
                    .setLabel('⚙️ Ayarlar')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('koruma_logs')
                    .setLabel('📊 Son Olaylar')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [statusEmbed], components: [statusButtons], ephemeral: true });
    },

    // Yardımcı fonksiyonlar
    async readProtectionData() {
        try {
            const data = await fs.readFile(PROTECTION_FILE, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            return {};
        }
    },

    async writeProtectionData(data) {
        try {
            await fs.writeFile(PROTECTION_FILE, JSON.stringify(data, null, 2));
        } catch (error) {
            console.error('Protection data yazma hatası:', error);
        }
    },

    // Güvenli kontrol fonksiyonları
    isUserSafe(guildId, userId) {
        const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
        return safeUsers.includes(userId);
    },

    isRoleSafe(guildId, roleId) {
        const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
        return safeRoles.includes(roleId);
    },

    isUserSafeByRole(guild, userId) {
        const safeRoles = db.get(`güvenli_roller_${guild.id}`) || [];
        const member = guild.members.cache.get(userId);
        
        if (!member) return false;
        
        return safeRoles.some(roleId => member.roles.cache.has(roleId));
    },

    // İhlal tracker fonksiyonları
    trackViolation(guildId, userId, actionType, guild = null) {
        // Bot'un kendisini takip etmemesi için kontrol
        if (guild && userId === guild.client.user.id) {
            console.log(`[KorumaTracker] Bot kendisini takip etmez, skipping...`);
            return 0;
        }
        
        const key = `${guildId}_${userId}`;
        const now = Date.now();
        
        if (!violationTracker.has(key)) {
            violationTracker.set(key, []);
        }
        
        const violations = violationTracker.get(key);
        violations.push({ type: actionType, timestamp: now });
        
        // 1 saatten eski ihlalleri temizle
        const filteredViolations = violations.filter(v => now - v.timestamp < 3600000);
        violationTracker.set(key, filteredViolations);
        
        console.log(`[KorumaTracker] Kullanıcı: ${userId} | Guild: ${guildId} | İşlem: ${actionType} | Toplam İhlal: ${filteredViolations.length}`);
        
        return filteredViolations.length;
    },

    // Aksiyon tracker
    trackUserAction(guildId, userId, actionType) {
        const key = `${guildId}_${userId}`;
        const now = Date.now();
        
        if (!userActions.has(key)) {
            userActions.set(key, []);
        }
        
        const actions = userActions.get(key);
        actions.push({ type: actionType, timestamp: now });
        
        // 1 dakikadan eski aksiyonları temizle
        const filteredActions = actions.filter(action => now - action.timestamp < 60000);
        userActions.set(key, filteredActions);
        
        return filteredActions.length;
    },

    async handleViolationLimit(guild, userId, actionType, violationCount) {
        console.log(`[Ban Logic] Violation limit check - User: ${userId} | Count: ${violationCount} | Type: ${actionType}`);
        
        if (violationCount >= 3) {
            console.log(`[Ban Logic] Violation count >= 3, proceeding with ban...`);
            const member = await guild.members.fetch(userId).catch(err => {
                console.error(`[Ban Logic] Member fetch failed:`, err.message);
                return null;
            });
            
            if (!member) {
                console.log(`[Ban Logic] Member not found in guild`);
                return;
            }

            console.log(`[Ban Logic] Member found: ${member.user.tag}`);
            
            try {
                console.log(`[Ban Logic] Attempting to ban ${member.user.tag}...`);
                
                // Kullanıcıyı yasakla
                await member.ban({ 
                    reason: `Koruma sistemi ihlali: ${actionType} - ${violationCount} ihlal`
                });

                console.log(`[Ban Logic] Ban successful for ${member.user.tag}`);

                // Log kanalına bildir
                await this.sendSecurityLog(guild, member.user, actionType, violationCount, 'ban');

                // Tracker'dan temizle
                violationTracker.delete(`${guild.id}_${userId}`);
                console.log(`[Ban Logic] Violation tracker cleared for ${userId}`);

            } catch (error) {
                console.error(`[Ban Logic] Ban failed:`, error.message);
                await this.sendSecurityLog(guild, member.user, actionType, violationCount, 'ban_failed', error?.message);
            }
        }
    },

    async sendSecurityLog(guild, user, actionType, violationCount, status = 'violation', errorMessage) {
        try {
            const protectionData = await this.readProtectionData();
            const channelId = protectionData[guild.id]?.logChannel;
            
            if (!channelId) return;
            
            const channel = guild.channels.cache.get(channelId);
            if (!channel) return;

            const embed = new EmbedBuilder()
                .setColor(status === 'ban' ? 0xFF0000 : status === 'ban_failed' ? 0xFFA000 : 0xFF9800)
                .setTitle(status === 'ban' ? '🚨 Otomatik Ban Uygulandı' : status === 'ban_failed' ? '⚠️ Ban Başarısız' : '⚠️ Güvenlik İhlali')
                .setDescription(`İşlem: ${actionType}`)
                .addFields(
                    { name: 'Kullanıcı', value: `${user.tag || 'Bilinmiyor'} (${user.id})`, inline: true },
                    { name: 'İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                    { name: 'Durum', value: status === 'ban' ? '🔨 **Banlandı**' : status === 'ban_failed' ? '❌ **Ban Başarısız**' : '⚠️ **Uyarı**', inline: true }
                )
                .setTimestamp();
            
            if (errorMessage) {
                embed.addFields({ name: 'Hata', value: `\`${errorMessage}\`` });
            }

            await channel.send({ embeds: [embed] });
        } catch (err) {
            console.error('Güvenlik logu gönderilemedi:', err);
        }
    }
};





