// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');

// TÜM BOT KOMUTLARI İÇİN KAPSAMLI KATEGORİ SİSTEMİ
const categories = {
  moderasyon: {
    name: 'Moderasyon Sistemi',
    emoji: '⚖️',
    color: '#FF4444',
    description: 'Sunucuda düzen ve güvenliği sağlamak için kullanılan moderasyon komutları. Ban, kick, mute, warn gibi temel moderasyon araçları.',
    adminLevel: 'Moderatör+',
    commands: [
      {
        name: 'ban',
        description: 'Kullanıcıyı sunucudan kalıcı olarak yasaklar',
        usage: '/ban <kullanıcı> [sebep] [süre]',
        example: '/ban @ToxicUser Spam ve trolling 7d',
        adminLevel: 'Moderatör+',
        category: 'Temel Moderasyon'
      },
      {
        name: 'unban',
        description: 'Yasaklı kullanıcının yasağını kaldırır',
        usage: '/unban <kullanıcı_id> [sebep]',
        example: '/unban 123456789 Appeal kabul edildi',
        adminLevel: 'Moderatör+',
        category: 'Temel Moderasyon'
      },
      {
        name: 'kick',
        description: 'Kullanıcıyı sunucudan atar (tekrar girebilir)',
        usage: '/kick <kullanıcı> [sebep]',
        example: '/kick @SpamUser Kuralları ihlal',
        adminLevel: 'Moderatör+',
        category: 'Temel Moderasyon'
      },
      {
        name: 'mute',
        description: 'Kullanıcının yazma ve konuşma iznini kaldırır',
        usage: '/mute <kullanıcı> <süre> [sebep]',
        example: '/mute @NoiseUser 1h Sesli kanalda gürültü',
        adminLevel: 'Moderatör+',
        category: 'Temel Moderasyon'
      },
      {
        name: 'unmute',
        description: 'Kullanıcının mute cezasını kaldırır',
        usage: '/unmute <kullanıcı> [sebep]',
        example: '/unmute @User Ceza süresi doldu',
        adminLevel: 'Moderatör+',
        category: 'Temel Moderasyon'
      },
      {
        name: 'warn',
        description: 'Kullanıcıya uyarı verir ve otomatik ceza sistemi',
        usage: '/warn <kullanıcı> <sebep>',
        example: '/warn @BadUser Küfür kullanımı',
        adminLevel: 'Yardımcı+',
        category: 'Uyarı Sistemi'
      },
      {
        name: 'uyarı',
        description: 'Gelişmiş uyarı sistemi ve yönetimi',
        usage: '/uyarı <işlem_türü>',
        example: '/uyarı ver @User Spam',
        adminLevel: 'Yardımcı+',
        category: 'Uyarı Sistemi'
      },
      {
        name: 'uyarı-sil',
        description: 'Kullanıcının uyarılarını siler',
        usage: '/uyarı-sil <kullanıcı> [miktar]',
        example: '/uyarı-sil @User 2',
        adminLevel: 'Moderatör+',
        category: 'Uyarı Sistemi'
      },
      {
        name: 'uyarı-stats',
        description: 'Uyarı istatistiklerini gösterir',
        usage: '/uyarı-stats [kullanıcı]',
        example: '/uyarı-stats @User',
        adminLevel: 'Yardımcı+',
        category: 'Uyarı Sistemi'
      },
      {
        name: 'sicil',
        description: 'Kullanıcının moderasyon geçmişini gösterir',
        usage: '/sicil <kullanıcı>',
        example: '/sicil @User',
        adminLevel: 'Yardımcı+',
        category: 'Bilgi ve İstatistik'
      },
      {
        name: 'case-yönetim',
        description: 'Moderasyon vakalarını yönetir',
        usage: '/case-yönetim <işlem>',
        example: '/case-yönetim edit 123',
        adminLevel: 'Moderatör+',
        category: 'Vaka Yönetimi'
      },
      {
        name: 'mass-mod',
        description: 'Toplu moderasyon işlemleri yapar',
        usage: '/mass-mod <işlem_türü>',
        example: '/mass-mod ban @Role Toplu temizlik',
        adminLevel: 'Adlyuexstrator',
        category: 'Toplu İşlemler'
      },
      {
        name: 'mod-panel',
        description: 'Moderasyon kontrol paneli',
        usage: '/mod-panel',
        example: '/mod-panel',
        adminLevel: 'Moderatör+',
        category: 'Panel ve Kontrol'
      }
    ],
    examples: [
      {
        title: 'Spam Yapan Kullanıcı',
        situation: 'Bir kullanıcı sürekli spam mesaj atıyor',
        command: '/warn @SpamUser Spam mesaj atma → /mute @SpamUser 30m Spam devam etti',
        explanation: 'Önce uyarı ver, devam ederse mute at',
        tip: 'Uyarı sistemini kullanarak otomatik escalation sağla'
      },
      {
        title: 'Toksik Davranış',
        situation: 'Kullanıcı sürekli kavga çıkarıyor ve küfür ediyor',
        command: '/ban @ToxicUser Toksik davranış ve küfür 3d',
        explanation: '3 günlük ban vererek zamanında düşünmesini sağla',
        tip: 'Geçici banlar genellikle kalıcı banlardan daha etkilidir'
      }
    ]
  },

  ekip: {
    name: 'Ekip Yönetimi',
    emoji: '👥',
    color: '#4CAF50',
    description: 'Discord sunucusunda ekip oluşturma, yönetme ve takip etme komutları. Ekip sisteminin tüm özelliklerini kapsar.',
    adminLevel: 'Ekip Yöneticisi+',
    commands: [
      {
        name: 'ekip',
        description: 'Yeni ekip oluşturur veya mevcut ekibi yönetir',
        usage: '/ekip <işlem_türü>',
        example: '/ekip oluştur EkipAdı',
        adminLevel: 'Ekip Yöneticisi+',
        category: 'Temel Ekip İşlemleri'
      },
      {
        name: 'ekip-sil',
        description: 'Ekipleri siler veya üyeleri çıkarır',
        usage: '/ekip-sil <seçenek>',
        example: '/ekip-sil tek EkipAdı',
        adminLevel: 'Ekip Yöneticisi+',
        category: 'Ekip Silme'
      },
      {
        name: 'ekip-profil',
        description: 'Ekip profilini ve istatistiklerini gösterir',
        usage: '/ekip-profil <ekip_adı>',
        example: '/ekip-profil PolisEkibi',
        adminLevel: 'Herkes',
        category: 'Bilgi ve Profil'
      },
      {
        name: 'ekip-roller',
        description: 'Ekip rollerini yönetir ve düzenler',
        usage: '/ekip-roller <işlem>',
        example: '/ekip-roller ayarla @EkipRolü',
        adminLevel: 'Ekip Yöneticisi+',
        category: 'Rol Yönetimi'
      },
      {
        name: 'ekip-uyarı',
        description: 'Ekiplere uyarı verir ve rol atar',
        usage: '/ekip-uyarı',
        example: '/ekip-uyarı → Ekip seç → Rol ata',
        adminLevel: 'Ekip Yöneticisi+',
        category: 'Ekip Uyarı'
      },
      {
        name: 'ekip-yedek',
        description: 'Ekip verilerini yedekler ve geri yükler',
        usage: '/ekip-yedek <işlem>',
        example: '/ekip-yedek oluştur EkipAdı',
        adminLevel: 'Adlyuexstrator',
        category: 'Yedekleme'
      },
      {
        name: 'ekip-yönetim',
        description: 'Gelişmiş ekip yönetim araçları',
        usage: '/ekip-yönetim <özellik>',
        example: '/ekip-yönetim xp-ver @User 100',
        adminLevel: 'Ekip Yöneticisi+',
        category: 'Gelişmiş Yönetim'
      },
      {
        name: 'ekip-istatistik',
        description: 'Ekip istatistiklerini ve analizlerini gösterir',
        usage: '/ekip-istatistik [ekip_adı]',
        example: '/ekip-istatistik PolisEkibi',
        adminLevel: 'Herkes',
        category: 'İstatistik ve Analiz'
      }
    ],
    examples: [
      {
        title: 'Yeni Ekip Kurma',
        situation: 'Sunucuda yeni bir polis ekibi kurmak istiyorsunuz',
        command: '/ekip oluştur PolisEkibi → Kanal oluştur → Rolleri ayarla',
        explanation: 'Otomatik olarak ekip kanalı, rolleri ve sistemleri kurulur',
        tip: 'Ekip kurarken açık bir isim seçin ve emoji kullanın'
      },
      {
        title: 'Ekip Disiplini',
        situation: 'Bir ekip kurallara uymuyorsa uyarı vermek istiyorsunuz',
        command: '/ekip-uyarı → Ekip seç → Uyarı ver → İsteğe bağlı rol ata',
        explanation: 'Ekibe hem uyarı verir hem de ceza rolü atayabilirsiniz',
        tip: 'Rol atama özelliğini disiplin için kullanın'
      }
    ]
  },

  ticket: {
    name: 'Ticket Sistemi',
    emoji: '🎫',
    color: '#2196F3',
    description: 'Kullanıcı destek ve talep sistemleri. Ticket oluşturma, yönetme ve özelleştirme komutları.',
    adminLevel: 'Destek Ekibi+',
    commands: [
      {
        name: 'ticket',
        description: 'Temel ticket işlemleri yapar',
        usage: '/ticket <işlem>',
        example: '/ticket kapat Bu ticket çözüldü',
        adminLevel: 'Destek Ekibi+',
        category: 'Temel Ticket'
      },
      {
        name: 'ticket-panel',
        description: 'Ticket paneli oluşturur',
        usage: '/ticket-panel',
        example: '/ticket-panel',
        adminLevel: 'Adlyuexstrator',
        category: 'Panel Oluşturma'
      },
      {
        name: 'ticket-panel-ozel',
        description: 'Özel ticket paneli oluşturur',
        usage: '/ticket-panel-ozel <kategori>',
        example: '/ticket-panel-ozel başvuru',
        adminLevel: 'Adlyuexstrator',
        category: 'Panel Oluşturma'
      },
      {
        name: 'custom-ticket-panel',
        description: 'Tamamen özelleştirilebilir ticket paneli',
        usage: '/custom-ticket-panel',
        example: '/custom-ticket-panel',
        adminLevel: 'Adlyuexstrator',
        category: 'Özel Panel'
      },
      {
        name: 'ticket-ayarla',
        description: 'Ticket sistemi ayarlarını yapar',
        usage: '/ticket-ayarla <ayar_türü>',
        example: '/ticket-ayarla kategori #tickets',
        adminLevel: 'Adlyuexstrator',
        category: 'Sistem Ayarları'
      },
      {
        name: 'ticket-yonetim',
        description: 'Ticket yönetim araçları',
        usage: '/ticket-yonetim <işlem>',
        example: '/ticket-yonetim transfer @Staff',
        adminLevel: 'Destek Ekibi+',
        category: 'Yönetim Araçları'
      },
      {
        name: 'ticket-istatistik',
        description: 'Ticket istatistiklerini gösterir',
        usage: '/ticket-istatistik [zaman_aralığı]',
        example: '/ticket-istatistik haftalık',
        adminLevel: 'Destek Ekibi+',
        category: 'İstatistik'
      },
      {
        name: 'borp-ticket',
        description: 'Borp özel ticket sistemi',
        usage: '/borp-ticket <işlem>',
        example: '/borp-ticket oluştur',
        adminLevel: 'Destek Ekibi+',
        category: 'Özel Sistemler'
      }
    ]
  },

  whitelist: {
    name: 'Whitelist Sistemi',
    emoji: '📋',
    color: '#FF9800',
    description: 'Sunucu whitelist yönetimi. Kullanıcı onaylama, beyaz liste kontrolü ve yönetimi.',
    adminLevel: 'Whitelist Yetkilisi+',
    commands: [
      {
        name: 'whitelist',
        description: 'Kullanıcıyı whitelist\'e ekler',
        usage: '/whitelist <kullanıcı> [sebep]',
        example: '/whitelist @NewUser Başvuru onaylandı',
        adminLevel: 'Whitelist Yetkilisi+',
        category: 'Temel Whitelist'
      },
      {
        name: 'whitelist-sil',
        description: 'Kullanıcıyı whitelist\'ten çıkarır',
        usage: '/whitelist-sil <kullanıcı> [sebep]',
        example: '/whitelist-sil @User Kural ihlali',
        adminLevel: 'Whitelist Yetkilisi+',
        category: 'Whitelist Yönetimi'
      },
      {
        name: 'whitelist-top',
        description: 'Whitelist istatistiklerini gösterir',
        usage: '/whitelist-top [sayı]',
        example: '/whitelist-top 10',
        adminLevel: 'Whitelist Yetkilisi+',
        category: 'İstatistik'
      },
      {
        name: 'non-wl-liste',
        description: 'Whitelist olmayan kullanıcıları listeler',
        usage: '/non-wl-liste',
        example: '/non-wl-liste',
        adminLevel: 'Whitelist Yetkilisi+',
        category: 'Liste ve Kontrol'
      },
      {
        name: 'guvenli',
        description: 'Rol veya kullanıcıyı güvenli listeye ekler',
        usage: '/guvenli rol:@rol veya /guvenli kullanıcı:@kullanıcı',
        example: '/guvenli rol:@Moderatör veya /guvenli kullanıcı:@TrustedUser',
        adminLevel: 'Moderatör+',
        category: 'Güvenlik'
      },
      {
        name: 'güvenli',
        description: 'Gelişmiş güvenli yönetim sistemi (ekle, liste, sil, panel)',
        usage: '/güvenli <ekle|liste|sil|panel> [seçenekler]',
        example: '/güvenli panel | /güvenli ekle rol:@Mod | /güvenli liste görünüm:analitik',
        adminLevel: 'Moderatör+',
        category: 'Güvenlik'
      }
    ]
  },

  otomod: {
    name: 'Otomod ve Koruma',
    emoji: '🤖',
    color: '#9C27B0',
    description: 'Otomatik moderasyon ve sunucu koruma sistemleri. Spam, raid ve güvenlik koruması.',
    adminLevel: 'Yönetici+',
    commands: [
      {
        name: 'automod',
        description: 'Otomatik moderasyon sistemini yönetir',
        usage: '/automod <ayar>',
        example: '/automod spam-koruma aç',
        adminLevel: 'Yönetici+',
        category: 'Temel Otomod'
      },
      // Guard komutu kaldırıldı
      {
        name: 'koruma',
        description: 'Gelişmiş koruma ayarları',
        usage: '/koruma <tür>',
        example: '/koruma kanal-koruma aç',
        adminLevel: 'Adlyuexstrator',
        category: 'Koruma Sistemi'
      },
      {
        name: 'af',
        description: 'Toplu af sistemi',
        usage: '/af <tür> [miktar]',
        example: '/af uyarı 50',
        adminLevel: 'Adlyuexstrator',
        category: 'Af Sistemi'
      }
    ]
  },

  rol: {
    name: 'Rol Yönetimi',
    emoji: '🎭',
    color: '#E91E63',
    description: 'Sunucu rol yönetimi. Rol verme, alma, düzenleme ve toplu rol işlemleri.',
    adminLevel: 'Yardımcı+',
    commands: [
      {
        name: 'rol',
        description: 'Temel rol işlemleri yapar',
        usage: '/rol <işlem> <kullanıcı> <rol>',
        example: '/rol ver @User @VIP',
        adminLevel: 'Yardımcı+',
        category: 'Temel Rol İşlemleri'
      },
      {
        name: 'rol-ver',
        description: 'Kullanıcıya rol verir',
        usage: '/rol-ver <kullanıcı> <rol>',
        example: '/rol-ver @User @Moderatör',
        adminLevel: 'Yardımcı+',
        category: 'Rol Verme'
      },
      {
        name: 'rol-al',
        description: 'Kullanıcıdan rol alır',
        usage: '/rol-al <kullanıcı> <rol>',
        example: '/rol-al @User @VIP',
        adminLevel: 'Yardımcı+',
        category: 'Rol Alma'
      },
      {
        name: 'toplurol',
        description: 'Toplu rol işlemleri yapar',
        usage: '/toplurol <işlem>',
        example: '/toplurol ver @everyone @Event',
        adminLevel: 'Yönetici+',
        category: 'Toplu İşlemler'
      },
      {
        name: 'rolbilgi',
        description: 'Rol hakkında detaylı bilgi verir',
        usage: '/rolbilgi <rol>',
        example: '/rolbilgi @Moderatör',
        adminLevel: 'Herkes',
        category: 'Bilgi'
      },
      {
        name: 'herkeserolver',
        description: 'Herkese rol verir',
        usage: '/herkeserolver <rol>',
        example: '/herkeserolver @Event',
        adminLevel: 'Adlyuexstrator',
        category: 'Toplu İşlemler'
      }
    ]
  },

  isim: {
    name: 'İsim Yönetimi',
    emoji: '📝',
    color: '#607D8B',
    description: 'Kullanıcı isim yönetimi ve IC isim sistemi. İsim değiştirme, onaylama ve kayıt işlemleri.',
    adminLevel: 'Yardımcı+',
    commands: [
      {
        name: 'isim',
        description: 'Kullanıcının ismini değiştirir',
        usage: '/isim <kullanıcı> <yeni_isim>',
        example: '/isim @User Ahmet Yılmaz',
        adminLevel: 'Yardımcı+',
        category: 'Temel İsim İşlemleri'
      },
      {
        name: 'ic-isim',
        description: 'IC isim sistemi ile isim değiştirir',
        usage: '/ic-isim <kullanıcı> <ic_isim>',
        example: '/ic-isim @User John Doe',
        adminLevel: 'Yardımcı+',
        category: 'IC İsim Sistemi'
      },
      {
        name: 'ic-isim-ayarla',
        description: 'IC isim sistemi ayarlarını yapar',
        usage: '/ic-isim-ayarla <ayar>',
        example: '/ic-isim-ayarla kanal #ic-names',
        adminLevel: 'Adlyuexstrator',
        category: 'IC Sistem Ayarları'
      },
      {
        name: 'kayıtsız',
        description: 'Kullanıcıyı kayıtsız yapar',
        usage: '/kayıtsız <kullanıcı>',
        example: '/kayıtsız @User',
        adminLevel: 'Yardımcı+',
        category: 'Kayıt İşlemleri'
      }
    ]
  },

  log: {
    name: 'Log ve İzleme',
    emoji: '📊',
    color: '#795548',
    description: 'Sunucu olaylarını izleme ve kaydetme sistemleri. Detaylı log tutma ve analiz araçları.',
    adminLevel: 'Yönetici+',
    commands: [
      {
        name: 'log-ayarla',
        description: 'Log sistemini yapılandırır',
        usage: '/log-ayarla <log_türü> <kanal>',
        example: '/log-ayarla mod-log #mod-logs',
        adminLevel: 'Adlyuexstrator',
        category: 'Log Ayarları'
      },
      {
        name: 'backup',
        description: 'Sunucu verilerini yedekler',
        usage: '/backup <tür>',
        example: '/backup full',
        adminLevel: 'Adlyuexstrator',
        category: 'Yedekleme'
      }
    ]
  },

  genel: {
    name: 'Genel Komutlar',
    emoji: '⚙️',
    color: '#607D8B',
    description: 'Genel bot komutları ve yardımcı araçlar. Bilgi, durum ve genel işlemler.',
    adminLevel: 'Herkes',
    commands: [
      {
        name: 'bot-durum',
        description: 'Bot durumunu ve istatistiklerini gösterir',
        usage: '/bot-durum',
        example: '/bot-durum',
        adminLevel: 'Herkes',
        category: 'Durum Bilgisi'
      },
      {
        name: 'status',
        description: 'Sunucu durumunu gösterir',
        usage: '/status',
        example: '/status',
        adminLevel: 'Herkes',
        category: 'Durum Bilgisi'
      },
      {
        name: 'sunucu',
        description: 'Sunucu bilgilerini gösterir',
        usage: '/sunucu',
        example: '/sunucu',
        adminLevel: 'Herkes',
        category: 'Bilgi'
      },
      {
        name: 'ip',
        description: 'Sunucu IP bilgilerini gösterir',
        usage: '/ip',
        example: '/ip',
        adminLevel: 'Herkes',
        category: 'Bilgi'
      },
      {
        name: 'sil',
        description: 'Mesajları siler',
        usage: '/sil <miktar>',
        example: '/sil 10',
        adminLevel: 'Yardımcı+',
        category: 'Temizlik'
      },
      {
        name: 'yardım',
        description: 'Bu yardım menüsünü gösterir',
        usage: '/yardım [kategori]',
        example: '/yardım moderasyon',
        adminLevel: 'Herkes',
        category: 'Yardım'
      }
    ]
  },

  eglence: {
    name: 'Eğlence ve Etkinlik',
    emoji: '🎉',
    color: '#4CAF50',
    description: 'Eğlence komutları ve etkinlik yönetimi. Çekiliş, oyunlar ve sosyal özellikler.',
    adminLevel: 'Herkes',
    commands: [
      {
        name: 'çekiliş',
        description: 'Çekiliş düzenler',
        usage: '/çekiliş <süre> <kazanan_sayısı> <ödül>',
        example: '/çekiliş 1h 1 VIP Üyelik',
        adminLevel: 'Yardımcı+',
        category: 'Çekiliş'
      },
      {
        name: 'çekiliş-liste',
        description: 'Aktif çekilişleri listeler',
        usage: '/çekiliş-liste',
        example: '/çekiliş-liste',
        adminLevel: 'Herkes',
        category: 'Çekiliş'
      },
      {
        name: 'reroll',
        description: 'Çekilişi tekrar çeker',
        usage: '/reroll <mesaj_id>',
        example: '/reroll 123456789',
        adminLevel: 'Yardımcı+',
        category: 'Çekiliş'
      }
    ]
  },

  ozel: {
    name: 'Özel Sistemler',
    emoji: '⭐',
    color: '#FFD700',
    description: 'Sunucuya özel geliştirilmiş sistemler ve özellikler.',
    adminLevel: 'Adlyuexstrator',
    commands: [
      {
        name: 'hex-ayarla',
        description: 'Hex sistemini ayarlar',
        usage: '/hex-ayarla <ayar>',
        example: '/hex-ayarla kanal #hex',
        adminLevel: 'Adlyuexstrator',
        category: 'Hex Sistemi'
      },
      {
        name: 'hex-durum',
        description: 'Hex sistem durumunu gösterir',
        usage: '/hex-durum',
        example: '/hex-durum',
        adminLevel: 'Adlyuexstrator',
        category: 'Hex Sistemi'
      },
      {
        name: 'eval',
        description: 'Kod çalıştırır (sadece bot sahipleri)',
        usage: '/eval <kod>',
        example: '/eval console.log("test")',
        adminLevel: 'Bot Sahibi',
        category: 'Geliştirici'
      },
      {
        name: 'bot-yetki',
        description: 'Bot yetki sistemini yönetir',
        usage: '/bot-yetki <işlem>',
        example: '/bot-yetki ekle @User',
        adminLevel: 'Bot Sahibi',
        category: 'Bot Yönetimi'
      }
    ]
  }
};

// Kullanıcı oturumları
const sessions = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('yardım')
    .setDescription('Kapsamlı bot yardım sistemi - Tüm komutlar ve kullanım rehberi')
    .addStringOption(option =>
      option.setName('kategori')
        .setDescription('Belirli bir kategori seçin')
        .addChoices(
          { name: '⚖️ Moderasyon Sistemi', value: 'moderasyon' },
          { name: '👥 Ekip Yönetimi', value: 'ekip' },
          { name: '🎫 Ticket Sistemi', value: 'ticket' },
          { name: '📋 Whitelist Sistemi', value: 'whitelist' },
          { name: '🤖 Otomod ve Koruma', value: 'otomod' },
          { name: '🎭 Rol Yönetimi', value: 'rol' },
          { name: '📝 İsim Yönetimi', value: 'isim' },
          { name: '📊 Log ve İzleme', value: 'log' },
          { name: '⚙️ Genel Komutlar', value: 'genel' },
          { name: '🎉 Eğlence ve Etkinlik', value: 'eglence' },
          { name: '⭐ Özel Sistemler', value: 'ozel' }
        )),

  async execute(interaction, client) {
    try {
      const selectedCategory = interaction.options.getString('kategori');
      
      // Kullanıcı oturum bilgilerini güncelle
      sessions.set(interaction.user.id, {
        lastInteraction: Date.now(),
        currentCategory: selectedCategory,
        currentPage: 0
      });

      // Tüm komutları topla
      const { commandMap } = require('../handlers/commandHandler');
      const allCommands = commandMap || new Map();

      if (selectedCategory) {
        // Direkt kategori göster
        await this.showCategory(interaction, selectedCategory, allCommands);
      } else {
        // Ana menüyü göster
        await this.showMainMenu(interaction, allCommands);
      }

    } catch (error) {
      console.error('Yardım komutu hatası:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('❌ **HATA!**')
        .setDescription('Yardım sistemi yüklenirken bir hata oluştu. Lütfen tekrar deneyin.')
        .setTimestamp();

      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
      } else {
        await interaction.followUp({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] });
      }
    }
  },

  // Ana menüyü göster
  async showMainMenu(interaction, allCommands) {
    const userPermissions = this.getUserPermissionLevel(interaction.member);
    
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle('🎯 **KAPSAMLI BOT YARDIM SİSTEMİ**')
      .setDescription(`
╭─────────────────────────────────╮
│  🚀 **HOŞGELDİNİZ!**              │
│  Tüm bot komutlarına erişin       │
╰─────────────────────────────────╯

👋 **Merhaba ${interaction.user.username}!**
Aşağıdan keşfetmek istediğiniz kategoriyi seçin.

🔑 **Yetki Seviyeniz:** ${userPermissions.level} ${this.getPermissionEmoji(userPermissions.level)}
🌟 **Erişim Durumunuz:** ${userPermissions.access}

💡 **Kullanım İpucu:** Her kategoride detaylı açıklamalar, örnekler ve pratik rehberler bulacaksınız!`)
      .setFooter({ 
        text: `Toplam ${Object.keys(categories).length} kategori mevcut • Yetki: ${userPermissions.level}`, 
        iconURL: interaction.user.displayAvatarURL() 
      })
      .setTimestamp();

    // Kullanıcının erişebileceği kategorileri filtrele
    const accessibleCategories = Object.entries(categories).filter(([key, category]) => {
      return this.checkCategoryAccess(category, userPermissions);
    });

    // Kategori istatistikleri ekle
    embed.addFields({
      name: '📊 **ERİŞİM İSTATİSTİKLERİ**',
      value: `
🟢 **Erişilebilir:** ${accessibleCategories.length} kategori
🔴 **Kısıtlı:** ${Object.keys(categories).length - accessibleCategories.length} kategori
📦 **Toplam Komut:** ${this.getTotalCommandCount()} komut
      `,
      inline: true
    });

    // Kategori seçici menu oluştur
    const categoryOptions = accessibleCategories.map(([key, category]) => ({
      label: category.name,
      value: key,
      description: category.description.substring(0, 100),
      emoji: category.emoji
    }));

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('help_category_select')
      .setPlaceholder('🎯 Kategori seçin...')
      .addOptions(categoryOptions);

    const actionRow = new ActionRowBuilder().addComponents(selectMenu);

    // Butonlar
    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('help_all_commands')
          .setLabel('📋 Tüm Komutlar')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('help_search')
          .setLabel('🔍 Komut Ara')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('help_guide')
          .setLabel('📚 Rehber')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('help_close')
          .setLabel('❌ Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ embeds: [embed], components: [actionRow, buttons] });
    } else {
      await interaction.reply({ embeds: [embed], components: [actionRow, buttons], flags: [MessageFlags.Ephemeral] });
    }

    this.setupCollector(interaction, allCommands);
  },

  // Kategori gösterimi
  async showCategory(interaction, categoryKey, allCommands) {
    const category = categories[categoryKey];
    if (!category) {
      return await interaction.reply({ 
        content: '❌ **Geçersiz kategori!** Lütfen geçerli bir kategori seçin.', 
        flags: [MessageFlags.Ephemeral] 
      });
    }

    // Yetki kontrolü
    const userPermissions = this.getUserPermissionLevel(interaction.member);
    if (!this.checkCategoryAccess(category, userPermissions)) {
      return await interaction.reply({
        content: `🔒 **Erişim Engellendi!**\n\nBu kategori için **${category.adminLevel}** yetkisi gerekiyor.\nMevcut yetki seviyeniz: **${userPermissions.level}**`,
        flags: [MessageFlags.Ephemeral]
      });
    }

    // Normal kategori görünümü
    const categoryCommands = category.commands || [];

    const embed = new EmbedBuilder()
      .setColor(category.color)
      .setTitle(`${category.emoji} **${category.name.toUpperCase()}**`)
      .setDescription(`
╭─────────────────────────────────╮
│  📋 **KATEGORİ BİLGİLERİ**        │
│  ${category.description}         │
╰─────────────────────────────────╯

👑 **Gereken Yetki:** ${category.adminLevel || 'Herkes'}
🔧 **Komut Sayısı:** ${categoryCommands.length}
📊 **Yetki Seviyeniz:** ${userPermissions.level} ✅`)
      .setFooter({ 
        text: `Kategori: ${category.name} • Sayfa 1/1`, 
        iconURL: interaction.user.displayAvatarURL() 
      })
      .setTimestamp();

    // Komutları detaylı olarak listele
    if (categoryCommands.length > 0) {
      // Komutları gruplara ayır
      const commandGroups = {};
      categoryCommands.forEach(cmd => {
        const group = cmd.category || 'Genel';
        if (!commandGroups[group]) commandGroups[group] = [];
        commandGroups[group].push(cmd);
      });

      // Her grup için field ekle
      Object.entries(commandGroups).forEach(([groupName, commands]) => {
        const commandList = commands.map((cmd, index) => {
          const emoji = this.getCommandEmoji(cmd);
          return `${emoji} \`/${cmd.name}\`\n└ ${cmd.description || 'Açıklama yok'}\n└ 📝 **Kullanım:** ${cmd.usage || `/${cmd.name}`}\n└ 💡 **Örnek:** ${cmd.example || 'Örnek yok'}`;
        }).join('\n\n');

        embed.addFields({
          name: `📂 **${groupName.toUpperCase()} KOMUTLARI**`,
          value: commandList.length > 1024 ? commandList.substring(0, 1021) + '...' : commandList,
          inline: false
        });
      });
    } else {
      embed.addFields({
        name: '❌ **KOMUT BULUNAMADI**',
        value: 'Bu kategoride henüz komut bulunmuyor.',
        inline: false
      });
    }

    // Navigation butonları
    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('help_back_main')
          .setLabel('⬅️ Ana Menü')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`help_command_detail_${categoryKey}`)
          .setLabel('📖 Detaylı Bilgi')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(`help_examples_${categoryKey}`)
          .setLabel('💡 Örnekler')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('help_close')
          .setLabel('❌ Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ embeds: [embed], components: [buttons] });
    } else {
      await interaction.reply({ embeds: [embed], components: [buttons], flags: [MessageFlags.Ephemeral] });
    }

    this.setupCollector(interaction, allCommands);
  },

  // Etkileşim toplayıcısı
  setupCollector(interaction, allCommands) {
    const collector = interaction.channel.createMessageComponentCollector({
      filter: i => i.user.id === interaction.user.id,
      time: 300000 // 5 dakika
    });

    collector.on('collect', async i => {
      try {
        if (!i.deferred && !i.replied) {
          await i.deferUpdate();
        }
      } catch (error) {
        console.log('Interaction defer hatası (normal):', error.message);
        return;
      }

      switch (i.customId) {
        case 'help_category_select':
          const categoryKey = i.values[0];
          await this.showCategory(i, categoryKey, allCommands);
          break;

        case 'help_back_main':
          await this.showMainMenu(i, allCommands);
          break;

        case 'help_close':
          await i.editReply({
            content: '✅ **Yardım menüsü kapatıldı.**\n\nTekrar yardıma ihtiyacınız olduğunda `/yardım` komutunu kullanabilirsiniz.',
            embeds: [],
            components: []
          });
          collector.stop();
          break;

        default:
          if (i.customId.startsWith('help_command_detail_') || 
              i.customId.startsWith('help_examples_') ||
              i.customId === 'help_guide_practice') {
            await this.handleButtonInteraction(i);
          }
          break;
      }
    });

    collector.on('end', () => {
      sessions.delete(interaction.user.id);
    });
  },

  // Yardımcı fonksiyonlar
  getTotalCommandCount() {
    return Object.values(categories).reduce((total, category) => {
      return total + (category.commands ? category.commands.length : 0);
    }, 0);
  },

  getPermissionEmoji(level) {
    const emojis = {
      'Adlyuexstrator': '👑',
      'Yönetici': '🛡️',
      'Moderatör': '⚖️',
      'Yardımcı': '🤝',
      'Üye': '👤'
    };
    return emojis[level] || '❓';
  },

  // Kullanıcının yetki seviyesini belirle
  getUserPermissionLevel(member) {
    if (!member) return { level: 'Üye', access: 'Sınırlı', priority: 0 };

    const permissions = member.permissions;
    
    if (permissions.has('Adlyuexstrator')) {
      return { level: 'Adlyuexstrator', access: 'Tam Erişim', priority: 4 };
    }
    
    if (permissions.has('ManageGuild') || permissions.has('ManageChannels')) {
      return { level: 'Yönetici', access: 'Geniş Erişim', priority: 3 };
    }
    
    if (permissions.has('ModerateMembers') || permissions.has('BanMembers') || permissions.has('KickMembers')) {
      return { level: 'Moderatör', access: 'Moderasyon Erişimi', priority: 2 };
    }
    
    if (permissions.has('ManageMessages') || permissions.has('ManageRoles')) {
      return { level: 'Yardımcı', access: 'Kısıtlı Erişim', priority: 1 };
    }
    
    return { level: 'Üye', access: 'Temel Erişim', priority: 0 };
  },

  // Kategoriye erişim kontrolü
  checkCategoryAccess(category, userPermissions) {
    if (!category.adminLevel || category.adminLevel === 'Herkes') return true;
    
    const requiredLevels = {
      'Üye': 0,
      'Yardımcı': 1,
      'Moderatör+': 2,
      'Moderatör': 2,
      'Yetkili+': 2,
      'Yönetici+': 3,
      'Yönetici': 3,
      'Adlyuexstrator': 4,
      'Ekip Yöneticisi+': 2,
      'Destek Ekibi+': 1,
      'Whitelist Yetkilisi+': 2,
      'Bot Sahibi': 5
    };
    
    const required = requiredLevels[category.adminLevel] || 0;
    return userPermissions.priority >= required;
  },

  // Buton etkileşimlerini handle et
  async handleButtonInteraction(interaction) {
    const customId = interaction.customId;
    
    try {
      if (customId === 'help_back_main') {
        // Ana menüye dön
        await this.showMainMenu(interaction);
        
      } else if (customId === 'help_close') {
        // Yardım menüsünü kapat
        await interaction.update({
          content: '✅ **Yardım menüsü kapatıldı.**\n\nTekrar yardıma ihtiyacınız olduğunda `/yardım` komutunu kullanabilirsiniz.',
          embeds: [],
          components: []
        });
        
      } else if (customId.startsWith('help_command_detail_')) {
        // Komut detaylarını göster
        const categoryKey = customId.replace('help_command_detail_', '');
        await this.showCommandDetails(interaction, categoryKey);
        
      } else if (customId.startsWith('help_examples_')) {
        // Komut örneklerini göster
        const categoryKey = customId.replace('help_examples_', '');
        await this.showCommandExamples(interaction, categoryKey);
        
      } else if (customId === 'help_guide_practice') {
        // Pratik yapma önerileri göster
        await this.showPracticeGuide(interaction);
      }
      
    } catch (error) {
      console.error('Yardım button interaction hatası:', error);
      
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: '❌ **Hata!** Button etkileşimi işlenirken bir sorun oluştu.',
          ephemeral: true
        });
      } else {
        await interaction.followUp({
          content: '❌ **Hata!** İşlem tamamlanamadı.',
          ephemeral: true
        });
      }
    }
  },

  // Komut detaylarını göster
  async showCommandDetails(interaction, categoryKey) {
    const category = categories[categoryKey];
    if (!category) return;

    const embed = new EmbedBuilder()
      .setColor(category.color)
      .setTitle(`${category.emoji} **${category.name.toUpperCase()} - DETAYLI BİLGİ**`)
      .setDescription(`
╭─────────────────────────────────╮
│  🔍 **KOMUT DETAYLARI**           │
│  Her komutun ayrıntılı açıklaması │
╰─────────────────────────────────╯`)
      .setFooter({ 
        text: `Detay sayfası: ${category.name}`, 
        iconURL: interaction.user.displayAvatarURL() 
      })
      .setTimestamp();

    // Her komut için detaylı bilgi
    if (category.commands && category.commands.length > 0) {
      category.commands.forEach((cmd, index) => {
        const permissions = cmd.adminLevel ? `🔒 **${cmd.adminLevel}**` : '🌍 **Herkes**';
        
        embed.addFields({
          name: `${index + 1}. \`/${cmd.name}\``,
          value: `
**📋 Açıklama:**
${cmd.description || 'Açıklama bulunmuyor'}

**⚙️ Kullanım:**
\`${cmd.usage || `/${cmd.name}`}\`

**💡 Örnek:**
\`${cmd.example || 'Örnek bulunmuyor'}\`

**👑 Gerekli Yetki:** ${permissions}

**🎯 Kategori:** ${cmd.category || 'Genel'}
          `,
          inline: false
        });
      });
    }

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('help_back_main')
          .setLabel('⬅️ Ana Menü')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`help_examples_${categoryKey}`)
          .setLabel('💡 Örnekler')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('help_close')
          .setLabel('❌ Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.update({ embeds: [embed], components: [buttons] });
  },

  // Komut örneklerini göster
  async showCommandExamples(interaction, categoryKey) {
    const category = categories[categoryKey];
    if (!category) return;

    const embed = new EmbedBuilder()
      .setColor(category.color)
      .setTitle(`${category.emoji} **${category.name.toUpperCase()} - ÖRNEK KULLANIM**`)
      .setDescription(`
╭─────────────────────────────────╮
│  💡 **KULLANIM ÖRNEKLERİ**        │
│  Pratik senaryolar ve örnekler    │
╰─────────────────────────────────╯

Aşağıdaki örnekleri inceleyerek komutları daha etkili kullanabilirsiniz:`)
      .setFooter({ 
        text: `Örnekler: ${category.name}`, 
        iconURL: interaction.user.displayAvatarURL() 
      })
      .setTimestamp();

    // Örnek senaryolar
    if (category.examples) {
      category.examples.forEach((example, index) => {
        embed.addFields({
          name: `📖 **SENARYO ${index + 1}: ${example.title}**`,
          value: `
**🎯 Durum:** ${example.situation}

**🔧 Çözüm:**
\`${example.command}\`

**📝 Açıklama:**
${example.explanation}

**⚡ İpucu:** ${example.tip}
          `,
          inline: false
        });
      });
    } else {
      // Komutlardan otomatik örnek oluştur
      if (category.commands && category.commands.length > 0) {
        category.commands.slice(0, 3).forEach((cmd, index) => {
          embed.addFields({
            name: `💡 **${cmd.name.toUpperCase()} ÖRNEK KULLANIM**`,
            value: `
**🔧 Temel Kullanım:**
\`${cmd.example || cmd.usage || `/${cmd.name}`}\`

**📋 Ne Yapar:**
${cmd.description || 'Bu komut belirli işlemleri gerçekleştirir'}
            `,
            inline: false
          });
        });
      }
    }

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('help_back_main')
          .setLabel('⬅️ Ana Menü')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`help_command_detail_${categoryKey}`)
          .setLabel('📖 Detaylı Bilgi')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('help_close')
          .setLabel('❌ Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.update({ embeds: [embed], components: [buttons] });
  },

  // Pratik rehberi göster
  async showPracticeGuide(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🎯 **PRATİK YAPMA REHBERİ**')
      .setDescription(`
╭─────────────────────────────────╮
│  🚀 **YETKİLİ OLARAK GELİŞİM**   │
│  Adım adım pratik önerileri       │
╰─────────────────────────────────╯

Bu rehber size yetkili olarak nasıl daha iyi olabileceğinizi gösterir:`)
      .addFields(
        {
          name: '📚 **1. TEMEL EĞİTİM**',
          value: `
• Discord sunucu kurallarını öğrenin
• Bot komutlarını günlük pratikte kullanın
• Farklı yetki seviyelerini anlayın
• Üyelerin sorularına sabırla cevap verin
          `,
          inline: false
        },
        {
          name: '⚡ **2. GÜNLÜK PRATİK**',
          value: `
• Her gün farklı komutları test edin
• Üyelerle etkileşime girin
• Sorunları çözmeye odaklanın
• Ekip arkadaşlarınızla işbirliği yapın
          `,
          inline: false
        },
        {
          name: '🎯 **3. İLERİ SEVİYE**',
          value: `
• Kompleks durumları yönetmeyi öğrenin
• Sistem ayarlarını anlayın
• Otomatik sistemleri kullanın
• Yeni yetkililere rehberlik edin
          `,
          inline: false
        },
        {
          name: '💡 **4. ÖNERİLER**',
          value: `
• **Günlük hedef:** En az 3 farklı komut kullanın
• **Haftalık hedef:** Yeni bir sistem öğrenin
• **Aylık hedef:** Bir başkasına öğretin
• **Sürekli:** Geri bildirim alın ve verin
          `,
          inline: false
        }
      )
      .setFooter({ 
        text: 'Pratik rehberi • Sürekli gelişim için', 
        iconURL: interaction.user.displayAvatarURL() 
      })
      .setTimestamp();

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('help_back_main')
          .setLabel('⬅️ Ana Menü')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('help_close')
          .setLabel('❌ Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.update({ embeds: [embed], components: [buttons] });
  },

  // Komut için emoji getir
  getCommandEmoji(command) {
    const emojis = {
      'ban': '🔨',
      'kick': '👢',
      'mute': '🔇',
      'warn': '⚠️',
      'ekip': '👥',
      'ticket': '🎫',
      'whitelist': '📋',
      'automod': '🤖',
      'backup': '💾',
      'default': '⚡'
    };
    
    return emojis[command.name] || emojis['default'];
  }
};





