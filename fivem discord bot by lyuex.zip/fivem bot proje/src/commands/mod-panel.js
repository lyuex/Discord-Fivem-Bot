// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { Moderation, Mute, TempBan } = require('../Schemas/ModerationSchema');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mod-panel')
    .setDescription('📊 Sunucu moderasyon istatistikleri ve genel bakış')
    .addStringOption(option =>
      option.setName('görünüm')
        .setDescription('📋 Hangi bilgileri görmek istiyorsunuz?')
        .setRequired(false)
        .addChoices(
          { name: '📊 Genel İstatistikler', value: 'stats' },
          { name: '🚨 Aktif Cezalar', value: 'active' },
          { name: '👮 Moderatör Performansı', value: 'moderators' },
          { name: '📅 Son 24 Saat', value: 'recent' },
          { name: '⚠️ Riskli Kullanıcılar', value: 'risky' },
          { name: '📈 Trend Analizi', value: 'trends' }
        ))
    .addStringOption(option =>
      option.setName('zaman_aralığı')
        .setDescription('📅 Zaman aralığı seçin')
        .setRequired(false)
        .addChoices(
          { name: 'Son 24 Saat', value: '24h' },
          { name: 'Son 7 Gün', value: '7d' },
          { name: 'Son 30 Gün', value: '30d' },
          { name: 'Tüm Zamanlar', value: 'all' }
        ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const view = interaction.options.getString('görünüm') || 'stats';
      const timeRange = interaction.options.getString('zaman_aralığı') || '30d';
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için moderasyon yetkisine sahip olmalısınız.'
        });
      }

      // Zaman aralığını hesapla
      let dateFilter = {};
      const now = new Date();
      
      switch (timeRange) {
        case '24h':
          dateFilter = { createdAt: { $gte: new Date(now.getTime() - 24 * 60 * 60 * 1000) } };
          break;
        case '7d':
          dateFilter = { createdAt: { $gte: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000) } };
          break;
        case '30d':
          dateFilter = { createdAt: { $gte: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000) } };
          break;
        case 'all':
        default:
          dateFilter = {};
          break;
      }

      const filter = { guildId: guild.id, ...dateFilter };

      switch (view) {
        case 'stats':
          await this.showGeneralStats(interaction, filter, timeRange);
          break;
        case 'active':
          await this.showActivePunishments(interaction, guild);
          break;
        case 'moderators':
          await this.showModeratorStats(interaction, filter, timeRange);
          break;
        case 'recent':
          await this.showRecentActivity(interaction, guild);
          break;
        case 'risky':
          await this.showRiskyUsers(interaction, guild);
          break;
        case 'trends':
          await this.showTrends(interaction, filter, timeRange);
          break;
        default:
          await this.showGeneralStats(interaction, filter, timeRange);
      }

    } catch (error) {
      console.error('Mod panel hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  },

  async showGeneralStats(interaction, filter, timeRange) {
    const guild = interaction.guild;

    // Genel istatistikler
    const totalActions = await Moderation.countDocuments(filter);
    const activeActions = await Moderation.countDocuments({ ...filter, active: true });
    
    // Tür bazlı istatistikler
    const typeStats = await Moderation.aggregate([
      { $match: filter },
      { $group: { _id: '$type', count: { $sum: 1 } } }
    ]);

    const typeMap = {};
    typeStats.forEach(stat => {
      typeMap[stat._id] = stat.count;
    });

    // Aktif cezalar
    const activeMutes = await Mute.countDocuments({ guildId: guild.id, active: true });
    const activeTempBans = await TempBan.countDocuments({ guildId: guild.id, active: true });

    // Son 7 günün günlük aktivitesi
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      
      const dailyCount = await Moderation.countDocuments({
        guildId: guild.id,
        createdAt: { $gte: date, $lt: nextDate }
      });
      
      last7Days.push(dailyCount);
    }

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('📊 Moderasyon Panel - Genel İstatistikler')
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setDescription(
        `**🏢 Sunucu:** ${guild.name}\n` +
        `**📅 Zaman Aralığı:** ${this.getTimeRangeText(timeRange)}\n` +
        `**📊 Toplam İşlem:** ${totalActions}\n` +
        `**🟢 Aktif İşlem:** ${activeActions}`
      );

    // Tür istatistikleri
    if (Object.keys(typeMap).length > 0) {
      const typeText = Object.entries(typeMap)
        .sort(([,a], [,b]) => b - a)
        .map(([type, count]) => {
          const emoji = this.getTypeEmoji(type);
          return `${emoji} ${type}: ${count}`;
        })
        .join('\n');
      
      embed.addFields({
        name: '📋 İşlem Türleri',
        value: typeText,
        inline: true
      });
    }

    // Aktif cezalar
    const activeText = [];
    if (activeMutes > 0) activeText.push(`🔇 Aktif Mute: ${activeMutes}`);
    if (activeTempBans > 0) activeText.push(`⏰ Geçici Ban: ${activeTempBans}`);
    
    if (activeText.length > 0) {
      embed.addFields({
        name: '🚨 Aktif Cezalar',
        value: activeText.join('\n'),
        inline: true
      });
    }

    // Haftalık trend
    const avgDaily = (last7Days.reduce((a, b) => a + b, 0) / 7).toFixed(1);
    embed.addFields({
      name: '📈 Son 7 Gün Trendi',
      value: `📊 Günlük Ortalama: ${avgDaily}\n📉 Aktivite: ${last7Days.join(' → ')}`,
      inline: false
    });

    // En aktif moderatörler
    const topMods = await Moderation.aggregate([
      { $match: filter },
      { $group: { _id: '$moderatorId', count: { $sum: 1 }, name: { $first: '$moderatorTag' } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);

    if (topMods.length > 0) {
      const modText = topMods
        .map((mod, index) => `${index + 1}. <@${mod._id}>: ${mod.count} işlem`)
        .join('\n');
      
      embed.addFields({
        name: '👮 En Aktif Moderatörler',
        value: modText,
        inline: false
      });
    }

    embed.setFooter({ 
      text: `${guild.name} • Moderasyon İstatistikleri`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  async showActivePunishments(interaction, guild) {
    const activeMutes = await Mute.find({ guildId: guild.id, active: true })
      .sort({ endTime: 1 })
      .limit(10);
    
    const activeTempBans = await TempBan.find({ guildId: guild.id, active: true })
      .sort({ endTime: 1 })
      .limit(10);

    const embed = new EmbedBuilder()
      .setColor(0xFF6B35)
      .setTitle('🚨 Aktif Cezalar')
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setDescription(
        `**🔇 Aktif Mute:** ${activeMutes.length}\n` +
        `**⏰ Geçici Ban:** ${activeTempBans.length}`
      );

    if (activeMutes.length > 0) {
      const muteText = activeMutes
        .slice(0, 5)
        .map(mute => {
          const endText = mute.endTime ? 
            `<t:${Math.floor(mute.endTime.getTime() / 1000)}:R>` : 
            'Kalıcı';
          return `<@${mute.userId}> - ${endText}`;
        })
        .join('\n');
      
      embed.addFields({
        name: `🔇 Aktif Mute'lar (${Math.min(activeMutes.length, 5)}/${activeMutes.length})`,
        value: muteText,
        inline: false
      });
    }

    if (activeTempBans.length > 0) {
      const banText = activeTempBans
        .slice(0, 5)
        .map(ban => {
          const endText = `<t:${Math.floor(ban.endTime.getTime() / 1000)}:R>`;
          return `<@${ban.userId}> - ${endText}`;
        })
        .join('\n');
      
      embed.addFields({
        name: `⏰ Geçici Ban'lar (${Math.min(activeTempBans.length, 5)}/${activeTempBans.length})`,
        value: banText,
        inline: false
      });
    }

    if (activeMutes.length === 0 && activeTempBans.length === 0) {
      embed.addFields({
        name: '✅ Temiz Durum',
        value: 'Şu anda aktif ceza bulunmuyor!',
        inline: false
      });
    }

    embed.setFooter({ 
      text: `${guild.name} • Aktif Cezalar`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  async showRiskyUsers(interaction, guild) {
    // Son 30 günde 3+ uyarı alan kullanıcılar
    const riskyUsers = await Moderation.aggregate([
      {
        $match: {
          guildId: guild.id,
          type: 'warn',
          active: true,
          createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
        }
      },
      {
        $group: {
          _id: '$userId',
          warnCount: { $sum: 1 },
          username: { $first: '$username' },
          lastWarn: { $max: '$createdAt' }
        }
      },
      {
        $match: { warnCount: { $gte: 3 } }
      },
      {
        $sort: { warnCount: -1, lastWarn: -1 }
      },
      {
        $limit: 10
      }
    ]);

    const embed = new EmbedBuilder()
      .setColor(0xFF4444)
      .setTitle('⚠️ Riskli Kullanıcılar')
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setDescription('Son 30 günde 3 veya daha fazla uyarı alan kullanıcılar');

    if (riskyUsers.length > 0) {
      const riskyText = riskyUsers
        .map((user, index) => {
          const lastWarnTime = `<t:${Math.floor(user.lastWarn.getTime() / 1000)}:R>`;
          return `${index + 1}. <@${user._id}>\n   📊 ${user.warnCount} uyarı • ⏰ Son: ${lastWarnTime}`;
        })
        .join('\n\n');
      
      embed.addFields({
        name: `📊 Toplam ${riskyUsers.length} Riskli Kullanıcı`,
        value: riskyText,
        inline: false
      });

      embed.addFields({
        name: '🛡️ Öneriler',
        value: '• Bu kullanıcıları yakından takip edin\n• Gerekirse ek önlemler alın\n• Davranış değişikliği için uyarın',
        inline: false
      });
    } else {
      embed.addFields({
        name: '✅ Güvenli Durum',
        value: 'Son 30 günde riskli kullanıcı bulunmuyor!',
        inline: false
      });
    }

    embed.setFooter({ 
      text: `${guild.name} • Risk Analizi`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  getTimeRangeText(timeRange) {
    switch (timeRange) {
      case '24h': return 'Son 24 Saat';
      case '7d': return 'Son 7 Gün';
      case '30d': return 'Son 30 Gün';
      case 'all': return 'Tüm Zamanlar';
      default: return 'Belirsiz';
    }
  },

  getTypeEmoji(type) {
    const emojis = {
      'ban': '🔨',
      'tempban': '⏰',
      'kick': '👢',
      'mute': '🔇',
      'tempmute': '🔇',
      'unmute': '🔊',
      'unban': '🔓',
      'warn': '⚠️'
    };
    return emojis[type] || '📝';
  }
};





