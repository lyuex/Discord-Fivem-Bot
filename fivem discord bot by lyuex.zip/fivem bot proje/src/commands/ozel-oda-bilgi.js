// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');
const config = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ozel-oda-bilgi')
        .setDescription('Özel oda sistemi hakkında bilgi gösterir')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        try {
            const guild = interaction.guild;
            
            // Kategori bilgilerini al
            const category = guild.channels.cache.get(config.ozel_oda.kategori_id);
            const mainChannel = guild.channels.cache.get(config.ozel_oda.kanal_id);
            
            if (!category || !mainChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('❌ Sistem Kurulmamış')
                    .setDescription('Özel oda sistemi henüz kurulmamış. `/ozel-oda-kur` komutunu kullanın.')
                    .setColor(0xff0000)
                    .setTimestamp();
                
                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            // Aktif özel odaları say
            const privateRooms = category.children.cache.filter(ch => 
                ch.type === ChannelType.GuildVoice && ch.id !== config.ozel_oda.kanal_id
            );

            // Kullanıcı sayısını hesapla
            let totalUsers = 0;
            let activeRooms = 0;
            const roomList = [];

            privateRooms.forEach(room => {
                const memberCount = room.members.size;
                totalUsers += memberCount;
                
                if (memberCount > 0) {
                    activeRooms++;
                    const ownerMatch = room.name.match(/👤 (.+?)'s/);
                    const ownerName = ownerMatch ? ownerMatch[1] : 'Bilinmiyor';
                    roomList.push(`🎵 **${room.name}** - ${memberCount} kişi`);
                }
            });

            // Sistem durumu
            const systemStatus = config.ozel_oda.enabled ? '🟢 Aktif' : '🔴 Pasif';
            
            const embed = new EmbedBuilder()
                .setTitle('📊 Özel Oda Sistemi Bilgileri')
                .setDescription(`
                **📍 Ana Kanal:** ${mainChannel}
                **📁 Kategori:** ${category}
                **🔧 Sistem Durumu:** ${systemStatus}
                `)
                .addFields(
                    {
                        name: '📈 İstatistikler',
                        value: `
                        **🏠 Toplam Oda:** ${privateRooms.size}/${config.ozel_oda.max_oda_sayisi}
                        **👥 Aktif Oda:** ${activeRooms}
                        **🎤 Toplam Kullanıcı:** ${totalUsers}
                        **⏱️ Boş Kalma Süresi:** ${config.ozel_oda.bos_kalma_suresi / 1000} saniye
                        **👑 Varsayılan Limit:** ${config.ozel_oda.varsayilan_limit === 99 ? 'Limitsiz' : config.ozel_oda.varsayilan_limit}
                        `,
                        inline: true
                    },
                    {
                        name: '⚙️ Sistem Ayarları',
                        value: `
                        **🗑️ Otomatik Silme:** ${config.ozel_oda.otomatik_sil ? '✅' : '❌'}
                        **📝 Log Kanalı:** ${config.ozel_oda.log_kanal ? `<#${config.ozel_oda.log_kanal}>` : '❌'}
                        **🎯 Maksimum Oda:** ${config.ozel_oda.max_oda_sayisi}
                        **🎲 Oda İsimleri:** ${config.ozel_oda.oda_isimleri.length} adet
                        `,
                        inline: true
                    }
                )
                .setColor(0x0099ff)
                .setTimestamp()
                .setFooter({ text: 'ZYM CİTY Özel Oda Sistemi' });

            // Aktif odalar varsa listele
            if (roomList.length > 0) {
                embed.addFields({
                    name: '🎵 Aktif Özel Odalar',
                    value: roomList.slice(0, 10).join('\n') + (roomList.length > 10 ? `\n*... ve ${roomList.length - 10} oda daha*` : ''),
                    inline: false
                });
            }

            // Oda isimleri listesi
            embed.addFields({
                name: '🎲 Mevcut Oda İsimleri',
                value: config.ozel_oda.oda_isimleri.slice(0, 7).join(', ') + (config.ozel_oda.oda_isimleri.length > 7 ? '...' : ''),
                inline: false
            });

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Özel oda bilgi hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Hata Oluştu')
                .setDescription('Bilgiler alınırken bir hata oluştu.')
                .setColor(0xff0000)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};