// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('👢 Kullanıcıyı sunucudan atar')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Atılacak kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Kick sebebi')
        .setRequired(false)
        .setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const reason = interaction.options.getString('sebep') || 'Sebep belirtilmedi';
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.KickMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Kick Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Bot izin kontrolü
      if (!guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
        return await interaction.editReply({
          content: '❌ **Bot Yetki Hatası!** Botun kullanıcı atma yetkisi yok!'
        });
      }

      // Hedef kullanıcı kontrolleri
      if (targetUser.id === moderator.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kendinizi atamazsınız!'
        });
      }

      if (targetUser.id === guild.ownerId) {
        return await interaction.editReply({
          content: '❌ **Hata!** Sunucu sahibini atamazsınız!'
        });
      }

      if (targetUser.bot && targetUser.id === interaction.client.user.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Beni atamazsınız!'
        });
      }

      // Üye kontrolü ve hiyerarşi kontrolü
      let targetMember = null;
      try {
        targetMember = await guild.members.fetch(targetUser.id);
        
        if (!targetMember) {
          return await interaction.editReply({
            content: '❌ **Hata!** Bu kullanıcı sunucuda bulunmuyor!'
          });
        }
        
        // Hiyerarşi kontrolü
        if (targetMember.roles.highest.position >= member.roles.highest.position && guild.ownerId !== moderator.id) {
          return await interaction.editReply({
            content: '❌ **Yetki Hatası!** Bu kullanıcı sizden yüksek veya eşit yetkiye sahip!'
          });
        }

        // Bot'un yetkisi kontrolü
        if (targetMember.roles.highest.position >= guild.members.me.roles.highest.position) {
          return await interaction.editReply({
            content: '❌ **Bot Yetki Hatası!** Bu kullanıcı bottan yüksek veya eşit yetkiye sahip!'
          });
        }

        // Korumalı rol kontrolü
        if (targetMember.roles.cache.has(lyuex.yetkili?.kurucu)) {
          return await interaction.editReply({
            content: '❌ **Korumalı Kullanıcı!** Bu kullanıcı kurucu rolüne sahip!'
          });
        }

        // Kick edilebilir kontrolü
        if (!targetMember.kickable) {
          return await interaction.editReply({
            content: '❌ **Hata!** Bu kullanıcı atılamaz! (Yetki veya rol problemi)'
          });
        }

      } catch (fetchError) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kullanıcı sunucuda bulunamadı veya erişilemez!'
        });
      }

      // Onay embed'i
      const confirmEmbed = new EmbedBuilder()
        .setColor(0xFF8C00)
        .setTitle('👢 Kick Onayı')
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Hedef Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '⚠️ Bilgi', value: 'Kullanıcı tekrar davet linkiyle sunucuya girebilir', inline: false }
        )
        .setFooter({ 
          text: `${guild.name} • Moderasyon Sistemi`,
          iconURL: guild.iconURL({ dynamic: true })
        })
        .setTimestamp();

      await interaction.editReply({
        content: '⚠️ **Kick işlemini onaylayın:**',
        embeds: [confirmEmbed]
      });

      // Kick işlemini gerçekleştir
      try {
        const result = await ModerationManager.kickUser({
          guild,
          member: targetMember,
          moderator,
          reason
        });

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Kick İşlemi Başarılı')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**📋 Case ID:** ${result.caseId}\n` +
            `**📝 Sebep:** ${reason}\n` +
            `**📱 DM Durumu:** ${result.dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
            `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
            `ℹ️ **Not:** Kullanıcı davet linkiyle tekrar sunucuya girebilir.`
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [successEmbed]
        });

        // Başarı logu
        console.log(`✅ Kick başarılı: ${targetUser.tag} (${result.caseId}) - Moderatör: ${moderator.tag}`);

      } catch (kickError) {
        console.error('Kick işlemi hatası:', kickError);
        
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Kick İşlemi Başarısız')
          .setDescription(
            `**Hata:** ${kickError.message}\n\n` +
            `**Olası Sebepler:**\n` +
            `• Bot yetkisi yetersiz\n` +
            `• Kullanıcı sunucudan ayrılmış\n` +
            `• Discord API hatası\n` +
            `• Veritabanı bağlantı sorunu\n` +
            `• Kullanıcı yetki hiyerarşisi problemi`
          )
          .setFooter({ text: 'Hatayı yöneticiye bildirin' })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [errorEmbed]
        });
      }

    } catch (error) {
      console.error('Kick komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};




