// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket-istatistik')
        .setDescription('🎫 Ticket istatistiklerini görüntüle')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        // Önce config dosyasını kontrol et
        const config = ticketUtil.getConfig();
        if (!config) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF6B6B)
                        .setTitle('❌ Ticket Sistemi Kapalı')
                        .setDescription('Ticket sistemi henüz ayarlanmamış.')
                ],
                ephemeral: true
            });
        }
        
        await interaction.deferReply();
        
        try {
            const guild = interaction.guild;
            
            // Tüm ticket verileri
            const ticketsDb = ticketUtil.getTicketsDb();
            
            // Aktif kanal bazlı ticket'ları bul
            const activeTickets = guild.channels.cache.filter(ch => 
                ch.name.includes('ticket-') && 
                ch.type === 0 // Text kanalı
            );
            
            // İstatistikleri hesapla
            const stats = calculateTicketStats(ticketsDb, activeTickets.size);
            
            // En çok ticket açan kullanıcıları bul
            const ticketCreators = new Map();
            
            ticketsDb.forEach(ticket => {
                if (ticket.userId) {
                    const count = ticketCreators.get(ticket.userId) || 0;
                    ticketCreators.set(ticket.userId, count + 1);
                }
            });
            
            // En çok ticket açanları sırala
            const topCreators = Array.from(ticketCreators.entries())
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5);
                
            // Ana istatistik embed'i
            const statsEmbed = new EmbedBuilder()
                .setColor(0x4CAF50)
                .setTitle('🎫 Ticket İstatistikleri')
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .addFields(
                    { name: '📊 Toplam Ticket', value: `${stats.totalTickets}`, inline: true },
                    { name: '🟢 Aktif Ticket', value: `${stats.openTickets}`, inline: true },
                    { name: '🔴 Kapalı Ticket', value: `${stats.closedTickets}`, inline: true },
                    { name: '⏱️ Ortalama Yanıt Süresi', value: stats.avgResponseTime, inline: true },
                    { name: '⌛ Ortalama Çözüm Süresi', value: stats.avgResolutionTime, inline: true },
                    { name: '📅 Son 7 Gün', value: `${stats.last7DaysCount} ticket açıldı`, inline: true }
                )
                .setFooter({ text: `${guild.name} • Ticket Sistemi • ${stats.totalTickets} ticket` })
                .setTimestamp();
                
            // Kategori dağılımı
            if (stats.categories && Object.keys(stats.categories).length > 0) {
                statsEmbed.addFields(
                    { name: '📋 Kategori Dağılımı', value: formatCategoryStats(stats.categories), inline: false }
                );
            }
            
            // En çok ticket açan kullanıcılar
            if (topCreators.length > 0) {
                const topCreatorsText = await Promise.all(topCreators.map(async ([userId, count]) => {
                    try {
                        const user = await interaction.client.users.fetch(userId);
                        return `${user.tag}: ${count} ticket`;
                    } catch {
                        return `<@${userId}>: ${count} ticket`;
                    }
                }));
                
                statsEmbed.addFields(
                    { name: '👤 En Çok Ticket Açanlar', value: topCreatorsText.join('\n'), inline: false }
                );
            }
            
            await interaction.editReply({
                embeds: [statsEmbed]
            });
            
        } catch (error) {
            console.error('Ticket istatistikleri hatası:', error);
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF6B6B)
                        .setTitle('❌ Hata')
                        .setDescription('İstatistikler yüklenirken bir hata oluştu.')
                ]
            });
        }
    }
};

// Ticket istatistiklerini hesapla
function calculateTicketStats(tickets, activeCount) {
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const sevenDaysAgo = now - (7 * oneDay);
    
    // Temel istatistikler
    const totalTickets = tickets.length;
    const openTickets = activeCount || tickets.filter(t => t.status === 'open').length;
    const closedTickets = tickets.filter(t => t.status === 'closed').length;
    const last7DaysCount = tickets.filter(t => t.createdAt > sevenDaysAgo).length;
    
    // Kategorilere göre dağılım
    const categories = {};
    tickets.forEach(ticket => {
        const subject = ticket.subject || 'Diğer';
        if (!categories[subject]) categories[subject] = 0;
        categories[subject]++;
    });
    
    // Zaman istatistikleri
    let totalResolutionTime = 0;
    let resolutionCount = 0;
    
    tickets.forEach(ticket => {
        if (ticket.status === 'closed' && ticket.createdAt && ticket.closedAt) {
            const resolutionTime = ticket.closedAt - ticket.createdAt;
            if (resolutionTime > 0) {
                totalResolutionTime += resolutionTime;
                resolutionCount++;
            }
        }
    });
    
    const avgResolutionTimeMs = resolutionCount > 0 ? totalResolutionTime / resolutionCount : 0;
    
    return {
        totalTickets,
        openTickets,
        closedTickets,
        last7DaysCount,
        categories,
        avgResponseTime: formatTime(oneDay * 0.25), // Varsayılan 6 saat
        avgResolutionTime: formatTime(avgResolutionTimeMs)
    };
}

// Zaman formatla (ms -> okunabilir süre)
function formatTime(ms) {
    if (ms < 1000) return '0 saniye';
    
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    
    const parts = [];
    if (days > 0) parts.push(`${days} gün`);
    if (hours > 0) parts.push(`${hours} saat`);
    if (minutes > 0 && days === 0) parts.push(`${minutes} dakika`);
    if (seconds > 0 && hours === 0 && days === 0) parts.push(`${seconds} saniye`);
    
    return parts.join(' ');
}

// Kategori istatistiklerini formatla
function formatCategoryStats(categories) {
    const sortedCategories = Object.entries(categories)
        .sort((a, b) => b[1] - a[1])
        .map(([name, count]) => `${getCategoryEmoji(name)} **${name}**: ${count} ticket`);
    
    return sortedCategories.join('\n');
}

// Kategori için emoji seç
function getCategoryEmoji(category) {
    const emojiMap = {
        'Destek': '📋',
        'Hata Bildir': '🐛',
        'Önerisi': '💡',
        'Şikayet': '⚠️',
        'Diğer': '📌'
    };
    
    return emojiMap[category] || '🔹';
}





