// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, RoleSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Uyarı yetki veritabanı dosyası
const uyariYetkiDB = path.join(__dirname, '../../db/uyariYetkileri.json');

// Veritabanı dosyasını oluştur
if (!fs.existsSync(uyariYetkiDB)) {
    if (!fs.existsSync(path.dirname(uyariYetkiDB))) {
        fs.mkdirSync(path.dirname(uyariYetkiDB), { recursive: true });
    }
    fs.writeFileSync(uyariYetkiDB, JSON.stringify({}));
}

// Veritabanı okuma/yazma fonksiyonları
function getUyariYetkiData() {
    try {
        const data = fs.readFileSync(uyariYetkiDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveUyariYetkiData(data) {
    fs.writeFileSync(uyariYetkiDB, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uyarı-yetki')
        .setDescription('⚙️ Uyarı sistemi yetki ayarları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('ayarla')
                .setDescription('🔧 Uyarı verebilecek rolleri ayarla')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('liste')
                .setDescription('📋 Mevcut yetkili rolleri görüntüle')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('sıfırla')
                .setDescription('🗑️ Tüm yetkili rolleri temizle')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;
        
        // Sadece yönetici kontrolü
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('❌ **YETERSİZ YETKİ**')
                        .setDescription('Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısınız.')
                        .setColor(0xF44336)
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }

        switch (subcommand) {
            case 'ayarla':
                await handleAyarla(interaction, guildId);
                break;
            case 'liste':
                await handleListe(interaction, guildId);
                break;
            case 'sıfırla':
                await handleSifirla(interaction, guildId);
                break;
        }
    },
};

async function handleAyarla(interaction, guildId) {
    const uyariYetkiData = getUyariYetkiData();
    
    const roleSelectMenu = new RoleSelectMenuBuilder()
        .setCustomId(`uyari_yetki_select_${guildId}`)
        .setPlaceholder('🏷️ Uyarı verebilecek rolleri seçin...')
        .setMinValues(1)
        .setMaxValues(10);

    const row = new ActionRowBuilder().addComponents(roleSelectMenu);

    const mevcutRoller = uyariYetkiData[guildId]?.roller || [];
    const mevcutRollerText = mevcutRoller.length > 0 ? 
        mevcutRoller.map(roleId => `<@&${roleId}>`).join('\n') : 
        '*Henüz hiçbir rol ayarlanmamış*';

    const ayarlaEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Uyarı Yetki Ayarları`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('⚙️ **UYARI YETKİ AYARLAMA PANELİ**')
        .setDescription(`
╭─────────────────────────────────╮
│  🛡️ **UYARI YETKİ YÖNETİMİ**     │
│  Rol seçim menüsünü kullanın     │
╰─────────────────────────────────╯

🎯 **Aşağıdaki menüden uyarı verebilecek rolleri seçin**`)
        .addFields(
            { 
                name: '📋 **MEVCUT YETKİLİ ROLLER**', 
                value: mevcutRollerText, 
                inline: false 
            },
            { 
                name: '⚙️ **AYARLAMA BİLGİLERİ**', 
                value: `
**Maksimum Seçim:** 10 rol
**Minimum Seçim:** 1 rol
**Mevcut Rol Sayısı:** ${mevcutRoller.length}
                `, 
                inline: true 
            },
            { 
                name: 'ℹ️ **BİLGİ**', 
                value: `
Seçilen roller uyarı verebilecek
Yöneticiler her zaman yetkilidir
Eski ayarlar değiştirilecek
                `, 
                inline: true 
            }
        )
        .setColor(0x2196F3)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ 
            text: 'Uyarı Sistemi • Yetki Yönetimi', 
            iconURL: interaction.user.displayAvatarURL() 
        })
        .setTimestamp();

    await interaction.reply({
        embeds: [ayarlaEmbed],
        components: [row],
        ephemeral: false
    });
}

async function handleListe(interaction, guildId) {
    const uyariYetkiData = getUyariYetkiData();
    const yetkiliRoller = uyariYetkiData[guildId]?.roller || [];

    const listeEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Uyarı Yetkileri`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('📋 **YETKİLİ ROL LİSTESİ**')
        .setDescription(`
╭─────────────────────────────────╮
│  🏷️ **UYARI VEREBİLECEK ROLLER** │
│  Mevcut yetki yapılandırması     │
╰─────────────────────────────────╯`)
        .addFields(
            { 
                name: '👥 **YETKİLİ ROLLER**', 
                value: yetkiliRoller.length > 0 ? 
                    yetkiliRoller.map((roleId, index) => {
                        const role = interaction.guild.roles.cache.get(roleId);
                        return `${index + 1}. ${role ? `<@&${roleId}> (\`${role.name}\`)` : `❌ Silinmiş Rol (\`${roleId}\`)`}`;
                    }).join('\n') :
                    '❌ *Henüz hiçbir rol ayarlanmamış*', 
                inline: false 
            },
            { 
                name: '📊 **İSTATİSTİKLER**', 
                value: `
**Toplam Yetkili Rol:** ${yetkiliRoller.length}
**Maksimum Limit:** 10 rol
**Kalan Slot:** ${10 - yetkiliRoller.length}
                `, 
                inline: true 
            },
            { 
                name: 'ℹ️ **HATIRLATMA**', 
                value: `
🔸 Yöneticiler her zaman yetkili
🔸 Roller silinirse otomatik çıkar
🔸 Maksimum 10 rol ayarlanabilir
                `, 
                inline: true 
            }
        )
        .setColor(yetkiliRoller.length > 0 ? '#4caf50' : '#ff9800')
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ 
            text: `Uyarı Sistemi • ${yetkiliRoller.length}/10 Rol Ayarlanmış`, 
            iconURL: interaction.user.displayAvatarURL() 
        })
        .setTimestamp();

    await interaction.reply({
        embeds: [listeEmbed],
        ephemeral: true
    });
}

async function handleSifirla(interaction, guildId) {
    const uyariYetkiData = getUyariYetkiData();
    
    if (!uyariYetkiData[guildId] || !uyariYetkiData[guildId].roller || uyariYetkiData[guildId].roller.length === 0) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('ℹ️ **BİLGİ**')
                    .setDescription('Zaten hiçbir yetkili rol ayarlanmamış.')
                    .setColor(0x607D8B)
                    .setTimestamp()
            ],
            ephemeral: true
        });
    }

    // Sıfırla
    if (uyariYetkiData[guildId]) {
        uyariYetkiData[guildId].roller = [];
        saveUyariYetkiData(uyariYetkiData);
    }

    const sifirlaEmbed = new EmbedBuilder()
        .setTitle('✅ **YETKİLER SIFIRLANDI**')
        .setDescription('Tüm uyarı yetkili rolleri başarıyla temizlendi.')
        .addFields(
            { name: '🗑️ İşlem', value: 'Tüm roller kaldırıldı', inline: true },
            { name: '👤 Yetkili', value: `${interaction.user.tag}`, inline: true },
            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
        )
        .setColor(0x4CAF50)
        .setTimestamp();

    await interaction.reply({
        embeds: [sifirlaEmbed],
        ephemeral: true
    });
}





