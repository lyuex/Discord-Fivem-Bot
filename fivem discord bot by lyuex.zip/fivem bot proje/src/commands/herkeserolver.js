// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');


module.exports = {
    data: new SlashCommandBuilder()
    .setName('herkeserolver')
    .setDescription('Sunucudaki herkese rol vermeniz için gereken bir menüyü gönderir.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(option => option
        .setName('rol')
        .setDescription('rol seçiniz.')
    ),

    async execute(interaction) {
        try {
            const sunucu = interaction.guild;
            const rol = interaction.options.getRole('rol');
            
            if (!rol) {
                return await interaction.reply({
                    content: '❌ Lütfen bir rol seçiniz!',
                    ephemeral: true
                });
            }

            await interaction.reply({
                content: '⏳ Rol dağıtımı başladı...',
                ephemeral: true
            });

            let count = 0;
            const errors = [];

            for (const member of sunucu.members.cache.values()) {
                try {
                    await member.roles.add(rol);
                    count++;
                } catch (err) {
                    console.error(`Rol verme hatası - ${member.user.tag}: ${err}`);
                    errors.push(member.user.tag);
                }
            }

            const errorText = errors.length > 0 
                ? `\n⚠️ ${errors.length} üyeye rol verilemedi: ${errors.slice(0, 5).join(', ')}${errors.length > 5 ? '...' : ''}`
                : '';

            await interaction.channel.send(
                `✅ Rol dağıtımı tamamlandı!\n` +
                `👥 ${count} üyeye başarıyla \`${rol.name}\` rolü verildi.${errorText}`
            );
        } catch (error) {
            console.error('Herkese rol verme komutunda hata:', error);
            
            if (!interaction.replied) {
                await interaction.reply({
                    content: '❌ Komut çalıştırılırken bir hata oluştu.',
                    ephemeral: true
                });
            }
        }
    }
}







