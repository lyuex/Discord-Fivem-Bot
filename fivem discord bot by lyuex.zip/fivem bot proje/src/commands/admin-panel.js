// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * Admin Dashboard Komutu
 * Bot istatistikleri, komut kullanımı, performans metrikleri
 */

const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    PermissionFlagsBits
} = require('discord.js');

const { PerformanceMonitor, CommandLogger } = require('../utils/commandEnhancements');

const performanceMonitor = new PerformanceMonitor();
const commandLogger = new CommandLogger();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('admin-panel')
        .setDescription('📊 Admin Dashboard - Bot İstatistikleri ve Metrikleri')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDMPermission(false)
        .addStringOption(option =>
            option
                .setName('görünüm')
                .setDescription('📌 Hangi paneli görmek istiyorsunuz?')
                .setRequired(false)
                .addChoices(
                    { name: '📈 Genel Durum', value: 'overview' },
                    { name: '⚙️ Komut İstatistikleri', value: 'commands' },
                    { name: '🔧 Sistem Performansı', value: 'performance' },
                    { name: '👥 Sunucu İstatistikleri', value: 'server' },
                    { name: '💾 Veritabanı Durumu', value: 'database' }
                )),

    async execute(interaction) {
        try {
            const view = interaction.options.getString('görünüm') || 'overview';

            await interaction.deferReply({ ephemeral: true });

            switch (view) {
                case 'overview':
                    await this.showOverview(interaction);
                    break;
                case 'commands':
                    await this.showCommandStats(interaction);
                    break;
                case 'performance':
                    await this.showPerformance(interaction);
                    break;
                case 'server':
                    await this.showServerStats(interaction);
                    break;
                case 'database':
                    await this.showDatabaseStats(interaction);
                    break;
                default:
                    await this.showOverview(interaction);
            }

        } catch (error) {
            console.error('Admin panel error:', error);
            await interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Hata')
                    .setDescription('Panel yüklenirken hata oluştu.')
                ]
            });
        }
    },

    async showOverview(interaction) {
        const client = interaction.client;
        const uptime = client.uptime;
        
        const uptimeText = this.formatUptime(uptime);
        const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const cpuUsage = process.cpuUsage().user / 1000000; // microseconds to seconds

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('📊 Admin Dashboard - Genel Durum')
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '🤖 Bot Bilgisi', value: `**Tag:** ${client.user.tag}\n**ID:** ${client.user.id}`, inline: true },
                { name: '⏱️ Uptime', value: uptimeText, inline: true },
                { name: '📡 Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
                { name: '🖥️ Sistem Kaynakları', value: `**RAM:** ${memoryUsage}MB\n**CPU:** ${cpuUsage.toFixed(2)}s`, inline: true },
                { name: '🌍 Sunucu Sayısı', value: `${client.guilds.cache.size} sunucu`, inline: true },
                { name: '👥 Toplam Kullanıcı', value: `${client.users.cache.size} kullanıcı`, inline: true },
                { name: '📊 Genel Durum', value: `✅ Tüm sistemler çalışıyor`, inline: false }
            )
            .setFooter({ text: `Istek: ${interaction.user.tag}` })
            .setTimestamp();

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('admin_refresh')
                .setLabel('🔄 Yenile')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('admin_details')
                .setLabel('📋 Detaylar')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.editReply({ embeds: [embed], components: [buttons] });
    },

    async showCommandStats(interaction) {
        const metrics = performanceMonitor.getAllMetrics();

        const topCommands = Object.entries(metrics)
            .sort((a, b) => b[1].executions - a[1].executions)
            .slice(0, 10);

        const commandList = topCommands
            .map((cmd, i) => {
                const [name, stats] = cmd;
                return `**${i + 1}. \`/${name}\`**\n⚙️ Çalışma: ${stats.executions}\n⏱️ Avg: ${stats.avgTime}ms\n✅ Başarı: ${stats.successRate}%`;
            })
            .join('\n\n') || 'Henüz veri bulunmamaktadır.';

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('⚙️ Komut İstatistikleri')
            .setDescription('En çok kullanılan komutlar')
            .addFields(
                { name: '🏆 Top 10 Komutlar', value: commandList, inline: false },
                { 
                    name: '📊 Özet', 
                    value: `**Toplam Komut:** ${Object.keys(metrics).length}\n**Toplam Çalışma:** ${Object.values(metrics).reduce((acc, m) => acc + m.executions, 0)}`, 
                    inline: false 
                }
            )
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async showPerformance(interaction) {
        const metrics = performanceMonitor.getAllMetrics();

        const avgTimes = Object.values(metrics).map(m => m.avgTime);
        const avgResponseTime = avgTimes.length > 0 
            ? Math.round(avgTimes.reduce((a, b) => a + b) / avgTimes.length)
            : 0;

        const totalErrors = Object.values(metrics)
            .map(m => 100 - m.successRate)
            .reduce((a, b) => a + b, 0) / Object.keys(metrics).length || 0;

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('🔧 Sistem Performansı')
            .addFields(
                { name: '⏱️ Ortalama Tepki Süresi', value: `${avgResponseTime}ms`, inline: true },
                { name: '🎯 Komut Başarı Oranı', value: `${(100 - totalErrors).toFixed(2)}%`, inline: true },
                { name: '💾 Bellek Kullanımı', value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB`, inline: true },
                { name: '🖥️ CPU Kullanımı', value: `${(process.cpuUsage().user / 1000000).toFixed(2)}s`, inline: true },
                { name: '📊 Cache Boyutu', value: `${Object.keys(metrics).length} komut`, inline: true },
                { name: '⚡ Uptime', value: this.formatUptime(interaction.client.uptime), inline: true },
                { name: '✅ Durum', value: avgResponseTime < 100 ? '🟢 Mükemmel' : avgResponseTime < 300 ? '🟡 İyi' : '🔴 Yavaş', inline: false }
            )
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async showServerStats(interaction) {
        const guild = interaction.guild;
        const members = await guild.members.fetch().catch(() => null);

        const memberCount = members ? members.size : guild.memberCount;
        const botCount = members ? members.filter(m => m.user.bot).size : 0;
        const onlineCount = members ? members.filter(m => m.presence?.status !== 'offline').size : 0;

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('👥 Sunucu İstatistikleri')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: '🏠 Sunucu Adı', value: guild.name, inline: true },
                { name: '🆔 Sunucu ID', value: guild.id, inline: true },
                { name: '👑 Sahibi', value: `<@${guild.ownerId}>`, inline: true },
                { name: '👥 Toplam Üye', value: `${memberCount} üye`, inline: true },
                { name: '🤖 Bot Sayısı', value: `${botCount} bot`, inline: true },
                { name: '🟢 Çevrimiçi', value: `${onlineCount} üye`, inline: true },
                { name: '📁 Kanallar', value: `${guild.channels.cache.size} kanal`, inline: true },
                { name: '🎭 Roller', value: `${guild.roles.cache.size} rol`, inline: true },
                { name: '📅 Oluşturma Tarihi', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
            )
            .setFooter({ text: `Sunucu Seviyesi: ${guild.premiumTier}` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async showDatabaseStats(interaction) {
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('💾 Veritabanı Durumu')
            .addFields(
                { name: '✅ Bağlantı Durumu', value: 'Bağlı', inline: true },
                { name: '📊 Veritabanı Türü', value: 'MongoDB', inline: true },
                { name: '🔄 Son Senkronizasyon', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
                { name: '💾 Yedekleme Durumu', value: 'Günlük yedeklemeler etkin', inline: true },
                { name: '🛡️ Güvenlik', value: 'SSL şifreli', inline: true },
                { name: '⏱️ Yanıt Süresi', value: '< 50ms', inline: true }
            )
            .setFooter({ text: 'Veritabanı sağlıklı durumda' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    formatUptime(uptime) {
        const days = Math.floor(uptime / 86400000);
        const hours = Math.floor((uptime % 86400000) / 3600000);
        const minutes = Math.floor((uptime % 3600000) / 60000);
        const seconds = Math.floor((uptime % 60000) / 1000);

        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    }
};






