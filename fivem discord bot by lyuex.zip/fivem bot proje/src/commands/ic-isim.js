// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ic-isim')
    .setDescription('🎭 IC isim onay sistemi hakkında bilgi verir'),

  async execute(interaction) {
    try {
      const icKanal = lyuex.ic_isim?.kanal;
      
      const embed = new EmbedBuilder()
        .setColor(0x0099FF)
        .setTitle('🎭 IC İsim Onay Sistemi')
        .setDescription('**In-Character (IC)** isminizi onaylatmak için aşağıdaki adımları takip edin:')
        .addFields(
          {
            name: '📝 1. Adım: İsim Yazma',
            value: icKanal ? `${icKanal ? `<#${icKanal}>` : '❌ Kanal ayarlanmamış'} kanalına sadece IC isminizi yazın.` : '❌ IC isim kanalı ayarlanmamış!',
            inline: false
          },
          {
            name: '✅ 2. Adım: Onay Bekleme',
            value: 'Otomatik olarak onay paneli oluşacak. Yetkili onayını bekleyin.',
            inline: false
          },
          {
            name: '🏷️ 3. Adım: Rol Alma',
            value: 'İsminiz onaylandığında otomatik olarak IC onay rolü alacaksınız.',
            inline: false
          },
          {
            name: '📋 IC İsim Kuralları',
            value: '• Sadece **gerçek isimler** kabul edilir\n• **Harf ve boşluk** dışında karakter kullanmayın\n• **En az 3, en fazla 50** karakter olmalı\n• **Küfür ve uygunsuz** kelimeler yasak\n• **Troll isimler** reddedilir',
            inline: false
          },
          {
            name: '✅ Doğru Örnekler',
            value: '• `Ahmet Yılmaz`\n• `Ayşe Kaya`\n• `Mehmet Ali`\n• `Fatma Öztürk`',
            inline: true
          },
          {
            name: '❌ Yanlış Örnekler',
            value: '• `XxAhmetxX`\n• `Ahmet123`\n• `Troll İsim`\n• `@#$%`',
            inline: true
          }
        )
        .setFooter({ text: 'IC İsim Onay Sistemi' })
        .setTimestamp();

      // Eğer IC kanal yoksa uyarı ekle
      if (!icKanal) {
        embed.setColor(0xFF0000);
        embed.addFields({
          name: '⚠️ Uyarı',
          value: 'IC isim onay sistemi henüz kurulmamış. Yöneticilerle iletişime geçin.',
          inline: false
        });
      }

      await interaction.reply({ 
        embeds: [embed],
        flags: [MessageFlags.Ephemeral]
      });

    } catch (error) {
      console.error('IC isim bilgi hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      await interaction.reply({ 
        content: errorMessage, 
        flags: [MessageFlags.Ephemeral] 
      });
    }
  }
};




