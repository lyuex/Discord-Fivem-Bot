// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * GELİŞMİŞ KOMUT ŞABLONU
 * 
 * Bu şablon, yeni enhancement sisteminin tüm özelliklerini gösterir.
 * Yeni komut oluştururken bu dosyayı kopyalayın ve düzenleyin.
 * 
 * Özellikler:
 * - ✅ Rate Limiting
 * - ✅ Permission Check
 * - ✅ Performance Monitoring
 * - ✅ Command Logging
 * - ✅ Cache Kullanımı
 * - ✅ Safe Reply
 * - ✅ Error Handling
 * - ✅ Pagination
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('template-enhanced')
        .setDescription('🎯 Gelişmiş komut şablonu - Tüm best practices')
        .addUserOption(option =>
            option
                .setName('kullanıcı')
                .setDescription('Hedef kullanıcı')
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName('işlem')
                .setDescription('Yapılacak işlem')
                .setRequired(false)
                .addChoices(
                    { name: '📊 İstatistik Göster', value: 'stats' },
                    { name: '📋 Liste Göster', value: 'list' },
                    { name: '🔍 Detaylı Bilgi', value: 'detail' }
                )
        ),

    async execute(interaction) {
        // ====================================
        // 1. ENHANCEMENT SİSTEMİNİ YÜKLEYİN
        // ====================================
        const { rateLimiter, logger, cache, perf, helpers } = this.enhancements;
        
        // ====================================
        // 2. PERFORMANCE MONITORING BAŞLAT
        // ====================================
        const timer = perf.startTimer('template-enhanced');

        try {
            // ====================================
            // 3. RATE LIMIT KONTROLÜ
            // ====================================
            const cooldown = rateLimiter.check(interaction.user.id);
            if (cooldown.limited) {
                perf.endTimer('template-enhanced', timer, false);
                
                return helpers.InteractionHelper.safeReply(interaction, {
                    embeds: [helpers.InteractionHelper.createWarningEmbed(
                        'Çok Hızlısın!',
                        `⏱️ Bu komutu tekrar kullanmak için **${cooldown.secondsLeft} saniye** bekle.\n\n` +
                        `Kalan istek hakkı: ${rateLimiter.getRemainingRequests(interaction.user.id)}`,
                        [
                            { name: '⏰ Bekleme Süresi', value: `${cooldown.secondsLeft}s`, inline: true },
                            { name: '🔄 Sıfırlanma', value: `<t:${Math.floor(cooldown.resetTime / 1000)}:R>`, inline: true }
                        ]
                    )]
                }, true);
            }

            // ====================================
            // 4. YETKİ KONTROLÜ (Opsiyonel)
            // ====================================
            const permCheck = helpers.PermissionHelper.check(interaction.member, {
                perms: [], // Gerekli izinler: [PermissionFlagsBits.ManageMessages]
                roles: []  // Gerekli roller: ['roleId1', 'roleId2']
            });

            if (!permCheck.ok) {
                perf.endTimer('template-enhanced', timer, false);
                
                return helpers.InteractionHelper.safeReply(interaction, {
                    embeds: [helpers.InteractionHelper.createErrorEmbed(
                        'Yetersiz Yetki',
                        '❌ Bu komutu kullanmak için yeterli yetkiniz yok!',
                        [
                            { name: '🔒 Eksik Yetkiler', value: permCheck.missing.join(', ') || 'Bilinmiyor', inline: false }
                        ]
                    )]
                }, true);
            }

            // ====================================
            // 5. CACHE KONTROLÜ
            // ====================================
            const cacheKey = `template_${interaction.user.id}`;
            let cachedData = cache.get(cacheKey);

            if (cachedData) {
                // Cache'den veri geldi
                await helpers.InteractionHelper.safeReply(interaction, {
                    embeds: [helpers.InteractionHelper.createSuccessEmbed(
                        'Cache Verisi',
                        '📦 Bu veri cache\'den geldi (5 dakika geçerli)',
                        [
                            { name: '💾 Data', value: JSON.stringify(cachedData), inline: false }
                        ]
                    )]
                }, true);

                logger.log('template-enhanced', interaction.user.id, interaction.user.tag, 'success', {
                    source: 'cache',
                    responseTime: Date.now() - timer
                });

                perf.endTimer('template-enhanced', timer, true);
                return;
            }

            // ====================================
            // 6. DEFER REPLY (Uzun işlemler için)
            // ====================================
            await helpers.InteractionHelper.deferIfNeeded(interaction, true);

            // ====================================
            // 7. KOMUT LOJİĞİ - İŞLEM YAPMA
            // ====================================
            const targetUser = interaction.options.getUser('kullanıcı') || interaction.user;
            const operation = interaction.options.getString('işlem') || 'stats';

            // Simüle edilmiş veri işleme (gerçek uygulamada DB sorgusu vs. olur)
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1 saniye bekle

            const data = {
                user: targetUser.tag,
                operation: operation,
                timestamp: Date.now(),
                guild: interaction.guild.name
            };

            // Veriyi cache'e kaydet
            cache.set(cacheKey, data);

            // ====================================
            // 8. İŞLEM TİPİNE GÖRE YANIT
            // ====================================
            if (operation === 'list') {
                // PAGINATION ÖRNEĞİ
                const pages = [
                    new EmbedBuilder()
                        .setTitle('📋 Sayfa 1 - Genel Bilgiler')
                        .setColor(0x00D4FF)
                        .setDescription('İlk sayfaya hoş geldiniz!')
                        .addFields(
                            { name: '👤 Kullanıcı', value: targetUser.tag, inline: true },
                            { name: '🆔 ID', value: targetUser.id, inline: true },
                            { name: '📅 Hesap Oluşturulma', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:D>`, inline: true }
                        ),
                    
                    new EmbedBuilder()
                        .setTitle('📊 Sayfa 2 - İstatistikler')
                        .setColor(0x00FF88)
                        .setDescription('İstatistik bilgileri')
                        .addFields(
                            { name: '🏆 Seviye', value: 'Örnek: 25', inline: true },
                            { name: '💎 XP', value: 'Örnek: 5000', inline: true },
                            { name: '⭐ Rank', value: 'Örnek: #42', inline: true }
                        ),
                    
                    new EmbedBuilder()
                        .setTitle('🎯 Sayfa 3 - Detaylar')
                        .setColor(0xFF8C00)
                        .setDescription('Ek bilgiler ve detaylar')
                        .addFields(
                            { name: '📝 Son Aktivite', value: '<t:' + Math.floor(Date.now() / 1000) + ':R>', inline: true },
                            { name: '🔧 Durum', value: 'Aktif', inline: true }
                        )
                ];

                await helpers.PaginationHelper.paginate(interaction, pages, {
                    ephemeral: true,
                    time: 120000 // 2 dakika
                });

            } else {
                // NORMAL YANIT - SUCCESS EMBED
                const successEmbed = helpers.InteractionHelper.createSuccessEmbed(
                    'İşlem Başarılı',
                    `✅ **${operation}** işlemi başarıyla tamamlandı!`,
                    [
                        { name: '👤 Hedef Kullanıcı', value: targetUser.tag, inline: true },
                        { name: '⚙️ İşlem', value: operation, inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
                        { name: '💾 Cache Durumu', value: 'Kaydedildi (5 dk)', inline: true },
                        { name: '🎯 Komut', value: this.data.name, inline: true },
                        { name: '👨‍💻 Kullanan', value: interaction.user.tag, inline: true }
                    ]
                );

                successEmbed.setFooter({ 
                    text: `${interaction.guild.name} • Enhancement System v2.0`,
                    iconURL: interaction.guild.iconURL()
                });

                await helpers.InteractionHelper.safeReply(interaction, {
                    embeds: [successEmbed]
                }, true);
            }

            // ====================================
            // 9. BAŞARILI İŞLEM LOGLA
            // ====================================
            logger.log('template-enhanced', interaction.user.id, interaction.user.tag, 'success', {
                operation: operation,
                targetUser: targetUser.id,
                cached: false,
                responseTime: Date.now() - timer
            });

            // ====================================
            // 10. PERFORMANCE METRIC GÜNCELLENDİ
            // ====================================
            perf.endTimer('template-enhanced', timer, true);

        } catch (error) {
            // ====================================
            // HATA YÖNETİMİ
            // ====================================
            console.error('Template Enhanced komut hatası:', error);

            const errorEmbed = helpers.InteractionHelper.createErrorEmbed(
                'Komut Hatası',
                `❌ Bir hata oluştu: ${error.message}`,
                [
                    { name: '🔍 Hata Türü', value: error.name || 'Unknown', inline: true },
                    { name: '📍 Konum', value: this.data.name, inline: true },
                    { name: '⏰ Zaman', value: new Date().toLocaleString('tr-TR'), inline: true }
                ]
            );

            await helpers.InteractionHelper.safeReply(interaction, {
                embeds: [errorEmbed]
            }, true);

            // Hata logla
            logger.log('template-enhanced', interaction.user.id, interaction.user.tag, 'error', {
                error: error.message,
                stack: error.stack?.split('\n')[0]
            });

            // Performance metric güncelle (başarısız)
            perf.endTimer('template-enhanced', timer, false);
        }
    }
};





