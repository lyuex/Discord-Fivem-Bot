// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { Moderation } = require('../Schemas/ModerationSchema');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('⚠️ Kullanıcıyı uyarır ve otomatik ceza sistemi uygular')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Uyarılacak kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Uyarı sebebi')
        .setRequired(true)
        .setMaxLength(500))
    .addIntegerOption(option =>
      option.setName('seviye')
        .setDescription('🔢 Uyarı seviyesi (1-5, otomatik tespit edilir)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(5))
    .addBooleanOption(option =>
      option.setName('otomatik_ceza')
        .setDescription('⚖️ Otomatik ceza sistemini uygula (varsayılan: true)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const reason = interaction.options.getString('sebep');
      const manualLevel = interaction.options.getInteger('seviye');
      const autoAction = interaction.options.getBoolean('otomatik_ceza') ?? true;
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Moderate Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Hedef kullanıcı kontrolleri
      if (targetUser.id === moderator.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kendinizi uyaramazsınız!'
        });
      }

      if (targetUser.id === guild.ownerId) {
        return await interaction.editReply({
          content: '❌ **Hata!** Sunucu sahibini uyaramazsınız!'
        });
      }

      if (targetUser.bot) {
        return await interaction.editReply({
          content: '❌ **Hata!** Bot kullanıcılarını uyaramazsınız!'
        });
      }

      // Üye kontrolü ve hiyerarşi kontrolü
      let targetMember = null;
      try {
        targetMember = await guild.members.fetch(targetUser.id);
        
        if (targetMember) {
          // Hiyerarşi kontrolü
          if (targetMember.roles.highest.position >= member.roles.highest.position && guild.ownerId !== moderator.id) {
            return await interaction.editReply({
              content: '❌ **Yetki Hatası!** Bu kullanıcı sizden yüksek veya eşit yetkiye sahip!'
            });
          }

          // Korumalı rol kontrolü
          if (targetMember.roles.cache.has(lyuex.yetkili?.kurucu)) {
            return await interaction.editReply({
              content: '❌ **Korumalı Kullanıcı!** Bu kullanıcı kurucu rolüne sahip!'
            });
          }
        }
      } catch (fetchError) {
        // Kullanıcı sunucuda değil, yine de uyarılabilir
        console.log(`Kullanıcı sunucuda değil, yine de uyarılacak: ${targetUser.tag}`);
      }

      // Mevcut uyarıları say
      const existingWarns = await Moderation.countDocuments({
        guildId: guild.id,
        userId: targetUser.id,
        type: 'warn',
        active: true
      });

      // Uyarı seviyesini belirle
      const warnLevel = manualLevel || (existingWarns + 1);
      
      // Case ID oluştur
      const caseId = await ModerationManager.generateCaseId(guild.id);

      // Uyarı kaydı oluştur
      const warnRecord = new Moderation({
        caseId,
        guildId: guild.id,
        type: 'warn',
        userId: targetUser.id,
        username: targetUser.username,
        userTag: targetUser.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        notes: `Seviye: ${warnLevel}, Toplam Uyarı: ${existingWarns + 1}`,
        active: true
      });

      await warnRecord.save();

      // Otomatik ceza sistemi
      let autoActionResult = null;
      let nextAction = null;

      if (autoAction) {
        // Ceza sistemini uygula
        try {
          switch (warnLevel) {
            case 1:
            case 2:
              nextAction = '🔶 Henüz otomatik ceza yok';
              break;
            case 3:
              // 3. uyarıda 30 dakika mute
              if (targetMember) {
                autoActionResult = await ModerationManager.muteUser({
                  guild,
                  member: targetMember,
                  moderator: interaction.client.user,
                  reason: `Otomatik ceza - 3. uyarı: ${reason}`,
                  duration: 30
                });
                nextAction = '🔸 Otomatik: 30 dakika mute uygulandı';
              }
              break;
            case 4:
              // 4. uyarıda 2 saat mute
              if (targetMember) {
                autoActionResult = await ModerationManager.muteUser({
                  guild,
                  member: targetMember,
                  moderator: interaction.client.user,
                  reason: `Otomatik ceza - 4. uyarı: ${reason}`,
                  duration: 120
                });
                nextAction = '🔸 Otomatik: 2 saat mute uygulandı';
              }
              break;
            case 5:
              // 5. uyarıda kick
              if (targetMember) {
                autoActionResult = await ModerationManager.kickUser({
                  guild,
                  member: targetMember,
                  moderator: interaction.client.user,
                  reason: `Otomatik ceza - 5. uyarı: ${reason}`
                });
                nextAction = '🔸 Otomatik: Kick uygulandı';
              }
              break;
            default:
              if (warnLevel >= 6) {
                // 6+ uyarıda ban
                autoActionResult = await ModerationManager.banUser({
                  guild,
                  user: targetUser,
                  moderator: interaction.client.user,
                  reason: `Otomatik ceza - ${warnLevel}. uyarı: ${reason}`,
                  duration: null,
                  deleteMessages: 1
                });
                nextAction = '🔴 Otomatik: Kalıcı ban uygulandı';
              }
          }
        } catch (autoError) {
          console.error('Otomatik ceza hatası:', autoError);
          nextAction = `❌ Otomatik ceza uygulanamadı: ${autoError.message}`;
        }
      }

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor(warnLevel >= 5 ? '#FF0000' : warnLevel >= 3 ? '#FF8C00' : '#FFA500')
        .setTitle(`⚠️ ${guild.name} Sunucusunda Uyarı Aldınız`)
        .setDescription(
          `**Sebep:** ${reason}\n` +
          `**Moderatör:** ${moderator.tag}\n` +
          `**Uyarı Seviyesi:** ${warnLevel}\n` +
          `**Toplam Uyarı:** ${existingWarns + 1}\n` +
          `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          `**Case ID:** ${caseId}\n\n` +
          (autoActionResult ? `**Otomatik Ceza:** ${nextAction}\n\n` : '') +
          `⚠️ **Uyarı Sistemi:**\n` +
          `• 3 uyarı: 30 dakika mute\n` +
          `• 4 uyarı: 2 saat mute\n` +
          `• 5 uyarı: Kick\n` +
          `• 6+ uyarı: Ban`
        )
        .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
        .setTimestamp();

      const dmSent = await ModerationManager.sendDM(targetUser, dmEmbed);
      if (dmSent) {
        warnRecord.dmSent = true;
        await warnRecord.save();
      }

      // Ana embed
      const mainEmbed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle('⚠️ Uyarı Sistemi')
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .setDescription(
          `**👤 Kullanıcı:** ${targetUser.tag}\n` +
          `**📋 Case ID:** ${caseId}\n` +
          `**📝 Sebep:** ${reason}\n` +
          `**🔢 Uyarı Seviyesi:** ${warnLevel}\n` +
          `**📊 Toplam Uyarı:** ${existingWarns + 1}\n` +
          `**📱 DM Durumu:** ${dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
          `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`
        );

      // Otomatik ceza bilgisi
      if (autoAction) {
        mainEmbed.addFields({
          name: '⚖️ Otomatik Ceza Sistemi',
          value: nextAction || '🔶 Bu seviyede otomatik ceza yok',
          inline: false
        });

        if (autoActionResult) {
          mainEmbed.addFields({
            name: '📋 Otomatik Ceza Case ID',
            value: autoActionResult.caseId,
            inline: true
          });
        }
      }

      // Gelecek cezalar
      const nextWarnings = [];
      for (let i = warnLevel + 1; i <= Math.min(warnLevel + 3, 6); i++) {
        let penalty = '';
        switch (i) {
          case 3: penalty = '30 dakika mute'; break;
          case 4: penalty = '2 saat mute'; break;
          case 5: penalty = 'Kick'; break;
          case 6: penalty = 'Ban'; break;
          default: penalty = 'Ban'; break;
        }
        nextWarnings.push(`${i}. uyarı → ${penalty}`);
      }

      if (nextWarnings.length > 0) {
        mainEmbed.addFields({
          name: '📈 Gelecek Cezalar',
          value: nextWarnings.join('\n'),
          inline: false
        });
      }

      mainEmbed.setFooter({ 
        text: `${guild.name} • Moderasyon Sistemi`,
        iconURL: guild.iconURL({ dynamic: true })
      }).setTimestamp();

      await interaction.editReply({
        embeds: [mainEmbed]
      });

      // Log embed'i
      const logEmbed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle('⚠️ Uyarı')
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📋 Case ID', value: caseId, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '🔢 Seviye', value: warnLevel.toString(), inline: true },
          { name: '📊 Toplam', value: `${existingWarns + 1} uyarı`, inline: true },
          { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true }
        );

      if (autoActionResult) {
        logEmbed.addFields({
          name: '⚖️ Otomatik Ceza',
          value: `${nextAction}\n**Case:** ${autoActionResult.caseId}`,
          inline: false
        });
      }

      logEmbed.setFooter({ text: `${guild.name} • Moderasyon Log` }).setTimestamp();

      await ModerationManager.sendToLogChannel(guild, logEmbed);

      // Başarı logu
      console.log(`⚠️ Uyarı başarılı: ${targetUser.tag} (${caseId}) - Seviye: ${warnLevel} - Moderatör: ${moderator.tag}`);
      if (autoActionResult) {
        console.log(`⚖️ Otomatik ceza uygulandı: ${nextAction} (${autoActionResult.caseId})`);
      }

    } catch (error) {
      console.error('Warn komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};





