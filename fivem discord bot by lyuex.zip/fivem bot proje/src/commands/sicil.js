// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Moderation } = require('../Schemas/ModerationSchema');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');
const { CommandLogger, PerformanceMonitor, InteractionHelper } = require('../utils/commandEnhancements');

const commandLogger = new CommandLogger();
const performanceMonitor = new PerformanceMonitor();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sicil')
    .setDescription('📋 Kullanıcının moderasyon geçmişini görüntüler')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Geçmişi görüntülenecek kullanıcı')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('sayfa')
        .setDescription('📄 Sayfa numarası (varsayılan: 1)')
        .setRequired(false)
        .setMinValue(1))
    .addStringOption(option =>
      option.setName('tür')
        .setDescription('🔍 Sadece belirli işlem türünü göster')
        .setRequired(false)
        .addChoices(
          { name: 'Tümü', value: 'all' },
          { name: 'Ban', value: 'ban' },
          { name: 'Geçici Ban', value: 'tempban' },
          { name: 'Kick', value: 'kick' },
          { name: 'Mute', value: 'mute' },
          { name: 'Geçici Mute', value: 'tempmute' },
          { name: 'Unmute', value: 'unmute' },
          { name: 'Unban', value: 'unban' },
          { name: 'Uyarı', value: 'warn' }
        ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const page = interaction.options.getInteger('sayfa') || 1;
      const filterType = interaction.options.getString('tür') || 'all';
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Moderate Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Filtre oluştur
      const filter = {
        guildId: guild.id,
        userId: targetUser.id
      };

      if (filterType !== 'all') {
        filter.type = filterType;
      }

      // Toplam kayıt sayısı
      const totalRecords = await Moderation.countDocuments(filter);

      if (totalRecords === 0) {
        const noRecordsEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('📋 Temiz Sicil!')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**🆔 ID:** ${targetUser.id}\n\n` +
            `✅ **Bu kullanıcının hiç moderasyon kaydı bulunmuyor!**`
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        return await interaction.editReply({
          embeds: [noRecordsEmbed]
        });
      }

      // Sayfalama
      const recordsPerPage = 5;
      const totalPages = Math.ceil(totalRecords / recordsPerPage);
      const skip = (page - 1) * recordsPerPage;

      if (page > totalPages) {
        return await interaction.editReply({
          content: `❌ **Geçersiz Sayfa!** Toplam ${totalPages} sayfa var, ${page}. sayfa mevcut değil.`
        });
      }

      // Kayıtları getir
      const records = await Moderation.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(recordsPerPage);

      // İstatistikler
      const stats = await Moderation.aggregate([
        { $match: { guildId: guild.id, userId: targetUser.id } },
        { $group: { _id: '$type', count: { $sum: 1 } } }
      ]);

      const statsMap = {};
      stats.forEach(stat => {
        statsMap[stat._id] = stat.count;
      });

      // Aktif cezalar
      const activeMutes = await require('../Schemas/ModerationSchema').Mute.countDocuments({
        userId: targetUser.id,
        guildId: guild.id,
        active: true
      });

      const activeTempBans = await require('../Schemas/ModerationSchema').TempBan.countDocuments({
        userId: targetUser.id,
        guildId: guild.id,
        active: true
      });

      // Emoji haritası
      const typeEmojis = {
        'ban': '🔨',
        'tempban': '⏰',
        'kick': '👢',
        'mute': '🔇',
        'tempmute': '🔇',
        'unmute': '🔊',
        'unban': '🔓',
        'warn': '⚠️'
      };

      // Ana embed
      const historyEmbed = new EmbedBuilder()
        .setColor(0x4169E1)
        .setTitle(`📋 ${targetUser.tag} - Moderasyon Sicili`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .setDescription(
          `**👤 Kullanıcı:** ${targetUser.tag}\n` +
          `**🆔 ID:** ${targetUser.id}\n` +
          `**📊 Toplam Kayıt:** ${totalRecords}\n` +
          `**📄 Sayfa:** ${page}/${totalPages}\n` +
          `**🔍 Filtre:** ${filterType === 'all' ? 'Tümü' : filterType}`
        );

      // İstatistikler field
      if (Object.keys(statsMap).length > 0) {
        const statsText = Object.entries(statsMap)
          .map(([type, count]) => `${typeEmojis[type] || '📝'} ${type}: ${count}`)
          .join('\n');
        
        historyEmbed.addFields({
          name: '📊 İstatistikler',
          value: statsText,
          inline: true
        });
      }

      // Aktif cezalar
      const activeText = [];
      if (activeMutes > 0) activeText.push(`🔇 Aktif Mute: ${activeMutes}`);
      if (activeTempBans > 0) activeText.push(`⏰ Aktif Geçici Ban: ${activeTempBans}`);
      
      if (activeText.length > 0) {
        historyEmbed.addFields({
          name: '🚨 Aktif Cezalar',
          value: activeText.join('\n'),
          inline: true
        });
      }

      // Son kayıtlar
      if (records.length > 0) {
        historyEmbed.addFields({
          name: `📜 Son Kayıtlar (${records.length}/${totalRecords})`,
          value: '\u200B',
          inline: false
        });

        records.forEach((record, index) => {
          const emoji = typeEmojis[record.type] || '📝';
          const date = `<t:${Math.floor(record.createdAt.getTime() / 1000)}:d>`;
          const moderatorMention = `<@${record.moderatorId}>`;
          
          let fieldValue = `**Moderatör:** ${moderatorMention}\n`;
          fieldValue += `**Sebep:** ${record.reason}\n`;
          fieldValue += `**Tarih:** ${date}\n`;
          
          if (record.duration) {
            fieldValue += `**Süre:** ${ModerationManager.formatDuration(record.duration)}\n`;
          }
          
          if (record.expiresAt) {
            fieldValue += `**Bitiş:** <t:${Math.floor(record.expiresAt.getTime() / 1000)}:d>\n`;
          }
          
          fieldValue += `**Durum:** ${record.active ? '🟢 Aktif' : '🔴 Pasif'}`;

          historyEmbed.addFields({
            name: `${emoji} ${record.type.toUpperCase()} - Case #${record.caseId.split('-')[1]}`,
            value: fieldValue,
            inline: true
          });
        });
      }

      // Sayfa navigasyonu
      if (totalPages > 1) {
        let navigationText = `\n**📄 Sayfa Navigasyonu:**\n`;
        if (page > 1) navigationText += `◀️ Önceki: \`/sicil kullanıcı:${targetUser.tag} sayfa:${page - 1}\`\n`;
        if (page < totalPages) navigationText += `▶️ Sonraki: \`/sicil kullanıcı:${targetUser.tag} sayfa:${page + 1}\``;
        
        historyEmbed.setFooter({ 
          text: `${guild.name} • Moderasyon Sistemi • Sayfa ${page}/${totalPages}`,
          iconURL: guild.iconURL({ dynamic: true })
        });
      } else {
        historyEmbed.setFooter({ 
          text: `${guild.name} • Moderasyon Sistemi`,
          iconURL: guild.iconURL({ dynamic: true })
        });
      }

      historyEmbed.setTimestamp();

      await interaction.editReply({
        embeds: [historyEmbed]
      });

    } catch (error) {
      console.error('Sicil komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  }
};





