// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const lyuex = require('../../lyuex.json');

// Rate limiting için Map
const cooldowns = new Map();
const COOLDOWN_TIME = 5000; // 5 saniye

// İsim geçmişi için basit storage
const nameHistory = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('isim')
        .setDescription('🏷️ Belirtilen kullanıcının ismini değiştirir')
        .addUserOption(option => 
            option.setName('kullanici')
            .setDescription('📝 İsmi değiştirilecek kullanıcıyı seçin')
            .setRequired(true))
        .addStringOption(option =>
            option.setName('yeni_isim')
            .setDescription('✨ Kullanıcının yeni ismi (2-32 karakter)')
            .setRequired(true))
        .addBooleanOption(option =>
            option.setName('onaysiz')
            .setDescription('⚡ Onay almadan direkt değiştir (yöneticiler için)')
            .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),

    async execute(interaction) {
        try {
            // Cooldown kontrolü
            const userId = interaction.user.id;
            const now = Date.now();
            const cooldownAmount = cooldowns.get(userId);

            if (cooldownAmount && (now < cooldownAmount + COOLDOWN_TIME)) {
                const timeLeft = Math.ceil((cooldownAmount + COOLDOWN_TIME - now) / 1000);
                const cooldownEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('⏱️ Yavaş Ol!')
                    .setDescription(`Bu komutu tekrar kullanabilmek için **${timeLeft}** saniye beklemelisin.`)
                    .setFooter({ text: 'Spam koruması aktif', iconURL: interaction.user.displayAvatarURL() });
                return await interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
            }

            const targetMember = interaction.options.getMember('kullanici');
            const newName = interaction.options.getString('yeni_isim');
            const skipConfirmation = interaction.options.getBoolean('onaysiz') || false;

            // Temel validasyonlar
            if (!targetMember) {
                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('❌ Kullanıcı Bulunamadı')
                    .setDescription('Belirtilen kullanıcı bu sunucuda bulunamadı.')
                    .setFooter({ text: 'İsim Değiştirme Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // İsim uzunluğu ve karakter kontrolü
            if (newName.length < 2 || newName.length > 32) {
                const lengthEmbed = new EmbedBuilder()
                    .setColor(0xFF9F43)
                    .setTitle('⚠️ Geçersiz İsim Uzunluğu')
                    .setDescription(`İsim **2-32** karakter arasında olmalıdır.\n**Girilen:** ${newName.length} karakter`)
                    .addFields(
                        { name: '📏 Minimum', value: '2 karakter', inline: true },
                        { name: '📏 Maksimum', value: '32 karakter', inline: true },
                        { name: '📝 Öneri', value: 'Kısa ve anlaşılır bir isim seçin', inline: true }
                    )
                    .setFooter({ text: 'İsim Kuralları', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [lengthEmbed], ephemeral: true });
            }

            // Yasaklı karakterler kontrolü
            const forbiddenChars = /[<>@#&!]/g;
            if (forbiddenChars.test(newName)) {
                const charEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('🚫 Yasak Karakterler')
                    .setDescription(`İsimde yasaklı karakterler bulundu: \`< > @ # & !\``)
                    .addFields(
                        { name: '❌ Girilen İsim', value: `\`${newName}\``, inline: false },
                        { name: '✅ İzin Verilen', value: 'Harfler, rakamlar, boşluk ve -, _, . karakterleri', inline: false }
                    )
                    .setFooter({ text: 'Karakter Kuralları', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [charEmbed], ephemeral: true });
            }

            // Yetki kontrolü
            const hasManageNicknames = interaction.member.permissions.has(PermissionFlagsBits.ManageNicknames);
            const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
            const authorizedRoles = lyuex.yetkili.rol || [];
            const hasAuthorizedRole = authorizedRoles.some(roleId => interaction.member.roles.cache.has(roleId));

            if (!hasManageNicknames && !isAdmin && !hasAuthorizedRole) {
                const permEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('🔒 Yetersiz Yetki')
                    .setDescription('Bu komutu kullanmak için gerekli yetkilere sahip değilsin.')
                    .addFields(
                        { name: '📋 Gerekli Yetkiler', value: '• İsimleri Yönet\n• Yönetici\n• Yetkili Rolleri', inline: false }
                    )
                    .setFooter({ text: 'Yetki Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [permEmbed], ephemeral: true });
            }

            // Hedef kullanıcı yetki kontrolü
            if (targetMember.permissions.has(PermissionFlagsBits.Administrator) && !isAdmin) {
                const adminEmbed = new EmbedBuilder()
                    .setColor(0xFF6B6B)
                    .setTitle('👑 Yönetici Koruması')
                    .setDescription('Yönetici yetkisine sahip kullanıcıların ismini değiştiremezsin.')
                    .setFooter({ text: 'Güvenlik Sistemi', iconURL: interaction.guild.iconURL() });
                return await interaction.reply({ embeds: [adminEmbed], ephemeral: true });
            }

            // Eski isim bilgisi
            const oldName = targetMember.nickname || targetMember.user.displayName;
            const currentTime = Math.floor(Date.now() / 1000);

            // Onay sistemi (yöneticiler onaysız işlem yapabilir)
            if (!skipConfirmation && !isAdmin) {
                const confirmEmbed = new EmbedBuilder()
                    .setColor(0x54A0FF)
                    .setTitle('🔄 İsim Değişikliği Onayı')
                    .setDescription('Aşağıdaki bilgileri kontrol ederek işlemi onaylayın.')
                    .addFields(
                        { name: '👤 Hedef Kullanıcı', value: `${targetMember.user.tag}\n<@${targetMember.id}>`, inline: true },
                        { name: '📝 Mevcut İsim', value: oldName, inline: true },
                        { name: '✨ Yeni İsim', value: newName, inline: true },
                        { name: '👮 İşlemi Yapan', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${currentTime}:F>`, inline: true },
                        { name: '🔧 İşlem', value: 'İsim Değişikliği', inline: true }
                    )
                    .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: '⏱️ 30 saniye içinde yanıt verin', iconURL: interaction.guild.iconURL() });

                const confirmButtons = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('confirm_rename')
                            .setLabel('✅ Onayla')
                            .setStyle(ButtonStyle.Success),
                        new ButtonBuilder()
                            .setCustomId('cancel_rename')
                            .setLabel('❌ İptal Et')
                            .setStyle(ButtonStyle.Danger),
                        new ButtonBuilder()
                            .setCustomId('preview_rename')
                            .setLabel('👁️ Önizle')
                            .setStyle(ButtonStyle.Secondary)
                    );

                const response = await interaction.reply({ 
                    embeds: [confirmEmbed], 
                    components: [confirmButtons], 
                    ephemeral: true 
                });

                const filter = i => i.user.id === interaction.user.id;
                const collector = response.createMessageComponentCollector({ filter, time: 30000 });

                collector.on('collect', async i => {
                    if (i.customId === 'confirm_rename') {
                        // Gerçek isim değiştirme işlemi
                        await performRename(i, targetMember, newName, oldName, currentTime);
                        cooldowns.set(userId, now);
                    } else if (i.customId === 'cancel_rename') {
                        const cancelEmbed = new EmbedBuilder()
                            .setColor(0x95AFC0)
                            .setTitle('❌ İşlem İptal Edildi')
                            .setDescription('İsim değiştirme işlemi iptal edildi.')
                            .setFooter({ text: 'İptal Edildi', iconURL: interaction.user.displayAvatarURL() });
                        await i.update({ embeds: [cancelEmbed], components: [] });
                    } else if (i.customId === 'preview_rename') {
                        const previewEmbed = new EmbedBuilder()
                            .setColor(0xFECA57)
                            .setTitle('👁️ İsim Önizleme')
                            .setDescription(`**${targetMember.user.tag}** kullanıcısının ismi şu şekilde görünecek:`)
                            .addFields(
                                { name: '📝 Mevcut Görünüm', value: `\`${oldName}\``, inline: true },
                                { name: '✨ Yeni Görünüm', value: `\`${newName}\``, inline: true },
                                { name: '📊 Karakter Sayısı', value: `${newName.length}/32`, inline: true }
                            )
                            .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
                            .setFooter({ text: 'Önizleme Modu', iconURL: interaction.guild.iconURL() });
                        await i.reply({ embeds: [previewEmbed], ephemeral: true });
                    }
                });

                collector.on('end', async collected => {
                    if (collected.size === 0) {
                        const timeoutEmbed = new EmbedBuilder()
                            .setColor(0xFF6B6B)
                            .setTitle('⏰ Zaman Aşımı')
                            .setDescription('İsim değiştirme işlemi zaman aşımına uğradı.')
                            .setFooter({ text: 'İşlem İptal Edildi', iconURL: interaction.user.displayAvatarURL() });
                        try {
                            await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
                        } catch (error) {
                            console.error('Timeout mesajı güncellenemedi:', error);
                        }
                    }
                });

            } else {
                // Direkt işlem (yöneticiler için)
                await interaction.deferReply({ ephemeral: true });
                await performRename(interaction, targetMember, newName, oldName, currentTime);
                cooldowns.set(userId, now);
            }

        } catch (error) {
            console.error('İsim değiştirme komutunda hata:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF6B6B)
                .setTitle('❌ Sistem Hatası')
                .setDescription('İsim değiştirme işlemi sırasında bir hata oluştu.')
                .addFields(
                    { name: '🔧 Hata Kodu', value: error.code || 'Bilinmiyor', inline: true },
                    { name: '📝 Hata Mesajı', value: error.message || 'Detay yok', inline: true }
                )
                .setFooter({ text: 'Hata Sistemi', iconURL: interaction.user.displayAvatarURL() });
            
            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },
};

async function performRename(interaction, targetMember, newName, oldName, currentTime) {
    try {
        // İsim değiştirme işlemi
        await targetMember.setNickname(newName);

        // İsim geçmişini kaydet
        const userId = targetMember.id;
        if (!nameHistory.has(userId)) {
            nameHistory.set(userId, []);
        }
        const history = nameHistory.get(userId);
        history.push({
            oldName: oldName,
            newName: newName,
            changedBy: interaction.user.id,
            timestamp: currentTime
        });
        if (history.length > 10) history.shift(); // Son 10 değişikliği tut

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
            .setColor(0x2ED573)
            .setTitle('✅ İsim Başarıyla Değiştirildi')
            .setDescription(`**${targetMember.user.tag}** kullanıcısının ismi başarıyla güncellendi!`)
            .addFields(
                { name: '👤 Kullanıcı', value: `<@${targetMember.id}>`, inline: true },
                { name: '📝 Eski İsim', value: oldName, inline: true },
                { name: '✨ Yeni İsim', value: newName, inline: true },
                { name: '👮 İşlemi Yapan', value: `<@${interaction.user.id}>`, inline: true },
                { name: '⏰ İşlem Zamanı', value: `<t:${currentTime}:R>`, inline: true },
                { name: '📊 Toplam Değişiklik', value: `${history.length} kez`, inline: true }
            )
            .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `İsim Sistemi • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        if (interaction.deferred) {
            await interaction.editReply({ embeds: [successEmbed], components: [] });
        } else {
            await interaction.update({ embeds: [successEmbed], components: [] });
        }

        // Merkezi log kanalına gönder
        const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
        if (logChannelId) {
            const logChannel = interaction.client.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(0x54A0FF)
                    .setTitle('🏷️ İsim Değişikliği Logu')
                    .setDescription('Bir kullanıcının ismi değiştirildi.')
                    .addFields(
                        { name: '👤 Hedef Kullanıcı', value: `${targetMember.user.tag}\n<@${targetMember.id}>\n\`${targetMember.id}\``, inline: true },
                        { name: '👮 İşlemi Yapan', value: `${interaction.user.tag}\n<@${interaction.user.id}>\n\`${interaction.user.id}\``, inline: true },
                        { name: '🔧 İşlem Detayı', value: `\`\`\`diff\n- ${oldName}\n+ ${newName}\`\`\``, inline: false },
                        { name: '📍 Kanal', value: `<#${interaction.channel.id}>`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${currentTime}:F>`, inline: true },
                        { name: '📊 Karakter', value: `${newName.length}/32`, inline: true }
                    )
                    .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: `İsim Değişiklik Sistemi • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] }).catch(console.error);
            }
        }

    } catch (error) {
        console.error('İsim değiştirme hatası:', error);
        
        let errorMessage = 'Bilinmeyen bir hata oluştu.';
        if (error.code === 50013) {
            errorMessage = 'Bu kullanıcının ismini değiştirmek için yeterli yetkiye sahip değilim.';
        } else if (error.code === 50035) {
            errorMessage = 'Geçersiz isim formatı.';
        }

        const errorEmbed = new EmbedBuilder()
            .setColor(0xFF6B6B)
            .setTitle('❌ İsim Değiştirilemedi')
            .setDescription(errorMessage)
            .addFields(
                { name: '🔧 Hata Kodu', value: error.code?.toString() || 'Bilinmiyor', inline: true },
                { name: '👤 Hedef', value: `<@${targetMember.id}>`, inline: true }
            )
            .setFooter({ text: 'Hata Detayı', iconURL: interaction.user.displayAvatarURL() });

        if (interaction.deferred) {
            await interaction.editReply({ embeds: [errorEmbed], components: [] });
        } else {
            await interaction.update({ embeds: [errorEmbed], components: [] });
        }
    }
}





