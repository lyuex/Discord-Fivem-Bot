// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ComponentType } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('non-wl-liste')
        .setDescription('Kayıtsız rolündeki kişileri listeler')
        .addRoleOption(option => 
            option.setName('rol')
                .setDescription('Listelenecek rol (belirtilmezse kayıtsız rolü kullanılır)')
                .setRequired(false)),
    
    async execute(interaction) {
        try {
            // Yetkili kontrolü
            const memberRoles = interaction.member.roles.cache;
            const hasPermission = lyuex.yetkili.kayit.some(roleId => memberRoles.has(roleId)) || 
                                 memberRoles.has(lyuex.yetkili.yasaklama) ||
                                 lyuex.yetkili.rol.some(roleId => memberRoles.has(roleId));
            
            if (!hasPermission) {
                return interaction.reply({ 
                    content: '❌ Bu komutu kullanma yetkiniz bulunmuyor.', 
                    ephemeral: true 
                });
            }

            await interaction.deferReply();

            // Rol kontrolü
            let role = interaction.options.getRole('rol');
            
            // Rol belirtilmemişse, lyuex.json'daki kayıtsız rolünü kullan
            if (!role) {
                const kayitsizRolId = lyuex.rol?.kayıtsız;
                if (kayitsizRolId) {
                    role = interaction.guild.roles.cache.get(kayitsizRolId);
                }
                
                // Eğer lyuex.json'daki rol bulunamazsa, "non-wl" rolünü ara
                if (!role) {
                    role = interaction.guild.roles.cache.find(r => 
                        r.name.toLowerCase().includes('non-wl') || 
                        r.name.toLowerCase().includes('nonwl') || 
                        r.name.toLowerCase().includes('non whitelist') ||
                        r.name.toLowerCase().includes('kayıtsız') ||
                        r.name.toLowerCase().includes('unverified')
                    );
                }
                
                if (!role) {
                    return interaction.editReply('❌ Kayıtsız rolü bulunamadı! Lütfen bir rol belirtin veya lyuex.json dosyasında "rol.kayıtsız" ayarını kontrol edin.');
                }
            }

            // Roldeki üyeleri al
            const members = role.members.map(member => {
                return {
                    id: member.id,
                    tag: member.user.tag || member.user.username,
                    displayName: member.displayName,
                    joined: member.joinedAt ? member.joinedAt.toLocaleDateString('tr-TR') : 'Bilinmiyor',
                    joinedTimestamp: member.joinedAt ? member.joinedAt.getTime() : 0,
                    accountAge: member.user.createdAt ? Math.floor((Date.now() - member.user.createdAt.getTime()) / (1000 * 60 * 60 * 24)) : 0
                };
            });

            if (members.length === 0) {
                return interaction.editReply(`📋 **${role.name}** rolünde hiç üye bulunmuyor.`);
            }

            // Üyeleri katılma tarihine göre sırala (en yeni en üstte)
            members.sort((a, b) => b.joinedTimestamp - a.joinedTimestamp);

            // Sayfalandırma için değişkenler
            const itemsPerPage = 10;
            const pages = Math.ceil(members.length / itemsPerPage);
            let currentPage = 0;
            
            // Embed oluştur
            const generateEmbed = (page) => {
                const startIndex = page * itemsPerPage;
                const currentMembers = members.slice(startIndex, startIndex + itemsPerPage);
                
                const embed = new EmbedBuilder()
                    .setTitle(`📋 ${role.name} Rolündeki Üyeler`)
                    .setColor(role.color || '#5865F2')
                    .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                    .setFooter({ 
                        text: `${interaction.user.tag} tarafından istendi • Sayfa ${page + 1}/${pages} • Toplam: ${members.length} üye`,
                        iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                    })
                    .setTimestamp();
                
                // Üye listesini hazırla
                let description = `🔢 **Toplam Üye:** ${members.length}\n📄 **Sayfa:** ${page + 1}/${pages}\n📅 **Sıralama:** En yeni katılanlar üstte\n\n`;
                
                currentMembers.forEach((member, index) => {
                    const globalIndex = startIndex + index + 1;
                    const accountAgeText = member.accountAge < 7 ? '🔴 Yeni' : member.accountAge < 30 ? '🟡 Genç' : '🟢 Eski';
                    
                    description += `**${globalIndex}.** <@${member.id}>\n`;
                    description += `> 👤 **İsim:** ${member.displayName}\n`;
                    description += `> 📅 **Katılım:** ${member.joined}\n`;
                    description += `> 🗓️ **Hesap:** ${accountAgeText} (${member.accountAge} gün)\n`;
                    description += `> 🆔 **ID:** \`${member.id}\`\n\n`;
                });
                
                embed.setDescription(description);
                
                return embed;
            };

            // Select menü oluştur (sayfa seçimi için)
            const getPageSelectMenu = (currentPage) => {
                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('page_select')
                    .setPlaceholder(`📄 Sayfa Seç veya İşlem Yap (Şu an: ${currentPage + 1}/${pages})`)
                    .setMinValues(1)
                    .setMaxValues(1);

                // Sayfalar (eğer birden fazla sayfa varsa)
                if (pages > 1) {
                    // Maksimum 20 sayfa göster (diğer seçenekler için yer bırak)
                    const maxPagesToShow = Math.min(pages, 20);
                    
                    for (let i = 0; i < maxPagesToShow; i++) {
                        const startIndex = i * itemsPerPage;
                        const endIndex = Math.min(startIndex + itemsPerPage, members.length);
                        
                        selectMenu.addOptions({
                            label: `Sayfa ${i + 1}`,
                            description: `Üyeler ${startIndex + 1}-${endIndex} (${endIndex - startIndex} üye)`,
                            value: `page_${i}`,
                            emoji: currentPage === i ? '📍' : '📄'
                        });
                    }
                    
                    // Ayırıcı
                    selectMenu.addOptions({
                        label: '────────────────',
                        description: 'İşlemler',
                        value: 'separator',
                        emoji: '➖'
                    });
                }

                // İşlem seçenekleri
                selectMenu.addOptions({
                    label: '🔄 Listeyi Yenile',
                    description: 'Güncel verileri getir',
                    value: 'refresh_list',
                    emoji: '🔄'
                });

                selectMenu.addOptions({
                    label: '📤 Listeyi Export Et',
                    description: 'Tüm üyeleri metin olarak al',
                    value: 'export_list',
                    emoji: '📤'
                });

                selectMenu.addOptions({
                    label: '❌ Listeyi Kapat',
                    description: 'Etkileşimi sonlandır',
                    value: 'close_list',
                    emoji: '❌'
                });

                return new ActionRowBuilder().addComponents(selectMenu);
            };
            
            // Komponentleri hazırla
            const getComponents = (currentPage) => {
                return [getPageSelectMenu(currentPage)];
            };
            
            // İlk mesajı gönder
            const message = await interaction.editReply({
                embeds: [generateEmbed(currentPage)],
                components: getComponents(currentPage)
            });
            
            // Etkileşim koleksiyonunu oluştur (her zaman, çünkü yenile/export/kapat seçenekleri var)
            const collector = message.createMessageComponentCollector({ 
                time: 10 * 60 * 1000 // 10 dakika
            });
            
            // Etkileşimleri dinle
            collector.on('collect', async (componentInteraction) => {
                // Sadece komutu kullanan kişinin etkileşimde bulunmasına izin ver
                if (componentInteraction.user.id !== interaction.user.id) {
                    return componentInteraction.reply({ 
                        content: '❌ Bu listeyi sadece komutu kullanan kişi kontrol edebilir.', 
                        ephemeral: true 
                    });
                }
                
                await componentInteraction.deferUpdate();
                
                // Select menu etkileşimi
                if (componentInteraction.isStringSelectMenu() && componentInteraction.customId === 'page_select') {
                    const selectedValue = componentInteraction.values[0];
                    
                    // Sayfa seçimi
                    if (selectedValue.startsWith('page_')) {
                        currentPage = parseInt(selectedValue.replace('page_', ''));
                    }
                    // İşlem seçimleri
                    else if (selectedValue === 'refresh_list') {
                        // Listeyi yenile mesajı
                        await componentInteraction.followUp({
                            content: '🔄 Liste yenilendi! Güncel veriler gösteriliyor.',
                            ephemeral: true
                        });
                    }
                    else if (selectedValue === 'export_list') {
                        // Export işlemi
                        const exportText = members.map((member, index) => 
                            `${index + 1}. ${member.tag} (ID: ${member.id}) - Katılım: ${member.joined}`
                        ).join('\n');
                        
                        await componentInteraction.followUp({
                            content: `📤 **${role.name}** rolündeki ${members.length} üye:\n\`\`\`\n${exportText.substring(0, 1900)}\n\`\`\`${exportText.length > 1900 ? '\n*(Liste kesildi, tam liste için bot loglarını kontrol edin)*' : ''}`,
                            ephemeral: true
                        });
                    }
                    else if (selectedValue === 'close_list') {
                        collector.stop('user_closed');
                        return;
                    }
                    else if (selectedValue === 'separator') {
                        // Ayırıcı seçeneği - hiçbir şey yapma
                        return;
                    }
                }
                
                // Mesajı güncelle
                await componentInteraction.editReply({
                    embeds: [generateEmbed(currentPage)],
                    components: getComponents(currentPage)
                });
            });
            
            // Koleksiyonun süresi dolduğunda
            collector.on('end', async (collected, reason) => {
                try {
                    const endEmbed = new EmbedBuilder()
                        .setTitle('⏰ Liste Süresi Doldu')
                        .setDescription(reason === 'user_closed' ? 
                            '❌ Liste kullanıcı tarafından kapatıldı.' : 
                            '⏰ Liste etkileşim süresi (10 dakika) doldu.')
                        .setColor(reason === 'user_closed' ? '#FF4444' : '#FFA500')
                        .setFooter({ text: 'Yeni bir liste için komutu tekrar kullanın' })
                        .setTimestamp();

                    await message.edit({
                        embeds: [endEmbed],
                        components: []
                    });
                } catch (error) {
                    console.error('Liste sonlandırma hatası:', error);
                }
            });

        } catch (error) {
            console.error("Non-WL liste komutu hatası:", error);
            const hataEmbed = new EmbedBuilder()
                .setTitle('❌ Sistem Hatası')
                .setDescription('Liste oluşturulurken bir hata oluştu!')
                .addFields(
                    { name: '🔍 Hata Detayı', value: '```' + error.message + '```', inline: false },
                    { name: '💡 Çözüm', value: 'Lütfen komutu tekrar deneyin veya yöneticiye bildirin', inline: false }
                )
                .setColor('#FF0000')
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.editReply({ embeds: [hataEmbed], components: [] });
            } else {
                await interaction.reply({ embeds: [hataEmbed], ephemeral: true });
            }
        }
    }
};