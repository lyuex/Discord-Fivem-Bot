// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');
const path = require('path');

// Uyarı veritabanı dosyası
const uyariDB = path.join(__dirname, '../../db/uyarilar.json');

// Veritabanı okuma/yazma fonksiyonları
function getUyariData() {
    try {
        const data = fs.readFileSync(uyariDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveUyariData(data) {
    fs.writeFileSync(uyariDB, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uyarı-sil')
        .setDescription('Kullanıcının uyarısını sil')
        .addUserOption(option =>
            option.setName('kullanıcı')
                .setDescription('Uyarısı silinecek kullanıcı')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('uyarı-id')
                .setDescription('Silinecek uyarının ID\'si (opsiyonel - boş bırakırsa son uyarı silinir)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        await interaction.deferReply();
        
        const targetUser = interaction.options.getUser('kullanıcı');
        const uyariId = interaction.options.getString('uyarı-id');
        
        // Admin kontrolü
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('❌ Yetki Hatası')
                        .setDescription('Bu komutu sadece Administrator yetkisine sahip kişiler kullanabilir!')
                        .setColor(0xF44336)
                        .setTimestamp()
                ]
            });
        }
        
        const uyariData = getUyariData();
        const userData = uyariData[targetUser.id];
        
        if (!userData || !userData.uyarilar || userData.uyarilar.length === 0) {
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('❌ Uyarı Bulunamadı')
                        .setDescription(`<@${targetUser.id}> kullanıcısının silinecek uyarısı yok!`)
                        .setColor(0xF44336)
                        .setTimestamp()
                ]
            });
        }
        
        let silinecekUyari;
        let uyariIndex;
        
        if (uyariId) {
            // Belirli ID'li uyarıyı bul
            uyariIndex = userData.uyarilar.findIndex(u => u.id.toString() === uyariId);
            if (uyariIndex === -1) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('❌ Uyarı Bulunamadı')
                            .setDescription(`ID: \`${uyariId}\` olan uyarı bulunamadı!`)
                            .setColor(0xF44336)
                            .setTimestamp()
                    ]
                });
            }
            silinecekUyari = userData.uyarilar[uyariIndex];
        } else {
            // Son uyarıyı sil
            uyariIndex = userData.uyarilar.length - 1;
            silinecekUyari = userData.uyarilar[uyariIndex];
        }
        
        // Onay embed'i
        const onayEmbed = new EmbedBuilder()
            .setTitle('⚠️ Uyarı Silme Onayı')
            .setDescription(`Aşağıdaki uyarıyı silmek istediğinizden emin misiniz?`)
            .addFields(
                { 
                    name: '👤 Kullanıcı', 
                    value: `<@${targetUser.id}>\n\`${targetUser.tag}\``, 
                    inline: true 
                },
                { 
                    name: '🆔 Uyarı ID', 
                    value: `\`${silinecekUyari.id}\``, 
                    inline: true 
                },
                { 
                    name: '📅 Tarih', 
                    value: `<t:${silinecekUyari.timestamp}:F>`, 
                    inline: true 
                },
                { 
                    name: '📋 Sebep', 
                    value: silinecekUyari.sebep, 
                    inline: false 
                },
                { 
                    name: '⚖️ Ceza', 
                    value: silinecekUyari.ceza, 
                    inline: true 
                },
                { 
                    name: '👮 Veren Yetkili', 
                    value: `<@${silinecekUyari.yetkili.id}>\n\`${silinecekUyari.yetkili.tag}\``, 
                    inline: true 
                }
            )
            .setColor(0xFF9800)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'Bu işlem geri alınamaz!' })
            .setTimestamp();
        
        const onayRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('uyari_sil_onayla')
                    .setLabel('Evet, Sil')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️'),
                new ButtonBuilder()
                    .setCustomId('uyari_sil_iptal')
                    .setLabel('İptal Et')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('❌')
            );
        
        const response = await interaction.editReply({
            embeds: [onayEmbed],
            components: [onayRow]
        });
        
        // Button collector
        const filter = i => i.user.id === interaction.user.id;
        const collector = response.createMessageComponentCollector({ filter, time: 30000 });
        
        collector.on('collect', async i => {
            if (i.customId === 'uyari_sil_onayla') {
                // Uyarıyı sil
                userData.uyarilar.splice(uyariIndex, 1);
                
                // Eğer uyarı kalmadıysa kullanıcı verisini tamamen sil
                if (userData.uyarilar.length === 0) {
                    delete uyariData[targetUser.id];
                } else {
                    uyariData[targetUser.id] = userData;
                }
                
                saveUyariData(uyariData);
                
                const basariliEmbed = new EmbedBuilder()
                    .setTitle('✅ Uyarı Silindi')
                    .setDescription(`<@${targetUser.id}> kullanıcısının uyarısı başarıyla silindi!`)
                    .addFields(
                        { 
                            name: '🆔 Silinen Uyarı ID', 
                            value: `\`${silinecekUyari.id}\``, 
                            inline: true 
                        },
                        { 
                            name: '📊 Kalan Uyarı', 
                            value: userData.uyarilar ? userData.uyarilar.length.toString() : '0', 
                            inline: true 
                        },
                        { 
                            name: '👮 Silen Yetkili', 
                            value: `<@${interaction.user.id}>\n\`${interaction.user.tag}\``, 
                            inline: true 
                        }
                    )
                    .setColor(0x4CAF50)
                    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                    .setTimestamp();
                
                await i.update({ embeds: [basariliEmbed], components: [] });
                
                // Log kanalına gönder
                const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                if (logChannelId) {
                    const logChannel = interaction.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setAuthor({ 
                                name: 'Uyarı Sistemi - Uyarı Silindi', 
                                iconURL: interaction.guild.iconURL({ dynamic: true }) 
                            })
                            .setTitle('🗑️ Uyarı Silme Kaydı')
                            .addFields(
                                { name: '👤 Kullanıcı', value: `<@${targetUser.id}> (\`${targetUser.tag}\`)`, inline: true },
                                { name: '👮 Silen Yetkili', value: `<@${interaction.user.id}> (\`${interaction.user.tag}\`)`, inline: true },
                                { name: '🆔 Silinen Uyarı ID', value: silinecekUyari.id.toString(), inline: true },
                                { name: '📋 Silinen Uyarı Sebebi', value: silinecekUyari.sebep, inline: false },
                                { name: '⚖️ Silinen Uyarı Cezası', value: silinecekUyari.ceza, inline: true },
                                { name: '📊 Kalan Toplam Uyarı', value: (userData.uyarilar ? userData.uyarilar.length : 0).toString(), inline: true }
                            )
                            .setColor(0xFF5722)
                            .setTimestamp();
                        
                        await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
                    }
                }
                
            } else if (i.customId === 'uyari_sil_iptal') {
                const iptalEmbed = new EmbedBuilder()
                    .setTitle('✅ İşlem İptal Edildi')
                    .setDescription('Uyarı silme işlemi iptal edildi.')
                    .setColor(0x607D8B)
                    .setTimestamp();
                
                await i.update({ embeds: [iptalEmbed], components: [] });
            }
        });
        
        collector.on('end', collected => {
            if (collected.size === 0) {
                const zamanasimiEmbed = new EmbedBuilder()
                    .setTitle('⏰ Zaman Aşımı')
                    .setDescription('İşlem zaman aşımına uğradı. Güvenlik amacıyla iptal edildi.')
                    .setColor(0x9E9E9E)
                    .setTimestamp();
                
                interaction.editReply({ embeds: [zamanasimiEmbed], components: [] }).catch(() => {});
            }
        });
    },
};





