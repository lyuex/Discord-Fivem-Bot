// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mass-mod')
    .setDescription('🔨 Toplu moderasyon işlemleri')
    .addStringOption(option =>
      option.setName('işlem')
        .setDescription('⚖️ Yapılacak işlem türü')
        .setRequired(true)
        .addChoices(
          { name: '🔨 Toplu Ban', value: 'ban' },
          { name: '👢 Toplu Kick', value: 'kick' },
          { name: '🔇 Toplu Mute', value: 'mute' },
          { name: '⚠️ Toplu Uyarı', value: 'warn' },
          { name: '🧹 Spam Temizleme', value: 'spam' },
          { name: '🎭 Rol Bazlı İşlem', value: 'role' }
        ))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('� Toplu işlem sebebi')
        .setRequired(true)
        .setMaxLength(500))
    .addStringOption(option =>
      option.setName('hedefler')
        .setDescription('👥 Hedef kullanıcılar (ID\'leri boşlukla ayırın)')
        .setRequired(false)
        .setMaxLength(2000))
    .addRoleOption(option =>
      option.setName('hedef_rol')
        .setDescription('🎭 Hedef rol (rol bazlı işlemler için)')
        .setRequired(false))
    .addIntegerOption(option =>
      option.setName('süre')
        .setDescription('⏰ Süre (dakika, mute/tempban için)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(525600))
    .addBooleanOption(option =>
      option.setName('onay_gerektir')
        .setDescription('✅ Her işlem için ayrı onay iste (varsayılan: true)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const action = interaction.options.getString('işlem');
      const reason = interaction.options.getString('sebep');
      const targets = interaction.options.getString('hedefler');
      const targetRole = interaction.options.getRole('hedef_rol');
      const duration = interaction.options.getInteger('süre');
      const requireConfirmation = interaction.options.getBoolean('onay_gerektir') ?? true;
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Süper yetki kontrolü (sadece Adlyuexstrator veya kurucu)
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü\n\n' +
                  '⚠️ **Uyarı:** Bu komut çok tehlikeli olduğu için sadece en üst düzey yetkililere açıktır!'
        });
      }

      // Hedef belirleme
      let userIds = [];
      
      if (targets) {
        // Manuel ID listesi
        userIds = targets.split(/\s+/).filter(id => /^\d{17,19}$/.test(id));
        if (userIds.length === 0) {
          return await interaction.editReply({
            content: '❌ **Geçersiz Hedefler!** Lütfen geçerli kullanıcı ID\'leri girin (17-19 haneli).'
          });
        }
      } else if (targetRole) {
        // Rol bazlı hedefleme
        const members = targetRole.members;
        userIds = members.map(member => member.user.id);
        
        if (userIds.length === 0) {
          return await interaction.editReply({
            content: `❌ **Boş Rol!** ${targetRole.name} rolünde hiç kullanıcı bulunmuyor.`
          });
        }
      } else {
        return await interaction.editReply({
          content: '❌ **Hedef Eksik!** Lütfen hedef kullanıcıları veya rolü belirtin.'
        });
      }

      // Güvenlik kontrolleri
      if (userIds.length > 50) {
        return await interaction.editReply({
          content: '❌ **Çok Fazla Hedef!** Güvenlik nedeniyle maksimum 50 kullanıcıya işlem yapabilirsiniz.'
        });
      }

      // Bot ve moderatör koruması
      const protectedIds = [
        interaction.client.user.id, // Bot
        guild.ownerId, // Sunucu sahibi
        moderator.id // Kendisi
      ];

      userIds = userIds.filter(id => !protectedIds.includes(id));

      if (userIds.length === 0) {
        return await interaction.editReply({
          content: '❌ **Geçerli Hedef Yok!** Tüm hedefler korumalı kullanıcılar (bot, sahip, kendiniz).'
        });
      }

      // İşlem validasyonu
      switch (action) {
        case 'mute':
          if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return await interaction.editReply({
              content: '❌ **Bot Yetki Hatası!** Rol yönetme yetkisi gerekli.'
            });
          }
          break;
        case 'ban':
          if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
            return await interaction.editReply({
              content: '❌ **Bot Yetki Hatası!** Ban yetkisi gerekli.'
            });
          }
          break;
        case 'kick':
          if (!guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
            return await interaction.editReply({
              content: '❌ **Bot Yetki Hatası!** Kick yetkisi gerekli.'
            });
          }
          break;
      }

      // Hedef bilgilerini topla
      const targetUsers = [];
      const missingUsers = [];

      for (const userId of userIds) {
        try {
          const user = await interaction.client.users.fetch(userId);
          targetUsers.push(user);
        } catch {
          missingUsers.push(userId);
        }
      }

      // Onay embed'i oluştur
      const actionEmojis = {
        'ban': '🔨',
        'kick': '👢',
        'mute': '🔇',
        'warn': '⚠️',
        'spam': '🧹',
        'role': '🎭'
      };

      const actionNames = {
        'ban': 'Toplu Ban',
        'kick': 'Toplu Kick',
        'mute': 'Toplu Mute',
        'warn': 'Toplu Uyarı',
        'spam': 'Spam Temizleme',
        'role': 'Rol Bazlı İşlem'
      };

      const confirmEmbed = new EmbedBuilder()
        .setColor(0xFF4444)
        .setTitle(`${actionEmojis[action]} ${actionNames[action]} - ONAY GEREKİYOR`)
        .setDescription(
          `⚠️ **UYARI: Bu işlem geri alınamaz!**\n\n` +
          `**🎯 İşlem Türü:** ${actionNames[action]}\n` +
          `**👥 Hedef Sayısı:** ${targetUsers.length} kullanıcı\n` +
          `**📝 Sebep:** ${reason}\n` +
          (duration ? `**⏰ Süre:** ${ModerationManager.formatDuration(duration)}\n` : '') +
          (targetRole ? `**🎭 Hedef Rol:** ${targetRole.name}\n` : '') +
          `**👮 Moderatör:** ${moderator.tag}`
        );

      // Hedef kullanıcıları göster (max 10)
      if (targetUsers.length > 0) {
        const userList = targetUsers
          .slice(0, 10)
          .map((user, index) => `${index + 1}. ${user.tag} (${user.id})`)
          .join('\n');
        
        const moreText = targetUsers.length > 10 ? `\n... ve ${targetUsers.length - 10} kullanıcı daha` : '';
        
        confirmEmbed.addFields({
          name: `👥 Hedef Kullanıcılar (${Math.min(targetUsers.length, 10)}/${targetUsers.length})`,
          value: `\`\`\`\n${userList}${moreText}\n\`\`\``,
          inline: false
        });
      }

      if (missingUsers.length > 0) {
        confirmEmbed.addFields({
          name: '❌ Bulunamayan ID\'ler',
          value: `${missingUsers.length} adet geçersiz/bulunamayan ID`,
          inline: true
        });
      }

      // Güvenlik uyarıları
      const warnings = [];
      if (targetUsers.length >= 20) warnings.push('⚠️ 20+ kullanıcıya işlem yapılacak');
      if (action === 'ban') warnings.push('🔨 Kalıcı ban işlemi');
      if (targetRole) warnings.push(`🎭 Tüm ${targetRole.name} rolü etkilenecek`);

      if (warnings.length > 0) {
        confirmEmbed.addFields({
          name: '🚨 Güvenlik Uyarıları',
          value: warnings.join('\n'),
          inline: false
        });
      }

      confirmEmbed.setFooter({ 
        text: `${guild.name} • TOPLU MODERASYON - DİKKATLE ONAYLAYIN!`,
        iconURL: guild.iconURL({ dynamic: true })
      }).setTimestamp();

      // Onay butonları
      const confirmButton = new ButtonBuilder()
        .setCustomId('mass_mod_confirm')
        .setLabel('✅ ONAYLA VE UYGULA')
        .setStyle(ButtonStyle.Danger);

      const cancelButton = new ButtonBuilder()
        .setCustomId('mass_mod_cancel')
        .setLabel('❌ İptal Et')
        .setStyle(ButtonStyle.Secondary);

      const row = new ActionRowBuilder()
        .addComponents(confirmButton, cancelButton);

      const response = await interaction.editReply({
        content: `🚨 **TEHLİKELİ İŞLEM ONAY BEKLİYOR!**\n\n**${targetUsers.length} kullanıcıya ${actionNames[action]} uygulanacak!**`,
        embeds: [confirmEmbed],
        components: [row]
      });

      // Buton collector
      const collector = response.createMessageComponentCollector({ time: 60000 });

      collector.on('collect', async (buttonInteraction) => {
        if (buttonInteraction.user.id !== moderator.id) {
          return await buttonInteraction.reply({
            content: '❌ Bu onayı sadece komutu kullanan kişi verebilir!',
            ephemeral: true
          });
        }

        await buttonInteraction.deferUpdate();

        if (buttonInteraction.customId === 'mass_mod_cancel') {
          const cancelEmbed = new EmbedBuilder()
            .setColor(0x808080)
            .setTitle('❌ Toplu Moderasyon İptal Edildi')
            .setDescription('İşlem kullanıcı tarafından iptal edildi.')
            .setTimestamp();

          await interaction.editReply({
            content: null,
            embeds: [cancelEmbed],
            components: []
          });
          return;
        }

        if (buttonInteraction.customId === 'mass_mod_confirm') {
          // İşlemi başlat
          await this.executeMassAction(interaction, action, targetUsers, reason, duration, moderator, guild);
        }
      });

      collector.on('end', async (collected) => {
        if (collected.size === 0) {
          const timeoutEmbed = new EmbedBuilder()
            .setColor(0x808080)
            .setTitle('⏰ Toplu Moderasyon Zaman Aşımı')
            .setDescription('60 saniye içinde yanıt verilmediği için işlem iptal edildi.')
            .setTimestamp();

          await interaction.editReply({
            content: null,
            embeds: [timeoutEmbed],
            components: []
          });
        }
      });

    } catch (error) {
      console.error('Mass moderation hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  },

  async executeMassAction(interaction, action, targetUsers, reason, duration, moderator, guild) {
    const results = {
      success: [],
      failed: [],
      skipped: []
    };

    const progressEmbed = new EmbedBuilder()
      .setColor(0xFFA500)
      .setTitle('⚙️ Toplu Moderasyon İşleniyor...')
      .setDescription(`📊 İlerleme: 0/${targetUsers.length}`)
      .setTimestamp();

    await interaction.editReply({
      content: null,
      embeds: [progressEmbed],
      components: []
    });

    // İşlemleri sırayla gerçekleştir
    for (let i = 0; i < targetUsers.length; i++) {
      const user = targetUsers[i];
      
      try {
        // İlerleme güncelle
        if (i % 5 === 0 || i === targetUsers.length - 1) {
          progressEmbed.setDescription(`📊 İlerleme: ${i + 1}/${targetUsers.length}\n🔄 İşleniyor: ${user.tag}`);
          await interaction.editReply({ embeds: [progressEmbed] });
        }

        let result = null;
        let member = null;

        // Üye kontrolü (kick/mute için gerekli)
        if (['kick', 'mute'].includes(action)) {
          try {
            member = await guild.members.fetch(user.id);
          } catch {
            results.skipped.push({ user, reason: 'Sunucuda değil' });
            continue;
          }
        }

        // İşlemi gerçekleştir
        switch (action) {
          case 'ban':
            result = await ModerationManager.banUser({
              guild,
              user,
              moderator,
              reason: `Toplu Ban: ${reason}`,
              duration,
              deleteMessages: 1
            });
            break;

          case 'kick':
            result = await ModerationManager.kickUser({
              guild,
              member,
              moderator,
              reason: `Toplu Kick: ${reason}`
            });
            break;

          case 'mute':
            result = await ModerationManager.muteUser({
              guild,
              member,
              moderator,
              reason: `Toplu Mute: ${reason}`,
              duration
            });
            break;

          case 'warn':
            // Warn işlemi için özel kod
            result = await this.executeWarn(guild, user, moderator, `Toplu Uyarı: ${reason}`);
            break;
        }

        if (result && result.success) {
          results.success.push({ user, caseId: result.caseId });
        } else {
          results.failed.push({ user, reason: 'İşlem başarısız' });
        }

        // Rate limiting için kısa bekleme
        await new Promise(resolve => setTimeout(resolve, 500));

      } catch (error) {
        console.error(`Toplu moderasyon hatası (${user.tag}):`, error);
        results.failed.push({ user, reason: error.message });
      }
    }

    // Sonuç raporu
    const resultEmbed = new EmbedBuilder()
      .setColor(results.failed.length > results.success.length ? '#FF0000' : '#00FF00')
      .setTitle('📊 Toplu Moderasyon Tamamlandı')
      .setDescription(
        `**✅ Başarılı:** ${results.success.length}\n` +
        `**❌ Başarısız:** ${results.failed.length}\n` +
        `**⏭️ Atlanan:** ${results.skipped.length}\n` +
        `**📊 Toplam:** ${targetUsers.length}`
      );

    if (results.success.length > 0) {
      const successText = results.success
        .slice(0, 10)
        .map(r => `✅ ${r.user.tag} (${r.caseId})`)
        .join('\n');
      
      resultEmbed.addFields({
        name: `✅ Başarılı İşlemler (${Math.min(results.success.length, 10)}/${results.success.length})`,
        value: successText,
        inline: false
      });
    }

    if (results.failed.length > 0) {
      const failedText = results.failed
        .slice(0, 5)
        .map(r => `❌ ${r.user.tag}: ${r.reason}`)
        .join('\n');
      
      resultEmbed.addFields({
        name: `❌ Başarısız İşlemler (${Math.min(results.failed.length, 5)}/${results.failed.length})`,
        value: failedText,
        inline: false
      });
    }

    resultEmbed.setFooter({ 
      text: `${guild.name} • Toplu Moderasyon Raporu`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({
      content: `🏁 **Toplu moderasyon tamamlandı!**`,
      embeds: [resultEmbed]
    });

    // Log raporu
    const logEmbed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('📊 Toplu Moderasyon Raporu')
      .addFields(
        { name: '👮 Moderatör', value: moderator.tag, inline: true },
        { name: '⚖️ İşlem', value: action, inline: true },
        { name: '📊 Sonuç', value: `${results.success.length}/${targetUsers.length}`, inline: true },
        { name: '📝 Sebep', value: reason, inline: false }
      )
      .setTimestamp();

    await ModerationManager.sendToLogChannel(guild, logEmbed);
  },

  async executeWarn(guild, user, moderator, reason) {
    try {
      const caseId = await ModerationManager.generateCaseId(guild.id);
      
      const warnRecord = new (require('../Schemas/ModerationSchema').Moderation)({
        caseId,
        guildId: guild.id,
        type: 'warn',
        userId: user.id,
        username: user.username,
        userTag: user.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        active: true
      });

      await warnRecord.save();
      
      return { success: true, caseId };
    } catch (error) {
      throw error;
    }
  }
};





