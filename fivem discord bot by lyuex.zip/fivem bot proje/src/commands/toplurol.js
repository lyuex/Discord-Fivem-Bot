// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { ActionRowBuilder, UserSelectMenuBuilder, SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionFlagsBits } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('toplurol')
        .setDescription('🎭 Gelişmiş toplu rol yönetim sistemi')
        .addSubcommand(subcommand =>
            subcommand
                .setName('ver')
                .setDescription('📋 Seçili kullanıcılara rol ver')
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Verilecek rol')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('al')
                .setDescription('🗑️ Seçili kullanıcılardan rol al')
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Alınacak rol')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('herkese-ver')
                .setDescription('🌐 Sunucudaki herkese rol ver')
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Herkese verilecek rol')
                        .setRequired(true)
                )
                .addBooleanOption(option =>
                    option.setName('botlar')
                        .setDescription('Botlara da rol verilsin mi?')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('herkesten-al')
                .setDescription('🗑️ Sunucudaki herkesten rol al')
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Herkesten alınacak rol')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('rol-sahipleri')
                .setDescription('👥 Belirli role sahip kullanıcıları listele')
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Listelenecek rol')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('rol-değiştir')
                .setDescription('🔄 Bir roldeki tüm kullanıcıların rolünü değiştir')
                .addRoleOption(option =>
                    option.setName('eski-rol')
                        .setDescription('Değiştirilecek eski rol')
                        .setRequired(true)
                )
                .addRoleOption(option =>
                    option.setName('yeni-rol')
                        .setDescription('Verilecek yeni rol')
                        .setRequired(true)
                )
        ),

    async execute(interaction) {
        // Yetki kontrolü
        const lyuexinyetkilisi = interaction.member.roles.cache;
        const lyuexsinyetkilisi = lyuex.yetkili.rol.some(roleID => lyuexinyetkilisi.has(roleID));
        
        if (!lyuexsinyetkilisi && !interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({ 
                embeds: [
                    new EmbedBuilder()
                        .setTitle('❌ **YETERSİZ YETKİ**')
                        .setDescription('Bu komutu kullanmak için rol yönetimi yetkisine sahip olmalısınız.')
                        .setColor(0xFF6B6B)
                        .setTimestamp()
                ],
                ephemeral: true 
            });
        }

        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'ver':
                await handleRoleGive(interaction);
                break;
            case 'al':
                await handleRoleRemove(interaction);
                break;
            case 'herkese-ver':
                await handleGiveToEveryone(interaction);
                break;
            case 'herkesten-al':
                await handleRemoveFromEveryone(interaction);
                break;
            case 'rol-sahipleri':
                await handleListRoleMembers(interaction);
                break;
            case 'rol-değiştir':
                await handleRoleSwap(interaction);
                break;
        }
    },
};

async function handleRoleGive(interaction) {
    const selectedRole = interaction.options.getRole('rol');
    
    // Rol yetki kontrolü
    if (selectedRole.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **ROL YETKİ HATASI**')
                    .setDescription(`**${selectedRole.name}** rolü sizin en yüksek rolünüzden daha yüksek konumda!`)
                    .setColor(0xFF6B6B)
            ],
            ephemeral: true
        });
    }

    const userSelectMenu = new UserSelectMenuBuilder()
        .setCustomId(`role_give_${selectedRole.id}`)
        .setPlaceholder('👥 Rol verilecek kullanıcıları seçin...')
        .setMinValues(1)
        .setMaxValues(25);

    const row = new ActionRowBuilder().addComponents(userSelectMenu);

    const initialEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Toplu Rol Verme`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('📋 **ROL VERME PANELİ**')
        .setDescription(`
╭─────────────────────────────────╮
│  🎭 **ROL VERİLECEK**            │
│  ${selectedRole} (${selectedRole.id})     │
╰─────────────────────────────────╯

👥 **Kullanıcı seçmek için aşağıdaki menüyü kullanın**`)
        .addFields(
            { name: '🏷️ Rol Bilgileri', value: `
**İsim:** ${selectedRole.name}
**Renk:** ${selectedRole.hexColor}
**Pozisyon:** ${selectedRole.position}
**Mevcut Üye:** ${selectedRole.members.size}
            `, inline: true },
            { name: '⚙️ İşlem Detayları', value: `
**Maksimum Seçim:** 25 kullanıcı
**Zaman Limiti:** 60 saniye
**İşlem Türü:** Rol Verme
            `, inline: true }
        )
        .setColor(selectedRole.hexColor || '#2196F3')
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: 'Toplu Rol Sistemi • Kullanıcı Seçimi', iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    await interaction.reply({
        embeds: [initialEmbed],
        components: [row],
        ephemeral: false
    });

    // Collector
    const filter = i => i.customId === `role_give_${selectedRole.id}` && i.user.id === interaction.user.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
        await i.deferUpdate();
        
        const selectedUsers = i.values;
        const successfulUsers = [];
        const failedUsers = [];

        // Progress embed
        const progressEmbed = new EmbedBuilder()
            .setTitle('⏳ **ROL VERİLİYOR...**')
            .setDescription('Lütfen bekleyin, roller veriliyor...')
            .setColor(0xFFC107)
            .setTimestamp();

        await interaction.editReply({ embeds: [progressEmbed], components: [] });

        // Rol verme işlemi
        for (const userId of selectedUsers) {
            try {
                const member = await interaction.guild.members.fetch(userId);
                
                if (member.roles.cache.has(selectedRole.id)) {
                    failedUsers.push({ user: member.user, reason: 'Zaten bu role sahip' });
                    continue;
                }

                await member.roles.add(selectedRole);
                successfulUsers.push(member.user);
                
                // Kısa bekleme (rate limit için)
                await new Promise(resolve => setTimeout(resolve, 200));
            } catch (error) {
                const user = await interaction.client.users.fetch(userId).catch(() => null);
                failedUsers.push({ user: user || { tag: 'Bilinmeyen Kullanıcı', id: userId }, reason: 'Hata: ' + error.message });
            }
        }

        // Sonuç embedi
        const resultEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Rol Verme Tamamlandı`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('✅ **ROL VERME İŞLEMİ TAMAMLANDI**')
            .setDescription(`**${selectedRole.name}** rolü toplu olarak verildi.`)
            .addFields(
                { 
                    name: '✅ Başarılı İşlemler', 
                    value: successfulUsers.length > 0 ? 
                        successfulUsers.slice(0, 20).map(user => `• ${user.tag}`).join('\n') + 
                        (successfulUsers.length > 20 ? `\n*... ve ${successfulUsers.length - 20} kişi daha*` : '') :
                        'Hiç başarılı işlem yok', 
                    inline: false 
                }
            )
            .setColor(0x4CAF50)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ 
                text: `✅ ${successfulUsers.length} başarılı • ❌ ${failedUsers.length} başarısız`, 
                iconURL: interaction.user.displayAvatarURL() 
            })
            .setTimestamp();

        if (failedUsers.length > 0) {
            resultEmbed.addFields({
                name: '❌ Başarısız İşlemler',
                value: failedUsers.slice(0, 10).map(item => `• ${item.user.tag}: ${item.reason}`).join('\n') +
                    (failedUsers.length > 10 ? `\n*... ve ${failedUsers.length - 10} hata daha*` : ''),
                inline: false
            });
        }

        await interaction.editReply({ embeds: [resultEmbed] });

        // Log gönderme
        await sendRoleLog(interaction, selectedRole, successfulUsers, 'VERİLDİ');

        collector.stop();
    });

    collector.on('end', collected => {
        if (collected.size === 0) {
            const timeoutEmbed = new EmbedBuilder()
                .setTitle('⏰ **ZAMAN AŞIMI**')
                .setDescription('60 saniye içinde kullanıcı seçimi yapılmadı.')
                .setColor(0xFF9800)
                .setTimestamp();

            interaction.editReply({ embeds: [timeoutEmbed], components: [] });
        }
    });
}

async function handleRoleRemove(interaction) {
    const selectedRole = interaction.options.getRole('rol');
    
    // Rol yetki kontrolü
    if (selectedRole.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **ROL YETKİ HATASI**')
                    .setDescription(`**${selectedRole.name}** rolü sizin en yüksek rolünüzden daha yüksek konumda!`)
                    .setColor(0xFF6B6B)
            ],
            ephemeral: true
        });
    }

    const userSelectMenu = new UserSelectMenuBuilder()
        .setCustomId(`role_remove_${selectedRole.id}`)
        .setPlaceholder('👥 Rolü alınacak kullanıcıları seçin...')
        .setMinValues(1)
        .setMaxValues(25);

    const row = new ActionRowBuilder().addComponents(userSelectMenu);

    const initialEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Toplu Rol Alma`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('🗑️ **ROL ALMA PANELİ**')
        .setDescription(`
╭─────────────────────────────────╮
│  🎭 **ROL ALINACAK**             │
│  ${selectedRole} (${selectedRole.id})     │
╰─────────────────────────────────╯

👥 **Kullanıcı seçmek için aşağıdaki menüyü kullanın**`)
        .addFields(
            { name: '🏷️ Rol Bilgileri', value: `
**İsim:** ${selectedRole.name}
**Renk:** ${selectedRole.hexColor}
**Pozisyon:** ${selectedRole.position}
**Mevcut Üye:** ${selectedRole.members.size}
            `, inline: true },
            { name: '⚙️ İşlem Detayları', value: `
**Maksimum Seçim:** 25 kullanıcı
**Zaman Limiti:** 60 saniye
**İşlem Türü:** Rol Alma
            `, inline: true }
        )
        .setColor(0xF44336)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: 'Toplu Rol Sistemi • Kullanıcı Seçimi', iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    await interaction.reply({
        embeds: [initialEmbed],
        components: [row],
        ephemeral: false
    });

    // Collector (rol alma için benzer mantık)
    const filter = i => i.customId === `role_remove_${selectedRole.id}` && i.user.id === interaction.user.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
        await i.deferUpdate();
        
        const selectedUsers = i.values;
        const successfulUsers = [];
        const failedUsers = [];

        const progressEmbed = new EmbedBuilder()
            .setTitle('⏳ **ROL ALINIYOR...**')
            .setDescription('Lütfen bekleyin, roller alınıyor...')
            .setColor(0xFFC107)
            .setTimestamp();

        await interaction.editReply({ embeds: [progressEmbed], components: [] });

        for (const userId of selectedUsers) {
            try {
                const member = await interaction.guild.members.fetch(userId);
                
                if (!member.roles.cache.has(selectedRole.id)) {
                    failedUsers.push({ user: member.user, reason: 'Bu role sahip değil' });
                    continue;
                }

                await member.roles.remove(selectedRole);
                successfulUsers.push(member.user);
                
                await new Promise(resolve => setTimeout(resolve, 200));
            } catch (error) {
                const user = await interaction.client.users.fetch(userId).catch(() => null);
                failedUsers.push({ user: user || { tag: 'Bilinmeyen Kullanıcı', id: userId }, reason: 'Hata: ' + error.message });
            }
        }

        const resultEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Rol Alma Tamamlandı`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('✅ **ROL ALMA İŞLEMİ TAMAMLANDI**')
            .setDescription(`**${selectedRole.name}** rolü toplu olarak alındı.`)
            .addFields(
                { 
                    name: '✅ Başarılı İşlemler', 
                    value: successfulUsers.length > 0 ? 
                        successfulUsers.slice(0, 20).map(user => `• ${user.tag}`).join('\n') + 
                        (successfulUsers.length > 20 ? `\n*... ve ${successfulUsers.length - 20} kişi daha*` : '') :
                        'Hiç başarılı işlem yok', 
                    inline: false 
                }
            )
            .setColor(0xF44336)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ 
                text: `✅ ${successfulUsers.length} başarılı • ❌ ${failedUsers.length} başarısız`, 
                iconURL: interaction.user.displayAvatarURL() 
            })
            .setTimestamp();

        if (failedUsers.length > 0) {
            resultEmbed.addFields({
                name: '❌ Başarısız İşlemler',
                value: failedUsers.slice(0, 10).map(item => `• ${item.user.tag}: ${item.reason}`).join('\n') +
                    (failedUsers.length > 10 ? `\n*... ve ${failedUsers.length - 10} hata daha*` : ''),
                inline: false
            });
        }

        await interaction.editReply({ embeds: [resultEmbed] });
        await sendRoleLog(interaction, selectedRole, successfulUsers, 'ALINDI');

        collector.stop();
    });

    collector.on('end', collected => {
        if (collected.size === 0) {
            const timeoutEmbed = new EmbedBuilder()
                .setTitle('⏰ **ZAMAN AŞIMI**')
                .setDescription('60 saniye içinde kullanıcı seçimi yapılmadı.')
                .setColor(0xFF9800)
                .setTimestamp();

            interaction.editReply({ embeds: [timeoutEmbed], components: [] });
        }
    });
}

async function handleGiveToEveryone(interaction) {
    const selectedRole = interaction.options.getRole('rol');
    const includeBots = interaction.options.getBoolean('botlar') || false;

    // Onay sistemi
    const confirmEmbed = new EmbedBuilder()
        .setTitle('⚠️ **TOPLU ROL ONAY**')
        .setDescription(`**DİKKAT:** Bu işlem sunucudaki ${includeBots ? 'tüm üyelere (botlar dahil)' : 'tüm gerçek kullanıcılara'} **${selectedRole.name}** rolünü verecek!`)
        .addFields(
            { name: '🎭 Rol', value: `${selectedRole} (${selectedRole.id})`, inline: true },
            { name: '👥 Etkilenecek Üye', value: `~${interaction.guild.memberCount} üye`, inline: true },
            { name: '🤖 Botlar', value: includeBots ? '✅ Dahil' : '❌ Hariç', inline: true }
        )
        .setColor(0xFF9800)
        .setTimestamp();

    const confirmButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`confirm_give_all_${selectedRole.id}_${includeBots}`)
            .setLabel('✅ Onayla')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId('cancel_give_all')
            .setLabel('❌ İptal Et')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons],
        ephemeral: true
    });
}

async function handleRemoveFromEveryone(interaction) {
    const selectedRole = interaction.options.getRole('rol');

    const confirmEmbed = new EmbedBuilder()
        .setTitle('⚠️ **TOPLU ROL ALMA ONAY**')
        .setDescription(`**DİKKAT:** Bu işlem **${selectedRole.name}** rolüne sahip tüm üyelerden bu rolü alacak!`)
        .addFields(
            { name: '🎭 Rol', value: `${selectedRole} (${selectedRole.id})`, inline: true },
            { name: '👥 Etkilenecek Üye', value: `${selectedRole.members.size} üye`, inline: true }
        )
        .setColor(0xFF9800)
        .setTimestamp();

    const confirmButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`confirm_remove_all_${selectedRole.id}`)
            .setLabel('✅ Onayla')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId('cancel_remove_all')
            .setLabel('❌ İptal Et')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons],
        ephemeral: true
    });
}

async function handleListRoleMembers(interaction) {
    const selectedRole = interaction.options.getRole('rol');
    const members = selectedRole.members;

    if (members.size === 0) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('📋 **ROL ÜYE LİSTESİ**')
                    .setDescription(`**${selectedRole.name}** rolüne sahip hiç üye bulunmuyor.`)
                    .setColor(0x607D8B)
            ],
            ephemeral: true
        });
    }

    const memberList = members.map(member => `• ${member.user.tag} (${member.id})`);
    const pages = [];
    
    for (let i = 0; i < memberList.length; i += 20) {
        pages.push(memberList.slice(i, i + 20));
    }

    const listEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Rol Üye Listesi`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle(`👥 **${selectedRole.name.toUpperCase()} ROLÜ ÜYELERİ**`)
        .setDescription(pages[0].join('\n'))
        .addFields(
            { name: '📊 İstatistikler', value: `**Toplam Üye:** ${members.size}\n**Sayfa:** 1/${pages.length}`, inline: true },
            { name: '🎭 Rol Bilgileri', value: `**Renk:** ${selectedRole.hexColor}\n**Pozisyon:** ${selectedRole.position}`, inline: true }
        )
        .setColor(selectedRole.hexColor || '#2196F3')
        .setFooter({ text: `Sayfa 1/${pages.length} • Toplam ${members.size} üye`, iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    const components = [];
    if (pages.length > 1) {
        components.push(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`role_members_prev_0`)
                    .setLabel('◀️ Önceki')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId(`role_members_next_0`)
                    .setLabel('Sonraki ▶️')
                    .setStyle(ButtonStyle.Secondary)
            )
        );
    }

    await interaction.reply({
        embeds: [listEmbed],
        components: components,
        ephemeral: true
    });
}

async function handleRoleSwap(interaction) {
    const oldRole = interaction.options.getRole('eski-rol');
    const newRole = interaction.options.getRole('yeni-rol');

    if (oldRole.id === newRole.id) {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **AYNI ROL HATASI**')
                    .setDescription('Eski rol ve yeni rol aynı olamaz!')
                    .setColor(0xFF6B6B)
            ],
            ephemeral: true
        });
    }

    const confirmEmbed = new EmbedBuilder()
        .setTitle('🔄 **ROL DEĞİŞTİRME ONAY**')
        .setDescription(`**${oldRole.name}** rolüne sahip tüm üyelerin rolü **${newRole.name}** ile değiştirilecek.`)
        .addFields(
            { name: '🗑️ Alınacak Rol', value: `${oldRole} (${oldRole.members.size} üye)`, inline: true },
            { name: '✅ Verilecek Rol', value: `${newRole} (${newRole.members.size} üye)`, inline: true }
        )
        .setColor(0xFF9800)
        .setTimestamp();

    const confirmButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`confirm_swap_${oldRole.id}_${newRole.id}`)
            .setLabel('✅ Onayla')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId('cancel_swap')
            .setLabel('❌ İptal Et')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons],
        ephemeral: true
    });
}

async function sendRoleLog(interaction, role, users, action) {
    const logChannel = interaction.guild.channels.cache.find(channel => channel.name === 'role-log' || channel.name === 'rol-log');
    
    if (!logChannel) return;

    const logEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Rol ${action}`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle(`🎭 **TOPLU ROL ${action}**`)
        .setDescription(`**${role.name}** rolü toplu olarak ${action.toLowerCase()}.`)
        .addFields(
            { name: '👤 Yetkili', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
            { name: '🎭 Rol', value: `${role.name} (${role.id})`, inline: true },
            { name: '📊 İşlem Sayısı', value: `${users.length} kullanıcı`, inline: true },
            { 
                name: '👥 Etkilenen Kullanıcılar', 
                value: users.length > 10 ? 
                    users.slice(0, 10).map(user => `• ${user.tag}`).join('\n') + `\n*... ve ${users.length - 10} kişi daha*` :
                    users.map(user => `• ${user.tag}`).join('\n') || 'Hiç kullanıcı etkilenmedi',
                inline: false 
            }
        )
        .setColor(role.hexColor || '#2196F3')
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: 'Toplu Rol Sistemi • İşlem Logu', iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    await logChannel.send({ embeds: [logEmbed] });
}




