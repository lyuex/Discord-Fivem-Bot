// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rol-al')
        .setDescription('🗑️ Kullanıcıdan rol al (Yetkili/Bot sahipleri)')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false)
        .addUserOption(option =>
            option
                .setName('kullanıcı')
                .setDescription('Rolü alınacak kullanıcı')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option
                .setName('rol')
                .setDescription('Alınacak rol')
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName('sebep')
                .setDescription('Rol alma sebebi')
                .setRequired(false)
        ),

    async execute(interaction) {
        // Sadece belirtilen role sahip kullanıcılar kullanabilir
        const allowedRoleId = '1424063580340490351';

        if (!interaction.member.roles.cache.has(allowedRoleId)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('❌ Yetkisiz Erişim')
                        .setDescription('Bu komut sadece belirtilen yetkili role sahip kullanıcılar tarafından kullanılabilir!')
                        .addFields(
                            { name: '🔒 Gerekli Rol', value: `<@&${allowedRoleId}>`, inline: false },
                            { name: '👤 Sen', value: `${interaction.user} (${interaction.user.tag})`, inline: true }
                        )
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }

        const targetUser = interaction.options.getUser('kullanıcı');
        const targetRole = interaction.options.getRole('rol');
        const sebep = interaction.options.getString('sebep') || 'Sebep belirtilmedi';

        try {
            const targetMember = await interaction.guild.members.fetch(targetUser.id);
            
            if (!targetMember) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFF4444)
                        .setTitle('❌ Kullanıcı Bulunamadı')
                        .setDescription(`**${targetUser.tag}** bu sunucuda bulunamadı!`)
                        .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            // Kullanıcının bu role sahip olup olmadığını kontrol et
            if (!targetMember.roles.cache.has(targetRole.id)) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFFA500)
                        .setTitle('⚠️ Rol Zaten Yok')
                        .setDescription(`**${targetUser.tag}** zaten **${targetRole.name}** rolüne sahip değil!`)
                        .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            await interaction.deferReply();

            // Rolü al
            await targetMember.roles.remove(targetRole, `Rol alma komutu | Yetkili: ${interaction.user.tag} | Sebep: ${sebep}`);

            // Başarı mesajı
            const successEmbed = new EmbedBuilder()
                .setColor(0xFF6B35)
                .setTitle('🗑️ Rol Başarıyla Alındı!')
                .setDescription(`**${targetUser.tag}** kullanıcısından **${targetRole.name}** rolü alındı!`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '🎭 Alınan Rol', value: `${targetRole} (${targetRole.name})`, inline: true },
                    { name: '👮 Yetkili', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '📝 Sebep', value: sebep, inline: false },
                    { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '📊 Kalan Rol Sayısı', value: `${targetMember.roles.cache.size} rol`, inline: true }
                )
                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ 
                    text: `Yetkili: ${interaction.user.tag} • ZYM CİTY`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // Log kanalına gönder
            const logChannelId = lyuex.botSettings?.LOG_CHANNEL_ID;
            if (logChannelId) {
                const logChannel = interaction.guild.channels.cache.get(logChannelId);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(0xFF6B35)
                        .setTitle('📋 Rol Alma İşlemi')
                        .addFields(
                            { name: '👤 Hedef', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                            { name: '🎭 Rol', value: `${targetRole.name} (${targetRole.id})`, inline: true },
                            { name: '👮 Yetkili', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
                            { name: '📝 Sebep', value: sebep, inline: false }
                        )
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

        } catch (error) {
            console.error('Rol alma hatası:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Rol Alma Hatası')
                .setDescription('Rol alınırken bir hata oluştu!')
                .addFields(
                    { name: '💥 Hata', value: error.message || 'Bilinmeyen hata', inline: false }
                )
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },
};




