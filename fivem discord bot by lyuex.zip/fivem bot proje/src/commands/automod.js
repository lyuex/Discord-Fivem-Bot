// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const { Moderation, Mute, TempBan } = require('../Schemas/ModerationSchema');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('🤖 Otomatik moderasyon sistemi ayarları')
    .addSubcommand(subcommand =>
      subcommand
        .setName('ayarla')
        .setDescription('🔧 Automod kurallarını ayarla')
        .addStringOption(option =>
          option.setName('kural')
            .setDescription('📜 Automod kuralı türü')
            .setRequired(true)
            .addChoices(
              { name: '🔗 Link Engelleme', value: 'anti_link' },
              { name: '🚫 Küfür Engelleme', value: 'anti_swear' },
              { name: '📢 Spam Engelleme', value: 'anti_spam' },
              { name: '🔴 CAPS Engelleme', value: 'anti_caps' },
              { name: '😀 Emoji Spam', value: 'anti_emoji' },
              { name: '🔁 Tekrar Engelleme', value: 'anti_repeat' },
              { name: '🎯 Mention Spam', value: 'anti_mention' },
              { name: '🤖 Bot Koruması', value: 'anti_bot' }
            ))
        .addBooleanOption(option =>
          option.setName('aktif')
            .setDescription('✅ Kuralı aktif/pasif yap')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('eylem')
            .setDescription('⚖️ İhlal durumunda yapılacak eylem')
            .setRequired(false)
            .addChoices(
              { name: '🗑️ Mesaj Sil', value: 1 },
              { name: '⚠️ Uyarı Ver', value: 2 },
              { name: '🔇 10 Dk Mute', value: 3 },
              { name: '🔇 1 Saat Mute', value: 4 },
              { name: '👢 Kick', value: 5 },
              { name: '🔨 1 Gün Ban', value: 6 }
            ))
        .addIntegerOption(option =>
          option.setName('limit')
            .setDescription('🔢 İhlal limiti (kaç kez sonra eylem)')
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(10)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('durum')
        .setDescription('📊 Automod durumunu görüntüle'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('beyaz-liste')
        .setDescription('📝 Automod beyaz listesi yönetimi')
        .addStringOption(option =>
          option.setName('tür')
            .setDescription('🏷️ Beyaz liste türü')
            .setRequired(true)
            .addChoices(
              { name: '👤 Kullanıcı', value: 'user' },
              { name: '🎭 Rol', value: 'role' },
              { name: '📁 Kanal', value: 'channel' }
            ))
        .addStringOption(option =>
          option.setName('işlem')
            .setDescription('⚙️ Yapılacak işlem')
            .setRequired(true)
            .addChoices(
              { name: '➕ Ekle', value: 'add' },
              { name: '➖ Çıkar', value: 'remove' },
              { name: '📄 Listele', value: 'list' }
            ))
        .addUserOption(option =>
          option.setName('kullanıcı')
            .setDescription('👤 Hedef kullanıcı')
            .setRequired(false))
        .addRoleOption(option =>
          option.setName('rol')
            .setDescription('🎭 Hedef rol')
            .setRequired(false))
        .addChannelOption(option =>
          option.setName('kanal')
            .setDescription('📁 Hedef kanal')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('istatistik')
        .setDescription('📈 Automod istatistikleri')
        .addStringOption(option =>
          option.setName('süre')
            .setDescription('📅 İstatistik süresi')
            .setRequired(false)
            .addChoices(
              { name: '📅 Bugün', value: 'today' },
              { name: '📅 Bu Hafta', value: 'week' },
              { name: '📅 Bu Ay', value: 'month' },
              { name: '📅 Tüm Zamanlar', value: 'all' }
            )))
    .addSubcommand(subcommand =>
      subcommand
        .setName('sıfırla')
        .setDescription('🔄 Automod ayarlarını sıfırla'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();
      
      const subcommand = interaction.options.getSubcommand();
      const guild = interaction.guild;

      switch (subcommand) {
        case 'ayarla':
          await this.handleSetup(interaction);
          break;
        case 'durum':
          await this.handleStatus(interaction);
          break;
        case 'beyaz-liste':
          await this.handleWhitelist(interaction);
          break;
        case 'istatistik':
          await this.handleStats(interaction);
          break;
        case 'sıfırla':
          await this.handleReset(interaction);
          break;
      }
    } catch (error) {
      console.error('Automod hatası:', error);
      
      const errorMessage = `❌ **Automod Hatası!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  },

  async handleSetup(interaction) {
    const rule = interaction.options.getString('kural');
    const isActive = interaction.options.getBoolean('aktif');
    const action = interaction.options.getInteger('eylem') || 1;
    const limit = interaction.options.getInteger('limit') || 3;
    const guild = interaction.guild;

    const ruleNames = {
      'anti_link': '🔗 Link Engelleme',
      'anti_swear': '🚫 Küfür Engelleme',
      'anti_spam': '📢 Spam Engelleme',
      'anti_caps': '🔴 CAPS Engelleme',
      'anti_emoji': '😀 Emoji Spam',
      'anti_repeat': '🔁 Tekrar Engelleme',
      'anti_mention': '🎯 Mention Spam',
      'anti_bot': '🤖 Bot Koruması'
    };

    const actionNames = {
      1: '🗑️ Mesaj Sil',
      2: '⚠️ Uyarı Ver',
      3: '🔇 10 Dk Mute',
      4: '🔇 1 Saat Mute',
      5: '👢 Kick',
      6: '🔨 1 Gün Ban'
    };

    // Automod ayarlarını veritabanına kaydet
    const automodConfig = await this.getAutomodConfig(guild.id);
    
    automodConfig.rules[rule] = {
      enabled: isActive,
      action: action,
      limit: limit,
      violations: automodConfig.rules[rule]?.violations || 0
    };

    await this.saveAutomodConfig(guild.id, automodConfig);

    const embed = new EmbedBuilder()
      .setColor(isActive ? '#00FF00' : '#FF0000')
      .setTitle('🤖 Automod Kuralı Güncellendi')
      .addFields(
        { name: '📜 Kural', value: ruleNames[rule], inline: true },
        { name: '✅ Durum', value: isActive ? 'Aktif' : 'Pasif', inline: true },
        { name: '⚖️ Eylem', value: actionNames[action], inline: true },
        { name: '🔢 Limit', value: limit.toString(), inline: true },
        { name: '📊 İhlal Sayısı', value: automodConfig.rules[rule]?.violations?.toString() || '0', inline: true }
      )
      .setFooter({ 
        text: `${guild.name} • Automod Sistemi`,
        iconURL: guild.iconURL({ dynamic: true })
      })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    // Log kaydı
    const logEmbed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('🤖 Automod Kural Güncelleme')
      .addFields(
        { name: '👮 Moderatör', value: interaction.user.tag, inline: true },
        { name: '📜 Kural', value: ruleNames[rule], inline: true },
        { name: '🔄 Değişiklik', value: `${isActive ? 'Aktif' : 'Pasif'} (${actionNames[action]})`, inline: false }
      )
      .setTimestamp();

    await ModerationManager.sendToLogChannel(guild, logEmbed);
  },

  async handleStatus(interaction) {
    const guild = interaction.guild;
    const automodConfig = await this.getAutomodConfig(guild.id);

    const ruleNames = {
      'anti_link': '🔗 Link Engelleme',
      'anti_swear': '🚫 Küfür Engelleme',
      'anti_spam': '📢 Spam Engelleme',
      'anti_caps': '🔴 CAPS Engelleme',
      'anti_emoji': '😀 Emoji Spam',
      'anti_repeat': '🔁 Tekrar Engelleme',
      'anti_mention': '🎯 Mention Spam',
      'anti_bot': '🤖 Bot Koruması'
    };

    const actionNames = {
      1: '🗑️ Sil',
      2: '⚠️ Uyar',
      3: '🔇 10dk Mute',
      4: '🔇 1sa Mute',
      5: '👢 Kick',
      6: '🔨 1g Ban'
    };

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('🤖 Automod Sistem Durumu')
      .setDescription(`**📊 Genel Durum:** ${automodConfig.enabled ? '✅ Aktif' : '❌ Pasif'}`);

    let activeRules = 0;
    let totalViolations = 0;

    Object.entries(automodConfig.rules).forEach(([rule, config]) => {
      const status = config.enabled ? '✅' : '❌';
      const action = actionNames[config.action] || '❓';
      const violations = config.violations || 0;
      
      if (config.enabled) activeRules++;
      totalViolations += violations;

      embed.addFields({
        name: `${status} ${ruleNames[rule]}`,
        value: `**Eylem:** ${action}\n**Limit:** ${config.limit}\n**İhlal:** ${violations}`,
        inline: true
      });
    });

    embed.addFields(
      { name: '📊 İstatistikler', value: `**Aktif Kurallar:** ${activeRules}/8\n**Toplam İhlal:** ${totalViolations}`, inline: false },
      { name: '📝 Beyaz Liste', value: `**Kullanıcılar:** ${automodConfig.whitelist.users.length}\n**Roller:** ${automodConfig.whitelist.roles.length}\n**Kanallar:** ${automodConfig.whitelist.channels.length}`, inline: true }
    );

    embed.setFooter({ 
      text: `${guild.name} • Automod Durumu`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    // Hızlı eylem butonları
    const enableButton = new ButtonBuilder()
      .setCustomId('automod_toggle_global')
      .setLabel(automodConfig.enabled ? '❌ Automod\'u Kapat' : '✅ Automod\'u Aç')
      .setStyle(automodConfig.enabled ? ButtonStyle.Danger : ButtonStyle.Success);

    const resetButton = new ButtonBuilder()
      .setCustomId('automod_reset_stats')
      .setLabel('📊 İstatistikleri Sıfırla')
      .setStyle(ButtonStyle.Secondary);

    const configButton = new ButtonBuilder()
      .setCustomId('automod_quick_config')
      .setLabel('⚙️ Hızlı Yapılandırma')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder()
      .addComponents(enableButton, resetButton, configButton);

    await interaction.editReply({ embeds: [embed], components: [row] });
  },

  async handleWhitelist(interaction) {
    const type = interaction.options.getString('tür');
    const operation = interaction.options.getString('işlem');
    const user = interaction.options.getUser('kullanıcı');
    const role = interaction.options.getRole('rol');
    const channel = interaction.options.getChannel('kanal');
    const guild = interaction.guild;

    const automodConfig = await this.getAutomodConfig(guild.id);
    let target, targetId, targetName;

    // Hedef belirleme
    switch (type) {
      case 'user':
        if (!user && operation !== 'list') {
          return await interaction.editReply({ content: '❌ Kullanıcı belirtmelisiniz!' });
        }
        target = user;
        targetId = user?.id;
        targetName = user?.tag;
        break;
      case 'role':
        if (!role && operation !== 'list') {
          return await interaction.editReply({ content: '❌ Rol belirtmelisiniz!' });
        }
        target = role;
        targetId = role?.id;
        targetName = role?.name;
        break;
      case 'channel':
        if (!channel && operation !== 'list') {
          return await interaction.editReply({ content: '❌ Kanal belirtmelisiniz!' });
        }
        target = channel;
        targetId = channel?.id;
        targetName = channel?.name;
        break;
    }

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('📝 Automod Beyaz Liste Yönetimi');

    switch (operation) {
      case 'add':
        if (automodConfig.whitelist[type + 's'].includes(targetId)) {
          embed.setColor(0xFFA500)
            .setDescription(`⚠️ **${targetName}** zaten beyaz listede!`);
        } else {
          automodConfig.whitelist[type + 's'].push(targetId);
          await this.saveAutomodConfig(guild.id, automodConfig);
          
          embed.setColor(0x00FF00)
            .setDescription(`✅ **${targetName}** beyaz listeye eklendi!`)
            .addFields({ 
              name: `📊 ${type === 'user' ? 'Kullanıcı' : type === 'role' ? 'Rol' : 'Kanal'} Sayısı`, 
              value: automodConfig.whitelist[type + 's'].length.toString(), 
              inline: true 
            });
        }
        break;

      case 'remove':
        const index = automodConfig.whitelist[type + 's'].indexOf(targetId);
        if (index === -1) {
          embed.setColor(0xFFA500)
            .setDescription(`⚠️ **${targetName}** beyaz listede değil!`);
        } else {
          automodConfig.whitelist[type + 's'].splice(index, 1);
          await this.saveAutomodConfig(guild.id, automodConfig);
          
          embed.setColor(0xFF0000)
            .setDescription(`❌ **${targetName}** beyaz listeden çıkarıldı!`)
            .addFields({ 
              name: `📊 ${type === 'user' ? 'Kullanıcı' : type === 'role' ? 'Rol' : 'Kanal'} Sayısı`, 
              value: automodConfig.whitelist[type + 's'].length.toString(), 
              inline: true 
            });
        }
        break;

      case 'list':
        const items = automodConfig.whitelist[type + 's'];
        if (items.length === 0) {
          embed.setDescription(`📄 **${type === 'user' ? 'Kullanıcı' : type === 'role' ? 'Rol' : 'Kanal'} beyaz listesi boş!**`);
        } else {
          let listText = '';
          for (let i = 0; i < Math.min(items.length, 10); i++) {
            const id = items[i];
            let name = id;
            
            try {
              switch (type) {
                case 'user':
                  const user = await guild.client.users.fetch(id);
                  name = user.tag;
                  break;
                case 'role':
                  const role = guild.roles.cache.get(id);
                  name = role ? role.name : 'Bilinmeyen Rol';
                  break;
                case 'channel':
                  const channel = guild.channels.cache.get(id);
                  name = channel ? channel.name : 'Bilinmeyen Kanal';
                  break;
              }
            } catch {}
            
            listText += `${i + 1}. ${name} (${id})\n`;
          }
          
          if (items.length > 10) {
            listText += `\n... ve ${items.length - 10} ${type === 'user' ? 'kullanıcı' : type === 'role' ? 'rol' : 'kanal'} daha`;
          }

          embed.setDescription(`📄 **${type === 'user' ? 'Kullanıcı' : type === 'role' ? 'Rol' : 'Kanal'} Beyaz Listesi (${items.length} adet):**`)
            .addFields({
              name: '📝 Liste',
              value: `\`\`\`\n${listText}\n\`\`\``,
              inline: false
            });
        }
        break;
    }

    embed.setFooter({ 
      text: `${guild.name} • Automod Beyaz Liste`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  async handleStats(interaction) {
    const period = interaction.options.getString('süre') || 'week';
    const guild = interaction.guild;

    // Tarih aralığı hesapla
    const now = new Date();
    let startDate;

    switch (period) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'all':
        startDate = new Date(0);
        break;
    }

    // Automod istatistiklerini al
    const automodStats = await this.getAutomodStats(guild.id, startDate);
    const automodConfig = await this.getAutomodConfig(guild.id);

    const periodNames = {
      'today': '📅 Bugün',
      'week': '📅 Bu Hafta',
      'month': '📅 Bu Ay',
      'all': '📅 Tüm Zamanlar'
    };

    const embed = new EmbedBuilder()
      .setColor(0x4169E1)
      .setTitle('📈 Automod İstatistikleri')
      .setDescription(`**📊 Dönem:** ${periodNames[period]}\n**🕐 Tarih:** ${startDate.toLocaleDateString('tr-TR')} - ${now.toLocaleDateString('tr-TR')}`);

    // Kural bazlı istatistikler
    const ruleNames = {
      'anti_link': '🔗 Link Engelleme',
      'anti_swear': '🚫 Küfür Engelleme',
      'anti_spam': '📢 Spam Engelleme',
      'anti_caps': '🔴 CAPS Engelleme',
      'anti_emoji': '😀 Emoji Spam',
      'anti_repeat': '🔁 Tekrar Engelleme',
      'anti_mention': '🎯 Mention Spam',
      'anti_bot': '🤖 Bot Koruması'
    };

    let totalViolations = 0;
    Object.entries(automodStats.violations).forEach(([rule, count]) => {
      if (count > 0) {
        totalViolations += count;
        embed.addFields({
          name: ruleNames[rule] || rule,
          value: `**İhlal:** ${count}\n**Durum:** ${automodConfig.rules[rule]?.enabled ? '✅' : '❌'}`,
          inline: true
        });
      }
    });

    if (totalViolations === 0) {
      embed.addFields({
        name: '🎉 Temiz Dönem!',
        value: 'Bu dönemde hiç automod ihlali tespit edilmedi.',
        inline: false
      });
    }

    // Genel istatistikler
    embed.addFields(
      { name: '📊 Toplam İhlal', value: totalViolations.toString(), inline: true },
      { name: '🗑️ Silinen Mesaj', value: automodStats.actions.deleted.toString(), inline: true },
      { name: '⚠️ Verilen Uyarı', value: automodStats.actions.warned.toString(), inline: true },
      { name: '🔇 Mute Edilen', value: automodStats.actions.muted.toString(), inline: true },
      { name: '👢 Kick Edilen', value: automodStats.actions.kicked.toString(), inline: true },
      { name: '🔨 Ban Edilen', value: automodStats.actions.banned.toString(), inline: true }
    );

    embed.setFooter({ 
      text: `${guild.name} • Automod İstatistikleri`,
      iconURL: guild.iconURL({ dynamic: true })
    }).setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },

  async handleReset(interaction) {
    const guild = interaction.guild;

    const confirmEmbed = new EmbedBuilder()
      .setColor(0xFF4444)
      .setTitle('🔄 Automod Sıfırlama Onayı')
      .setDescription(
        '⚠️ **UYARI: Bu işlem geri alınamaz!**\n\n' +
        'Aşağıdaki veriler silinecek:\n' +
        '• Tüm automod kuralları\n' +
        '• Beyaz liste kayıtları\n' +
        '• İstatistik verileri\n' +
        '• Özel ayarlar\n\n' +
        '**Emin misiniz?**'
      );

    const confirmButton = new ButtonBuilder()
      .setCustomId('automod_reset_confirm')
      .setLabel('✅ EVET, SİFIRLA')
      .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
      .setCustomId('automod_reset_cancel')
      .setLabel('❌ İptal Et')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder()
      .addComponents(confirmButton, cancelButton);

    const response = await interaction.editReply({
      embeds: [confirmEmbed],
      components: [row]
    });

    const collector = response.createMessageComponentCollector({ time: 30000 });

    collector.on('collect', async (buttonInteraction) => {
      if (buttonInteraction.user.id !== interaction.user.id) {
        return await buttonInteraction.reply({
          content: '❌ Bu onayı sadece komutu kullanan kişi verebilir!',
          ephemeral: true
        });
      }

      await buttonInteraction.deferUpdate();

      if (buttonInteraction.customId === 'automod_reset_cancel') {
        const cancelEmbed = new EmbedBuilder()
          .setColor(0x808080)
          .setTitle('❌ Sıfırlama İptal Edildi')
          .setDescription('Automod ayarları değiştirilmedi.')
          .setTimestamp();

        await interaction.editReply({
          embeds: [cancelEmbed],
          components: []
        });
        return;
      }

      if (buttonInteraction.customId === 'automod_reset_confirm') {
        // Sıfırlama işlemi
        await this.resetAutomodConfig(guild.id);

        const resetEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Automod Sıfırlandı')
          .setDescription(
            '🔄 **Automod sistemi başarıyla sıfırlandı!**\n\n' +
            '• Tüm kurallar pasif hale getirildi\n' +
            '• Beyaz listeler temizlendi\n' +
            '• İstatistikler sıfırlandı\n\n' +
            '📝 Yeni ayarları yapmak için `/automod ayarla` komutunu kullanın.'
          )
          .setTimestamp();

        await interaction.editReply({
          embeds: [resetEmbed],
          components: []
        });

        // Log kaydı
        const logEmbed = new EmbedBuilder()
          .setColor(0xFF4444)
          .setTitle('🔄 Automod Sistemi Sıfırlandı')
          .addFields({ name: '👮 Moderatör', value: interaction.user.tag, inline: true })
          .setTimestamp();

        await ModerationManager.sendToLogChannel(guild, logEmbed);
      }
    });

    collector.on('end', async (collected) => {
      if (collected.size === 0) {
        const timeoutEmbed = new EmbedBuilder()
          .setColor(0x808080)
          .setTitle('⏰ Zaman Aşımı')
          .setDescription('30 saniye içinde yanıt verilmediği için işlem iptal edildi.')
          .setTimestamp();

        await interaction.editReply({
          embeds: [timeoutEmbed],
          components: []
        });
      }
    });
  },

  // Yardımcı fonksiyonlar
  async getAutomodConfig(guildId) {
    // Veritabanından automod config'i al, yoksa varsayılan oluştur
    const defaultConfig = {
      enabled: true,
      rules: {
        anti_link: { enabled: false, action: 1, limit: 3, violations: 0 },
        anti_swear: { enabled: false, action: 2, limit: 3, violations: 0 },
        anti_spam: { enabled: false, action: 3, limit: 5, violations: 0 },
        anti_caps: { enabled: false, action: 1, limit: 3, violations: 0 },
        anti_emoji: { enabled: false, action: 1, limit: 5, violations: 0 },
        anti_repeat: { enabled: false, action: 1, limit: 3, violations: 0 },
        anti_mention: { enabled: false, action: 3, limit: 5, violations: 0 },
        anti_bot: { enabled: true, action: 6, limit: 1, violations: 0 }
      },
      whitelist: {
        users: [],
        roles: [],
        channels: []
      }
    };

    // Gerçek projede burayı veritabanı bağlantısı ile değiştirin
    return defaultConfig;
  },

  async saveAutomodConfig(guildId, config) {
    // Veritabanına kaydet
    // Gerçek projede burayı veritabanı kaydetme işlemi ile değiştirin
    console.log(`Automod config saved for guild ${guildId}:`, config);
  },

  async getAutomodStats(guildId, startDate) {
    // Automod istatistiklerini veritabanından al
    const defaultStats = {
      violations: {
        anti_link: 0,
        anti_swear: 0,
        anti_spam: 0,
        anti_caps: 0,
        anti_emoji: 0,
        anti_repeat: 0,
        anti_mention: 0,
        anti_bot: 0
      },
      actions: {
        deleted: 0,
        warned: 0,
        muted: 0,
        kicked: 0,
        banned: 0
      }
    };

    // Gerçek projede burayı veritabanı sorgusu ile değiştirin
    return defaultStats;
  },

  async resetAutomodConfig(guildId) {
    // Automod ayarlarını sıfırla
    const resetConfig = await this.getAutomodConfig(guildId);
    
    // Tüm kuralları pasif yap
    Object.keys(resetConfig.rules).forEach(rule => {
      resetConfig.rules[rule].enabled = false;
      resetConfig.rules[rule].violations = 0;
    });
    
    // Beyaz listeleri temizle
    resetConfig.whitelist = { users: [], roles: [], channels: [] };
    
    await this.saveAutomodConfig(guildId, resetConfig);
    
    // İstatistikleri de sıfırla (gerçek projede veritabanından sil)
    console.log(`Automod stats reset for guild ${guildId}`);
  }
};




