// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('🔨 Kullanıcıyı sunucudan yasaklar')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Yasaklanacak kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Ban sebebi')
        .setRequired(false)
        .setMaxLength(500))
    .addIntegerOption(option =>
      option.setName('süre')
        .setDescription('⏰ Geçici ban süresi (dakika cinsinden)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(525600)) // 1 yıl max
    .addIntegerOption(option =>
      option.setName('mesaj_sil')
        .setDescription('🗑️ Kaç günlük mesajları silinsin? (0-7)')
        .setRequired(false)
        .setMinValue(0)
        .setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const reason = interaction.options.getString('sebep') || 'Sebep belirtilmedi';
      const duration = interaction.options.getInteger('süre'); // dakika
      const deleteMessages = interaction.options.getInteger('mesaj_sil') || 1;
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.BanMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Ban Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Bot izin kontrolü
      if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
        return await interaction.editReply({
          content: '❌ **Bot Yetki Hatası!** Botu yasaklama yetkisi yok!'
        });
      }

      // Hedef kullanıcı kontrolleri
      if (targetUser.id === moderator.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kendinizi yasaklayamazsınız!'
        });
      }

      if (targetUser.id === guild.ownerId) {
        return await interaction.editReply({
          content: '❌ **Hata!** Sunucu sahibini yasaklayamazsınız!'
        });
      }

      if (targetUser.bot && targetUser.id === interaction.client.user.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Beni yasaklayamazsınız!'
        });
      }

      // Üye kontrolü ve hiyerarşi kontrolü
      let targetMember = null;
      try {
        targetMember = await guild.members.fetch(targetUser.id);
        
        // Hiyerarşi kontrolü
        if (targetMember.roles.highest.position >= member.roles.highest.position && guild.ownerId !== moderator.id) {
          return await interaction.editReply({
            content: '❌ **Yetki Hatası!** Bu kullanıcı sizden yüksek veya eşit yetkiye sahip!'
          });
        }

        // Bot'un yetkisi kontrolü
        if (targetMember.roles.highest.position >= guild.members.me.roles.highest.position) {
          return await interaction.editReply({
            content: '❌ **Bot Yetki Hatası!** Bu kullanıcı bottan yüksek veya eşit yetkiye sahip!'
          });
        }

        // Yasaklanamaz rol kontrolü
        if (targetMember.roles.cache.has(lyuex.yetkili?.kurucu)) {
          return await interaction.editReply({
            content: '❌ **Korumalı Kullanıcı!** Bu kullanıcı kurucu rolüne sahip!'
          });
        }

      } catch (fetchError) {
        // Kullanıcı sunucuda değil, yine de yasaklanabilir
        console.log(`Kullanıcı sunucuda değil, yine de yasaklanacak: ${targetUser.tag}`);
      }

      // Mevcut ban kontrolü
      try {
        const banInfo = await guild.bans.fetch(targetUser.id);
        if (banInfo) {
          return await interaction.editReply({
            content: '❌ **Zaten Yasaklı!** Bu kullanıcı zaten yasaklı durumda!'
          });
        }
      } catch (banCheckError) {
        // Kullanıcı yasaklı değil, devam et
      }

      // Süre formatı kontrolü ve dönüştürme
      let durationText = '';
      if (duration) {
        durationText = ModerationManager.formatDuration(duration);
        
        if (duration > 525600) { // 1 yıldan fazla
          return await interaction.editReply({
            content: '❌ **Hata!** Geçici ban süresi en fazla 1 yıl (525600 dakika) olabilir!'
          });
        }
      }

      // Onay embed'i
      const confirmEmbed = new EmbedBuilder()
        .setColor(duration ? '#FF8C00' : '#FF0000')
        .setTitle(`🔨 ${duration ? 'Geçici ' : ''}Ban Onayı`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Hedef Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '🗑️ Mesaj Silme', value: `${deleteMessages} günlük mesajlar`, inline: true }
        )
        .setFooter({ text: 'Bu işlem geri alınamaz!' })
        .setTimestamp();

      if (duration) {
        confirmEmbed.addFields(
          { name: '⏰ Süre', value: durationText, inline: true },
          { name: '🏁 Bitiş', value: `<t:${Math.floor((Date.now() + duration * 60000) / 1000)}:F>`, inline: true }
        );
      } else {
        confirmEmbed.addFields({ name: '⚠️ Tür', value: '**KALICI BAN**', inline: true });
      }

      await interaction.editReply({
        content: '⚠️ **Ban işlemini onaylayın:**',
        embeds: [confirmEmbed]
      });

      // Ban işlemini gerçekleştir
      try {
        const result = await ModerationManager.banUser({
          guild,
          user: targetUser,
          moderator,
          reason,
          duration,
          deleteMessages
        });

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Ban İşlemi Başarılı')
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**📋 Case ID:** ${result.caseId}\n` +
            `**📝 Sebep:** ${reason}\n` +
            (duration ? `**⏰ Süre:** ${durationText}\n` : '') +
            `**📱 DM Durumu:** ${result.dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
            `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`
          )
          .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [successEmbed]
        });

      } catch (banError) {
        console.error('Ban işlemi hatası:', banError);
        
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Ban İşlemi Başarısız')
          .setDescription(
            `**Hata:** ${banError.message}\n\n` +
            `**Olası Sebepler:**\n` +
            `• Bot yetkisi yetersiz\n` +
            `• Kullanıcı zaten yasaklı\n` +
            `• Discord API hatası\n` +
            `• Veritabanı bağlantı sorunu`
          )
          .setFooter({ text: 'Hatayı yöneticiye bildirin' })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [errorEmbed]
        });
      }

    } catch (error) {
      console.error('Ban komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};




