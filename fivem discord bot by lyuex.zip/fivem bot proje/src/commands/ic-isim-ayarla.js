// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ic-isim-ayarla')
    .setDescription('🎭 IC isim onay sistemini ayarlar')
    .addSubcommand(subcommand =>
      subcommand
        .setName('kanal')
        .setDescription('IC isim onay kanalını ayarlar')
        .addChannelOption(option =>
          option.setName('kanal')
            .setDescription('IC isim onay kanalı')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('log-kanal')
        .setDescription('IC isim log kanalını ayarlar')
        .addChannelOption(option =>
          option.setName('kanal')
            .setDescription('IC isim log kanalı')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('rol')
        .setDescription('IC isim onay rolünü ayarlar')
        .addRoleOption(option =>
          option.setName('rol')
            .setDescription('IC isim onaylandığında verilecek rol')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('yetkili-rol')
        .setDescription('IC isim onaylayabilecek yetkili rolünü ayarlar')
        .addRoleOption(option =>
          option.setName('rol')
            .setDescription('IC isim onaylayabilecek rol')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('durum')
        .setDescription('IC isim onay sistemi durumunu gösterir'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('test')
        .setDescription('IC isim onay sistemini test eder'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    try {
      await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

      const subcommand = interaction.options.getSubcommand();

      switch (subcommand) {
        case 'kanal': {
          const kanal = interaction.options.getChannel('kanal');
          
          // lyuex.json'ı güncelle (gerçek projede veritabanı kullanılmalı)
          // Bu örnekte sadece gösterim amaçlı
          
          const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ IC İsim Onay Kanalı Ayarlandı')
            .setDescription(`IC isim onay kanalı ${kanal} olarak ayarlandı!`)
            .addFields(
              { name: '📢 Bilgi', value: 'Artık kullanıcılar bu kanala IC isimlerini yazabilirler.', inline: false },
              { name: '⚙️ Yapılacaklar', value: '• `lyuex.json` dosyasında `ic_isim.kanal` değerini `' + kanal.id + '` olarak güncelleyin\n• Botu yeniden başlatın', inline: false }
            )
            .setFooter({ text: 'IC İsim Onay Sistemi' })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case 'log-kanal': {
          const kanal = interaction.options.getChannel('kanal');
          
          const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ IC İsim Log Kanalı Ayarlandı')
            .setDescription(`IC isim log kanalı ${kanal} olarak ayarlandı!`)
            .addFields(
              { name: '📋 Bilgi', value: 'Artık tüm IC isim onay/red işlemleri bu kanala loglanacak.', inline: false },
              { name: '⚙️ Yapılacaklar', value: '• `lyuex.json` dosyasında `ic_isim.log_kanal` değerini `' + kanal.id + '` olarak güncelleyin\n• Botu yeniden başlatın', inline: false }
            )
            .setFooter({ text: 'IC İsim Onay Sistemi' })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case 'rol': {
          const rol = interaction.options.getRole('rol');
          
          const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ IC İsim Onay Rolü Ayarlandı')
            .setDescription(`IC isim onay rolü ${rol} olarak ayarlandı!`)
            .addFields(
              { name: '🏷️ Bilgi', value: 'Artık IC isimleri onaylanan kullanıcılara bu rol verilecek.', inline: false },
              { name: '⚙️ Yapılacaklar', value: '• `lyuex.json` dosyasında `rol.ic_onay` değerini `' + rol.id + '` olarak güncelleyin\n• Botu yeniden başlatın', inline: false }
            )
            .setFooter({ text: 'IC İsim Onay Sistemi' })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case 'yetkili-rol': {
          const rol = interaction.options.getRole('rol');
          
          const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ IC İsim Yetkili Rolü Ayarlandı')
            .setDescription(`IC isim yetkili rolü ${rol} olarak ayarlandı!`)
            .addFields(
              { name: '👮 Bilgi', value: 'Artık bu role sahip kullanıcılar IC isimleri onaylayabilir.', inline: false },
              { name: '⚙️ Yapılacaklar', value: '• `lyuex.json` dosyasında `ic_isim.yetkili_rol` listesine `' + rol.id + '` ekleyin\n• Botu yeniden başlatın', inline: false }
            )
            .setFooter({ text: 'IC İsim Onay Sistemi' })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case 'durum': {
          const icKanal = lyuex.ic_isim?.kanal;
          const logKanal = lyuex.ic_isim?.log_kanal;
          const icRol = lyuex.rol?.ic_onay;
          const yetkiliRoller = lyuex.ic_isim?.yetkili_rol || [];

          const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('📊 IC İsim Onay Sistemi Durumu')
            .addFields(
              { 
                name: '📢 IC İsim Kanalı', 
                value: icKanal ? `<#${icKanal}>` : '❌ Ayarlanmamış', 
                inline: true 
              },
              { 
                name: '📋 Log Kanalı', 
                value: logKanal ? `<#${logKanal}>` : '❌ Ayarlanmamış', 
                inline: true 
              },
              { 
                name: '🏷️ IC Onay Rolü', 
                value: icRol ? `<@&${icRol}>` : '❌ Ayarlanmamış', 
                inline: true 
              },
              { 
                name: '👮 Yetkili Roller', 
                value: yetkiliRoller.length > 0 ? yetkiliRoller.map(id => `<@&${id}>`).join('\n') : '❌ Ayarlanmamış', 
                inline: false 
              }
            )
            .setFooter({ text: 'IC İsim Onay Sistemi' })
            .setTimestamp();

          // Sistem durumu kontrolü
          const sistemAktif = icKanal && icRol && yetkiliRoller.length > 0;
          embed.setDescription(sistemAktif ? '✅ **Sistem Aktif**' : '❌ **Sistem Eksik Ayarlar Nedeniyle İnaktif**');

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case 'test': {
          const icKanal = lyuex.ic_isim?.kanal;
          
          if (!icKanal) {
            const embed = new EmbedBuilder()
              .setColor(0xFF0000)
              .setTitle('❌ Test Başarısız')
              .setDescription('IC isim kanalı ayarlanmamış!')
              .setTimestamp();

            return await interaction.editReply({ embeds: [embed] });
          }

          const kanal = interaction.guild.channels.cache.get(icKanal);
          
          if (!kanal) {
            const embed = new EmbedBuilder()
              .setColor(0xFF0000)
              .setTitle('❌ Test Başarısız')
              .setDescription('IC isim kanalı bulunamadı!')
              .setTimestamp();

            return await interaction.editReply({ embeds: [embed] });
          }

          try {
            const testEmbed = new EmbedBuilder()
              .setColor(0xFFA500)
              .setTitle('🧪 IC İsim Sistemi Test')
              .setDescription('Bu bir test mesajıdır. Sistem çalışıyor! ✅')
              .addFields(
                { name: '📋 Test Yapan', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Test Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
              )
              .setFooter({ text: 'IC İsim Onay Sistemi - Test' })
              .setTimestamp();

            await kanal.send({ embeds: [testEmbed] });

            const basariliEmbed = new EmbedBuilder()
              .setColor(0x00FF00)
              .setTitle('✅ Test Başarılı')
              .setDescription(`Test mesajı ${kanal} kanalına gönderildi!`)
              .setTimestamp();

            await interaction.editReply({ embeds: [basariliEmbed] });
          } catch (error) {
            const hataEmbed = new EmbedBuilder()
              .setColor(0xFF0000)
              .setTitle('❌ Test Başarısız')
              .setDescription(`Test mesajı gönderilemedi: ${error.message}`)
              .setTimestamp();

            await interaction.editReply({ embeds: [hataEmbed] });
          }
          break;
        }
      }

    } catch (error) {
      console.error('IC isim ayarlama hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};





