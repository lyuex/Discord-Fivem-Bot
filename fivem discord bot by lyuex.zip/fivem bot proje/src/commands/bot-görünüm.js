// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');
const axios = require('axios');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-görünüm')
        .setDescription('Bot avatar ve banner değiştirme sistemi')
        .addSubcommand(subcommand =>
            subcommand
                .setName('avatar')
                .setDescription('Bot avatarını değiştir')
                .addStringOption(option =>
                    option
                        .setName('url')
                        .setDescription('Yeni avatar için resim URL\'si')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('banner')
                .setDescription('Bot bannerını değiştir')
                .addStringOption(option =>
                    option
                        .setName('url')
                        .setDescription('Yeni banner için resim URL\'si')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('görüntüle')
                .setDescription('Mevcut bot avatar ve banner bilgilerini göster')
        ),

    async execute(interaction) {
        // Bot sahipliği kontrolü
        const botOwners = lyuex.botSettings?.botOwners || [];
        if (!botOwners.includes(interaction.user.id)) {
            const yetkisizEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Yetki Hatası')
                .setDescription('Bu komut sadece **Bot Sahipleri** tarafından kullanılabilir!')
                .addFields(
                    { name: '🔐 Sebep', value: 'Bot görünüm ayarları', inline: true },
                    { name: '👑 Gerekli Yetki', value: 'Bot Sahibi', inline: true },
                    { name: '📝 Not', value: 'Bu işlem bot ayarlarını değiştirir', inline: false }
                )
                .setFooter({ text: 'ZYM CİTY • Bot Yönetimi' })
                .setTimestamp();

            return interaction.reply({ embeds: [yetkisizEmbed], ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            if (subcommand === 'avatar') {
                await handleAvatarChange(interaction);
            } else if (subcommand === 'banner') {
                await handleBannerChange(interaction);
            } else if (subcommand === 'görüntüle') {
                await handleDisplayInfo(interaction);
            }
        } catch (error) {
            console.error('Bot görünüm komutu hatası:', error);
            
            const hataEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Sistem Hatası')
                .setDescription('Bot görünüm değişikliği sırasında bir hata oluştu!')
                .addFields(
                    { name: '🔍 Hata Detayı', value: '```' + error.message + '```', inline: false },
                    { name: '💡 Çözüm Önerileri', value: '• URL\'nin geçerli olduğundan emin olun\n• Resim formatının desteklendiğini kontrol edin\n• İnternet bağlantınızı kontrol edin', inline: false }
                )
                .setFooter({ text: 'ZYM CİTY • Hata Sistemi' })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [hataEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [hataEmbed], ephemeral: true });
            }
        }
    }
};

// Avatar değiştirme fonksiyonu
async function handleAvatarChange(interaction) {
    const imageUrl = interaction.options.getString('url');
    
    // URL validasyonu
    if (!isValidImageUrl(imageUrl)) {
        const hataliUrlEmbed = new EmbedBuilder()
            .setColor(0xFF4444)
            .setTitle('⚠️ Geçersiz URL')
            .setDescription('Lütfen geçerli bir resim URL\'si girin!')
            .addFields(
                { name: '✅ Desteklenen Formatlar', value: 'PNG, JPG, JPEG, GIF, WEBP', inline: true },
                { name: '📏 Boyut Limiti', value: 'Maksimum 8MB', inline: true },
                { name: '📐 Önerilen Boyut', value: '512x512 piksel', inline: true },
                { name: '🔗 Örnek URL', value: '```https://cdn.discordapp.com/attachments/.../resim.png```', inline: false }
            )
            .setFooter({ text: 'ZYM CİTY • Avatar Sistemi' })
            .setTimestamp();

        return interaction.reply({ embeds: [hataliUrlEmbed], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
        // Resmi indir ve doğrula
        const response = await axios.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 10000,
            maxContentLength: 8 * 1024 * 1024 // 8MB limit
        });

        const buffer = Buffer.from(response.data);
        
        // Bot avatarını değiştir
        await interaction.client.user.setAvatar(buffer);

        // Başarı mesajı
        const basariEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ Avatar Başarıyla Değiştirildi!')
            .setDescription(`Bot avatarı **başarıyla güncellendi**!`)
            .addFields(
                { name: '🖼️ Yeni Avatar', value: 'Aşağıda görüntüleniyor', inline: true },
                { name: '👤 İşlemi Yapan', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Değişiklik Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '🔗 Kaynak URL', value: `[Resim Linki](${imageUrl})`, inline: false },
                { name: '📊 Dosya Boyutu', value: `${(buffer.length / 1024).toFixed(2)} KB`, inline: true },
                { name: '💡 Not', value: 'Değişiklik tüm sunucularda görünmesi birkaç dakika sürebilir', inline: false }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true, size: 512 }))
            .setImage(imageUrl)
            .setFooter({ text: 'ZYM CİTY • Avatar Güncellendi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [basariEmbed] });

        // Log kanalına bilgi gönder
        await sendLogMessage(interaction, 'AVATAR', imageUrl, buffer.length);

    } catch (error) {
        console.error('Avatar değiştirme hatası:', error);
        
        let hataAciklama = 'Avatar değiştirme işlemi başarısız!';
        if (error.response?.status === 429) {
            hataAciklama = 'Discord API rate limit! Lütfen biraz bekleyip tekrar deneyin.';
        } else if (error.code === 'ENOTFOUND') {
            hataAciklama = 'URL\'ye erişilemiyor! Lütfen geçerli bir URL girin.';
        } else if (error.message.includes('timeout')) {
            hataAciklama = 'İndirme zaman aşımı! Daha küçük bir resim deneyin.';
        }

        const hataEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Avatar Değiştirme Hatası')
            .setDescription(hataAciklama)
            .addFields(
                { name: '🔍 Hata Kodu', value: '```' + (error.code || error.message) + '```', inline: false },
                { name: '💡 Çözüm Önerileri', value: '• Farklı bir resim URL\'si deneyin\n• Resim boyutunun 8MB\'dan küçük olduğundan emin olun\n• İnternet bağlantınızı kontrol edin\n• Birkaç dakika bekleyip tekrar deneyin', inline: false }
            )
            .setFooter({ text: 'ZYM CİTY • Hata Sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [hataEmbed] });
    }
}

// Banner değiştirme fonksiyonu
async function handleBannerChange(interaction) {
    const imageUrl = interaction.options.getString('url');
    
    // URL validasyonu
    if (!isValidImageUrl(imageUrl)) {
        const hataliUrlEmbed = new EmbedBuilder()
            .setColor(0xFF4444)
            .setTitle('⚠️ Geçersiz URL')
            .setDescription('Lütfen geçerli bir resim URL\'si girin!')
            .addFields(
                { name: '✅ Desteklenen Formatlar', value: 'PNG, JPG, JPEG, GIF, WEBP', inline: true },
                { name: '📏 Boyut Limiti', value: 'Maksimum 8MB', inline: true },
                { name: '📐 Önerilen Boyut', value: '960x540 piksel (16:9)', inline: true },
                { name: '🔗 Örnek URL', value: '```https://cdn.discordapp.com/attachments/.../banner.png```', inline: false }
            )
            .setFooter({ text: 'ZYM CİTY • Banner Sistemi' })
            .setTimestamp();

        return interaction.reply({ embeds: [hataliUrlEmbed], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
        // Resmi indir ve doğrula
        const response = await axios.get(imageUrl, {
            responseType: 'arraybuffer',
            timeout: 10000,
            maxContentLength: 8 * 1024 * 1024 // 8MB limit
        });

        const buffer = Buffer.from(response.data);
        
        // Bot bannerını değiştir
        await interaction.client.user.setBanner(buffer);

        // Başarı mesajı
        const basariEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ Banner Başarıyla Değiştirildi!')
            .setDescription(`Bot bannerı **başarıyla güncellendi**!`)
            .addFields(
                { name: '🖼️ Yeni Banner', value: 'Aşağıda görüntüleniyor', inline: true },
                { name: '👤 İşlemi Yapan', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Değişiklik Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '🔗 Kaynak URL', value: `[Resim Linki](${imageUrl})`, inline: false },
                { name: '📊 Dosya Boyutu', value: `${(buffer.length / 1024).toFixed(2)} KB`, inline: true },
                { name: '💡 Not', value: 'Banner değişikliği tüm sunucularda görünmesi birkaç dakika sürebilir', inline: false }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setImage(imageUrl)
            .setFooter({ text: 'ZYM CİTY • Banner Güncellendi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [basariEmbed] });

        // Log kanalına bilgi gönder
        await sendLogMessage(interaction, 'BANNER', imageUrl, buffer.length);

    } catch (error) {
        console.error('Banner değiştirme hatası:', error);
        
        let hataAciklama = 'Banner değiştirme işlemi başarısız!';
        if (error.response?.status === 429) {
            hataAciklama = 'Discord API rate limit! Lütfen biraz bekleyip tekrar deneyin.';
        } else if (error.code === 'ENOTFOUND') {
            hataAciklama = 'URL\'ye erişilemiyor! Lütfen geçerli bir URL girin.';
        } else if (error.message.includes('timeout')) {
            hataAciklama = 'İndirme zaman aşımı! Daha küçük bir resim deneyin.';
        }

        const hataEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Banner Değiştirme Hatası')
            .setDescription(hataAciklama)
            .addFields(
                { name: '🔍 Hata Kodu', value: '```' + (error.code || error.message) + '```', inline: false },
                { name: '💡 Çözüm Önerileri', value: '• Farklı bir resim URL\'si deneyin\n• Resim boyutunun 8MB\'dan küçük olduğundan emin olun\n• İnternet bağlantınızı kontrol edin\n• Birkaç dakika bekleyip tekrar deneyin', inline: false }
            )
            .setFooter({ text: 'ZYM CİTY • Hata Sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [hataEmbed] });
    }
}

// Mevcut görünüm bilgilerini göster
async function handleDisplayInfo(interaction) {
    const bot = interaction.client.user;
    
    const bilgiEmbed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🤖 Bot Görünüm Bilgileri')
        .setDescription(`**${bot.username}** botunun mevcut görünüm ayarları`)
        .addFields(
            { name: '🏷️ Bot Adı', value: `${bot.username}`, inline: true },
            { name: '🆔 Bot ID', value: `${bot.id}`, inline: true },
            { name: '🎭 Discriminator', value: `#${bot.discriminator}`, inline: true },
            { name: '📅 Oluşturulma Tarihi', value: `<t:${Math.floor(bot.createdTimestamp / 1000)}:F>`, inline: false },
            { name: '🖼️ Avatar URL', value: `[Avatar Linki](${bot.displayAvatarURL({ dynamic: true, size: 1024 })})`, inline: true },
            { name: '🏳️ Banner Durumu', value: bot.banner ? '✅ Mevcut' : '❌ Yok', inline: true },
            { name: '🎨 Aksen Rengi', value: bot.accentColor ? `#${bot.accentColor.toString(16).padStart(6, '0')}` : 'Yok', inline: true }
        )
        .setThumbnail(bot.displayAvatarURL({ dynamic: true, size: 512 }))
        .setFooter({ text: 'ZYM CİTY • Bot Bilgileri' })
        .setTimestamp();

    if (bot.banner) {
        bilgiEmbed.setImage(bot.bannerURL({ dynamic: true, size: 1024 }));
        bilgiEmbed.addFields(
            { name: '🏳️ Banner URL', value: `[Banner Linki](${bot.bannerURL({ dynamic: true, size: 1024 })})`, inline: false }
        );
    }

    await interaction.reply({ embeds: [bilgiEmbed], ephemeral: true });
}

// Log mesajı gönderme fonksiyonu
async function sendLogMessage(interaction, type, imageUrl, fileSize) {
    try {
        const logChannelId = lyuex.log?.channels?.system_logs;
        if (!logChannelId) return;

        const logChannel = interaction.guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const logEmbed = new EmbedBuilder()
            .setColor(type === 'AVATAR' ? 0x00FF00 : 0x0099FF)
            .setTitle(`🤖 Bot ${type === 'AVATAR' ? 'Avatar' : 'Banner'} Değiştirildi`)
            .addFields(
                { name: '👤 İşlemi Yapan', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                { name: '🔧 İşlem Türü', value: `Bot ${type === 'AVATAR' ? 'Avatar' : 'Banner'} Güncelleme`, inline: true },
                { name: '📊 Dosya Boyutu', value: `${(fileSize / 1024).toFixed(2)} KB`, inline: true },
                { name: '🔗 Kaynak URL', value: `[Resim Linki](${imageUrl})`, inline: false },
                { name: '⏰ Değişiklik Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'ZYM CİTY • Bot Yönetimi Log' })
            .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
    } catch (error) {
        console.error('Log mesajı gönderme hatası:', error);
    }
}

// URL validasyon fonksiyonu
function isValidImageUrl(url) {
    try {
        const urlObj = new URL(url);
        const pathname = urlObj.pathname.toLowerCase();
        const validExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp'];
        
        // URL format kontrolü
        if (!['http:', 'https:'].includes(urlObj.protocol)) {
            return false;
        }
        
        // Discord CDN veya bilinen resim servisleri kontrolü
        const validDomains = [
            'cdn.discordapp.com',
            'media.discordapp.net',
            'imgur.com',
            'i.imgur.com',
            'gyazo.com',
            'i.gyazo.com'
        ];
        
        const isDomainValid = validDomains.some(domain => urlObj.hostname.includes(domain));
        const hasValidExtension = validExtensions.some(ext => pathname.includes(ext));
        
        return isDomainValid || hasValidExtension;
    } catch {
        return false;
    }
}