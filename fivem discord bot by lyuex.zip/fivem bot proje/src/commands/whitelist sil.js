// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const lyuex = require('../../lyuex.json');

const config = {
  roles: {
    whitelist: '1423300483329822731',
    kayitsiz: '1423300349896298638'
  },
  authRoles: [
    '1423300954606010510',
    'AUTH_ROLE_ID_2'
  ],
  channels: {
    whitelist_log: '1423321674966896782'
  }
};

const logPath = path.join(__dirname, '../../db/whitelistLogs.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wl-sil')
    .setDescription('🗑️ Whitelist sisteminden kullanıcı kaldırır ve rol işlemlerini yapar')
    .addSubcommand(sub =>
      sub
        .setName('kullanici')
        .setDescription('👤 Belirli bir kullanıcının whitelist\'ini kaldırır')
        .addUserOption(opt =>
          opt.setName('hedef')
             .setDescription('Whitelist\'i kaldırılacak kullanıcı')
             .setRequired(true)
        )
        .addStringOption(opt =>
          opt.setName('sebep')
             .setDescription('Kaldırma sebebi (opsiyonel)')
             .setRequired(false)
             .setMaxLength(200)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('logs')
        .setDescription('📄 Tüm whitelist log kayıtlarını temizler')
    )
    .addSubcommand(sub =>
      sub
        .setName('liste')
        .setDescription('📋 Whitelist\'li kullanıcıları listeler')
    ),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      // Yetki kontrolü
      const memberRoles = interaction.member.roles.cache;
      const isAuthorized = config.authRoles.some(id => memberRoles.has(id)) ||
                          interaction.member.permissions.has('ManageRoles') ||
                          interaction.member.permissions.has('Administrator');
                          
      if (!isAuthorized) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanma yetkiniz bulunmamaktadır.' 
        });
      }

      // Bot izinlerini kontrol et
      const botMember = interaction.guild.members.cache.get(interaction.client.user.id);
      if (!botMember.permissions.has('ManageRoles')) {
        return await interaction.editReply({ 
          content: '❌ **Bot Hatası!** Benim rol yönetme iznim yok.' 
        });
      }

      // Dosya ve klasör hazırla
      const dir = path.dirname(logPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      if (!fs.existsSync(logPath)) fs.writeFileSync(logPath, JSON.stringify([], null, 2));

      const sub = interaction.options.getSubcommand();

      if (sub === 'kullanici') {
        const target = interaction.options.getUser('hedef');
        const sebep = interaction.options.getString('sebep') || 'Sebep belirtilmedi';
        
        // Kullanıcının sunucuda olup olmadığını kontrol et
        const targetMember = interaction.guild.members.cache.get(target.id);
        if (!targetMember) {
          return await interaction.editReply({ 
            content: '❌ **Kullanıcı Bulunamadı!** Belirtilen kullanıcı sunucuda değil.' 
          });
        }

        // Rolleri kontrol et
        const whitelistRole = interaction.guild.roles.cache.get(config.roles.whitelist);
        const kayitsizRole = interaction.guild.roles.cache.get(config.roles.kayitsiz);

        if (!whitelistRole) {
          return await interaction.editReply({ 
            content: '❌ **Rol Hatası!** Whitelist rolü bulunamadı.' 
          });
        }

        // Kullanıcının whitelist rolü var mı kontrol et
        if (!targetMember.roles.cache.has(whitelistRole.id)) {
          return await interaction.editReply({ 
            content: `❌ **Zaten Whitelist\'li Değil!** ${target.tag} kullanıcısı zaten whitelist rolüne sahip değil.` 
          });
        }

        // Rolleri değiştir
        await targetMember.roles.remove(whitelistRole, `Whitelist kaldırıldı: ${interaction.user.tag} tarafından - Sebep: ${sebep}`);
        
        if (kayitsizRole) {
          await targetMember.roles.add(kayitsizRole, 'Whitelist kaldırıldığı için kayıtsız rolü eklendi');
        }

        // Log dosyasından kullanıcı kayıtlarını sil
        let logs = [];
        try {
          if (fs.existsSync(logPath)) {
            logs = JSON.parse(fs.readFileSync(logPath, 'utf8'));
            if (!Array.isArray(logs)) logs = [];
          }
        } catch (error) {
          console.error('Log dosyası okuma hatası:', error);
          logs = [];
        }

        // Bu kullanıcının kayıtlarını filtrele
        const beforeCount = logs.length;
        logs = logs.filter(log => log.target?.id !== target.id);
        const removedCount = beforeCount - logs.length;

        // Yeni kaldırma kaydı ekle
        const removalLog = {
          timestamp: new Date().toISOString(),
          action: 'removal',
          executor: {
            id: interaction.user.id,
            tag: interaction.user.tag
          },
          target: {
            id: target.id,
            tag: target.tag
          },
          reason: sebep
        };
        logs.push(removalLog);

        // Dosyayı güncelle
        try {
          fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
        } catch (error) {
          console.error('Log dosyası yazma hatası:', error);
        }

        // Log kanalına bildirim gönder
        const logChannel = interaction.guild.channels.cache.get(config.channels.whitelist_log);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('🗑️ Whitelist Kaldırıldı')
            .setColor(0xFF6B6B)
            .addFields(
              { name: '👤 Kaldırılan Kullanıcı', value: `${target} (${target.tag})`, inline: true },
              { name: '👑 Kaldıran Yetkili', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
              { name: '📝 Sebep', value: sebep, inline: false },
              { name: '🗂️ Silinen Log Sayısı', value: removedCount.toString(), inline: true },
              { name: '⏰ Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            )
            .setFooter({ 
              text: `${interaction.guild.name} • Whitelist Sistemi`,
              iconURL: interaction.guild.iconURL({ dynamic: true })
            })
            .setTimestamp();

          await logChannel.send({ embeds: [logEmbed] });
        }

        await interaction.editReply({ 
          content: `✅ **Whitelist başarıyla kaldırıldı!**\n\n` +
                  `🎯 **Hedef:** ${target.tag}\n` +
                  `📝 **Sebep:** ${sebep}\n` +
                  `👑 **Yetkili:** ${interaction.user.tag}\n\n` +
                  `**Yapılan işlemler:**\n` +
                  `• ❌ Whitelist rolü kaldırıldı\n` +
                  `• ✅ Kayıtsız rolü eklendi\n` +
                  `• 🗂️ ${removedCount} log kaydı silindi\n` +
                  `• 📊 Kaldırma işlemi loglandı`
        });

      } else if (sub === 'logs') {
        // Tüm log kayıtlarını temizle
        fs.writeFileSync(logPath, JSON.stringify([], null, 2));

        const logEmbed = new EmbedBuilder()
          .setTitle('🗑️ Log Temizleme')
          .setDescription('Tüm whitelist log kayıtları başarıyla temizlendi.')
          .setColor(0xFFA500)
          .addFields(
            { name: '👑 Temizleyen', value: `${interaction.user.tag}`, inline: true },
            { name: '⏰ Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
          )
          .setTimestamp();

        await interaction.editReply({ embeds: [logEmbed] });

      } else if (sub === 'liste') {
        // Whitelist rolüne sahip kullanıcıları listele
        const whitelistRole = interaction.guild.roles.cache.get(config.roles.whitelist);
        
        if (!whitelistRole) {
          return await interaction.editReply({ 
            content: '❌ **Rol Hatası!** Whitelist rolü bulunamadı.' 
          });
        }

        const whitelistedMembers = whitelistRole.members;
        
        if (whitelistedMembers.size === 0) {
          return await interaction.editReply({ 
            content: '📭 **Liste Boş!** Şu an whitelist rolüne sahip hiç kullanıcı yok.' 
          });
        }

        const memberList = whitelistedMembers
          .map((member, index) => `${index + 1}. ${member.user.tag} (${member.user.id})`)
          .slice(0, 20) // İlk 20 kullanıcı
          .join('\n');

        const moreCount = Math.max(0, whitelistedMembers.size - 20);

        const listEmbed = new EmbedBuilder()
          .setTitle(`📋 Whitelist Kullanıcı Listesi (${whitelistedMembers.size} kullanıcı)`)
          .setDescription(`\`\`\`\n${memberList}${moreCount > 0 ? `\n... ve ${moreCount} kullanıcı daha` : ''}\n\`\`\``)
          .setColor(0x00AEEF)
          .setFooter({ 
            text: `${interaction.guild.name} • Whitelist Sistemi`,
            iconURL: interaction.guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({ embeds: [listEmbed] });
      }

    } catch (error) {
      console.error('Whitelist silme işlemi hatası:', error);
      
      const errorMessage = error.message || 'Bilinmeyen hata';
      
      await interaction.editReply({
        content: `❌ **İşlem başarısız!**\n\n` +
                `**Hata:** ${errorMessage}\n\n` +
                `🔧 **Çözüm önerileri:**\n` +
                `• Bot izinlerini kontrol edin\n` +
                `• Rol ID'lerini kontrol edin\n` +
                `• Hedef kullanıcının sunucuda olduğunu kontrol edin`
      });
    }
  }
};






