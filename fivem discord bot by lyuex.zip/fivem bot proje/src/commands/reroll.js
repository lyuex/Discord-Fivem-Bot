// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('yeniden-çekiliş')
    .setDescription('🔄 Biten bir çekilişi yeniden çek')
    .addStringOption(opt =>
      opt.setName('mesaj_id')
         .setDescription('🆔 Çekiliş mesajının ID\'si')
         .setRequired(true))
    .addChannelOption(opt =>
      opt.setName('kanal')
         .setDescription('📍 Çekiliş mesajının bulunduğu kanal')
         .setRequired(true))
    .addIntegerOption(opt =>
      opt.setName('kazanan_sayısı')
         .setDescription('🏆 Kaç kişi yeniden çekilecek? (Varsayılan: 1)')
         .setRequired(false)
         .setMinValue(1)
         .setMaxValue(50))
    .addBooleanOption(opt =>
      opt.setName('önceki_kazananlar')
         .setDescription('⚠️ Önceki kazananlar tekrar kazanabilir mi? (Varsayılan: hayır)')
         .setRequired(false)),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has('ManageGuild') ||
                          member.permissions.has('Adlyuexstrator');
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Kurucu rolü\n' +
                  '• Sunucuyu Yönet yetkisi\n' +
                  '• Yönetici yetkisi' 
        });
      }

      // Parametreler
      const messageId = interaction.options.getString('mesaj_id');
      const channel = interaction.options.getChannel('kanal');
      const winnerCount = interaction.options.getInteger('kazanan_sayısı') || 1;
      const includeWinners = interaction.options.getBoolean('önceki_kazananlar') ?? false;
      
      // Kanal erişimi kontrolü
      if (!channel.isTextBased()) {
        return await interaction.editReply({ content: '❌ **Hata!** Belirtilen kanal bir metin kanalı değil!' });
      }

      try {
        // Mesajı getir
        const message = await channel.messages.fetch(messageId).catch(e => null);
        if (!message) {
          return await interaction.editReply({ 
            content: '❌ **Mesaj Bulunamadı!** Belirtilen ID ile bir mesaj bulunamadı. Doğru ID girdiğinizden emin olun.'
          });
        }

        // Mesajın çekiliş mesajı olduğunu kontrol et (botun göndermiş olması ve içeriğinde "ÇEKİLİŞ" geçmesi)
        const isBotMessage = message.author.id === interaction.client.user.id;
        const hasGiveawayContent = 
          message.content.includes('ÇEKİLİŞ') || 
          (message.embeds[0] && message.embeds[0].title && message.embeds[0].title.includes('ÇEKİLİŞ'));
        
        if (!isBotMessage || !hasGiveawayContent) {
          return await interaction.editReply({ 
            content: '❌ **Geçersiz Mesaj!** Belirtilen mesaj bir çekiliş mesajı değil.'
          });
        }

        // Katılımcıları topla - çekiliş mesajına yapılan tepkileri al (🎉)
        await interaction.editReply({ content: '⏳ **Katılımcılar toplanıyor...**' });

        // Reaksiyonları topla veya içerikten çıkar
        let participants = [];
        
        // Embed içeriğinden ödül adını çıkarmaya çalış
        let prizeText = "Çekiliş Ödülü";
        if (message.embeds[0]) {
          const descriptionText = message.embeds[0].description;
          if (descriptionText) {
            const prizeMatch = descriptionText.match(/\*\*🎁 Ödül:\*\* (.*?)(?:\n|$)/);
            if (prizeMatch && prizeMatch[1]) {
              prizeText = prizeMatch[1];
            }
          }
        }

        // Tüm tepkileri kontrol et
        const reactions = message.reactions.cache;
        if (reactions.size > 0) {
          for (const reaction of reactions.values()) {
            if (reaction.emoji.name === '🎉' || reaction.emoji.name === '🎟️') {
              const users = await reaction.users.fetch();
              participants = users
                .filter(user => !user.bot)
                .map(user => ({ id: user.id, tag: user.tag, user }));
              break;
            }
          }
        }

        // Katılımcı yoksa hata ver
        if (participants.length === 0) {
          return await interaction.editReply({ 
            content: '❌ **Katılımcı Yok!** Bu çekilişte hiç katılımcı bulunamadı veya tepkiler alınamadı.'
          });
        }

        // Önceki kazananları çıkar (eğer önceki_kazananlar=false ise)
        let previousWinners = [];
        if (!includeWinners && message.content.includes('TEBRİKLER!')) {
          const content = message.content;
          const userMentionRegex = /<@!?(\d+)>/g;
          let match;
          while ((match = userMentionRegex.exec(content)) !== null) {
            previousWinners.push(match[1]);
          }
          
          if (previousWinners.length > 0) {
            participants = participants.filter(p => !previousWinners.includes(p.id));
            
            // Filtreleme sonrası katılımcı kontrolü
            if (participants.length === 0) {
              return await interaction.editReply({ 
                content: '❌ **Katılımcı Yok!** Önceki kazananlar çıkarıldıktan sonra yeterli katılımcı kalmadı.'
              });
            }
          }
        }

        // Yeterli katılımcı kontrolü
        if (participants.length < winnerCount) {
          return await interaction.editReply({ 
            content: `⚠️ **Yetersiz Katılımcı!** İstediğiniz ${winnerCount} kazanan için yeterli katılımcı yok. Mevcut katılımcı: ${participants.length}`
          });
        }

        // Yeni kazananları belirle
        const winners = [];
        const participantsCopy = [...participants];
        for (let i = 0; i < winnerCount && participantsCopy.length > 0; i++) {
          const randomIndex = Math.floor(Math.random() * participantsCopy.length);
          winners.push(participantsCopy[randomIndex]);
          participantsCopy.splice(randomIndex, 1);
        }

        // Yeni kazananları duyur
        const winnerMentions = winners.map(w => `<@${w.id}>`).join(' ');
        
        // Yeni kazananlar embed'i
        const rerollEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('🔄 YENİDEN ÇEKİLİŞ SONUÇLARI 🔄')
          .setDescription(
            `**🎁 Ödül:** ${prizeText}\n` +
            `**👥 Katılımcı Sayısı:** ${participants.length} kişi\n` +
            `**🏆 Yeniden Çekilen Kazanan Sayısı:** ${winners.length} kişi\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `**🎉 YENİ KAZANANLAR:**\n` +
            winners.map((winner, index) => `${index + 1}. <@${winner.id}> (${winner.tag})`).join('\n') +
            `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🎊 **Tebrikler yeni kazananlara!**`
          )
          .setFooter({ 
            text: `${lyuex.server.serverismi} • Yeniden Çekiliş • ${interaction.user.tag} tarafından yeniden çekildi`,
            iconURL: interaction.guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        // Çekiliş kanalına duyuru yap
        await channel.send({ 
          content: `🔄 **YENİDEN ÇEKİLİŞ YAPILDI!** 🔄\n${winnerMentions} TEBRİKLER! \`${prizeText}\` kazandınız!`, 
          embeds: [rerollEmbed] 
        });

        // Başarılı bildirim
        await interaction.editReply({ 
          content: `✅ **Yeniden çekiliş başarıyla yapıldı!**\n\n` +
                  `🎁 **Ödül:** ${prizeText}\n` +
                  `👥 **Katılımcı Sayısı:** ${participants.length}\n` +
                  `🏆 **Yeni Kazanan Sayısı:** ${winners.length}\n` +
                  `🔄 **Yeni Kazananlar:** ${winners.map(w => w.tag).join(', ')}`
        });
        
        // DM bildirimleri
        for (const winner of winners) {
          try {
            const user = await interaction.client.users.fetch(winner.id);
            if (user) {
              const dmEmbed = new EmbedBuilder()
                .setColor(0xFFD700)
                .setTitle('🎉 YENİDEN ÇEKİLİŞTE KAZANDINIZ! 🎉')
                .setDescription(
                  `Tebrikler **${user.tag}**!\n\n` +
                  `**🎁 Kazandığınız Ödül:** ${prizeText}\n` +
                  `**🏢 Sunucu:** ${interaction.guild.name}\n` +
                  `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
                  `🎊 Ödülünüzü almak için sunucu yöneticileri ile iletişime geçin!`
                )
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ 
                  text: `${lyuex.server.serverismi} • Çekiliş Sistemi • Yeniden Çekiliş`,
                  iconURL: interaction.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();
                
              await user.send({ embeds: [dmEmbed] });
            }
          } catch (dmError) {
            console.error(`DM gönderilemedi (${winner.tag}):`, dmError.message);
          }
        }

      } catch (fetchError) {
        console.error('Mesaj getirme hatası:', fetchError);
        return await interaction.editReply({ 
          content: `❌ **Hata!** Mesaj bilgileri alınırken bir sorun oluştu: ${fetchError.message}`
        });
      }

    } catch (error) {
      console.error('Yeniden çekiliş hatası:', error);
      
      const errorMessage = error.message || 'Bilinmeyen hata';
      const replyContent = `❌ **Yeniden çekiliş yapılırken hata oluştu!**\n\n**Hata:** ${errorMessage}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: replyContent });
      } else {
        await interaction.reply({ content: replyContent, ephemeral: true });
      }
    }
  }
};





