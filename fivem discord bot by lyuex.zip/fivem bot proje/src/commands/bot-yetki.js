// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-yetki')
        .setDescription('🔍 Bot yetkilerini kontrol et')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false),

    async execute(interaction) {
        // Sadece belirtilen kullanıcı kullanabilir
        const allowedUser = '384385365815066624';
        
        if (interaction.user.id !== allowedUser) {
            return interaction.reply({
                content: '❌ Bu komutu sadece bot sahibi kullanabilir!',
                ephemeral: true
            });
        }

        try {
            const guild = interaction.guild;
            const botMember = guild.members.me;
            const botPermissions = botMember.permissions;

            // Önemli yetkileri kontrol et
            const permissions = [
                { name: 'Manage Roles', flag: PermissionFlagsBits.ManageRoles },
                { name: 'Adlyuexstrator', flag: PermissionFlagsBits.Administrator },
                { name: 'Manage Guild', flag: PermissionFlagsBits.ManageGuild },
                { name: 'Manage Members', flag: PermissionFlagsBits.ModerateMembers },
                { name: 'Send Messages', flag: PermissionFlagsBits.SendMessages },
                { name: 'Use Slash Commands', flag: PermissionFlagsBits.UseApplicationCommands },
                { name: 'Embed Links', flag: PermissionFlagsBits.EmbedLinks },
                { name: 'Attach Files', flag: PermissionFlagsBits.AttachFiles }
            ];

            const permissionStatus = permissions.map(perm => {
                const hasPermission = botPermissions.has(perm.flag);
                return `${hasPermission ? '✅' : '❌'} **${perm.name}**`;
            }).join('\n');

            const embed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('🤖 Bot Yetki Kontrol Raporu')
                .setDescription('Botun mevcut yetkileri ve durumu')
                .addFields(
                    { name: '🔑 Yetkiler', value: permissionStatus, inline: false },
                    { name: '🎭 En Yüksek Rol', value: `**${botMember.roles.highest.name}**\nPozisyon: ${botMember.roles.highest.position}`, inline: true },
                    { name: '📊 Toplam Rol Sayısı', value: `${botMember.roles.cache.size} rol`, inline: true },
                    { name: '🆔 Bot ID', value: `${botMember.user.id}`, inline: true },
                    { name: '👤 Bot Tag', value: `${botMember.user.tag}`, inline: true },
                    { name: '🟢 Durum', value: `${botMember.presence?.status || 'online'}`, inline: true },
                    { name: '⏰ Sunucuya Katılım', value: `<t:${Math.floor(botMember.joinedAt.getTime() / 1000)}:F>`, inline: true }
                )
                .setThumbnail(botMember.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ 
                    text: `Kontrol Eden: ${interaction.user.tag}`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            // Rol listesi (ilk 10 rol)
            const roles = botMember.roles.cache
                .filter(role => role.name !== '@everyone')
                .sort((a, b) => b.position - a.position)
                .first(10)
                .map(role => `**${role.name}** (${role.position})`)
                .join('\n') || 'Rol yok';

            embed.addFields({ name: '🎭 Bot Rolleri (İlk 10)', value: roles, inline: false });

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error('Bot yetki kontrol hatası:', error);
            await interaction.reply({
                content: `❌ Yetki kontrolü sırasında hata: ${error.message}`,
                ephemeral: true
            });
        }
    },
};





