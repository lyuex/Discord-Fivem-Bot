// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');
const path = require('path');

// Rol ID'lerini lyuex.json'dan dinamik olarak al
function getConfig() {
  return {
    roles: {
      whitelist: Array.isArray(lyuex.rol.whitelist) ? lyuex.rol.whitelist[0] : lyuex.rol.whitelist,
      kayitsiz: lyuex.rol.kayıtsız
    },
    authRoles: [
      ...lyuex.yetkili.kayit,
      ...lyuex.yetkili.rol
    ],
    channels: {
      whitelist_log: lyuex.ozel_oda.log_kanal
    }
  };
}

const texts = {
  no_permission: 'Bu komutu kullanma yetkiniz bulunmamaktadır.',
  user_not_found: 'Belirtilen kullanıcı bulunamadı veya sunucuda değil.',
  success: 'Whitelist başarıyla verildi',
  log: {
    title: '📋 Kayıt Bilgileri',
    executor: 'Kayıt Eden',
    target: 'Kayıt Edilen',
    steam: 'Steam Profili',
    hex: 'Hex ID'
  }
};

const logPath = path.join(__dirname, '../../db/whitelistLogs.json');

function logWhitelistUsage(userId) {
  let data = {};
  const now = new Date();
  const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  if (fs.existsSync(logPath)) {
    data = JSON.parse(fs.readFileSync(logPath));
  }

  if (!data[yearMonth]) {
    data[yearMonth] = {};
  }

  if (!data[yearMonth][userId]) {
    data[yearMonth][userId] = 0;
  }

  data[yearMonth][userId] += 1;

  fs.writeFileSync(logPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Bir üyeye whitelist rolü verir.')
    .addUserOption(option =>
      option.setName('kullanici')
        .setDescription('Whitelist verilecek kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('hexid')
        .setDescription('Kullanıcının Hex ID\'si')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('steam')
        .setDescription('Steam profil bağlantısı')
        .setRequired(true)),

  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      const { guild, member, user, options } = interaction;
      const config = getConfig(); // Dinamik config kullan

      // Debug: Config'i loglayalım
      console.log('Whitelist Config:', {
        whitelistRoleId: config.roles.whitelist,
        kayitsizRoleId: config.roles.kayitsiz,
        authRoles: config.authRoles,
        logChannel: config.channels.whitelist_log
      });

      const memberRoles = member.roles.cache;
      const isAuthorized = config.authRoles.some(id => memberRoles.has(id)) ||
                          member.permissions.has('ManageRoles') ||
                          member.permissions.has('Administrator');
                          
      if (!isAuthorized) {
        return await interaction.editReply({ content: texts.no_permission });
      }

      const target = options.getMember('kullanici');
      const hexId = options.getString('hexid');
      const steamLink = options.getString('steam');

      if (!target) {
        return await interaction.editReply({ content: texts.user_not_found });
      }

      // Bot'un izinlerini kontrol et
      const botMember = guild.members.cache.get(interaction.client.user.id);
      if (!botMember.permissions.has('ManageRoles')) {
        return await interaction.editReply({ 
          content: '❌ **Bot Hatası!** Benim rol yönetme iznim yok. Lütfen bot izinlerini kontrol edin.' 
        });
      }

      // Rolleri kontrol et
      const whitelistRoleId = '1418690614697922722'; // Sabit whitelist rol ID'si
      const kayitsizRoleId = '1418690614697922721'; // Sabit kayıtsız rol ID'si
      let whitelistRole = guild.roles.cache.get(whitelistRoleId);
      let kayitsizRole = guild.roles.cache.get(kayitsizRoleId);

      // Whitelist rolü bulunamadıysa hata ver
      if (!whitelistRole) {
        return await interaction.editReply({ 
          content: `❌ **Rol Hatası!** Whitelist rolü bulunamadı (ID: \`${whitelistRoleId}\`). Lütfen rolün var olduğundan ve bot'un erişim iznine sahip olduğundan emin olun.` 
        });
      }

      // Kayıtsız rolü yoksa uyar ama devam et
      if (!kayitsizRole) {
        console.warn(`Kayıtsız rolü bulunamadı: ${kayitsizRoleId}`);
      }

      // Rolleri değiştir
      await target.roles.add(whitelistRole, `Whitelist verildi: ${member.user.tag} tarafından`);
      
      if (kayitsizRole && target.roles.cache.has(kayitsizRole.id)) {
        await target.roles.remove(kayitsizRole, 'Whitelist verildiği için kayıtsız rolü kaldırıldı');
      }

      // Nick değiştir
      try {
        await target.setNickname('IC ISIM', `Whitelist isim: ${member.user.tag} tarafından`);
      } catch (nickError) {
        console.warn('Nick değiştirilemedi:', nickError.message);
      }

      const logChannel = guild.channels.cache.get(config.channels.whitelist_log);

      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle(texts.log.title)
          .addFields(
            { name: texts.log.executor, value: `<@${user.id}>`, inline: true },
            { name: texts.log.target, value: `<@${target.id}>`, inline: true },
            { name: texts.log.steam, value: `[Steam profil git](${steamLink})` },
            { name: texts.log.hex, value: `\`${hexId}\`` }
          )
          .setColor(0x00AEEF)
          .setTimestamp()
          .setFooter({ 
            text: `${guild.name} • Whitelist Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          });

        await logChannel.send({ embeds: [embed] });
      }

      // Detaylı whitelist log kanalına gönder
      const detayliLogKanalId = '1428830066284036126';
      const detayliLogKanal = guild.channels.cache.get(detayliLogKanalId);
      
      if (detayliLogKanal) {
        const detayliEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('🎯 Whitelist İşlemi Tamamlandı')
          .setDescription('Yeni bir kullanıcı whitelist sistemine başarıyla kaydedildi.')
          .addFields(
            { name: '👤 Hedef Kullanıcı', value: `**${target.user.tag}**\n<@${target.id}>\n\`${target.id}\``, inline: true },
            { name: '👮 İşlemi Yapan', value: `**${user.tag}**\n<@${user.id}>\n\`${user.id}\``, inline: true },
            { name: '🔑 Steam Hex ID', value: `\`${hexId}\``, inline: true },
            { name: '🔗 Steam Profil', value: `[Steam Profiline Git](${steamLink})`, inline: true },
            { name: '🏷️ Verilen Rol', value: whitelistRole ? `<@&${whitelistRole.id}>` : 'Rol bulunamadı', inline: true },
            { name: '🗑️ Kaldırılan Rol', value: kayitsizRole && target.roles.cache.has(kayitsizRole.id) ? `<@&${kayitsizRole.id}>` : 'Kayıtsız rolü yok', inline: true },
            { name: '📝 İsim Değişikliği', value: '`IC ISIM` olarak güncellendi', inline: true },
            { name: '📍 İşlem Kanalı', value: `<#${interaction.channel.id}>`, inline: true },
            { name: '⏰ İşlem Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '📊 İşlem Detayları', value: '```\n✅ Whitelist rolü eklendi\n❌ Kayıtsız rolü kaldırıldı\n🏷️ İsim güncellendi\n💾 Veritabanına kaydedildi\n```', inline: false }
          )
          .setThumbnail(target.user.displayAvatarURL({ dynamic: true, size: 256 }))
          .setFooter({ 
            text: `${guild.name} • Whitelist Kayıt Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        try {
          await detayliLogKanal.send({ embeds: [detayliEmbed] });
          console.log(`Detaylı whitelist log gönderildi: ${target.user.tag} -> ${detayliLogKanalId}`);
        } catch (logError) {
          console.error('Detaylı log gönderme hatası:', logError);
        }
      } else {
        console.warn(`Detaylı log kanalı bulunamadı: ${detayliLogKanalId}`);
      }

      // Steam hex verilerini data/steamHex.json dosyasına kaydet
      const steamHexPath = path.join(__dirname, '../../data/steamHex.json');
      let steamHexData = { approved_hex: {}, metadata: { created: "2025-10-21", version: "1.0.0", description: "Onaylanmış Steam Hex verileri - Discord kullanıcı ID'si ile eşleştirilmiş" } };
      
      try {
        if (fs.existsSync(steamHexPath)) {
          steamHexData = JSON.parse(fs.readFileSync(steamHexPath, 'utf8'));
        }
      } catch (error) {
        console.error('Steam hex dosyası okuma hatası:', error);
      }

      // Steam hex verisini kullanıcı ID'si ile kaydet
      steamHexData.approved_hex[target.id] = {
        steamHex: hexId,
        steamLink: steamLink,
        approvedBy: user.id,
        approvedAt: new Date().toISOString(),
        status: "approved"
      };

      try {
        fs.writeFileSync(steamHexPath, JSON.stringify(steamHexData, null, 2));
        console.log(`Steam hex kaydedildi: ${target.id} -> ${hexId}`);
      } catch (error) {
        console.error('Steam hex dosyası yazma hatası:', error);
      }

      // Whitelist dosyasına kaydet
      const logData = {
        timestamp: new Date().toISOString(),
        executor: {
          id: user.id,
          tag: user.tag
        },
        target: {
          id: target.id,
          tag: target.user.tag
        },
        hexId: hexId,
        steamLink: steamLink
      };

      const logPath = path.join(__dirname, '../../db/whitelistLogs.json');
      let logs = [];
      
      try {
        if (fs.existsSync(logPath)) {
          logs = JSON.parse(fs.readFileSync(logPath, 'utf8'));
        }
      } catch (error) {
        console.error('Log dosyası okuma hatası:', error);
        logs = [];
      }

      logs.push(logData);
      
      try {
        fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
      } catch (error) {
        console.error('Log dosyası yazma hatası:', error);
      }

      await interaction.editReply({ 
        content: `✅ **${texts.success}!**\n\n` +
                `🎯 **Hedef:** ${target.user.tag}\n` +
                `🔑 **Hex ID:** \`${hexId}\`\n` +
                `🔗 **Steam:** [Profil](${steamLink})\n` +
                `👑 **Yetkili:** ${user.tag}\n\n` +
                `📝 **Yapılan işlemler:**\n` +
                `• ✅ Whitelist rolü eklendi\n` +
                `• ❌ Kayıtsız rolü kaldırıldı\n` +
                `• 🏷️ İsim değiştirildi\n` +
                `• 📊 Log kaydedildi`
      });

    } catch (error) {
      console.error('Whitelist işlemi sırasında hata:', error);
      
      const errorMessage = error.message || 'Bilinmeyen hata';
      
      await interaction.editReply({
        content: `❌ **Whitelist işlemi başarısız!**\n\n` +
                `**Hata:** ${errorMessage}\n\n` +
                `🔧 **Çözüm önerileri:**\n` +
                `• Bot izinlerini kontrol edin\n` +
                `• Rol ID'lerini kontrol edin\n` +
                `• Hedef kullanıcının sunucuda olduğunu kontrol edin`
      });
    }
  }
};






