// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-durum')
        .setDescription('Botun durumunu ve yetkilerini kontrol et')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        
        const guild = interaction.guild;
        const botMember = guild.members.me;
        
        // Bot yetkilerini kontrol et
        const permissions = botMember.permissions;
        const requiredPerms = [
            'ViewChannels',
            'SendMessages',
            'ManageChannels',
            'ManageRoles',
            'ReadMessageHistory',
            'EmbedLinks',
            'AttachFiles',
            'UseExternalEmojis'
        ];
        
        let permStatus = '';
        requiredPerms.forEach(perm => {
            const hasPerm = permissions.has(PermissionFlagsBits[perm]);
            permStatus += `${hasPerm ? '✅' : '❌'} ${perm}\n`;
        });
        
        // Kanal erişimi kontrol et
        let channelAccess = '';
        const importantChannels = [
            { name: 'Ticket Kanalı', id: null }, // Genel kontrol
            { name: 'Log Kanalı', id: null }     // Genel kontrol
        ];
        
        // Ticket config varsa kontrol et
        try {
            const ticketUtil = require('../utils/ticketUtil');
            const config = ticketUtil.getConfig();
            if (config) {
                if (config.channelId) {
                    const ticketChannel = guild.channels.cache.get(config.channelId);
                    channelAccess += `${ticketChannel ? '✅' : '❌'} Ticket Panel Kanalı (${config.channelId})\n`;
                }
                if (config.logChannelId) {
                    const logChannel = guild.channels.cache.get(config.logChannelId);
                    channelAccess += `${logChannel ? '✅' : '❌'} Log Kanalı (${config.logChannelId})\n`;
                }
                if (config.categoryId) {
                    const categoryChannel = guild.channels.cache.get(config.categoryId);
                    channelAccess += `${categoryChannel ? '✅' : '❌'} Ticket Kategorisi (${config.categoryId})\n`;
                }
            } else {
                channelAccess = '❌ Ticket sistemi ayarlanmamış';
            }
        } catch (error) {
            channelAccess = `❌ Ticket config hatası: ${error.message}`;
        }
        
        // Rol erişimi kontrol et
        let roleAccess = '';
        try {
            const ticketUtil = require('../utils/ticketUtil');
            const config = ticketUtil.getConfig();
            if (config) {
                if (config.supportRoleId) {
                    const supportRole = guild.roles.cache.get(config.supportRoleId);
                    roleAccess += `${supportRole ? '✅' : '❌'} Destek Ekibi Rolü (${config.supportRoleId})\n`;
                }
                if (config.adminRoleId) {
                    const adminRole = guild.roles.cache.get(config.adminRoleId);
                    roleAccess += `${adminRole ? '✅' : '❌'} Admin Rolü (${config.adminRoleId})\n`;
                }
            } else {
                roleAccess = '❌ Ticket sistemi ayarlanmamış';
            }
        } catch (error) {
            roleAccess = `❌ Rol config hatası: ${error.message}`;
        }
        
        // Bot bilgileri
        const botInfo = new EmbedBuilder()
            .setColor(0x3498DB)
            .setTitle('🤖 Bot Durum Raporu')
            .setDescription(`**Bot:** ${botMember.user.tag}\n**Sunucu:** ${guild.name}`)
            .addFields(
                { name: '🔐 Bot Yetkileri', value: permStatus || 'Yetki bulunamadı', inline: false },
                { name: '📁 Kanal Erişimi', value: channelAccess || 'Kanal bulunamadı', inline: false },
                { name: '👥 Rol Erişimi', value: roleAccess || 'Rol bulunamadı', inline: false },
                { name: '📊 Sistem Bilgileri', value: 
                    `• Ping: ${interaction.client.ws.ping}ms\n• Uptime: ${Math.floor(interaction.client.uptime / 1000 / 60)} dakika\n• Komut sayısı: ${interaction.client.commands.size}`, 
                    inline: false }
            )
            .setThumbnail(botMember.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
        
        await interaction.editReply({ embeds: [botInfo] });
    },
};





