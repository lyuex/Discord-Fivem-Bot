// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Collection } = require('discord.js');
const lyuex = require('../../lyuex.json');
const GiveawayManager = require('../utils/giveawayManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('çekiliş')
    .setDescription('🎉 Gelişmiş çekiliş sistemi - Özelleştirilebilir parametreler')
    .addStringOption(opt =>
      opt.setName('ödül')
         .setDescription('🎁 Çekiliş ödülü (max 256 karakter)')
         .setRequired(true)
         .setMaxLength(256))
    .addIntegerOption(opt =>
      opt.setName('kazanan_sayısı')
         .setDescription('🏆 Kaç kişi kazanacak? (1-50 arası)')
         .setRequired(true)
         .setMinValue(1)
         .setMaxValue(50))
    .addIntegerOption(opt =>
      opt.setName('süre')
         .setDescription('⏰ Çekiliş süresi (dakika cinsinden, 1-10080 arası)')
         .setRequired(true)
         .setMinValue(1)
         .setMaxValue(10080))
    .addChannelOption(opt =>
      opt.setName('kanal')
         .setDescription('📍 Çekilişin yapılacağı kanal (varsayılan: mevcut kanal)')
         .setRequired(false))
    .addStringOption(opt =>
      opt.setName('açıklama')
         .setDescription('📝 Çekiliş açıklaması (opsiyonel)')
         .setRequired(false)
         .setMaxLength(1000))
    .addStringOption(opt =>
      opt.setName('sponsor')
         .setDescription('🏢 Sponsor/Düzenleyen (opsiyonel)')
         .setRequired(false)
         .setMaxLength(100))
    .addRoleOption(opt =>
      opt.setName('gerekli_rol')
         .setDescription('🎭 Katılım için gerekli rol (opsiyonel)')
         .setRequired(false))
    .addRoleOption(opt =>
      opt.setName('bonus_rol1')
         .setDescription('🌟 2x şans verilecek özel rol (opsiyonel)')
         .setRequired(false))
    .addRoleOption(opt =>
      opt.setName('bonus_rol2')
         .setDescription('🌟 3x şans verilecek özel rol (opsiyonel)')
         .setRequired(false))
    .addBooleanOption(opt =>
      opt.setName('dm_bildirim')
         .setDescription('📱 Kazananlara DM ile bildirim gönder (varsayılan: true)')
         .setRequired(false))
    .addRoleOption(opt =>
      opt.setName('ödül_rolü')
         .setDescription('🎗️ Kazananlara otomatik verilecek rol (opsiyonel)')
         .setRequired(false))
    .addStringOption(opt =>
      opt.setName('resim_url')
         .setDescription('🖼️ Çekiliş için özel görsel URL (opsiyonel)')
         .setRequired(false)),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      // Yetki kontrolü - Daha detaylı
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                           member.permissions.has('ManageGuild') ||
                           member.permissions.has('Adlyuexstrator');
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Kurucu rolü\n' +
                  '• Sunucuyu Yönet yetkisi\n' +
                  '• Yönetici yetkisi' 
        });
      }

      // Parametreleri al ve validate et
      const ödül = interaction.options.getString('ödül');
      const kazananSayısı = interaction.options.getInteger('kazanan_sayısı');
      const süreInput = interaction.options.getInteger('süre'); // dakika
      const targetChannel = interaction.options.getChannel('kanal') || interaction.channel;
      const açıklama = interaction.options.getString('açıklama');
      const sponsor = interaction.options.getString('sponsor');
      const gerekliRol = interaction.options.getRole('gerekli_rol');
      const dmBildirim = interaction.options.getBoolean('dm_bildirim') ?? true;
      const ödülRolü = interaction.options.getRole('ödül_rolü');
      const resimUrl = interaction.options.getString('resim_url');
      const bonusRol1 = interaction.options.getRole('bonus_rol1'); // 2x şans
      const bonusRol2 = interaction.options.getRole('bonus_rol2'); // 3x şans
      
      const süre = süreInput * 60; // dakikayı saniyeye çevir

      // Kanal izin kontrolü
      if (!targetChannel.permissionsFor(interaction.guild.members.me).has(['SendMessages', 'EmbedLinks', 'AddReactions'])) {
        return await interaction.editReply({
          content: '❌ **Hata!** Belirtilen kanala mesaj gönderme, embed gönderme veya reaksiyon ekleme iznim yok!'
        });
      }

      // Başlangıç ve bitiş zamanları
      const startTime = Date.now();
      const endTimestamp = startTime + süre * 1000;
      const participants = new Collection();
      
      // Bonus rolleri için veritabanı formatında kayıt
      const bonusRolesData = [];
      if (bonusRol1) {
        bonusRolesData.push({
          roleId: bonusRol1.id,
          roleName: bonusRol1.name,
          multiplier: 2
        });
      }
      if (bonusRol2) {
        bonusRolesData.push({
          roleId: bonusRol2.id,
          roleName: bonusRol2.name,
          multiplier: 3
        });
      }

      // Gelişmiş Embed oluşturucu
      const createEmbed = (remainingSec, participantCount = 0) => {
        const hours = Math.floor(remainingSec / 3600);
        const mins = Math.floor((remainingSec % 3600) / 60);
        const secs = remainingSec % 60;
        
        let timeStr;
        if (hours > 0) {
          timeStr = `${hours}s ${mins}d ${secs}sn`;
        } else if (mins > 0) {
          timeStr = `${mins}d ${secs}sn`;
        } else {
          timeStr = `${secs}sn`;
        }

        const embed = new EmbedBuilder()
          .setColor(remainingSec > 60 ? '#FFD700' : '#FF6B6B')
          .setAuthor({ 
            name: `${interaction.user.tag} tarafından düzenlenen çekiliş`,
            iconURL: interaction.user.displayAvatarURL({ dynamic: true })
          })
          .setTitle('🎉 AKTİF ÇEKİLİŞ 🎉')
          .setDescription(
            `**🎁 Ödül:** ${ödül}\n` +
            `**🏆 Kazanan Sayısı:** ${kazananSayısı} kişi\n` +
            `**⏰ Kalan Süre:** ${timeStr}\n` +
            `**👥 Katılımcı:** ${participantCount} kişi\n` +
            `**📅 Başlangıç:** <t:${Math.floor(startTime / 1000)}:R>\n` +
            `**🏁 Bitiş:** <t:${Math.floor(endTimestamp / 1000)}:F>\n\n` +
            (açıklama ? `**📝 Açıklama:**\n${açıklama}\n\n` : '') +
            (gerekliRol ? `**🎭 Gerekli Rol:** ${gerekliRol}\n\n` : '') +
            (ödülRolü ? `**🎗️ Ödül Rolü:** ${ödülRolü}\n\n` : '') +
            (bonusRol1 || bonusRol2 ? `**🌟 Bonus Şans Rolleri:**\n${bonusRol1 ? `• ${bonusRol1} (2x şans)\n` : ''}${bonusRol2 ? `• ${bonusRol2} (3x şans)\n` : ''}\n` : '') +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🎟️ **Katılmak için** \`Katıl\` butonuna tıklayın!\n` +
            `❌ **Çıkmak için** \`Çık\` butonuna tıklayın!`
          )
          .setFooter({ 
            text: sponsor ? `${sponsor} sponsorluğunda • ${lyuex.server.serverismi}` : `${lyuex.server.serverismi} • Çekiliş Sistemi`,
            iconURL: interaction.guild.iconURL({ dynamic: true })
          })
          .setTimestamp(endTimestamp);
          
        // Add custom image if URL provided
        if (resimUrl && resimUrl.match(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)$/i)) {
          embed.setImage(resimUrl);
        }
          
        if (remainingSec <= 60) {
          embed.addFields({ 
            name: '🚨 SON DAKİKA!', 
            value: 'Çekiliş yakında sona erecek!', 
            inline: false 
          });
        }
        
        return embed;
      };

      // Gelişmiş Button Row
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('çekiliş_katıl')
            .setLabel('🎟️ Katıl')
            .setStyle(ButtonStyle.Success)
            .setEmoji('🎟️'),
          new ButtonBuilder()
            .setCustomId('çekiliş_çık')
            .setLabel('❌ Çık')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('❌'),
          new ButtonBuilder()
            .setCustomId('çekiliş_katılımcılar')
            .setLabel('👥 Katılımcılar')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('👥')
        );

      // Çekiliş mesajını oluştur
      const giveawayMsg = await targetChannel.send({
        content: `🎉 **YENİ ÇEKİLİŞ!** 🎉\n${gerekliRol ? `\n⚠️ **Dikkat:** Bu çekilişe katılmak için ${gerekliRol} rolüne sahip olmalısınız!` : ''}`,
        embeds: [createEmbed(süre, 0)],
        components: [row]
      });
      
      // Veritabanına çekiliş bilgilerini kaydet
      try {
        await GiveawayManager.createGiveaway({
          messageId: giveawayMsg.id,
          channelId: targetChannel.id,
          guildId: interaction.guild.id,
          hostId: interaction.user.id,
          prize: ödül,
          winnerCount: kazananSayısı,
          startTime: new Date(startTime),
          endTime: new Date(endTimestamp),
          status: 'active',
          participants: [],
          bonusRoles: bonusRolesData,
          requiredRoleId: gerekliRol ? gerekliRol.id : null,
          rewardRoleId: ödülRolü ? ödülRolü.id : null,
          imageUrl: resimUrl || null,
          description: açıklama || null,
          sponsor: sponsor || null,
          dmWinners: dmBildirim
        });
      } catch (dbError) {
        console.error('Çekiliş veritabanı kayıt hatası:', dbError);
        // Veritabanı hatası olsa bile çekilişi sürdür
      }

      // Başlangıç bildirimi
      await interaction.editReply({
        content: `✅ **Çekiliş başarıyla başlatıldı!**\n\n` +
                `📍 **Kanal:** ${targetChannel}\n` +
                `🎁 **Ödül:** ${ödül}\n` +
                `⏰ **Süre:** ${süreInput} dakika\n` +
                `🏆 **Kazanan:** ${kazananSayısı} kişi\n` +
                (ödülRolü ? `🎗️ **Ödül Rolü:** ${ödülRolü.name}\n` : '') +
                (bonusRol1 ? `🌟 **Bonus Rol 1:** ${bonusRol1.name} (2x şans)\n` : '') +
                (bonusRol2 ? `🌟 **Bonus Rol 2:** ${bonusRol2.name} (3x şans)\n` : '') +
                (resimUrl ? `🖼️ **Özel Görsel:** Eklendi\n` : '') +
                `🔗 **Mesaj:** [Çekilişe Git](${giveawayMsg.url})`
      });

      // Süre bitimine kadar düzenli güncelleme
      const updateInterval = süre > 300 ? 30000 : 10000; // 5dk'dan uzunsa 30sn, kısaysa 10sn
      const interval = setInterval(() => {
        const remaining = Math.max(0, Math.ceil((endTimestamp - Date.now()) / 1000));
        if (remaining <= 0) {
          clearInterval(interval);
          return;
        }
        giveawayMsg.edit({ 
          embeds: [createEmbed(remaining, participants.size)] 
        }).catch(console.error);
      }, updateInterval);

      // Button Collector
      const collector = giveawayMsg.createMessageComponentCollector({
        filter: i => ['çekiliş_katıl', 'çekiliş_çık', 'çekiliş_katılımcılar'].includes(i.customId),
        time: süre * 1000
      });

      collector.on('collect', async btn => {
        const uid = btn.user.id;
        const user = btn.user;
        
        // Gerekli rol kontrolü
        if (gerekliRol && !btn.member.roles.cache.has(gerekliRol.id)) {
          return await btn.reply({ 
            content: `❌ **Yetersiz Rol!** Bu çekilişe katılmak için ${gerekliRol} rolüne sahip olmalısınız!`, 
            ephemeral: true 
          });
        }
        
        // Bonus rolleri kontrolü ve gösterimi
        let bonusMultiplier = 1;
        let bonusRolInfo = '';
        
        if (bonusRol1 && btn.member.roles.cache.has(bonusRol1.id)) {
          bonusMultiplier = 2;
          bonusRolInfo = `\n🌟 **Bonus:** ${bonusRol1.name} rolüne sahip olduğunuz için **2x** şans`;
        }
        
        if (bonusRol2 && btn.member.roles.cache.has(bonusRol2.id)) {
          bonusMultiplier = 3; // Daha yüksek bonus öncelikli
          bonusRolInfo = `\n🌟 **Bonus:** ${bonusRol2.name} rolüne sahip olduğunuz için **3x** şans`;
        }

        if (btn.customId === 'çekiliş_katıl') {
          if (participants.has(uid)) {
            return await btn.reply({ 
              content: '⚠️ **Zaten katıldınız!** Bu çekilişe daha önce katılmışsınız.', 
              ephemeral: true 
            });
          }
          
          // Bonus uygulaması için katılımcı bilgilerini sakla
          participants.set(uid, { 
            user, 
            multiplier: bonusMultiplier, 
            roles: btn.member.roles.cache.map(r => r.id)
          });
          
          // Veritabanında da güncelleyelim
          try {
            await GiveawayManager.updateParticipant(
              giveawayMsg.id,
              uid,
              user.tag,
              bonusMultiplier,
              true // katılma durumu
            );
          } catch (dbError) {
            console.error('Katılımcı güncelleme hatası:', dbError);
            // Veritabanı hatası olsa bile devam et
          }
          
          await btn.reply({ 
            content: `✅ **Başarılı!** Çekilişe katıldınız!\n🎁 **Ödül:** ${ödül}\n👥 **Toplam Katılımcı:** ${participants.size}${bonusRolInfo}`, 
            ephemeral: true 
          });
          
        } else if (btn.customId === 'çekiliş_çık') {
          if (!participants.has(uid)) {
            return await btn.reply({ 
              content: '⚠️ **Zaten kayıtlı değilsiniz!** Bu çekilişe katılmamışsınız.', 
              ephemeral: true 
            });
          }
          
          participants.delete(uid);
          
          // Veritabanında da güncelleyelim
          try {
            await GiveawayManager.updateParticipant(
              giveawayMsg.id,
              uid,
              user.tag,
              1, // multiplier önemli değil, çıkış yapıyor
              false // çıkma durumu
            );
          } catch (dbError) {
            console.error('Katılımcı çıkarma hatası:', dbError);
            // Veritabanı hatası olsa bile devam et
          }
          
          await btn.reply({ 
            content: `❌ **Çıkış Başarılı!** Çekilişten çıktınız.\n👥 **Kalan Katılımcı:** ${participants.size}`, 
            ephemeral: true 
          });
          
        } else if (btn.customId === 'çekiliş_katılımcılar') {
          if (participants.size === 0) {
            return await btn.reply({ 
              content: '👥 **Henüz katılımcı yok!** Bu çekilişe henüz kimse katılmamış.', 
              ephemeral: true 
            });
          }
          
          const participantList = Array.from(participants.entries())
            .slice(0, 20) // İlk 20 kişi
            .map(([id, data], index) => {
              const multiplier = data.multiplier > 1 ? ` (${data.multiplier}x şans)` : '';
              return `${index + 1}. ${data.user.tag}${multiplier}`;
            })
            .join('\n');
          
          const moreCount = participants.size - 20;
          
          await btn.reply({ 
            content: `👥 **Katılımcı Listesi** (${participants.size} kişi):\n\n\`\`\`\n${participantList}${moreCount > 0 ? `\n... ve ${moreCount} kişi daha` : ''}\n\`\`\``, 
            ephemeral: true 
          });
        }
      });

      collector.on('end', async () => {
        clearInterval(interval);
        
        // Yetersiz katılımcı kontrolü
        if (participants.size < kazananSayısı) {
          const insufficientEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Çekiliş İptal Edildi')
            .setDescription(
              `**🎁 Ödül:** ${ödül}\n` +
              `**👥 Gereken Katılımcı:** ${kazananSayısı}\n` +
              `**📊 Mevcut Katılımcı:** ${participants.size}\n\n` +
              `⚠️ **Yeterli katılımcı olmadığı için çekiliş iptal edildi.**`
            )
            .setFooter({ 
              text: `${lyuex.server.serverismi} • Çekiliş İptal`,
              iconURL: interaction.guild.iconURL({ dynamic: true })
            })
            .setTimestamp();
            
          await giveawayMsg.edit({ 
            content: '❌ **ÇEKİLİŞ İPTAL EDİLDİ!**', 
            embeds: [insufficientEmbed], 
            components: [] 
          });
          
          // Veritabanında çekilişi iptal olarak işaretle
          try {
            await GiveawayManager.cancelGiveaway(
              giveawayMsg.id, 
              `Yeterli katılımcı yok. Gereken: ${kazananSayısı}, Mevcut: ${participants.size}`
            );
          } catch (dbError) {
            console.error('Çekiliş iptal veritabanı hatası:', dbError);
            // Veritabanı hatası olsa bile devam et
          }
          
          return;
        }

        // Weighted selection - Bonus giriş şansları için geliştirilmiş algoritma
        const weightedParticipants = [];
        let totalEntries = 0;
        
        // Ağırlıklı katılımcı listesi oluştur
        for (const [userId, participantData] of participants.entries()) {
          const multiplier = participantData.multiplier || 1;
          
          // Her katılımcı için birden fazla giriş ekle
          for (let i = 0; i < multiplier; i++) {
            weightedParticipants.push({
              userId,
              user: participantData.user
            });
          }
          
          totalEntries += multiplier;
        }
        
        console.log(`Toplam katılımcı: ${participants.size}, Toplam giriş: ${totalEntries}`);
        
        // Kazananları seç
        const winners = [];
        const selectedUserIds = new Set();
        
        // Her kazanan için rastgele seçim yap
        while (winners.length < kazananSayısı && selectedUserIds.size < participants.size) {
          const randomIndex = Math.floor(Math.random() * weightedParticipants.length);
          const selectedEntry = weightedParticipants[randomIndex];
          
          // Aynı kullanıcı birden fazla kazanamasın
          if (!selectedUserIds.has(selectedEntry.userId)) {
            selectedUserIds.add(selectedEntry.userId);
            winners.push(selectedEntry.user);
            
            // Debug için
            const participant = participants.get(selectedEntry.userId);
            console.log(`Kazanan seçildi: ${selectedEntry.user.tag}, Bonus: ${participant.multiplier}x`);
          }
        }

        // Sonuç embed'i
        const resultEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('🏆 ÇEKİLİŞ TAMAMLANDI! 🏆')
          .setDescription(
            `**🎁 Ödül:** ${ödül}\n` +
            `**👥 Toplam Katılımcı:** ${participants.size} kişi\n` +
            `**�️ Toplam Giriş Hakkı:** ${weightedParticipants.length}\n` +
            `**�🏆 Kazanan Sayısı:** ${winners.length} kişi\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `**🎉 KAZANANLAR:**\n` +
            winners.map((winner, index) => `${index + 1}. ${winner} (${winner.tag})`).join('\n') +
            `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            (sponsor ? `\n💼 **Sponsor:** ${sponsor}` : '') +
            `\n🎊 **Tebrikler kazananlara!**`
          )
          .setFooter({ 
            text: `${lyuex.server.serverismi} • Çekiliş Tamamlandı`,
            iconURL: interaction.guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        // Reroll butonu ekle
        const rerollButton = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`çekiliş_reroll_${giveawayMsg.id}`)
              .setLabel('🔄 Yeniden Çekiliş Yap')
              .setStyle(ButtonStyle.Primary)
              .setEmoji('🔄')
          );
          
        await giveawayMsg.edit({ 
          content: `🎉 **ÇEKİLİŞ SONA ERDİ!** 🎉\n${winners.map(w => w).join(' ')} TEBRİKLER!`, 
          embeds: [resultEmbed], 
          components: [rerollButton] 
        });
        
        // Veritabanında çekilişi tamamlandı olarak işaretle
        try {
          await GiveawayManager.completeGiveaway(giveawayMsg.id, winners);
        } catch (dbError) {
          console.error('Çekiliş tamamlama veritabanı hatası:', dbError);
          // Veritabanı hatası olsa bile devam et
        }

        // Otomatik rol ödülü verme
        if (ödülRolü) {
          const rolSuccesses = [];
          const rolErrors = [];
          
          for (const winner of winners) {
            try {
              // Get guild member object for each winner
              const member = await interaction.guild.members.fetch(winner.id);
              if (member) {
                await member.roles.add(ödülRolü);
                rolSuccesses.push(winner.tag);
              }
            } catch (rolError) {
              console.error(`❌ Rol eklenemedi (${winner.tag}):`, rolError.message);
              rolErrors.push(winner.tag);
            }
          }
          
          // Log role assignment results
          if (rolSuccesses.length > 0) {
            console.log(`✅ ${ödülRolü.name} rolü başarıyla eklendi: ${rolSuccesses.join(', ')}`);
          }
          if (rolErrors.length > 0) {
            console.error(`❌ Rol eklenemedi: ${rolErrors.join(', ')}`);
          }
        }
        
        // Kazananlara bildirimler
        if (dmBildirim) {
          for (const [index, winner] of winners.entries()) {
            try {
              const dmEmbed = new EmbedBuilder()
                .setColor(0xFFD700)
                .setTitle('🎉 ÇEKİLİŞ KAZANDINIZ! 🎉')
                .setDescription(
                  `Tebrikler **${winner.tag}**!\n\n` +
                  `**🎁 Kazandığınız Ödül:** ${ödül}\n` +
                  `**🏆 Sıralama:** ${index + 1}. kazanan\n` +
                  `**🏢 Sunucu:** ${interaction.guild.name}\n` +
                  `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
                  (ödülRolü ? `**🎗️ Otomatik Verilen Rol:** ${ödülRolü.name}\n\n` : '') +
                  `🎊 ${ödülRolü ? 'Ek ödülleriniz' : 'Ödülünüzü'} almak için sunucu yöneticileri ile iletişime geçin!`
                )
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ 
                  text: `${lyuex.server.serverismi} • Çekiliş Sistemi`,
                  iconURL: interaction.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();
                
              await winner.send({ embeds: [dmEmbed] });
              console.log(`✅ DM gönderildi: ${winner.tag}`);
            } catch (dmError) {
              console.error(`❌ DM gönderilemedi (${winner.tag}):`, dmError.message);
            }
          }
        }

        // Log kanalına bildirim
        try {
          const logChannelId = lyuex.botSettings?.LOG_CHANNEL_ID;
          if (logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
              const logEmbed = new EmbedBuilder()
                .setColor(0xFFD700)
                .setTitle('📊 Çekiliş Tamamlandı - Log')
                .addFields(
                  { name: '🎁 Ödül', value: ödül, inline: true },
                  { name: '👑 Düzenleyen', value: interaction.user.tag, inline: true },
                  { name: '👥 Katılımcı', value: participants.size.toString(), inline: true },
                  { name: '🏆 Kazananlar', value: winners.map(w => w.tag).join('\n'), inline: false }
                )
                .setTimestamp();
              
              await logChannel.send({ embeds: [logEmbed] });
            }
          }
        } catch (logError) {
          console.error('Log gönderme hatası:', logError);
        }
      });

    } catch (error) {
      console.error('Çekiliş hatası:', error);
      
      const errorMessage = error.message || 'Bilinmeyen hata';
      const replyContent = `❌ **Çekiliş oluşturulurken hata oluştu!**\n\n**Hata:** ${errorMessage}\n\n` +
                          `🔧 **Çözüm önerileri:**\n` +
                          `• Parametreleri kontrol edin\n` +
                          `• Bot izinlerini kontrol edin\n` +
                          `• Kanal erişimini kontrol edin`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: replyContent });
      } else {
        await interaction.reply({ content: replyContent, ephemeral: true });
      }
    }
  }
};






