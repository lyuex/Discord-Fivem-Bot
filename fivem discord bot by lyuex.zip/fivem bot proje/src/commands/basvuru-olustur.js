// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('başvuru-oluştur')
    .setDescription('🎯 Gelişmiş başvuru paneli oluşturur - Çoklu buton desteği')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('📍 Başvuru panelinin gönderileceği kanal')
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText)
    )
    .addStringOption(option =>
      option
        .setName('title')
        .setDescription('📝 Panel başlığı (max 256 karakter)')
        .setRequired(true)
        .setMaxLength(256)
    )
    .addStringOption(option =>
      option
        .setName('description')
        .setDescription('📋 Panel açıklaması (max 2000 karakter)')
        .setRequired(true)
        .setMaxLength(2000)
    )
    .addStringOption(option =>
      option
        .setName('image')
        .setDescription('🖼️ Panel görselinin URL\'si (https:// ile başlamalı)')
        .setRequired(false)
    )
    .addStringOption(option =>
      option
        .setName('content')
        .setDescription('💬 Panel üstündeki mesaj (opsiyonel)')
        .setRequired(false)
        .setMaxLength(2000)
    )
    .addStringOption(option =>
      option
        .setName('yetkilibutonu')
        .setDescription('👑 Yetkili başvuru butonu yazısı')
        .setRequired(false)
        .setMaxLength(80)
    )
    .addStringOption(option =>
      option
        .setName('helperbutonu')
        .setDescription('🆘 Helper başvuru butonu yazısı')
        .setRequired(false)
        .setMaxLength(80)
    )
    .addStringOption(option =>
      option
        .setName('color')
        .setDescription('🎨 Panel rengi (hex: #FF0000 veya isim: red)')
        .setRequired(false)
        .addChoices(
          { name: '🔴 Kırmızı', value: '#FF0000' },
          { name: '🟢 Yeşil', value: '#00FF00' },
          { name: '🔵 Mavi', value: '#0000FF' },
          { name: '🟡 Sarı', value: '#FFFF00' },
          { name: '🟣 Mor', value: '#800080' },
          { name: '🟠 Turuncu', value: '#FFA500' },
          { name: '🩷 Pembe', value: '#FFC0CB' },
          { name: '⚫ Siyah', value: '#000000' },
          { name: '⚪ Beyaz', value: '#FFFFFF' },
          { name: '🌈 Varsayılan', value: '#2F3136' }
        )
    )
    .addStringOption(option =>
      option
        .setName('yetkiliemoji')
        .setDescription('👑 Yetkili butonu emojisi (🎯 veya <:name:id>)')
        .setRequired(false)
    )
    .addStringOption(option =>
      option
        .setName('helperemoji')
        .setDescription('🆘 Helper butonu emojisi (🎯 veya <:name:id>)')
        .setRequired(false)
    )
    .addStringOption(option =>
      option
        .setName('footer')
        .setDescription('📄 Panel alt yazısı (max 2048 karakter)')
        .setRequired(false)
        .setMaxLength(2048)
    ),
  async execute(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      // Parametreleri al
      const channel = interaction.options.getChannel('channel');
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const imageUrl = interaction.options.getString('image');
      const content = interaction.options.getString('content');
      const yetkiliButtonText = interaction.options.getString('yetkilibutonu') || '👑 Yetkili Başvurusu';
      const helperButtonText = interaction.options.getString('helperbutonu') || '🆘 Helper Başvurusu';
      const colorInput = interaction.options.getString('color') || '#2F3136';
      const yetkiliEmoji = interaction.options.getString('yetkiliemoji') || '👑';
      const helperEmoji = interaction.options.getString('helperemoji') || '🆘';
      const footer = interaction.options.getString('footer') || `📋 ${interaction.guild.name} • Başvuru Sistemi`;

      // Validasyon kontrolleri
      if (!channel.permissionsFor(interaction.guild.members.me).has(['SendMessages', 'EmbedLinks'])) {
        return await interaction.editReply({
          content: '❌ **Hata!** Belirtilen kanala mesaj gönderme veya embed gönderme iznim yok!'
        });
      }

      // Resim URL validasyonu
      if (imageUrl && !isValidUrl(imageUrl)) {
        return await interaction.editReply({
          content: '❌ **Geçersiz URL!** Resim URL\'si geçerli bir https:// adresi olmalıdır!\n\n' +
                  '**Doğru format:** `https://imgur.com/resim.png`'
        });
      }

      // Renk validasyonu ve dönüştürme
      let embedColor;
      try {
        embedColor = parseColor(colorInput);
      } catch (error) {
        return await interaction.editReply({
          content: '❌ **Geçersiz Renk!** Renk formatı şunlardan biri olmalıdır:\n\n' +
                  '• **Hex Kodu:** `#FF0000`, `#00FF00`\n' +
                  '• **Renk İsimleri:** `red`, `blue`, `green`\n' +
                  '• **RGB:** `rgb(255, 0, 0)`'
        });
      }

      // Emoji validasyonu
      if (yetkiliEmoji && !isValidEmoji(yetkiliEmoji)) {
        return await interaction.editReply({
          content: '❌ **Geçersiz Yetkili Emojisi!** Emoji formatı şunlardan biri olmalıdır:\n\n' +
                  '• **Unicode:** `🎯`, `👑`, `🆘`\n' +
                  '• **Custom:** `<:name:123456789>`'
        });
      }

      if (helperEmoji && !isValidEmoji(helperEmoji)) {
        return await interaction.editReply({
          content: '❌ **Geçersiz Helper Emojisi!** Emoji formatı şunlardan biri olmalıdır:\n\n' +
                  '• **Unicode:** `🎯`, `👑`, `🆘`\n' +
                  '• **Custom:** `<:name:123456789>`'
        });
      }

      // Gelişmiş Embed oluştur
      const embed = new EmbedBuilder()
        .setTitle(`${title}`)
        .setDescription(`${description}\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                       `📋 **Başvuru Türleri:**\n` +
                       `${yetkiliEmoji} **Yetkili Başvurusu** - Sunucu yönetimi için\n` +
                       `${helperEmoji} **Helper Başvurusu** - Yardım ekibi için\n\n` +
                       `⚠️ **Önemli:** Başvuru yapmadan önce kuralları okuduğunuzdan emin olun!`)
        .setColor(embedColor)
        .setFooter({ 
          text: footer,
          iconURL: interaction.guild.iconURL({ dynamic: true }) || undefined
        })
        .setTimestamp()
        .addFields(
          {
            name: '📊 Başvuru İstatistikleri',
            value: `🔄 **Aktif:** Sürekli açık\n⏱️ **Yanıt Süresi:** 24-48 saat\n📝 **Format:** Otomatik form`,
            inline: true
          },
          {
            name: '🎯 Başvuru Süreci',
            value: `1️⃣ Butona tıkla\n2️⃣ Formu doldur\n3️⃣ Gönder\n4️⃣ Bekle`,
            inline: true
          }
        );

      // Resim ekle (varsa)
      if (imageUrl) {
        embed.setImage(imageUrl);
      }

      // Thumbnail ekle
      if (interaction.guild.iconURL()) {
        embed.setThumbnail(interaction.guild.iconURL({ dynamic: true }));
      }

      // Gelişmiş Butonlar oluştur
      const components = [];
      
      if (yetkiliButtonText && yetkiliButtonText.trim() !== '') {
        const yetkiliButton = new ButtonBuilder()
          .setCustomId('lyuexinmodali')
          .setLabel(yetkiliButtonText)
          .setStyle(ButtonStyle.Primary)
          .setEmoji(yetkiliEmoji);
        components.push(yetkiliButton);
      }

      if (helperButtonText && helperButtonText.trim() !== '') {
        const helperButton = new ButtonBuilder()
          .setCustomId('lyuexinhelpermodali')
          .setLabel(helperButtonText)
          .setStyle(ButtonStyle.Success)
          .setEmoji(helperEmoji);
        components.push(helperButton);
      }

      // Buton yoksa varsayılan butonları ekle
      if (components.length === 0) {
        components.push(
          new ButtonBuilder()
            .setCustomId('lyuexinmodali')
            .setLabel('👑 Yetkili Başvurusu')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('👑'),
          new ButtonBuilder()
            .setCustomId('lyuexinhelpermodali')
            .setLabel('🆘 Helper Başvurusu')
            .setStyle(ButtonStyle.Success)
            .setEmoji('🆘')
        );
      }

      const actionRow = new ActionRowBuilder().addComponents(components);

      // Mesajı gönder
      const message = await channel.send({
        content: content || null,
        embeds: [embed],
        components: [actionRow]
      });

      // Başarılı yanıt
      return await interaction.editReply({
        content: `✅ **Başvuru paneli başarıyla oluşturuldu!**\n\n` +
                `📍 **Kanal:** ${channel}\n` +
                `📝 **Başlık:** ${title}\n` +
                `🔗 **Mesaj ID:** ${message.id}\n\n` +
                `**Panel özellikleri:**\n` +
                `• ${yetkiliEmoji} ${yetkiliButtonText}\n` +
                `• ${helperEmoji} ${helperButtonText}\n` +
                `• 🎨 Renk: ${colorInput}\n` +
                `• 📊 Gelişmiş istatistikler`
      });

    } catch (error) {
      console.error('Başvuru paneli oluşturma hatası:', error);
      
      const errorMessage = getErrorMessage(error);
      
      if (interaction.deferred) {
        return await interaction.editReply({
          content: `❌ **Bir hata oluştu!**\n\n**Hata:** ${errorMessage}\n\n` +
                  `🔧 **Çözüm önerileri:**\n` +
                  `• Kanalın var olduğunu kontrol edin\n` +
                  `• Bot izinlerini kontrol edin\n` +
                  `• Parametreleri tekrar kontrol edin`
        });
      } else {
        return await interaction.reply({
          content: `❌ **Kritik hata oluştu!** ${errorMessage}`,
          ephemeral: true
        });
      }
    }
  }
};

// Yardımcı fonksiyonlar
function isValidUrl(string) {
  try {
    const url = new URL(string);
    return url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function parseColor(colorInput) {
  // Hex renk kontrolü
  if (/^#[0-9A-F]{6}$/i.test(colorInput)) {
    return colorInput;
  }
  
  // RGB formatı kontrolü
  const rgbMatch = colorInput.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
  if (rgbMatch) {
    const [, r, g, b] = rgbMatch;
    if (r <= 255 && g <= 255 && b <= 255) {
      return `#${Number(r).toString(16).padStart(2, '0')}${Number(g).toString(16).padStart(2, '0')}${Number(b).toString(16).padStart(2, '0')}`;
    }
  }
  
  // Renk isimleri
  const colorNames = {
    'red': '#FF0000', 'green': '#00FF00', 'blue': '#0000FF',
    'yellow': '#FFFF00', 'purple': '#800080', 'orange': '#FFA500',
    'pink': '#FFC0CB', 'black': '#000000', 'white': '#FFFFFF',
    'gray': '#808080', 'grey': '#808080', 'cyan': '#00FFFF',
    'magenta': '#FF00FF', 'lime': '#00FF00', 'navy': '#000080'
  };
  
  if (colorNames[colorInput.toLowerCase()]) {
    return colorNames[colorInput.toLowerCase()];
  }
  
  throw new Error('Geçersiz renk formatı');
}

function isValidEmoji(emoji) {
  // Unicode emoji kontrolü
  const unicodeEmojiRegex = /^[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]$/u;
  if (unicodeEmojiRegex.test(emoji)) {
    return true;
  }
  
  // Custom emoji kontrolü
  const customEmojiRegex = /^<:[a-zA-Z0-9_]+:\d+>$/;
  if (customEmojiRegex.test(emoji)) {
    return true;
  }
  
  // Basit karakterler (sayılar, harfler)
  if (/^[a-zA-Z0-9]{1,2}$/.test(emoji)) {
    return true;
  }
  
  return false;
}

function getErrorMessage(error) {
  if (error.code === 50013) return 'Yetersiz izinler!';
  if (error.code === 50001) return 'Kanala erişim yok!';
  if (error.code === 10003) return 'Kanal bulunamadı!';
  if (error.code === 50035) return 'Geçersiz form verisi!';
  return error.message || 'Bilinmeyen hata!';
}





