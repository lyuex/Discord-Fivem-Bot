// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const ModerationManager = require('../utils/moderationManager');
const lyuex = require('../../lyuex.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('🔇 Kullanıcıyı susturur (chat mute)')
    .addUserOption(option =>
      option.setName('kullanıcı')
        .setDescription('👤 Susturulacak kullanıcı')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('sebep')
        .setDescription('📝 Mute sebebi')
        .setRequired(false)
        .setMaxLength(500))
    .addIntegerOption(option =>
      option.setName('süre')
        .setDescription('⏰ Mute süresi (dakika cinsinden)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(525600)) // 1 yıl max
    .addStringOption(option =>
      option.setName('süre_birimi')
        .setDescription('📅 Süre birimi (hızlı seçim)')
        .setRequired(false)
        .addChoices(
          { name: '5 dakika', value: '5' },
          { name: '10 dakika', value: '10' },
          { name: '30 dakika', value: '30' },
          { name: '1 saat', value: '60' },
          { name: '2 saat', value: '120' },
          { name: '6 saat', value: '360' },
          { name: '12 saat', value: '720' },
          { name: '1 gün', value: '1440' },
          { name: '3 gün', value: '4320' },
          { name: '1 hafta', value: '10080' },
          { name: '1 ay', value: '43200' }
        ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    try {
      await interaction.deferReply();

      const targetUser = interaction.options.getUser('kullanıcı');
      const reason = interaction.options.getString('sebep') || 'Sebep belirtilmedi';
      let duration = interaction.options.getInteger('süre');
      const durationChoice = interaction.options.getString('süre_birimi');
      const moderator = interaction.user;
      const guild = interaction.guild;

      // Süre birimi seçimi öncelikli
      if (durationChoice && !duration) {
        duration = parseInt(durationChoice);
      }

      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
                          member.permissions.has(PermissionFlagsBits.Administrator);
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu komutu kullanmak için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Moderate Members yetkisi\n' +
                  '• Administrator yetkisi\n' +
                  '• Kurucu rolü'
        });
      }

      // Bot izin kontrolü
      if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return await interaction.editReply({
          content: '❌ **Bot Yetki Hatası!** Botun rol yönetme yetkisi yok!'
        });
      }

      // Hedef kullanıcı kontrolleri
      if (targetUser.id === moderator.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kendinizi susturamazsınız!'
        });
      }

      if (targetUser.id === guild.ownerId) {
        return await interaction.editReply({
          content: '❌ **Hata!** Sunucu sahibini susturamazsınız!'
        });
      }

      if (targetUser.bot && targetUser.id === interaction.client.user.id) {
        return await interaction.editReply({
          content: '❌ **Hata!** Beni susturamazsınız!'
        });
      }

      // Üye kontrolü ve hiyerarşi kontrolü
      let targetMember = null;
      try {
        targetMember = await guild.members.fetch(targetUser.id);
        
        if (!targetMember) {
          return await interaction.editReply({
            content: '❌ **Hata!** Bu kullanıcı sunucuda bulunmuyor!'
          });
        }
        
        // Hiyerarşi kontrolü
        if (targetMember.roles.highest.position >= member.roles.highest.position && guild.ownerId !== moderator.id) {
          return await interaction.editReply({
            content: '❌ **Yetki Hatası!** Bu kullanıcı sizden yüksek veya eşit yetkiye sahip!'
          });
        }

        // Bot'un yetkisi kontrolü
        if (targetMember.roles.highest.position >= guild.members.me.roles.highest.position) {
          return await interaction.editReply({
            content: '❌ **Bot Yetki Hatası!** Bu kullanıcı bottan yüksek veya eşit yetkiye sahip!'
          });
        }

        // Korumalı rol kontrolü
        if (targetMember.roles.cache.has(lyuex.yetkili?.kurucu)) {
          return await interaction.editReply({
            content: '❌ **Korumalı Kullanıcı!** Bu kullanıcı kurucu rolüne sahip!'
          });
        }

      } catch (fetchError) {
        return await interaction.editReply({
          content: '❌ **Hata!** Kullanıcı sunucuda bulunamadı veya erişilemez!'
        });
      }

      // Zaten mute kontrolü
      try {
        const existingMute = await require('../Schemas/ModerationSchema').Mute.findOne({
          userId: targetUser.id,
          guildId: guild.id,
          active: true
        });

        if (existingMute) {
          return await interaction.editReply({
            content: `❌ **Zaten Susturulmuş!** Bu kullanıcı zaten susturulmuş durumda.\n` +
                    `**Case ID:** ${existingMute.caseId}\n` +
                    `**Bitiş:** ${existingMute.endTime ? `<t:${Math.floor(existingMute.endTime.getTime() / 1000)}:F>` : 'Kalıcı'}`
          });
        }
      } catch (muteCheckError) {
        console.log('Mute kontrolü hatası:', muteCheckError);
      }

      // Süre formatı kontrolü
      let durationText = '';
      if (duration) {
        durationText = ModerationManager.formatDuration(duration);
        
        if (duration > 525600) { // 1 yıldan fazla
          return await interaction.editReply({
            content: '❌ **Hata!** Mute süresi en fazla 1 yıl (525600 dakika) olabilir!'
          });
        }
      }

      // Onay embed'i
      const confirmEmbed = new EmbedBuilder()
        .setColor(duration ? '#FFA500' : '#FF6B35')
        .setTitle(`🔇 ${duration ? 'Geçici ' : 'Kalıcı '}Mute Onayı`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Hedef Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📝 Sebep', value: reason, inline: false }
        )
        .setFooter({ 
          text: `${guild.name} • Moderasyon Sistemi`,
          iconURL: guild.iconURL({ dynamic: true })
        })
        .setTimestamp();

      if (duration) {
        confirmEmbed.addFields(
          { name: '⏰ Süre', value: durationText, inline: true },
          { name: '🏁 Bitiş', value: `<t:${Math.floor((Date.now() + duration * 60000) / 1000)}:F>`, inline: true }
        );
      } else {
        confirmEmbed.addFields(
          { name: '⚠️ Tür', value: '**KALICI MUTE**', inline: true },
          { name: '🔓 Açma', value: 'Manuel unmute gerekli', inline: true }
        );
      }

      await interaction.editReply({
        content: '⚠️ **Mute işlemini onaylayın:**',
        embeds: [confirmEmbed]
      });

      // Mute işlemini gerçekleştir
      try {
        const result = await ModerationManager.muteUser({
          guild,
          member: targetMember,
          moderator,
          reason,
          duration
        });

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Mute İşlemi Başarılı')
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setDescription(
            `**👤 Kullanıcı:** ${targetUser.tag}\n` +
            `**📋 Case ID:** ${result.caseId}\n` +
            `**📝 Sebep:** ${reason}\n` +
            (duration ? `**⏰ Süre:** ${durationText}\n` : '**⚠️ Tür:** Kalıcı mute\n') +
            (duration ? `**🏁 Bitiş:** <t:${Math.floor((Date.now() + duration * 60000) / 1000)}:F>\n` : '') +
            `**📱 DM Durumu:** ${result.dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi'}\n` +
            `**📅 Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
            `🔇 **Etki:** Kullanıcı artık mesaj gönderemez ve reaksiyon ekleyemez.`
          )
          .setFooter({ 
            text: `${guild.name} • Moderasyon Sistemi`,
            iconURL: guild.iconURL({ dynamic: true })
          })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [successEmbed]
        });

        // Başarı logu
        console.log(`🔇 Mute başarılı: ${targetUser.tag} (${result.caseId}) - Moderatör: ${moderator.tag} - Süre: ${duration ? durationText : 'Kalıcı'}`);

      } catch (muteError) {
        console.error('Mute işlemi hatası:', muteError);
        
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Mute İşlemi Başarısız')
          .setDescription(
            `**Hata:** ${muteError.message}\n\n` +
            `**Olası Sebepler:**\n` +
            `• Bot rol yönetme yetkisi yok\n` +
            `• Mute rolü oluşturulamadı\n` +
            `• Kullanıcı yetki hiyerarşisi problemi\n` +
            `• Discord API hatası\n` +
            `• Veritabanı bağlantı sorunu\n` +
            `• Kanal izinleri ayarlanamadı`
          )
          .addFields(
            { 
              name: '🔧 Çözüm Önerileri', 
              value: '• Botun rol sırasını kontrol edin\n• Kanal izinlerini kontrol edin\n• Mute rolünü manuel oluşturmayı deneyin', 
              inline: false 
            }
          )
          .setFooter({ text: 'Hatayı yöneticiye bildirin' })
          .setTimestamp();

        await interaction.editReply({
          content: null,
          embeds: [errorEmbed]
        });
      }

    } catch (error) {
      console.error('Mute komutu hatası:', error);
      
      const errorMessage = `❌ **Beklenmeyen Hata!**\n\n**Detay:** ${error.message}`;
      
      if (interaction.deferred) {
        await interaction.editReply({ content: errorMessage });
      } else {
        await interaction.reply({ content: errorMessage, flags: [MessageFlags.Ephemeral] });
      }
    }
  }
};





