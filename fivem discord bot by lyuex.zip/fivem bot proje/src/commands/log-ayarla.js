// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('log-ayarla')
        .setDescription('Gelişmiş log sistemini yönet')
        .addSubcommand(subcommand =>
            subcommand
                .setName('kanal')
                .setDescription('Log kanallarını ayarla')
                .addStringOption(option =>
                    option.setName('tip')
                        .setDescription('Log türü seçin')
                        .setRequired(true)
                        .addChoices(
                            { name: '🏷️ Rol Logları', value: 'role_logs' },
                            { name: '📁 Kanal Logları', value: 'channel_logs' },
                            { name: '👤 Kullanıcı Logları', value: 'user_logs' },
                            { name: '⚖️ Moderasyon Logları', value: 'moderation_logs' },
                            { name: '🔧 Sistem Logları', value: 'system_logs' },
                            { name: '🛡️ Güvenlik Logları', value: 'security_logs' },
                            { name: '🌐 Hepsi', value: 'all' }
                        ))
                .addChannelOption(option =>
                    option.setName('kanal')
                        .setDescription('Log kanalı seçin')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('etkinleştir')
                .setDescription('Log olaylarını etkinleştir/devre dışı bırak')
                .addStringOption(option =>
                    option.setName('olay')
                        .setDescription('Log olayı seçin')
                        .setRequired(true)
                        .addChoices(
                            { name: '🏷️ Rol Ekleme', value: 'role_add' },
                            { name: '🏷️ Rol Silme', value: 'role_remove' },
                            { name: '🏷️ Rol Oluşturma', value: 'role_create' },
                            { name: '🏷️ Rol Güncelleme', value: 'role_update' },
                            { name: '📁 Kanal Oluşturma', value: 'channel_create' },
                            { name: '📁 Kanal Silme', value: 'channel_delete' },
                            { name: '📁 Kanal Güncelleme', value: 'channel_update' },
                            { name: '👤 Kullanıcı Katılma', value: 'user_join' },
                            { name: '👤 Kullanıcı Ayrılma', value: 'user_leave' },
                            { name: '👤 Kullanıcı Güncelleme', value: 'user_update' },
                            { name: '🔨 Ban Ekleme', value: 'ban_add' },
                            { name: '✅ Ban Kaldırma', value: 'ban_remove' },
                            { name: '� Kick İşlemi', value: 'kick' },
                            { name: '�🔊 Sesli Kanal Katılma', value: 'voice_join' },
                            { name: '🔇 Sesli Kanal Ayrılma', value: 'voice_leave' },
                            { name: '🔄 Sesli Kanal Değiştirme', value: 'voice_move' },
                            { name: '💬 Mesaj Silme', value: 'message_delete' },
                            { name: '✏️ Mesaj Düzenleme', value: 'message_edit' },
                            { name: '😀 Emoji İşlemleri', value: 'emoji_events' },
                            { name: '🔗 Davet İşlemleri', value: 'invite_events' },
                            { name: '🌐 Tüm Olayları Aç/Kapat', value: 'all_events' }
                        ))
                .addBooleanOption(option =>
                    option.setName('durum')
                        .setDescription('Etkinleştir veya devre dışı bırak')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('durum')
                .setDescription('Log sisteminin mevcut durumunu göster'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('test')
                .setDescription('Log sistemini test et')
                .addStringOption(option =>
                    option.setName('tip')
                        .setDescription('Test edilecek log türü')
                        .setRequired(true)
                        .addChoices(
                            { name: '🏷️ Rol Logları', value: 'role' },
                            { name: '📁 Kanal Logları', value: 'channel' },
                            { name: '👤 Kullanıcı Logları', value: 'user' },
                            { name: '⚖️ Moderasyon Logları', value: 'moderation' }
                        ))),

    async execute(interaction) {
        // Yetki kontrolü
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Yetkisiz Erişim')
                    .setDescription('Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!')
                    .setTimestamp()
                ],
                flags: [MessageFlags.Ephemeral]
            });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            if (subcommand === 'kanal') {
                const logTip = interaction.options.getString('tip');
                const kanal = interaction.options.getChannel('kanal');

                // lyuex.json güncelle
                const lyuexPath = './lyuex.json';
                const lyuexData = JSON.parse(fs.readFileSync(lyuexPath, 'utf8'));
                
                if (!lyuexData.log) lyuexData.log = {};
                if (!lyuexData.log.channels) lyuexData.log.channels = {};
                
                // "Hepsi" seçeneği kontrolü
                if (logTip === 'all') {
                    const allChannelTypes = ['role_logs', 'channel_logs', 'user_logs', 'moderation_logs', 'system_logs', 'security_logs'];
                    allChannelTypes.forEach(type => {
                        lyuexData.log.channels[type] = kanal.id;
                    });
                } else {
                    lyuexData.log.channels[logTip] = kanal.id;
                }
                
                fs.writeFileSync(lyuexPath, JSON.stringify(lyuexData, null, 4));

                const logTipi = {
                    'role_logs': '🏷️ Rol Logları',
                    'channel_logs': '📁 Kanal Logları',
                    'user_logs': '👤 Kullanıcı Logları',
                    'moderation_logs': '⚖️ Moderasyon Logları',
                    'system_logs': '🔧 Sistem Logları',
                    'security_logs': '🛡️ Güvenlik Logları',
                    'all': '🌐 Tüm Log Türleri'
                };

                const embed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('✅ Log Kanalı Ayarlandı')
                    .setDescription(`**${logTipi[logTip]}** için log kanalı başarıyla ayarlandı!`)
                    .addFields(
                        { name: '📝 Log Türü', value: logTipi[logTip], inline: true },
                        { name: '📁 Kanal', value: `${kanal} (${kanal.id})`, inline: true },
                        { name: '⏰ Ayarlanma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setFooter({ text: 'Log sistemi aktif edildi!' })
                    .setTimestamp();

                // Eğer "hepsi" seçildiyse detay ekle
                if (logTip === 'all') {
                    embed.addFields({
                        name: '📋 Ayarlanan Kanallar',
                        value: '🏷️ Rol Logları\n📁 Kanal Logları\n👤 Kullanıcı Logları\n⚖️ Moderasyon Logları\n🔧 Sistem Logları\n🛡️ Güvenlik Logları',
                        inline: false
                    });
                }

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'etkinleştir') {
                const olay = interaction.options.getString('olay');
                const durum = interaction.options.getBoolean('durum');

                // lyuex.json güncelle
                const lyuexPath = './lyuex.json';
                const lyuexData = JSON.parse(fs.readFileSync(lyuexPath, 'utf8'));
                
                if (!lyuexData.log) lyuexData.log = {};
                if (!lyuexData.log.events) lyuexData.log.events = {};
                
                // "Tüm olaylar" seçeneği kontrolü
                if (olay === 'all_events') {
                    const allEvents = [
                        'role_add', 'role_remove', 'role_create', 'role_delete', 'role_update',
                        'channel_create', 'channel_delete', 'channel_update',
                        'user_join', 'user_leave', 'user_update',
                        'ban_add', 'ban_remove', 'kick', 'timeout',
                        'message_delete', 'message_edit',
                        'voice_join', 'voice_leave', 'voice_move',
                        'emoji_create', 'emoji_delete', 'emoji_update',
                        'invite_create', 'invite_delete'
                    ];
                    allEvents.forEach(event => {
                        lyuexData.log.events[event] = durum;
                    });
                } else if (olay === 'emoji_events') {
                    lyuexData.log.events.emoji_create = durum;
                    lyuexData.log.events.emoji_delete = durum;
                    lyuexData.log.events.emoji_update = durum;
                } else if (olay === 'invite_events') {
                    lyuexData.log.events.invite_create = durum;
                    lyuexData.log.events.invite_delete = durum;
                } else {
                    lyuexData.log.events[olay] = durum;
                }
                
                fs.writeFileSync(lyuexPath, JSON.stringify(lyuexData, null, 4));

                const olayAdi = {
                    'role_add': '🏷️ Rol Ekleme',
                    'role_remove': '🏷️ Rol Silme',
                    'role_create': '🏷️ Rol Oluşturma',
                    'role_update': '🏷️ Rol Güncelleme',
                    'channel_create': '📁 Kanal Oluşturma',
                    'channel_delete': '📁 Kanal Silme',
                    'channel_update': '📁 Kanal Güncelleme',
                    'user_join': '👤 Kullanıcı Katılma',
                    'user_leave': '👤 Kullanıcı Ayrılma',
                    'user_update': '👤 Kullanıcı Güncelleme',
                    'ban_add': '🔨 Ban Ekleme',
                    'ban_remove': '✅ Ban Kaldırma',
                    'kick': '👢 Kick İşlemi',
                    'voice_join': '🔊 Sesli Kanal Katılma',
                    'voice_leave': '🔇 Sesli Kanal Ayrılma',
                    'voice_move': '🔄 Sesli Kanal Değiştirme',
                    'message_delete': '💬 Mesaj Silme',
                    'message_edit': '✏️ Mesaj Düzenleme',
                    'emoji_events': '😀 Emoji İşlemleri',
                    'invite_events': '🔗 Davet İşlemleri',
                    'all_events': '🌐 Tüm Log Olayları'
                };

                const embed = new EmbedBuilder()
                    .setColor(durum ? '#00FF00' : '#FF6600')
                    .setTitle(durum ? '✅ Log Olayı Etkinleştirildi' : '⚠️ Log Olayı Devre Dışı Bırakıldı')
                    .setDescription(`**${olayAdi[olay]}** log olayı ${durum ? 'etkinleştirildi' : 'devre dışı bırakıldı'}!`)
                    .addFields(
                        { name: '📝 Olay', value: olayAdi[olay], inline: true },
                        { name: '📊 Durum', value: durum ? '🟢 Etkin' : '🔴 Devre Dışı', inline: true },
                        { name: '⏰ Değiştirilme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setTimestamp();

                // Eğer "tüm olaylar" seçildiyse detay ekle
                if (olay === 'all_events') {
                    embed.addFields({
                        name: '📋 Etkilenen Olaylar',
                        value: '🏷️ Tüm rol işlemleri\n📁 Tüm kanal işlemleri\n👤 Tüm kullanıcı işlemleri\n⚖️ Tüm moderasyon işlemleri\n🔊 Tüm sesli kanal işlemleri\n💬 Mesaj işlemleri\n😀 Emoji işlemleri\n🔗 Davet işlemleri',
                        inline: false
                    });
                }

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'durum') {
                const logConfig = lyuex.log || {};
                
                const kanallar = Object.entries(logConfig.channels || {}).map(([tip, id]) => {
                    const kanal = interaction.guild.channels.cache.get(id);
                    const tipAdi = {
                        'role_logs': '🏷️ Rol',
                        'channel_logs': '📁 Kanal',
                        'user_logs': '👤 Kullanıcı',
                        'moderation_logs': '⚖️ Moderasyon',
                        'system_logs': '🔧 Sistem',
                        'security_logs': '🛡️ Güvenlik'
                    };
                    return `**${tipAdi[tip]}:** ${kanal ? `${kanal}` : `❌ Bulunamadı (${id})`}`;
                }).join('\n') || 'Henüz ayarlanmamış';

                const olaylar = Object.entries(logConfig.events || {}).map(([olay, durum]) => {
                    const olayAdi = {
                        'role_add': 'Rol Ekleme',
                        'role_remove': 'Rol Silme',
                        'channel_create': 'Kanal Oluşturma',
                        'channel_delete': 'Kanal Silme',
                        'user_join': 'Kullanıcı Katılma',
                        'user_leave': 'Kullanıcı Ayrılma'
                    };
                    return `${durum ? '🟢' : '🔴'} ${olayAdi[olay] || olay}`;
                }).join('\n') || 'Henüz ayarlanmamış';

                const embed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle('📊 Log Sistemi Durumu')
                    .setDescription('Mevcut log sistemi yapılandırması')
                    .addFields(
                        { name: '📊 Genel Durum', value: logConfig.enabled ? '🟢 Etkin' : '🔴 Devre Dışı', inline: true },
                        { name: '📁 Log Kanalları', value: kanallar, inline: false },
                        { name: '⚙️ Aktif Olaylar', value: olaylar, inline: false }
                    )
                    .setFooter({ text: 'ZYM CİTY Log Sistemi' })
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'test') {
                const testTip = interaction.options.getString('tip');
                
                const testEmbeds = {
                    'role': new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setTitle('🧪 Rol Log Testi')
                        .setDescription('Bu bir test mesajıdır - Rol log sistemi çalışıyor!')
                        .addFields(
                            { name: '👤 Test Kullanıcı', value: interaction.user.tag, inline: true },
                            { name: '🏷️ Test Rol', value: 'Test Rolü', inline: true },
                            { name: '⏰ Test Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        ),
                    'channel': new EmbedBuilder()
                        .setColor(0x0099FF)
                        .setTitle('🧪 Kanal Log Testi')
                        .setDescription('Bu bir test mesajıdır - Kanal log sistemi çalışıyor!')
                        .addFields(
                            { name: '📁 Test Kanal', value: 'test-kanalı', inline: true },
                            { name: '👮 Test Yetkili', value: interaction.user.tag, inline: true },
                            { name: '⏰ Test Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        ),
                    'user': new EmbedBuilder()
                        .setColor(0xFF6600)
                        .setTitle('🧪 Kullanıcı Log Testi')
                        .setDescription('Bu bir test mesajıdır - Kullanıcı log sistemi çalışıyor!')
                        .addFields(
                            { name: '👤 Test Kullanıcı', value: interaction.user.tag, inline: true },
                            { name: '📊 İşlem', value: 'Test İşlemi', inline: true },
                            { name: '⏰ Test Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        ),
                    'moderation': new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('🧪 Moderasyon Log Testi')
                        .setDescription('Bu bir test mesajıdır - Moderasyon log sistemi çalışıyor!')
                        .addFields(
                            { name: '👮 Test Moderatör', value: interaction.user.tag, inline: true },
                            { name: '⚖️ Test İşlem', value: 'Test Moderasyon İşlemi', inline: true },
                            { name: '⏰ Test Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        )
                };

                // İlgili log kanalına test mesajı gönder
                const kanalTipleri = {
                    'role': 'role_logs',
                    'channel': 'channel_logs',
                    'user': 'user_logs',
                    'moderation': 'moderation_logs'
                };

                const logKanalId = lyuex.log?.channels?.[kanalTipleri[testTip]];
                const logKanal = interaction.guild.channels.cache.get(logKanalId);

                if (logKanal) {
                    await logKanal.send({ embeds: [testEmbeds[testTip]] });
                    
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setColor(0x00FF00)
                            .setTitle('✅ Test Başarılı')
                            .setDescription(`${testTip} log sistemi test edildi! Test mesajı ${logKanal} kanalına gönderildi.`)
                            .setTimestamp()
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                } else {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setColor(0xFF0000)
                            .setTitle('❌ Test Başarısız')
                            .setDescription(`${testTip} log kanalı bulunamadı! Önce log kanalını ayarlayın.`)
                            .setTimestamp()
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            }

        } catch (error) {
            console.error('Log ayarlama hatası:', error);
            
            await interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Hata Oluştu')
                    .setDescription('Log sistemi ayarlanırken bir hata oluştu!')
                    .addFields({ name: 'Hata', value: error.message })
                    .setTimestamp()
                ],
                flags: [MessageFlags.Ephemeral]
            });
        }
    }
};





