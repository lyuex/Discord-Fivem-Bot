// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ActivityType } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('twitch-durum')
        .setDescription('Bot Twitch durumunu ayarla ve yönet')
        .addSubcommand(subcommand =>
            subcommand
                .setName('streaming')
                .setDescription('Twitch streaming durumunu aç')
                .addStringOption(option =>
                    option
                        .setName('yayın-adı')
                        .setDescription('Twitch yayın başlığı')
                        .setRequired(true)
                )
                .addStringOption(option =>
                    option
                        .setName('twitch-url')
                        .setDescription('Twitch kanal URL\'si')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('durdur')
                .setDescription('Twitch streaming durumunu kapat')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Twitch durum kontrol panelini göster')
        ),

    async execute(interaction) {
        // Bot sahipliği kontrolü
        const botOwners = lyuex.botSettings?.botOwners || [];
        if (!botOwners.includes(interaction.user.id)) {
            const yetkisizEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Yetki Hatası')
                .setDescription('Bu komut sadece **Bot Sahipleri** tarafından kullanılabilir!')
                .addFields(
                    { name: '🔐 Sebep', value: 'Bot durum ayarları', inline: true },
                    { name: '👑 Gerekli Yetki', value: 'Bot Sahibi', inline: true },
                    { name: '📝 Not', value: 'Bu işlem bot durumunu değiştirir', inline: false }
                )
                .setFooter({ text: 'LYUEX • Bot Yönetimi' })
                .setTimestamp();

            return interaction.reply({ embeds: [yetkisizEmbed], ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            if (subcommand === 'streaming') {
                await handleStreamingStart(interaction);
            } else if (subcommand === 'durdur') {
                await handleStreamingStop(interaction);
            } else if (subcommand === 'panel') {
                await handleControlPanel(interaction);
            }
        } catch (error) {
            console.error('Twitch durum komutu hatası:', error);
            
            const hataEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Sistem Hatası')
                .setDescription('Twitch durum değişikliği sırasında bir hata oluştu!')
                .addFields(
                    { name: '🔍 Hata Detayı', value: '```' + error.message + '```', inline: false },
                    { name: '💡 Çözüm Önerileri', value: '• Bot izinlerini kontrol edin\n• İnternet bağlantınızı kontrol edin\n• Birkaç saniye bekleyip tekrar deneyin', inline: false }
                )
                .setFooter({ text: 'LYUEX • Hata Sistemi' })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [hataEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [hataEmbed], ephemeral: true });
            }
        }
    }
};

// Streaming başlatma fonksiyonu
async function handleStreamingStart(interaction) {
    const yayinAdi = interaction.options.getString('yayın-adı');
    const twitchUrl = interaction.options.getString('twitch-url') || 'https://twitch.tv/lyuex';

    // Twitch URL validasyonu
    if (!isValidTwitchUrl(twitchUrl)) {
        const hataliUrlEmbed = new EmbedBuilder()
            .setColor(0xFF4444)
            .setTitle('⚠️ Geçersiz Twitch URL')
            .setDescription('Lütfen geçerli bir Twitch URL\'si girin!')
            .addFields(
                { name: '✅ Doğru Format', value: '`https://twitch.tv/kanaladi`', inline: true },
                { name: '❌ Yanlış Format', value: '`twitch.tv/kanal` (https eksik)', inline: true },
                { name: '🔗 Örnek', value: '`https://twitch.tv/lyuex`', inline: false }
            )
            .setFooter({ text: 'LYUEX • Twitch Sistemi' })
            .setTimestamp();

        return interaction.reply({ embeds: [hataliUrlEmbed], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
        // Bot durumunu Twitch streaming olarak ayarla
        await interaction.client.user.setPresence({
            activities: [{
                name: yayinAdi,
                type: ActivityType.Streaming,
                url: twitchUrl
            }],
            status: 'online'
        });

        // Twitch bilgilerini kaydet
        const twitchData = {
            isStreaming: true,
            streamTitle: yayinAdi,
            twitchUrl: twitchUrl,
            startedAt: new Date().toISOString(),
            startedBy: interaction.user.id
        };

        // Dosyaya kaydet
        saveTwitchData(twitchData);

        // Başarı mesajı
        const basariEmbed = new EmbedBuilder()
            .setColor(0x9146FF) // Twitch mor rengi
            .setTitle('🟣 Twitch Streaming Başlatıldı!')
            .setDescription(`Bot artık **Twitch'te yayında** görünüyor!`)
            .addFields(
                { name: '📺 Yayın Başlığı', value: `\`${yayinAdi}\``, inline: true },
                { name: '🔗 Twitch URL', value: `[Yayına Git](${twitchUrl})`, inline: true },
                { name: '👤 Başlatan', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Başlangıç Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
                { name: '🎮 Durum', value: '🟢 **CANLI YAYIN**', inline: true },
                { name: '💡 Not', value: 'Yayın durumu tüm sunucularda görünür', inline: false }
            )
            .setThumbnail('https://static-cdn.jtvnw.net/jtv_user_pictures/8a6381c7-d0c0-4576-b179-38bd5ce1d6af-profile_image-300x300.png')
            .setFooter({ text: 'LYUEX • Twitch Yayını Aktif' })
            .setTimestamp();

        // Kontrol butonları
        const controlButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('twitch_stop_stream')
                    .setLabel('⏹️ Yayını Durdur')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('⏹️'),
                new ButtonBuilder()
                    .setCustomId('twitch_view_stats')
                    .setLabel('📊 Durum Bilgisi')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📊'),
                new ButtonBuilder()
                    .setURL(twitchUrl)
                    .setLabel('🔗 Twitch\'e Git')
                    .setStyle(ButtonStyle.Link)
                    .setEmoji('🔗')
            );

        await interaction.editReply({ 
            embeds: [basariEmbed], 
            components: [controlButtons] 
        });

        // Log kanalına bilgi gönder
        await sendTwitchLog(interaction, 'STREAM_START', yayinAdi, twitchUrl);

    } catch (error) {
        console.error('Streaming başlatma hatası:', error);
        
        const hataEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Streaming Başlatma Hatası')
            .setDescription('Twitch streaming durumu ayarlanamadı!')
            .addFields(
                { name: '🔍 Hata Kodu', value: '```' + (error.code || error.message) + '```', inline: false },
                { name: '💡 Çözüm Önerileri', value: '• Bot izinlerini kontrol edin\n• URL formatını kontrol edin\n• Birkaç saniye bekleyip tekrar deneyin', inline: false }
            )
            .setFooter({ text: 'LYUEX • Hata Sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [hataEmbed] });
    }
}

// Streaming durdurma fonksiyonu
async function handleStreamingStop(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
        // Bot durumunu normal haline döndür
        await interaction.client.user.setPresence({
            activities: [{
                name: lyuex.botSettings.oynuyor,
                type: ActivityType.Competing
            }],
            status: lyuex.botSettings.durum
        });

        // Twitch verilerini temizle
        const twitchData = getTwitchData();
        const streamDuration = twitchData.startedAt ? 
            Math.floor((Date.now() - new Date(twitchData.startedAt).getTime()) / 1000) : 0;

        clearTwitchData();

        // Başarı mesajı
        const basariEmbed = new EmbedBuilder()
            .setColor(0xFF4444)
            .setTitle('⏹️ Twitch Streaming Durduruldu!')
            .setDescription(`Bot artık **normal durum**da görünüyor!`)
            .addFields(
                { name: '📺 Son Yayın', value: `\`${twitchData.streamTitle || 'Bilinmiyor'}\``, inline: true },
                { name: '👤 Durduran', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Durdurma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '⏱️ Yayın Süresi', value: formatDuration(streamDuration), inline: true },
                { name: '🎮 Yeni Durum', value: `🎯 ${lyuex.botSettings.oynuyor}`, inline: true },
                { name: '💡 Not', value: 'Bot normal aktivite durumuna döndü', inline: false }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'LYUEX • Yayın Sonlandırıldı' })
            .setTimestamp();

        await interaction.editReply({ embeds: [basariEmbed] });

        // Log kanalına bilgi gönder
        await sendTwitchLog(interaction, 'STREAM_STOP', twitchData.streamTitle, null, streamDuration);

    } catch (error) {
        console.error('Streaming durdurma hatası:', error);
        
        const hataEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Streaming Durdurma Hatası')
            .setDescription('Twitch streaming durumu durdurulamadı!')
            .addFields(
                { name: '🔍 Hata Kodu', value: '```' + (error.code || error.message) + '```', inline: false }
            )
            .setFooter({ text: 'LYUEX • Hata Sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [hataEmbed] });
    }
}

// Kontrol paneli gösterme fonksiyonu
async function handleControlPanel(interaction) {
    const twitchData = getTwitchData();
    
    const panelEmbed = new EmbedBuilder()
        .setColor(twitchData.isStreaming ? 0x9146FF : 0x36393F)
        .setTitle('🎮 Twitch Durum Kontrol Paneli')
        .setDescription('Bot\'un mevcut Twitch durum bilgileri ve kontrolleri')
        .addFields(
            { name: '📊 Streaming Durumu', value: twitchData.isStreaming ? '🟢 **CANLI YAYIN**' : '🔴 **YAYIN YOK**', inline: true },
            { name: '📺 Mevcut Aktivite', value: interaction.client.user.presence?.activities[0]?.name || 'Bilinmiyor', inline: true },
            { name: '🎯 Aktivite Türü', value: getActivityTypeText(interaction.client.user.presence?.activities[0]?.type), inline: true }
        )
        .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: 'LYUEX • Twitch Panel' })
        .setTimestamp();

    if (twitchData.isStreaming) {
        const streamDuration = Math.floor((Date.now() - new Date(twitchData.startedAt).getTime()) / 1000);
        panelEmbed.addFields(
            { name: '📺 Yayın Başlığı', value: `\`${twitchData.streamTitle}\``, inline: true },
            { name: '🔗 Twitch URL', value: `[Yayına Git](${twitchData.twitchUrl})`, inline: true },
            { name: '⏰ Başlangıç', value: `<t:${Math.floor(new Date(twitchData.startedAt).getTime() / 1000)}:R>`, inline: true },
            { name: '⏱️ Süre', value: formatDuration(streamDuration), inline: true },
            { name: '👤 Başlatan', value: `<@${twitchData.startedBy}>`, inline: true }
        );
    }

    // Kontrol butonları
    const panelButtons = new ActionRowBuilder();
    
    if (twitchData.isStreaming) {
        panelButtons.addComponents(
            new ButtonBuilder()
                .setCustomId('twitch_stop_stream')
                .setLabel('⏹️ Yayını Durdur')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setURL(twitchData.twitchUrl)
                .setLabel('🔗 Twitch\'e Git')
                .setStyle(ButtonStyle.Link)
        );
    } else {
        panelButtons.addComponents(
            new ButtonBuilder()
                .setCustomId('twitch_start_quick')
                .setLabel('▶️ Hızlı Başlat')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('twitch_refresh_panel')
                .setLabel('🔄 Yenile')
                .setStyle(ButtonStyle.Secondary)
        );
    }

    await interaction.reply({ 
        embeds: [panelEmbed], 
        components: [panelButtons], 
        ephemeral: true 
    });
}

// Twitch URL validasyonu
function isValidTwitchUrl(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.hostname === 'twitch.tv' || urlObj.hostname === 'www.twitch.tv';
    } catch {
        return false;
    }
}

// Twitch verilerini kaydetme
function saveTwitchData(data) {
    const dataPath = './data/twitchStatus.json';
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

// Twitch verilerini alma
function getTwitchData() {
    const dataPath = './data/twitchStatus.json';
    try {
        if (fs.existsSync(dataPath)) {
            return JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
        }
    } catch (error) {
        console.error('Twitch data okuma hatası:', error);
    }
    return { isStreaming: false };
}

// Twitch verilerini temizleme
function clearTwitchData() {
    const dataPath = './data/twitchStatus.json';
    const clearedData = { isStreaming: false };
    fs.writeFileSync(dataPath, JSON.stringify(clearedData, null, 2));
}

// Süre formatlama
function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}s ${minutes}d ${secs}s`;
    } else if (minutes > 0) {
        return `${minutes}d ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

// Aktivite türü metni
function getActivityTypeText(type) {
    switch (type) {
        case ActivityType.Playing: return '🎮 Oynuyor';
        case ActivityType.Streaming: return '📺 Yayında';
        case ActivityType.Listening: return '🎵 Dinliyor';
        case ActivityType.Watching: return '👀 İzliyor';
        case ActivityType.Competing: return '🏆 Yarışıyor';
        default: return '❓ Bilinmiyor';
    }
}

// Log mesajı gönderme
async function sendTwitchLog(interaction, action, title, url, duration = null) {
    try {
        const logChannelId = lyuex.log?.channels?.system_logs;
        if (!logChannelId) return;

        const logChannel = interaction.guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const logEmbed = new EmbedBuilder()
            .setColor(action === 'STREAM_START' ? 0x9146FF : 0xFF4444)
            .setTitle(`📺 Twitch ${action === 'STREAM_START' ? 'Yayını Başlatıldı' : 'Yayını Durduruldu'}`)
            .addFields(
                { name: '👤 İşlemi Yapan', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                { name: '🔧 İşlem', value: action === 'STREAM_START' ? 'Yayın Başlatma' : 'Yayın Durdurma', inline: true },
                { name: '📺 Başlık', value: title || 'Bilinmiyor', inline: true }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'LYUEX • Twitch Log' })
            .setTimestamp();

        if (url && action === 'STREAM_START') {
            logEmbed.addFields({ name: '🔗 Twitch URL', value: `[Yayına Git](${url})`, inline: true });
        }

        if (duration && action === 'STREAM_STOP') {
            logEmbed.addFields({ name: '⏱️ Yayın Süresi', value: formatDuration(duration), inline: true });
        }

        await logChannel.send({ embeds: [logEmbed] });
    } catch (error) {
        console.error('Twitch log mesajı gönderme hatası:', error);
    }
}