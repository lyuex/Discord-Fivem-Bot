// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿// src/commands/guvenli.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const db = require('croxydb');

// Güvenli olmayan işlem tracker'ı
const violationTracker = new Map();

module.exports = {
  // Komut tanımı (veriyi commandHandler kullanacak)
  data: new SlashCommandBuilder()
    .setName('güvenli')
    .setDescription('🛡️ Gelişmiş güvenli yönetim sistemi!')
    .addSubcommand(subcommand =>
      subcommand
        .setName('ekle')
        .setDescription('🔒 Güvenli listeye rol veya kullanıcı ekleyin')
        .addRoleOption(option =>
          option
            .setName('rol')
            .setDescription('Güvenli listeye eklenecek rol')
            .setRequired(false)
        )
        .addUserOption(option =>
          option
            .setName('kullanıcı')
            .setDescription('Güvenli listeye eklenecek kullanıcı')
            .setRequired(false)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('liste')
        .setDescription('📋 Güvenli listeyi görüntüleyin')
        .addStringOption(option =>
          option.setName('görünüm')
            .setDescription('Liste görünüm türünü seçin')
            .addChoices(
              { name: '📊 Özet', value: 'ozet' },
              { name: '📋 Detaylı', value: 'detay' },
              { name: '🏷️ Roller', value: 'roller' },
              { name: '👥 Kullanıcılar', value: 'kullanicilar' },
              { name: '📈 Analitik', value: 'analitik' }
            )
            .setRequired(false))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('sil')
        .setDescription('🗑️ Güvenli listeden rol veya kullanıcı kaldırın')
        .addRoleOption(option =>
          option
            .setName('rol')
            .setDescription('Güvenli listeden kaldırılacak rol')
            .setRequired(false)
        )
        .addUserOption(option =>
          option
            .setName('kullanıcı')
            .setDescription('Güvenli listeden kaldırılacak kullanıcı')
            .setRequired(false)
        )
        .addStringOption(option =>
          option.setName('mod')
            .setDescription('Kaldırma modunu seçin')
            .addChoices(
              { name: '⚠️ Güvenli (Onaylı)', value: 'safe' },
              { name: '🔍 Hızlı (Onaysız)', value: 'quick' }
            )
            .setRequired(false))
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('panel')
        .setDescription('🎛️ Güvenli yönetim panelini açın')
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('korunan')
        .setDescription('📋 Korunan işlemlerin listesini göster')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  // Komut çalıştırma fonksiyonu
  async execute(interaction) {
    try {
      // Yetki kontrolü - Admin veya sunucu sahibi
      const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
      const isOwner = interaction.guild.ownerId === interaction.user.id;

      if (!isAdmin && !isOwner) {
        const yetkiEmbed = new EmbedBuilder()
          .setColor(0xFF6B6B)
          .setAuthor({ 
            name: '🔐 Güvenli Sistem • Erişim Engellendi'
          })
          .setTitle('❌ Yetersiz Yetki!')
          .setDescription(`
╭─────────────────────────────────╮
│  🚫 **ERİŞİM ENGELLENDİ**        │
│  Bu sistem sadece yetkililere    │
│  açıktır. Lütfen yetkinizi       │
│  kontrol edin.                   │
╰─────────────────────────────────╯`)
          .addFields(
            { 
              name: '🔑 Gerekli Yetkiler', 
              value: `
\`\`\`diff
+ Administrator yetkisi
+ Sunucu Sahibi
\`\`\``, 
              inline: true 
            },
            { 
              name: '👤 Mevcut Yetkiniz', 
              value: `
\`\`\`yaml
Seviye: ${isOwner ? 'Sunucu Sahibi' : 'Kullanıcı'}
Durum: ${isAdmin ? 'Yeterli' : 'Yetersiz'}
\`\`\``, 
              inline: true 
            },
            {
              name: '💡 Bilgi',
              value: 'Bu sistem sunucu güvenliğini yönetir. Yetkili olduğunuzdan emin olun.',
              inline: false
            }
          )
          .setFooter({ 
            text: `${interaction.guild.name} • Güvenlik Protokolü`, 
            iconURL: interaction.guild.iconURL() || interaction.client.user.displayAvatarURL() 
          })
          .setTimestamp();

        return interaction.reply({ embeds: [yetkiEmbed], ephemeral: true });
      }

      const subcommand = interaction.options.getSubcommand();

      switch (subcommand) {
        case 'ekle':
          await this.handleAdd(interaction);
          break;
        case 'liste':
          await this.handleListView(interaction);
          break;
        case 'sil':
          await this.handleRemove(interaction);
          break;
        case 'korunan':
          await this.handleProtectedActions(interaction);
          break;
        case 'panel':
          await this.handlePanel(interaction);
          break;
        default:
          await this.handlePanel(interaction);
      }

    } catch (error) {
      console.error('Güvenli komutu hatası:', error);

      const errorEmbed = new EmbedBuilder()
        .setColor(0xFF4444)
        .setAuthor({ 
          name: '⚠️ Güvenli Sistem • Sistem Hatası'
        })
        .setTitle('🚨 Beklenmeyen Hata!')
        .setDescription(`
╭─────────────────────────────────╮
│  ⚠️ **SİSTEM HATASI**            │
│  Güvenli sistem işlemi sırasında │
│  beklenmeyen bir hata oluştu.    │
╰─────────────────────────────────╯`)
        .addFields(
          { 
            name: '🔍 Hata Detayları', 
            value: `\`\`\`js\n${error.message}\`\`\``, 
            inline: false 
          },
          {
            name: '🛠️ Önerilen Çözümler',
            value: `
• Komutu tekrar deneyin
• Bot yetkililerini kontrol edin
• Sunucu bağlantısını kontrol edin
            `,
            inline: false
          }
        )
        .setFooter({ 
          text: `Hata Zamanı: ${new Date().toLocaleString('tr-TR')}`, 
          iconURL: interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },

  // Alt komut: Ekleme işlemi
  async handleAdd(interaction) {
    const rol = interaction.options.getRole('rol');
    const kullanıcı = interaction.options.getUser('kullanıcı');

    // Hiçbir seçenek seçilmemişse interaktif panel göster
    if (!rol && !kullanıcı) {
      const helpEmbed = new EmbedBuilder()
        .setColor(0x00D4FF)
        .setAuthor({ 
          name: '🛡️ Güvenli Sistem • Ekleme Rehberi'
        })
        .setTitle('🎯 Güvenli Ekleme İşlemi')
        .setDescription(`
╭─────────────────────────────────╮
│  🔒 **GÜVENLİ EKLEME SİSTEMİ**   │
│  Rol veya kullanıcı eklemek için │
│  aşağıdaki seçenekleri kullanın  │
╰─────────────────────────────────╯`)
        .addFields(
          { 
            name: '🏷️ Rol Ekleme', 
            value: `
\`\`\`yaml
Komut: /güvenli ekle rol:@rol_adı
Örnek: /güvenli ekle rol:@Moderatör
Açıklama: Tüm rol üyelerini güvenli yapar
\`\`\``, 
            inline: true 
          },
          { 
            name: '👤 Kullanıcı Ekleme', 
            value: `
\`\`\`yaml
Komut: /güvenli ekle kullanıcı:@user
Örnek: /güvenli ekle kullanıcı:@TrustedUser
Açıklama: Tek kullanıcıyı güvenli yapar
\`\`\``, 
            inline: true 
          },
          {
            name: '📊 Mevcut İstatistikler',
            value: await this.getStats(interaction.guild.id),
            inline: false
          }
        )
        .setThumbnail('🛡️')
        .setFooter({ 
          text: `${interaction.guild.name} • Güvenli Sistem v2.0`, 
          iconURL: interaction.guild.iconURL() || interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      const buttons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('guvenli_panel')
            .setLabel('🎛️ Yönetim Paneli')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('guvenli_quick_add_role')
            .setLabel('🏷️ Hızlı Rol Ekle')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('guvenli_quick_add_user')
            .setLabel('👤 Hızlı Kullanıcı Ekle')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('guvenli_view_list')
            .setLabel('📋 Listeyi Gör')
            .setStyle(ButtonStyle.Secondary)
        );

      return interaction.reply({ embeds: [helpEmbed], components: [buttons], ephemeral: true });
    }

    // Rol ekleme işlemi
    if (rol) {
      const roleKey = `güvenli_roller_${interaction.guild.id}`;
      let safeRoles = db.get(roleKey) || [];

      // Duplicate kontrolü
      if (safeRoles.includes(rol.id)) {
        const duplicateEmbed = new EmbedBuilder()
          .setColor(0xFFB74D)
          .setAuthor({ 
            name: '⚠️ Güvenli Sistem • Duplicate Kontrolü'
          })
          .setTitle('⚠️ Rol Zaten Listede!')
          .setDescription(`
╭─────────────────────────────────╮
│  🔄 **DUPLICATE TESPIT EDİLDİ**  │
│  Bu rol zaten güvenli listede    │
│  bulunuyor.                      │
╰─────────────────────────────────╯`)
          .addFields(
            { 
              name: '🏷️ Mevcut Rol', 
              value: `
**Rol:** ${rol}
**ID:** \`${rol.id}\`
**Üye Sayısı:** ${rol.members.size}
**Eklendi:** Daha önce
              `, 
              inline: true 
            },
            { 
              name: '📊 Liste Durumu', 
              value: `
**Toplam Rol:** ${safeRoles.length}
**Durum:** Güvenli ✅
**Eylem:** Gereksiz
              `, 
              inline: true 
            }
          )
          .setFooter({ 
            text: 'Bu rol zaten korunuyor • Sistem Durumu: Normal', 
            iconURL: interaction.client.user.displayAvatarURL() 
          })
          .setTimestamp();

        return interaction.reply({ embeds: [duplicateEmbed], ephemeral: true });
      }

      // Rolü ekle
      safeRoles.push(rol.id);
      db.set(roleKey, safeRoles);

      const successEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setAuthor({ 
          name: '✅ Güvenli Sistem • Başarılı İşlem'
        })
        .setTitle('🎉 Güvenli Rol Eklendi!')
        .setDescription(`
╭─────────────────────────────────╮
│  ✅ **BAŞARILI EKLEME**          │
│  Rol güvenli listeye eklendi ve │
│  artık korunuyor!               │
╰─────────────────────────────────╯`)
        .addFields(
          { 
            name: '🏷️ Eklenen Rol', 
            value: `
**Rol:** ${rol}
**ID:** \`${rol.id}\`
**Üye Sayısı:** ${rol.members.size}
**Renk:** ${rol.hexColor}
            `, 
            inline: true 
          },
          { 
            name: '👤 İşlem Bilgileri', 
            value: `
**Ekleyen:** ${interaction.user}
**Zaman:** <t:${Math.floor(Date.now() / 1000)}:F>
**Konum:** ${rol.position}. sıra
            `, 
            inline: true 
          },
          {
            name: '📈 Güncel İstatistikler',
            value: `
**Toplam Güvenli Rol:** ${safeRoles.length}
**Korunan Üye Sayısı:** ${rol.members.size} (bu rolden)
**Güvenlik Seviyesi:** ${this.getSecurityLevel(safeRoles.length)}
            `,
            inline: false
          }
        )
  .setThumbnail(rol.iconURL() || interaction.guild.iconURL({ dynamic: true, size: 128 }) || interaction.client.user.displayAvatarURL())
        .setFooter({ 
          text: `${interaction.guild.name} • Rol Koruması Aktif`, 
          iconURL: interaction.guild.iconURL() || interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      const actionButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('guvenli_view_list')
            .setLabel('📋 Listeyi Görüntüle')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('guvenli_add_more')
            .setLabel('➕ Daha Fazla Ekle')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('guvenli_panel')
            .setLabel('🎛️ Yönetim Paneli')
            .setStyle(ButtonStyle.Primary)
        );

      return interaction.reply({ embeds: [successEmbed], components: [actionButtons] });
    }

    // Kullanıcı ekleme işlemi
    if (kullanıcı) {
      const userKey = `güvenli_kullanıcılar_${interaction.guild.id}`;
      let safeUsers = db.get(userKey) || [];

      // Duplicate kontrolü
      if (safeUsers.includes(kullanıcı.id)) {
        const duplicateEmbed = new EmbedBuilder()
          .setColor(0xFFB74D)
          .setAuthor({ 
            name: '⚠️ Güvenli Sistem • Duplicate Kontrolü'
          })
          .setTitle('⚠️ Kullanıcı Zaten Listede!')
          .setDescription(`
╭─────────────────────────────────╮
│  🔄 **DUPLICATE TESPIT EDİLDİ**  │
│  Bu kullanıcı zaten güvenli     │
│  listede bulunuyor.             │
╰─────────────────────────────────╯`)
          .addFields(
            { 
              name: '👤 Mevcut Kullanıcı', 
              value: `
**Kullanıcı:** ${kullanıcı}
**ID:** \`${kullanıcı.id}\`
**Hesap Yaşı:** ${this.getAccountAge(kullanıcı.createdTimestamp)}
**Durum:** ${kullanıcı.presence?.status || 'Bilinmiyor'}
              `, 
              inline: true 
            },
            { 
              name: '📊 Liste Durumu', 
              value: `
**Toplam Kullanıcı:** ${safeUsers.length}
**Durum:** Güvenli ✅
**Eylem:** Gereksiz
              `, 
              inline: true 
            }
          )
          .setThumbnail(kullanıcı.displayAvatarURL({ dynamic: true }))
          .setFooter({ 
            text: 'Bu kullanıcı zaten korunuyor • Sistem Durumu: Normal', 
            iconURL: interaction.client.user.displayAvatarURL() 
          })
          .setTimestamp();

        return interaction.reply({ embeds: [duplicateEmbed], ephemeral: true });
      }

      // Kullanıcıyı ekle
      safeUsers.push(kullanıcı.id);
      db.set(userKey, safeUsers);

      const successEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setAuthor({ 
          name: '✅ Güvenli Sistem • Başarılı İşlem'
        })
        .setTitle('🎉 Güvenli Kullanıcı Eklendi!')
        .setDescription(`
╭─────────────────────────────────╮
│  ✅ **BAŞARILI EKLEME**          │
│  Kullanıcı güvenli listeye      │
│  eklendi ve artık korunuyor!    │
╰─────────────────────────────────╯`)
        .addFields(
          { 
            name: '👤 Eklenen Kullanıcı', 
            value: `
**Kullanıcı:** ${kullanıcı}
**ID:** \`${kullanıcı.id}\`
**Hesap Yaşı:** ${this.getAccountAge(kullanıcı.createdTimestamp)}
**Son Görülme:** ${kullanıcı.presence?.status || 'Bilinmiyor'}
            `, 
            inline: true 
          },
          { 
            name: '👤 İşlem Bilgileri', 
            value: `
**Ekleyen:** ${interaction.user}
**Zaman:** <t:${Math.floor(Date.now() / 1000)}:F>
**Güvenlik Puanı:** ${this.getSecurityScore(kullanıcı)}
            `, 
            inline: true 
          },
          {
            name: '📈 Güncel İstatistikler',
            value: `
**Toplam Güvenli Kullanıcı:** ${safeUsers.length}
**Güvenlik Seviyesi:** ${this.getSecurityLevel(safeUsers.length)}
**Koruma Durumu:** Aktif 🛡️
            `,
            inline: false
          }
        )
        .setThumbnail(kullanıcı.displayAvatarURL({ dynamic: true, size: 128 }))
        .setFooter({ 
          text: `${interaction.guild.name} • Kullanıcı Koruması Aktif`, 
          iconURL: interaction.guild.iconURL() || interaction.client.user.displayAvatarURL() 
        })
        .setTimestamp();

      const actionButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('guvenli_view_list')
            .setLabel('📋 Listeyi Görüntüle')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('guvenli_add_more')
            .setLabel('➕ Daha Fazla Ekle')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('guvenli_panel')
            .setLabel('🎛️ Yönetim Paneli')
            .setStyle(ButtonStyle.Primary)
        );

      return interaction.reply({ embeds: [successEmbed], components: [actionButtons] });
    }
  },

  // Alt komut: Liste görüntüleme (geliştirilmiş)
  async handleListView(interaction) {
    const viewType = interaction.options.getString('görünüm') || 'ozet';
    const safeRoles = db.get(`güvenli_roller_${interaction.guild.id}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${interaction.guild.id}`) || [];

    // Liste boşsa
    if (safeRoles.length === 0 && safeUsers.length === 0) {
      const emptyEmbed = new EmbedBuilder()
        .setColor(0x607D8B)
        .setAuthor({ name: '📋 Güvenli Sistem • Liste Boş' })
        .setTitle('📝 Güvenli Liste Boş')
        .setDescription(`
╭─────────────────────────────────╮
│  📭 **LİSTE BOŞ**                │
│  Henüz hiç güvenli rol veya     │
│  kullanıcı eklenmemiş.          │
╰─────────────────────────────────╯`)
        .addFields({
          name: '🚀 Hızlı Başlangıç',
          value: `
\`\`\`yaml
1. /güvenli ekle rol:@rol - Rol ekle
2. /güvenli ekle kullanıcı:@user - Kullanıcı ekle
3. /güvenli panel - Yönetim paneli
\`\`\``,
          inline: false
        })
        .setFooter({ text: 'Güvenli sistem kullanıma hazır', iconURL: interaction.client.user.displayAvatarURL() })
        .setTimestamp();

      return interaction.reply({ embeds: [emptyEmbed], ephemeral: true });
    }

    // Görünüm türüne göre yanıt
    switch (viewType) {
      case 'ozet':
        return this.showSummaryList(interaction, safeRoles, safeUsers);
      case 'detay':
        return this.showDetailedList(interaction, safeRoles, safeUsers);
      case 'roller':
        return this.showRolesList(interaction, safeRoles);
      case 'kullanicilar':
        return this.showUsersList(interaction, safeUsers);
      case 'analitik':
        return this.showAnalyticsList(interaction, safeRoles, safeUsers);
      default:
        return this.showSummaryList(interaction, safeRoles, safeUsers);
    }
  },

  // Özet liste
  async showSummaryList(interaction, safeRoles, safeUsers) {
    const totalProtected = safeRoles.length + safeUsers.length;

    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setAuthor({ name: '📊 Güvenli Sistem • Özet Görünüm' })
      .setTitle('🛡️ Güvenli Liste Özeti')
      .setDescription(`
╭─────────────────────────────────╮
│  📊 **ÖZET RAPOR**              │
│  Sunucunuzun güvenli           │
│  listesindin genel durumu       │
╰─────────────────────────────────╯`)
      .addFields(
        { name: '🏷️ Güvenli Roller', value: `\`${safeRoles.length}\` rol`, inline: true },
        { name: '👥 Güvenli Kullanıcılar', value: `\`${safeUsers.length}\` kullanıcı`, inline: true },
        { name: '📈 Toplam Korumalı', value: `\`${totalProtected}\` öğe`, inline: true },
        {
          name: '📋 Sistem Durumu',
          value: `\`\`\`yaml
Durum: Aktif 🟢
Güvenlik Seviyesi: ${this.getSecurityLevel(totalProtected)}
Koruma Aktif: ${totalProtected > 0 ? 'Evet' : 'Hayır'}
\`\`\``,
          inline: false
        }
      )
      .setFooter({ text: `${interaction.guild.name} • Güvenli Sistem`, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // Detaylı liste
  async showDetailedList(interaction, safeRoles, safeUsers) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setAuthor({ name: '📋 Güvenli Sistem • Detaylı Liste' })
      .setTitle('🛡️ Güvenli Liste - Detaylı Görünüm');

    // Roller
    if (safeRoles.length > 0) {
      const displayRoles = safeRoles.slice(0, 10);
      const rolesText = displayRoles.map((roleId, i) => {
        const role = interaction.guild.roles.cache.get(roleId);
        return `${i + 1}. ${role ? role : `\`Silinmiş Rol\` (${roleId})`}`;
      }).join('\n');

      embed.addFields({
        name: `🏷️ Güvenli Roller (${safeRoles.length})`,
        value: rolesText + (safeRoles.length > 10 ? `\n*... ve ${safeRoles.length - 10} rol daha*` : ''),
        inline: false
      });
    }

    // Kullanıcılar
    if (safeUsers.length > 0) {
      const displayUsers = safeUsers.slice(0, 10);
      const usersText = displayUsers.map((userId, i) => {
        const user = interaction.client.users.cache.get(userId);
        return `${i + 1}. ${user ? user.tag : `\`Bilinmeyen\` (${userId})`}`;
      }).join('\n');

      embed.addFields({
        name: `👥 Güvenli Kullanıcılar (${safeUsers.length})`,
        value: usersText + (safeUsers.length > 10 ? `\n*... ve ${safeUsers.length - 10} kullanıcı daha*` : ''),
        inline: false
      });
    }

    embed.setFooter({ text: `${interaction.guild.name} • Güvenli Sistem`, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // Sadece roller
  async showRolesList(interaction, safeRoles) {
    if (safeRoles.length === 0) {
      return interaction.reply({ content: '❌ Güvenli listede hiç rol yok!', ephemeral: true });
    }

    const rolesText = safeRoles.map((roleId, i) => {
      const role = interaction.guild.roles.cache.get(roleId);
      return `${i + 1}. ${role ? `${role} (${role.members.size} üye)` : `\`Silinmiş Rol\` (${roleId})`}`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle(`🏷️ Güvenli Roller (${safeRoles.length})`)
      .setDescription(rolesText)
      .setFooter({ text: `${interaction.guild.name} • Güvenli Sistem`, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // Sadece kullanıcılar
  async showUsersList(interaction, safeUsers) {
    if (safeUsers.length === 0) {
      return interaction.reply({ content: '❌ Güvenli listede hiç kullanıcı yok!', ephemeral: true });
    }

    const usersText = safeUsers.map((userId, i) => {
      const user = interaction.client.users.cache.get(userId);
      const member = interaction.guild.members.cache.get(userId);
      const status = member?.presence?.status || 'offline';
      const statusEmoji = { 'online': '🟢', 'idle': '🟡', 'dnd': '🔴', 'offline': '⚪' }[status] || '⚪';
      return `${i + 1}. ${statusEmoji} ${user ? user.tag : `\`Bilinmeyen\` (${userId})`}`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0x2196F3)
      .setTitle(`👥 Güvenli Kullanıcılar (${safeUsers.length})`)
      .setDescription(usersText)
      .setFooter({ text: `${interaction.guild.name} • Güvenli Sistem`, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // Analitik görünüm
  async showAnalyticsList(interaction, safeRoles, safeUsers) {
    const totalProtected = safeRoles.length + safeUsers.length;
    const totalMembers = safeRoles.reduce((total, roleId) => {
      const role = interaction.guild.roles.cache.get(roleId);
      return total + (role ? role.members.size : 0);
    }, 0) + safeUsers.length;

    const embed = new EmbedBuilder()
      .setColor(0x9C27B0)
      .setTitle('📈 Analitik Görünüm')
      .setDescription(`
╭─────────────────────────────────╮
│  📊 **YAKINDASTATISTIK**       │
│  Sistem performans ve          │
│  kullanım istatistikleri       │
╰─────────────────────────────────╯`)
      .addFields(
        {
          name: '🔢 Sayısal Veriler',
          value: `
\`\`\`yaml
Toplam Güvenli Öğe: ${totalProtected}
Güvenli Rol Sayısı: ${safeRoles.length}
Güvenli Kullanıcı Sayısı: ${safeUsers.length}
Korunan Üye: ~${totalMembers}
\`\`\``,
          inline: true
        },
        {
          name: '📊 Dağılım',
          value: `
\`\`\`yaml
Rol Oranı: %${totalProtected > 0 ? ((safeRoles.length / totalProtected) * 100).toFixed(1) : 0}
Kullanıcı Oranı: %${totalProtected > 0 ? ((safeUsers.length / totalProtected) * 100).toFixed(1) : 0}
Nüfus Katılımı: %${interaction.guild.memberCount > 0 ? ((totalMembers / interaction.guild.memberCount) * 100).toFixed(1) : 0}
\`\`\``,
          inline: true
        },
        {
          name: '🎯 Sistem Kalitesi',
          value: `
\`\`\`yaml
Güvenlik Seviyesi: ${this.getSecurityLevel(totalProtected)}
Koruma Etkinliği: ${totalProtected > 0 ? 'Aktif ✅' : 'Pasif ⚪'}
Performans: Optimal 🟢
\`\`\``,
          inline: false
        }
      )
      .setFooter({ text: `${interaction.guild.name} • Güvenli Sistem`, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // Alt komut: Silme işlemi (geliştirilmiş)
  async handleRemove(interaction) {
    const rol = interaction.options.getRole('rol');
    const kullanıcı = interaction.options.getUser('kullanıcı');
    const mod = interaction.options.getString('mod') || 'safe';

    if (!rol && !kullanıcı) {
      const helpEmbed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('🗑️ Kaldırma Seçenekleri')
        .setDescription(`Rol veya kullanıcı seçerek kaldırma işlemi yapın.`)
        .addFields(
          { name: '🏷️ Rol Kaldırma', value: `\`/güvenli sil rol:@rol\``, inline: true },
          { name: '👤 Kullanıcı Kaldırma', value: `\`/güvenli sil kullanıcı:@user\``, inline: true }
        )
        .setFooter({ text: 'Kaldırma işlemi geri alınamaz', iconURL: interaction.client.user.displayAvatarURL() })
        .setTimestamp();

      return interaction.reply({ embeds: [helpEmbed], ephemeral: true });
    }

    // Rol kaldırma
    if (rol) {
      return this.handleRoleRemoval(interaction, rol, mod);
    }

    // Kullanıcı kaldırma
    if (kullanıcı) {
      return this.handleUserRemoval(interaction, kullanıcı, mod);
    }
  },

  // Rol kaldırma işlemi
  async handleRoleRemoval(interaction, rol, mod) {
    const roleKey = `güvenli_roller_${interaction.guild.id}`;
    let safeRoles = db.get(roleKey) || [];

    if (!safeRoles.includes(rol.id)) {
      return interaction.reply({
        content: `❌ **${rol.name}** rolü güvenli listede değil!`,
        ephemeral: true
      });
    }

    // Hızlı mod - Onaysız
    if (mod === 'quick') {
      safeRoles = safeRoles.filter(id => id !== rol.id);
      db.set(roleKey, safeRoles);

      const successEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle('✅ Rol Kaldırıldı')
        .setDescription(`**${rol.name}** rolü güvenli listeden başarıyla kaldırıldı.`)
        .addFields({ name: 'Kalan Roller', value: `${safeRoles.length}`, inline: true })
        .setFooter({ text: 'İşlem tamamlandı', iconURL: interaction.client.user.displayAvatarURL() })
        .setTimestamp();

      return interaction.reply({ embeds: [successEmbed], ephemeral: true });
    }

    // Güvenli mod - Onaylı (default)
    const confirmEmbed = new EmbedBuilder()
      .setColor(0xFF9800)
      .setTitle('⚠️ Onay Gerekli')
      .setDescription(`**${rol.name}** rolünü güvenli listeden çıkarmak istediğinize emin misiniz?`)
      .addFields(
        { name: '🏷️ Rol', value: `${rol}`, inline: true },
        { name: '👥 Üye', value: `${rol.members.size}`, inline: true }
      )
      .setFooter({ text: 'Bu işlem geri alınamaz', iconURL: interaction.client.user.displayAvatarURL() })
      .setTimestamp();

    const confirmButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`guvenli_confirm_remove_role_${rol.id}`)
          .setLabel('✅ Kaldır')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('guvenli_cancel_remove')
          .setLabel('❌ İptal')
          .setStyle(ButtonStyle.Secondary)
      );

    return interaction.reply({ embeds: [confirmEmbed], components: [confirmButtons], ephemeral: true });
  },

  // Kullanıcı kaldırma işlemi
  async handleUserRemoval(interaction, kullanıcı, mod) {
    const userKey = `güvenli_kullanıcılar_${interaction.guild.id}`;
    let safeUsers = db.get(userKey) || [];

    if (!safeUsers.includes(kullanıcı.id)) {
      return interaction.reply({
        content: `❌ **${kullanıcı.tag}** kullanıcısı güvenli listede değil!`,
        ephemeral: true
      });
    }

    // Hızlı mod - Onaysız
    if (mod === 'quick') {
      safeUsers = safeUsers.filter(id => id !== kullanıcı.id);
      db.set(userKey, safeUsers);

      const successEmbed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle('✅ Kullanıcı Kaldırıldı')
        .setDescription(`**${kullanıcı.tag}** kullanıcısı güvenli listeden başarıyla kaldırıldı.`)
        .addFields({ name: 'Kalan Kullanıcılar', value: `${safeUsers.length}`, inline: true })
        .setFooter({ text: 'İşlem tamamlandı', iconURL: interaction.client.user.displayAvatarURL() })
        .setTimestamp();

      return interaction.reply({ embeds: [successEmbed], ephemeral: true });
    }

    // Güvenli mod - Onaylı (default)
    const confirmEmbed = new EmbedBuilder()
      .setColor(0xFF9800)
      .setTitle('⚠️ Onay Gerekli')
      .setDescription(`**${kullanıcı.tag}** kullanıcısını güvenli listeden çıkarmak istediğinize emin misiniz?`)
      .addFields({ name: '👤 Kullanıcı', value: `${kullanıcı}`, inline: true })
      .setFooter({ text: 'Bu işlem geri alınamaz', iconURL: interaction.client.user.displayAvatarURL() })
      .setTimestamp();

    const confirmButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`guvenli_confirm_remove_user_${kullanıcı.id}`)
          .setLabel('✅ Kaldır')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('guvenli_cancel_remove')
          .setLabel('❌ İptal')
          .setStyle(ButtonStyle.Secondary)
      );

    return interaction.reply({ embeds: [confirmEmbed], components: [confirmButtons], ephemeral: true });
  },

  // Alt komut: Korunan işlemleri göster
  async handleProtectedActions(interaction) {
    const embed = this.getProtectedActionsEmbed();
    
    const moreInfoButton = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_panel')
          .setLabel('🎛️ Yönetim Paneli')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_add_more')
          .setLabel('➕ Güvenli Ekle')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('guvenli_view_list')
          .setLabel('📋 Listeyi Gör')
          .setStyle(ButtonStyle.Secondary)
      );

    return interaction.reply({ embeds: [embed], components: [moreInfoButton], ephemeral: true });
  },

  // Alt komut: Yönetim paneli
  async handlePanel(interaction) {
    const safeRoles = db.get(`güvenli_roller_${interaction.guild.id}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${interaction.guild.id}`) || [];
    const totalProtected = safeRoles.length + safeUsers.length;

    const panelEmbed = new EmbedBuilder()
      .setColor(0x6A1B9A)
      .setAuthor({ 
        name: '🎛️ Güvenli Sistem • Yönetim Merkezi'
      })
      .setTitle('🎛️ Güvenli Yönetim Paneli')
      .setDescription(`
╭─────────────────────────────────╮
│  🎯 **KONTROL MERKEZİ**          │
│  Güvenli sisteminizi buradan    │
│  tam olarak yönetin             │
╰─────────────────────────────────╯

**Hoşgeldiniz ${interaction.user}!**
Aşağıdaki seçeneklerle güvenli sisteminizi yönetin.`)
      .addFields(
        { 
          name: '📊 Sistem Durumu', 
          value: `
\`\`\`yaml
Güvenli Rol: ${safeRoles.length}
Güvenli Kullanıcı: ${safeUsers.length}
Toplam Korumalı: ${totalProtected}
Güvenlik Seviyesi: ${this.getSecurityLevel(totalProtected)}
\`\`\``, 
          inline: true 
        },
        { 
          name: '⚡ Hızlı İstatistik', 
          value: `
\`\`\`yaml
Son Güncelleme: Az önce
Sistem Durumu: Online 🟢
Performans: Optimal
Uptime: ${this.getUptime()}
\`\`\``, 
          inline: true 
        },
        {
          name: '🛠️ Mevcut İşlemler',
          value: `
• **Ekleme:** Rol/Kullanıcı ekle
• **Görüntüleme:** Detaylı liste
• **Kaldırma:** Güvenli kaldır
• **Toplu İşlem:** Çoklu yönetim
• **Export:** Liste dışa aktar
• **Temizleme:** Eski kayıtları sil
          `,
          inline: false
        }
      )
      .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 128 }) || '🛡️')
      .setFooter({ 
        text: `${interaction.guild.name} • Güvenli Sistem v3.0 • Gelişmiş Yönetim`, 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    // Ana işlem butonları
    const mainButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_add_menu')
          .setLabel('➕ Ekle')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('guvenli_view_menu')
          .setLabel('📋 Görüntüle')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_remove_menu')
          .setLabel('🗑️ Kaldır')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('guvenli_bulk_menu')
          .setLabel('📦 Toplu İşlem')
          .setStyle(ButtonStyle.Secondary)
      );

    // Gelişmiş işlem butonları
    const advancedButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_export_menu')
          .setLabel('📤 Export')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('guvenli_import_menu')
          .setLabel('📥 Import')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('guvenli_analytics')
          .setLabel('📈 Analitik')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_settings')
          .setLabel('⚙️ Ayarlar')
          .setStyle(ButtonStyle.Secondary)
      );

    return interaction.reply({ 
      embeds: [panelEmbed], 
      components: [mainButtons, advancedButtons], 
      ephemeral: true 
    });
  },

  getUptime() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    return `${hours}s ${minutes}d`;
  },

  getSecurityLevel(count) {
    if (count === 0) return "Hiç";
    if (count < 3) return "Düşük";
    if (count < 7) return "Orta";
    if (count < 15) return "Yüksek";
    return "Maksimum";
  },

  getAccountAge(createdTimestamp) {
    const now = Date.now();
    const diff = now - createdTimestamp;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days < 1) return "Yeni";
    if (days < 30) return `${days} gün`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months} ay`;
    const years = Math.floor(months / 12);
    return `${years} yıl`;
  },

  getSecurityScore(user) {
    const age = Date.now() - user.createdTimestamp;
    const days = age / (1000 * 60 * 60 * 24);
    if (days < 7) return "Düşük";
    if (days < 30) return "Orta";
    if (days < 365) return "Yüksek";
    return "Çok Yüksek";
  },

  async getStats(guildId) {
    const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
    return `\`\`\`yaml\nRoller: ${safeRoles.length}\nKullanıcılar: ${safeUsers.length}\nToplam: ${safeRoles.length + safeUsers.length}\`\`\``;
  },

  // Güvenli kontrol fonksiyonları
  isUserSafe(guildId, userId) {
    const safeUsers = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
    return safeUsers.includes(userId);
  },

  isRoleSafe(guildId, roleId) {
    const safeRoles = db.get(`güvenli_roller_${guildId}`) || [];
    return safeRoles.includes(roleId);
  },

  // İhlal tracker fonksiyonları
  trackViolation(guildId, userId, actionType, guild = null) {
    // Bot'un kendisini takip etmemesi için kontrol
    if (guild && userId === guild.client.user.id) {
      console.log(`[GüvenliTracker] Bot kendisini takip etmez, skipping...`);
      return 0;
    }
    
    const key = `${guildId}_${userId}`;
    const now = Date.now();
    
    if (!violationTracker.has(key)) {
      violationTracker.set(key, []);
    }
    
    const violations = violationTracker.get(key);
    violations.push({ type: actionType, timestamp: now });
    
    // 1 saatten eski ihlalleri temizle
    const filteredViolations = violations.filter(v => now - v.timestamp < 3600000);
    violationTracker.set(key, filteredViolations);
    
    console.log(`[GüvenliTracker] Kullanıcı: ${userId} | Guild: ${guildId} | İşlem: ${actionType} | Toplam İhlal: ${filteredViolations.length}`);
    console.log(`[GüvenliTracker] İhlal kaydı:`, filteredViolations);
    
    return filteredViolations.length;
  },

  async handleViolationLimit(guild, userId, actionType, violationCount) {
    console.log(`[Ban Logic] Violation limit check - User: ${userId} | Count: ${violationCount} | Type: ${actionType}`);
    
    // Bot'un kendisini banlamaması için kontrol
    if (userId === guild.client.user.id) {
      console.log(`[Ban Logic] Cannot ban bot itself, skipping...`);
      return;
    }
    
    if (violationCount >= 3) {
      console.log(`[Ban Logic] Violation count >= 3, proceeding with ban...`);
      const member = await guild.members.fetch(userId).catch(err => {
        console.error(`[Ban Logic] Member fetch failed:`, err.message);
        return null;
      });
      
      if (!member) {
        console.log(`[Ban Logic] Member not found in guild`);
        return;
      }

      // Ek güvenlik kontrolü - bot kendisini banlayamaz
      if (member.user.id === guild.client.user.id) {
        console.log(`[Ban Logic] Cannot ban bot itself (double check), skipping...`);
        return;
      }

      console.log(`[Ban Logic] Member found: ${member.user.tag}`);
      
      try {
        console.log(`[Ban Logic] Attempting to ban ${member.user.tag}...`);
        
        // Kullanıcıyı yasakla (güvenli sistem ihlali için admin kontrol yapılmaz)
        await member.ban({ 
          reason: `Güvenli sistem ihlali: ${actionType} - ${violationCount} ihlal`
        });

        console.log(`[Ban Logic] Ban successful for ${member.user.tag}`);

        // DM gönder
        await this.sendViolationDM(guild, member.user, actionType);

        // Güvenlik log kanalına bildir
        await this.sendSecurityLog(guild, member.user, actionType, violationCount, 'ban');

        // Tracker'dan temizle
        violationTracker.delete(`${guild.id}_${userId}`);
        console.log(`[Ban Logic] Violation tracker cleared for ${userId}`);

      } catch (error) {
        console.error(`[Ban Logic] Ban failed:`, error.message);
        console.error(`[Ban Logic] Full error:`, error);
        
        // Ban başarısız olursa log kanalına yine de uyarı gönderelim
        await this.sendSecurityLog(guild, member.user, actionType, violationCount, 'ban_failed', error?.message);
      }
    } else {
      console.log(`[Ban Logic] Violation count < 3 (${violationCount}), no action needed`);
    }
  },

  async sendViolationDM(guild, user, actionType) {
    try {
      // 1422661219478929679 rolündeki kişilere DM at
      const notificationRoleId = '1422661219478929679';
      const notificationRole = guild.roles.cache.get(notificationRoleId);
      
      if (notificationRole) {
        const membersWithRole = notificationRole.members;
        
        const dmEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('🚨 Güvenlik İhlali - Otomatik Ban')
          .setDescription(`**${user.tag}** kullanıcısı koruma sistemi tarafından banlandı.`)
          .addFields(
            { name: '👤 Banlanan Kullanıcı', value: `${user.tag} (${user.id})`, inline: true },
            { name: '⚠️ İhlal Nedeni', value: actionType, inline: true },
            { name: '🛡️ Sistem', value: 'Güvenli Sistem v3.0', inline: true },
            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setFooter({ text: `${guild.name} • Güvenlik Bildirimi`, iconURL: guild.iconURL() })
          .setTimestamp();
        
        for (const [memberId, member] of membersWithRole) {
          try {
            await member.send({ embeds: [dmEmbed] });
          } catch (error) {
            console.error(`DM gönderilemedi ${member.user.tag}:`, error);
          }
        }
      }
    } catch (error) {
      console.error('DM gönderme hatası:', error);
    }
  }
  ,
  async sendSecurityLog(guild, user, actionType, violationCount, status = 'violation', errorMessage) {
    try {
      const lyuex = require('../../lyuex.json');
      const channelId = (lyuex.log && lyuex.log.channels && (lyuex.log.channels.security_logs || lyuex.log.channels.role_logs)) || lyuex.botSettings.LOG_CHANNEL_ID;
      const channel = guild.client.channels.cache.get(channelId);
      if (!channel) return;

      const embed = new EmbedBuilder()
        .setColor(status === 'ban' ? 0xFF0000 : status === 'ban_failed' ? 0xFFA000 : 0xFF9800)
        .setTitle(status === 'ban' ? '🚨 Güvenlik İhlali - Otomatik Ban' : status === 'ban_failed' ? '⚠️ Otomatik Ban Başarısız' : '⚠️ Güvenlik İhlali')
        .setDescription(`İşlem: ${actionType}`)
        .addFields(
          { name: 'Kullanıcı', value: `${user.tag || 'Bilinmiyor'} (${user.id})`, inline: true },
          { name: 'İhlal Sayısı', value: `${violationCount}`, inline: true },
        )
        .setTimestamp();
      if (errorMessage) embed.addFields({ name: 'Hata', value: `\`${errorMessage}\`` });

      await channel.send({ embeds: [embed] });
    } catch (err) {
      console.error('Güvenlik logu gönderilemedi:', err);
    }
  },

  // Korunan işlemleri kontrol et
  isProtectedAction(actionType) {
    const protectedActions = [
      'Rol Ekleme',
      'Kanal Ekleme',
      'Kanal Silme',
      'Sunucu Ayarlarıyla Oynama',
      'Webhook Oluşturma',
      'Davet Bağlantısı Değişikliği'
    ];
    return protectedActions.includes(actionType);
  },

  // Tüm korumalı işlemleri listeye ekle
  getProtectedActionsList() {
    return [
      { action: 'Rol Ekleme', icon: '🏷️', açıklama: 'Yeni rol oluşturma' },
      { action: 'Kanal Ekleme', icon: '📁', açıklama: 'Yeni kanal oluşturma' },
      { action: 'Kanal Silme', icon: '🗑️', açıklama: 'Mevcut kanal silme' },
      { action: 'Sunucu Ayarlarıyla Oynama', icon: '⚙️', açıklama: 'Sunucu ayarlarını değiştirme' },
      { action: 'Webhook Oluşturma', icon: '🪝', açıklama: 'Webhook oluşturma' },
      { action: 'Davet Bağlantısı Değişikliği', icon: '🔗', açıklama: 'Vanity URL değiştirme' }
    ];
  },

  // Korunan işlemleri bilgilendirme embed'i
  getProtectedActionsEmbed() {
    const protectedActions = this.getProtectedActionsList();
    const embed = new EmbedBuilder()
      .setColor(0xFF6B6B)
      .setTitle('🛡️ Korunan İşlemler Listesi')
      .setDescription(`Güvenli olmayan kişilerin aşağıdaki işlemleri yapması yasaklanmıştır:`)
      .addFields(
        {
          name: '📋 Yasak İşlemler',
          value: protectedActions.map(item => `${item.icon} **${item.action}** - ${item.açıklama}`).join('\n'),
          inline: false
        },
        {
          name: '⚠️ Uyarı',
          value: `Bu işlemlerden **3 tanesini** gerçekleştiren kullanıcı otomatik olarak banlanacaktır!`,
          inline: false
        }
      )
      .setFooter({ text: 'Güvenli Sistem v3.0 • Koruma Aktif' })
      .setTimestamp();
    
    return embed;
  }
};






