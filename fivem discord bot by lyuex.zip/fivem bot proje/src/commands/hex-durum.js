// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('hex-durum')
        .setDescription('🎨 Hex sistemi durumunu kontrol et')
        .setDefaultMemberPermissions(null)
        .setDMPermission(false),

    async execute(interaction) {
        // Sadece belirtilen kullanıcı kullanabilir
        const allowedUser = '384385365815066624';
        
        if (interaction.user.id !== allowedUser) {
            return interaction.reply({
                content: '❌ Bu komutu sadece bot sahibi kullanabilir!',
                ephemeral: true
            });
        }

        try {
            const hexKanal = lyuex.hex_sistem?.kanal;
            const hexRol = lyuex.rol?.hex_onay;
            const logKanal = lyuex.hex_sistem?.log_kanal;
            const yetkiliRoller = lyuex.hex_sistem?.yetkili_rol || [];

            const embed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('🎨 Hex Sistemi Durum Raporu')
                .setDescription('Hex onay sisteminin mevcut durumu')
                .addFields(
                    { name: '📁 Hex Kanal ID', value: hexKanal ? `\`${hexKanal}\`` : '❌ Ayarlanmamış', inline: true },
                    { name: '🔍 Kanal Varlık', value: hexKanal && interaction.guild.channels.cache.has(hexKanal) ? '✅ Var' : '❌ Yok', inline: true },
                    { name: '🏷️ Hex Rol ID', value: hexRol ? `\`${hexRol}\`` : '❌ Ayarlanmamış', inline: true },
                    { name: '🔍 Rol Varlık', value: hexRol && interaction.guild.roles.cache.has(hexRol) ? '✅ Var' : '❌ Yok', inline: true },
                    { name: '📋 Log Kanal', value: logKanal ? `\`${logKanal}\`` : '❌ Ayarlanmamış', inline: true },
                    { name: '👮 Yetkili Roller', value: yetkiliRoller.length > 0 ? yetkiliRoller.map(id => `\`${id}\``).join('\n') : '❌ Ayarlanmamış', inline: true }
                );

            // Kanal bilgilerini ekle
            if (hexKanal) {
                const kanal = interaction.guild.channels.cache.get(hexKanal);
                if (kanal) {
                    embed.addFields({ 
                        name: '📺 Kanal Bilgisi', 
                        value: `**${kanal.name}** (#${kanal.name})\nTip: ${kanal.type}`, 
                        inline: true 
                    });
                }
            }

            // Rol bilgilerini ekle
            if (hexRol) {
                const rol = interaction.guild.roles.cache.get(hexRol);
                if (rol) {
                    embed.addFields({ 
                        name: '🎭 Rol Bilgisi', 
                        value: `**${rol.name}**\nRenk: ${rol.hexColor}\nPozisyon: ${rol.position}`, 
                        inline: true 
                    });
                }
            }

            // Sistem durumu
            const sistemDurumu = hexKanal && hexRol ? '🟢 AKTİF' : '🔴 PASİF';
            embed.addFields({ name: '⚙️ Sistem Durumu', value: sistemDurumu, inline: true });

            embed.setFooter({ 
                text: `Kontrol Eden: ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true })
            })
            .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error('Hex durum kontrol hatası:', error);
            await interaction.reply({
                content: `❌ Durum kontrolü sırasında hata: ${error.message}`,
                ephemeral: true
            });
        }
    },
};




