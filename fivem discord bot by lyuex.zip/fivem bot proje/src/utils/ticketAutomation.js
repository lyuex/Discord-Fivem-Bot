// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

class TicketAutomation {
    constructor(client) {
        this.client = client;
        this.checkInterval = 30 * 60 * 1000; // 30 dakika
        this.autoCloseInterval = null;
        this.startAutomation();
    }
    
    startAutomation() {
        console.log('Ticket otomasyonu başlatıldı...');
        
        // Otomatik kapatma kontrolü
        this.autoCloseInterval = setInterval(() => {
            this.checkAutoClose();
        }, this.checkInterval);
        
        // İlk kontrol hemen yap
        setTimeout(() => this.checkAutoClose(), 10000); // 10 saniye sonra
    }
    
    async checkAutoClose() {
        try {
            const config = ticketUtil.getConfig();
            if (!config || !config.autoCloseHours || config.autoCloseHours <= 0) {
                return; // Otomatik kapatma kapalı
            }
            
            const autoCloseMs = config.autoCloseHours * 60 * 60 * 1000;
            const now = Date.now();
            let processedCount = 0;
            const maxPerCheck = 10; // Bir çalışmada max 10 kanal kontrol et (memory safe)
            
            // Tüm guild'ları kontrol et
            for (const guild of this.client.guilds.cache.values()) {
                if (guild.id !== config.guildId) continue;
                
                // Aktif ticket kanallarını bul
                const ticketChannels = Array.from(guild.channels.cache.values()).filter(ch => 
                    ch.name.startsWith('ticket-') && 
                    ch.type === 0 &&
                    !ch.name.startsWith('kapalı-')
                );
                
                // Rate limiting: sadece batch'in bir kısmını kontrol et
                const channelsToCheck = ticketChannels.slice(0, maxPerCheck - processedCount);
                
                for (const channel of channelsToCheck) {
                    processedCount++;
                    try {
                        // Son mesaj zamanını kontrol et (daha güvenli: limit 1)
                        let lastMessage = null;
                        try {
                            const messages = await channel.messages.fetch({ limit: 1 });
                            if (messages.size > 0) lastMessage = messages.first();
                        } catch (fetchErr) {
                            console.warn(`Mesaj fetch başarısız (${channel.name}):`, fetchErr.message);
                            continue; // Fetch başarısız ise atla
                        }
                        
                        if (!lastMessage) continue;
                        
                        const timeSinceLastMessage = now - lastMessage.createdTimestamp;
                        
                        // Otomatik kapatma zamanı geldi mi?
                        if (timeSinceLastMessage >= autoCloseMs) {
                            await this.autoCloseTicket(channel, config, timeSinceLastMessage);
                        } else {
                            // Kapatmaya 1 saat kala uyarı (daha az sıklıkla)
                            const warningTime = autoCloseMs - (60 * 60 * 1000); // 1 saat önce
                            if (timeSinceLastMessage >= warningTime && timeSinceLastMessage < autoCloseMs) {
                                await this.sendCloseWarning(channel, config, autoCloseMs - timeSinceLastMessage);
                            }
                        }
                        
                    } catch (error) {
                        console.warn(`Ticket kontrol hatası (${channel.name}):`, error.message);
                    }
                    
                    // API throttle: her kontrol arası 500ms bekleme
                    if (processedCount < channelsToCheck.length) {
                        await new Promise(resolve => setTimeout(resolve, 500));
                    }
                }
                
                if (processedCount >= maxPerCheck) {
                    break; // Bu check cycle'da yeter
                }
            }
            
            if (processedCount > 0) {
                console.log(`✅ Ticket kontrol: ${processedCount} kanal kontrol edildi`);
            }
            
        } catch (error) {
            console.error('Otomatik kapatma kontrol hatası:', error.message);
        }
    }
    
    async autoCloseTicket(channel, config, inactiveTime) {
        try {
            const ticketData = ticketUtil.getTicketByChannelId(channel.id);
            if (!ticketData) return;
            
            // Acil ticket'ları otomatik kapatma
            if (ticketData.isEmergency) return;
            
            const inactiveHours = Math.floor(inactiveTime / (60 * 60 * 1000));
            
            // Otomatik kapatma mesajı
            const autoCloseEmbed = new EmbedBuilder()
                .setColor(0xF39C12)
                .setTitle('⏰ Otomatik Ticket Kapatma')
                .setDescription(`Bu ticket ${inactiveHours} saattir inaktif olduğu için otomatik olarak kapatılıyor.\n\nEğer hala yardıma ihtiyacınız varsa yeni bir ticket açabilirsiniz.`)
                .addFields(
                    { name: 'İnaktif Süre', value: `${inactiveHours} saat`, inline: true },
                    { name: 'Otomatik Kapatma Sınırı', value: `${config.autoCloseHours} saat`, inline: true }
                )
                .setTimestamp();
                
            await channel.send({ embeds: [autoCloseEmbed] });
            
            // 30 saniye bekle sonra kapat
            setTimeout(async () => {
                try {
                    // Transcript oluştur
                    if (config.autoTranscript) {
                        const transcriptFiles = await ticketUtil.createHtmlTranscript(channel, ticketData);
                        if (transcriptFiles && config.logChannelId) {
                            const logChannel = channel.guild.channels.cache.get(config.logChannelId);
                            if (logChannel) {
                                await logChannel.send({
                                    content: `⏰ Otomatik kapatılan ticket #${ticketData.ticketNumber} kaydı`,
                                    files: [{
                                        attachment: transcriptFiles.html.path,
                                        name: `auto-closed-ticket-${ticketData.ticketNumber}.html`
                                    }]
                                });
                            }
                        }
                    }
                    
                    // Kapatma işlemi
                    const ticketCreatorId = ticketData.userId;
                    
                    await channel.send({
                        embeds: [
                            new EmbedBuilder()
                                .setColor(0xE74C3C)
                                .setTitle('🔒 Ticket Otomatik Kapatıldı')
                                .setDescription('Bu ticket inaktivite nedeniyle otomatik olarak kapatıldı.')
                                .addFields(
                                    { name: 'Talep Eden', value: `<@${ticketCreatorId}>`, inline: true },
                                    { name: 'Kapatılma Sebebi', value: 'Otomatik İnaktivite', inline: true },
                                    { name: 'İnaktif Süre', value: `${inactiveHours} saat`, inline: true }
                                )
                                .setTimestamp()
                        ]
                    });
                    
                    // Erişimi kaldır
                    await channel.permissionOverwrites.edit(ticketCreatorId, {
                        ViewChannel: false,
                        SendMessages: false
                    }).catch(console.error);
                    
                    // Kanal adını değiştir
                    await channel.setName(`kapalı-${channel.name.split('ticket-')[1]}`);
                    
                    // Ticket verilerini güncelle
                    ticketUtil.updateTicket(ticketData.id, {
                        status: 'auto-closed',
                        closedAt: Date.now(),
                        closedBy: 'system',
                        autoCloseReason: `İnaktivite (${inactiveHours} saat)`
                    });
                    
                    // Log
                    if (config.logChannelId) {
                        const logChannel = channel.guild.channels.cache.get(config.logChannelId);
                        if (logChannel) {
                            const logEmbed = new EmbedBuilder()
                                .setColor(0xF39C12)
                                .setTitle('⏰ Ticket Otomatik Kapatıldı')
                                .setDescription(`Ticket #${ticketData.ticketNumber} inaktivite nedeniyle otomatik kapatıldı`)
                                .addFields(
                                    { name: 'Talep Eden', value: `<@${ticketCreatorId}>`, inline: true },
                                    { name: 'İnaktif Süre', value: `${inactiveHours} saat`, inline: true },
                                    { name: 'Kanal', value: channel.name, inline: true }
                                )
                                .setTimestamp();
                                
                            await logChannel.send({ embeds: [logEmbed] });
                        }
                    }
                    
                    console.log(`Otomatik kapatıldı: ${channel.name} (${inactiveHours} saat inaktif)`);
                    
                } catch (error) {
                    console.error(`Otomatik kapatma hatası (${channel.name}):`, error);
                }
            }, 30000);
            
        } catch (error) {
            console.error(`Otomatik kapatma işlem hatası:`, error);
        }
    }
    
    async sendCloseWarning(channel, config, timeLeft) {
        try {
            const ticketData = ticketUtil.getTicketByChannelId(channel.id);
            if (!ticketData) return;
            
            // Uyarı mesajı daha önce gönderildi mi kontrol et
            const messages = await channel.messages.fetch({ limit: 10 });
            const hasWarning = messages.some(msg => 
                msg.author.id === this.client.user.id && 
                msg.embeds.length > 0 && 
                msg.embeds[0].title?.includes('Otomatik Kapatma Uyarısı')
            );
            
            if (hasWarning) return; // Zaten uyarı gönderilmiş
            
            const hoursLeft = Math.ceil(timeLeft / (60 * 60 * 1000));
            
            const warningEmbed = new EmbedBuilder()
                .setColor(0xF39C12)
                .setTitle('⚠️ Otomatik Kapatma Uyarısı')
                .setDescription(`Bu ticket ${hoursLeft} saat içinde inaktivite nedeniyle otomatik olarak kapatılacak.\n\nTicket'ı açık tutmak için herhangi bir mesaj gönderin.`)
                .addFields(
                    { name: 'Kalan Süre', value: `${hoursLeft} saat`, inline: true },
                    { name: 'Otomatik Kapatma Sınırı', value: `${config.autoCloseHours} saat`, inline: true }
                )
                .setTimestamp();
                
            await channel.send({
                content: `<@${ticketData.userId}>`,
                embeds: [warningEmbed]
            });
            
        } catch (error) {
            console.error('Uyarı gönderme hatası:', error);
        }
    }
    
    stop() {
        if (this.autoCloseInterval) {
            clearInterval(this.autoCloseInterval);
            this.autoCloseInterval = null;
            console.log('Ticket otomasyonu durduruldu.');
        }
    }
}

module.exports = TicketAutomation;




