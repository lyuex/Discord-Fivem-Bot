// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');

const backupPath = path.join(__dirname, '../data/channelBackup.json');

module.exports = async function cacheChannels(client) {
  const backupData = {};

  for (const [guildId, guild] of client.guilds.cache) {
    await guild.channels.fetch(); // Kanalları fetchle (önemli!)
    backupData[guildId] = {};

    for (const [channelId, channel] of guild.channels.cache) {
      backupData[guildId][channelId] = {
        name: channel.name,
        type: channel.type,
        parent: channel.parentId || null
      };
    }
  }

  fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
  console.log('[✅] Tüm kanal verileri yedeklendi.');
};





