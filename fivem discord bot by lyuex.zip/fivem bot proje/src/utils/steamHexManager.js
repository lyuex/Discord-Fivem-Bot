// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');

const STEAM_HEX_PATH = path.join(__dirname, '../../data/steamHex.json');
const WHITELIST_LOGS_PATH = path.join(__dirname, '../../db/whitelistLogs.json');

/**
 * Whitelist logs'dan Steam hex verilerini yükler
 * @returns {Array} Whitelist logs verisi
 */
function loadWhitelistLogs() {
    try {
        if (fs.existsSync(WHITELIST_LOGS_PATH)) {
            const data = fs.readFileSync(WHITELIST_LOGS_PATH, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error('Whitelist logs yükleme hatası:', error);
        return [];
    }
}

/**
 * Steam hex verisini yükler ve whitelist logs ile birleştirir
 * @returns {Object} Steam hex verisi
 */
/**
 * Steam hex verisini yükler - sadece whitelistLogs.json'dan
 * @returns {Object} Steam hex verisi
 */
function loadSteamHexData() {
    try {
        let data = {
            approved_hex: {},
            metadata: {
                created: new Date().toISOString().split('T')[0],
                version: "1.0.0",
                description: "Onaylanmış Steam Hex verileri - whitelistLogs.json'dan yüklenir"
            }
        };

        // Sadece whitelist logs'dan verileri yükle
        const whitelistLogs = loadWhitelistLogs();
        for (const log of whitelistLogs) {
            if (log.hexId && log.target && log.target.id) {
                const userId = log.target.id;
                data.approved_hex[userId] = {
                    steamHex: log.hexId,
                    steamLink: log.steamLink || null,
                    approvedBy: log.executor ? log.executor.id : 'unknown',
                    approvedAt: log.timestamp || new Date().toISOString(),
                    status: 'approved',
                    source: 'whitelistLogs'
                };
            }
        }
        
        return data;
    } catch (error) {
        console.error('Steam hex data yükleme hatası:', error);
        return {
            approved_hex: {},
            metadata: {
                created: new Date().toISOString().split('T')[0],
                version: "1.0.0",
                description: "Onaylanmış Steam Hex verileri - whitelistLogs.json'dan yüklenir"
            }
        };
    }
}

/**
 * Steam hex verisini kaydeder (artık kullanılmıyor - sadece uyumluluk için)
 * @param {Object} data - Kaydedilecek data
 */
function saveSteamHexData(data) {
    console.log('saveSteamHexData çağrıldı ama artık kullanılmıyor - whitelistLogs.json kullanılıyor');
    return true;
}

/**
 * Whitelist logs'a yeni giriş ekler
 * @param {string} executorId - İşlemi yapan kişinin ID'si  
 * @param {string} targetId - Hedef kullanıcının ID'si
 * @param {string} targetTag - Hedef kullanıcının tag'i
 * @param {string} hexId - Steam hex ID'si
 * @param {string} steamLink - Steam profil linki
 */
function addToWhitelistLogs(executorId, targetId, targetTag, hexId, steamLink) {
    try {
        const logs = loadWhitelistLogs();
        const newLog = {
            timestamp: new Date().toISOString(),
            executor: {
                id: executorId,
                tag: "unknown" // Bu bilgiyi dışarıdan alabilirsiniz
            },
            target: {
                id: targetId,
                tag: targetTag || "unknown"
            },
            hexId: hexId,
            steamLink: steamLink || "https://www.steam.com"
        };
        
        logs.push(newLog);
        fs.writeFileSync(WHITELIST_LOGS_PATH, JSON.stringify(logs, null, 2));
        return true;
    } catch (error) {
        console.error('Whitelist logs ekleme hatası:', error);
        return false;
    }
}

/**
 * Steam hex onaylandığında veriyi kaydeder - sadece whitelistLogs.json'a
 * @param {string} userId - Discord kullanıcı ID'si
 * @param {string} steamHex - Steam hex kodu
 * @param {string} approvedBy - Onaylayan yetkili
 * @param {string} steamLink - Steam profil linki (opsiyonel)
 * @param {string} userTag - Kullanıcı tag'i (opsiyonel)
 * @returns {boolean} Başarı durumu
 */
function saveSteamHex(userId, steamHex, approvedBy, steamLink = null, userTag = null) {
    try {
        // Direkt whitelistLogs.json dosyasına ekle
        return addToWhitelistLogs(approvedBy, userId, userTag, steamHex, steamLink);
    } catch (error) {
        console.error('Steam hex kaydetme hatası:', error);
        return false;
    }
}

/**
 * Kullanıcının onaylanmış steam hex'ini kontrol eder
 * @param {string} userId - Discord kullanıcı ID'si
 * @returns {Object|null} Steam hex verisi veya null
 */
function getUserSteamHex(userId) {
    try {
        const data = loadSteamHexData();
        return data.approved_hex[userId] || null;
    } catch (error) {
        console.error('Steam hex kontrol hatası:', error);
        return null;
    }
}

/**
 * Steam hex kodunun daha önce onaylanıp onaylanmadığını kontrol eder
 * @param {string} steamHex - Kontrol edilecek steam hex
 * @returns {Object|null} Hex zaten onaylanmışsa kullanıcı bilgisi, yoksa null
 */
function checkSteamHexExists(steamHex) {
    try {
        const data = loadSteamHexData();
        
        for (const [userId, hexData] of Object.entries(data.approved_hex)) {
            if (hexData.steamHex === steamHex && hexData.status === 'approved') {
                return {
                    userId: userId,
                    ...hexData
                };
            }
        }
        
        return null;
    } catch (error) {
        console.error('Steam hex varlik kontrol hatası:', error);
        return null;
    }
}

/**
 * Kullanıcının steam hex'ini siler
 * @param {string} userId - Discord kullanıcı ID'si
 * @returns {boolean} Başarı durumu
 */
function removeSteamHex(userId) {
    try {
        const data = loadSteamHexData();
        
        if (data.approved_hex[userId]) {
            delete data.approved_hex[userId];
            return saveSteamHexData(data);
        }
        
        return true;
    } catch (error) {
        console.error('Steam hex silme hatası:', error);
        return false;
    }
}

/**
 * Tüm onaylanmış steam hex'leri listeler
 * @returns {Array} Steam hex listesi
 */
function getAllApprovedSteamHex() {
    try {
        const data = loadSteamHexData();
        
        return Object.entries(data.approved_hex)
            .filter(([userId, hexData]) => hexData.status === 'approved')
            .map(([userId, hexData]) => ({
                userId,
                ...hexData
            }));
    } catch (error) {
        console.error('Steam hex listeleme hatası:', error);
        return [];
    }
}

module.exports = {
    saveSteamHex,
    getUserSteamHex,
    checkSteamHexExists,
    removeSteamHex,
    getAllApprovedSteamHex,
    loadSteamHexData,
    saveSteamHexData,
    loadWhitelistLogs,
    addToWhitelistLogs
};




