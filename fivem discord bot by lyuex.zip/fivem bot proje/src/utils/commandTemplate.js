// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * Geliştirilmiş Komut Template
 * Tüm komutlar bu template'i takip edecek şekilde yapılandırılmalı
 */

const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    PermissionFlagsBits 
} = require('discord.js');

const {
    RateLimiter,
    CommandLogger,
    CommandErrorHandler,
    InteractionHelper,
    PerformanceMonitor
} = require('./commandEnhancements');

// Global instances
const rateLimiter = new RateLimiter(5, 60000); // 5 requests per minute
const commandLogger = new CommandLogger();
const performanceMonitor = new PerformanceMonitor();

/**
 * TEMPLATE KOMUT YAPISI
 * 
 * Tüm yeni komutlar bu yapıyı takip etmelidir:
 * - Rate limiting
 * - Yetki kontrolü
 * - Input validation
 * - Error handling
 * - Logging
 * - Performance monitoring
 */

module.exports = {
    data: new SlashCommandBuilder()
        .setName('template-command')
        .setDescription('Bu bir template komuttur')
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
        .setDMPermission(false)
        .addStringOption(option =>
            option
                .setName('input')
                .setDescription('Input parametresi')
                .setRequired(true)
                .setMinLength(1)
                .setMaxLength(100)
        ),

    // Komut metadata'sı
    metadata: {
        category: 'Kategori Adı',
        cooldown: 5, // saniye
        permissions: [PermissionFlagsBits.SendMessages],
        botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks],
        dmPermission: false,
        aliases: [],
        examples: [
            '/template-command input:test'
        ]
    },

    async execute(interaction) {
        const startTime = performanceMonitor.startTimer('template-command');
        
        try {
            // 1. Rate Limiting Kontrolü
            const rateLimitCheck = rateLimiter.check(interaction.user.id);
            if (rateLimitCheck.limited) {
                const errorEmbed = InteractionHelper.createWarningEmbed(
                    'Rate Limit',
                    `Çok hızlı komut çalıştırıyorsunuz! ${rateLimitCheck.secondsLeft} saniye bekleyin.`,
                    [
                        { name: '⏱️ Yeniden Deneyin', value: `<t:${Math.floor(rateLimitCheck.resetTime / 1000)}:R>`, inline: false }
                    ]
                );
                return await InteractionHelper.safeReply(interaction, { embeds: [errorEmbed] });
            }

            // 2. Yetki Kontrolü
            if (!this.hasPermissions(interaction)) {
                commandLogger.log('template-command', interaction.user.id, interaction.user.username, 'permission_denied');
                
                return await InteractionHelper.safeReply(
                    interaction,
                    { 
                        embeds: [InteractionHelper.createErrorEmbed(
                            'Yetki Hatası',
                            'Bu komutu kullanmak için gerekli yetkilere sahip değilsiniz.'
                        )]
                    }
                );
            }

            // 3. Bot Yetkileri Kontrolü
            if (!this.botHasPermissions(interaction)) {
                commandLogger.log('template-command', interaction.user.id, interaction.user.username, 'bot_permission_denied');
                
                return await InteractionHelper.safeReply(
                    interaction,
                    {
                        embeds: [InteractionHelper.createErrorEmbed(
                            'Bot Yetkileri Yetersiz',
                            'Bot bu işlemi gerçekleştirmek için gerekli yetkilere sahip değil.'
                        )]
                    }
                );
            }

            // 4. Input Validation
            const input = interaction.options.getString('input');
            
            if (!this.validateInput(input)) {
                commandLogger.log('template-command', interaction.user.id, interaction.user.username, 'invalid_input');
                
                return await InteractionHelper.safeReply(
                    interaction,
                    {
                        embeds: [InteractionHelper.createErrorEmbed(
                            'Geçersiz Input',
                            'Girdiğiniz input değerleri geçerli değil.'
                        )]
                    }
                );
            }

            // 5. Defer Reply (uzun işlemler için)
            await InteractionHelper.deferIfNeeded(interaction, false);

            // 6. Ana Logik
            const result = await this.executeLogic(interaction, input);

            // 7. Başarılı Yanıt
            const successEmbed = InteractionHelper.createSuccessEmbed(
                'İşlem Başarılı',
                result.description,
                result.fields || []
            );

            await InteractionHelper.safeReply(interaction, { embeds: [successEmbed] });

            // 8. Logging
            commandLogger.log(
                'template-command',
                interaction.user.id,
                interaction.user.username,
                'success',
                { input, result: result.summary }
            );

            performanceMonitor.endTimer('template-command', startTime, true);

        } catch (error) {
            console.error('Template command error:', error);

            // Error Handling
            commandLogger.log(
                'template-command',
                interaction.user.id,
                interaction.user.username,
                'error',
                { error: error.message, stack: error.stack }
            );

            const errorEmbed = CommandErrorHandler.createErrorEmbed(error, 'template-command');
            await InteractionHelper.safeReply(interaction, { embeds: [errorEmbed] });

            performanceMonitor.endTimer('template-command', startTime, false);
        }
    },

    /**
     * Yetki Kontrolü
     */
    hasPermissions(interaction) {
        const requiredPermissions = this.metadata.permissions;
        
        if (!requiredPermissions || requiredPermissions.length === 0) {
            return true;
        }

        return interaction.member.permissions.has(requiredPermissions);
    },

    /**
     * Bot Yetkileri Kontrolü
     */
    botHasPermissions(interaction) {
        const requiredPermissions = this.metadata.botPermissions;
        
        if (!requiredPermissions || requiredPermissions.length === 0) {
            return true;
        }

        return interaction.guild.members.me.permissions.has(requiredPermissions);
    },

    /**
     * Input Validation
     */
    validateInput(input) {
        // Custom validation logic
        if (!input || input.trim().length === 0) return false;
        if (input.length > 100) return false;
        
        return true;
    },

    /**
     * Ana Logik (Override edilmeli her komutta)
     */
    async executeLogic(interaction, input) {
        // Bu method her komutta override edilmelidir
        return {
            description: 'İşlem başarıyla tamamlandı.',
            summary: 'Tamamlandı',
            fields: [
                { name: 'Input', value: input, inline: false }
            ]
        };
    }
};

/**
 * USAGE (Yeni komut oluştururken):
 * 
 * 1. Dosyayı kopyala: cp commandTemplate.js new-command.js
 * 2. Metadata'yı güncelle (category, permissions, etc.)
 * 3. executeLogic() methodunu doldur
 * 4. validateInput() metodunu customize et (isteğe bağlı)
 * 5. data builder'ını güncelle
 * 
 * Sonuç: Otomatik olarak rate limiting, logging, error handling,
 *        permission checking ve performance monitoring içerecek!
 */





