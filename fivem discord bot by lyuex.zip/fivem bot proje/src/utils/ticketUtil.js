// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, StringSelectMenuBuilder, ChannelType } = require('discord.js');

// HTML güvenlik fonksiyonu
function sanitizeHtml(input) {
    return input
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;');
}

// Geliştirilmiş Ticket sistemi için utility fonksiyonları
class TicketUtil {
    constructor() {
        this.configPath = path.join(process.cwd(), 'data', 'ticketConfig.json');
        this.transcriptsDir = path.join(process.cwd(), 'data', 'transcripts');
        this.ticketsDbPath = path.join(process.cwd(), 'data', 'tickets.json');
        
        // Dizinleri oluştur
        if (!fs.existsSync(this.transcriptsDir)) {
            fs.mkdirSync(this.transcriptsDir, { recursive: true });
        }
        
        // Tickets veritabanını oluştur
        if (!fs.existsSync(this.ticketsDbPath)) {
            fs.writeFileSync(this.ticketsDbPath, JSON.stringify([], null, 2));
        }
    }
    
    // Config dosyasını oku
    getConfig() {
        try {
            const defaults = {
                enabled: true,
                cooldownMinutes: 0,
                maxActiveTickets: 1,
                requireDetailsModal: false
            };
            if (fs.existsSync(this.configPath)) {
                const cfg = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
                return { ...defaults, ...cfg };
            }
            return { ...defaults };
        } catch (error) {
            console.error('Ticket config okuma hatası:', error);
            return { enabled: true, cooldownMinutes: 0, maxActiveTickets: 1, requireDetailsModal: false };
        }
    }
    
    // Config dosyasını güncelle
    updateConfig(newConfig) {
        try {
            fs.writeFileSync(this.configPath, JSON.stringify(newConfig, null, 2));
            return true;
        } catch (error) {
            console.error('Ticket config güncelleme hatası:', error);
            return false;
        }
    }
    
    // Ticket numarası al ve arttır
    getNextTicketNumber() {
        const config = this.getConfig();
        if (!config) return 1;
        
        config.ticketCount = (config.ticketCount || 0) + 1;
        this.updateConfig(config);
        return config.ticketCount;
    }
    
    // Ticket kategorilerini al
    getCategories() {
        const config = this.getConfig();
        return config?.ticketCategories || [];
    }
    
    // Kategori bilgisini ID'ye göre bul
    getCategoryById(categoryId) {
        const categories = this.getCategories();
        return categories.find(cat => cat.id === categoryId);
    }
    
    // Ticket etiketlerini al
    getTags() {
        const config = this.getConfig();
        return config?.ticketTags || [];
    }
    
    // Etiket bilgisini ID'ye göre bul
    getTagById(tagId) {
        const tags = this.getTags();
        return tags.find(tag => tag.id === tagId);
    }
    
    // Ticket önceliklerini al
    getPriorities() {
        const config = this.getConfig();
        return config?.ticketPriorities || [];
    }
    
    // Öncelik bilgisini ID'ye göre bul
    getPriorityById(priorityId) {
        const priorities = this.getPriorities();
        return priorities.find(p => p.id === priorityId);
    }
    
    // Kullanıcının aktif ticket sayısını kontrol et
    async getUserActiveTickets(guild, userId) {
        return guild.channels.cache.filter(channel => 
            channel.type === ChannelType.GuildText && 
            channel.name.startsWith('ticket-') && 
            channel.topic && 
            channel.topic.includes(`Talep Eden: ${userId}`)
        );
    }
    
    // Kullanıcı için yeni ticket açabilir mi
    async canCreateTicket(guild, userId) {
        const config = this.getConfig();
        const maxTickets = config?.maxActiveTickets || 1;
        
        const activeTickets = await this.getUserActiveTickets(guild, userId);
        return activeTickets.size < maxTickets;
    }
    
    // Kullanıcının son ticket açma zamanını kontrol et (cooldown)
    checkCooldown(userId) {
        try {
            const tickets = this.getTicketsDb();
            const config = this.getConfig();
            const cooldownMinutes = config?.cooldownMinutes || 0;
            
            if (cooldownMinutes <= 0) return { onCooldown: false };
            
            const userTickets = tickets.filter(t => t.userId === userId);
            if (userTickets.length === 0) return { onCooldown: false };
            
            const lastTicket = userTickets.sort((a, b) => b.createdAt - a.createdAt)[0];
            const cooldownTime = cooldownMinutes * 60 * 1000;
            const timeSinceLastTicket = Date.now() - lastTicket.createdAt;
            
            if (timeSinceLastTicket < cooldownTime) {
                const timeLeft = cooldownTime - timeSinceLastTicket;
                return {
                    onCooldown: true,
                    timeLeft,
                    lastTicket
                };
            }
            
            return { onCooldown: false };
            
        } catch (error) {
            console.error('Cooldown kontrolü hatası:', error);
            return { onCooldown: false };
        }
    }
    
    // Ticket verilerini kaydet
    saveTicket(ticketData) {
        try {
            const tickets = this.getTicketsDb();
            tickets.push({
                ...ticketData,
                createdAt: Date.now()
            });
            this.saveTicketsDb(tickets);
            return true;
        } catch (error) {
            console.error('Ticket kaydetme hatası:', error);
            return false;
        }
    }
    
    // Ticket verilerini güncelle
    updateTicket(ticketId, updatedData) {
        try {
            const tickets = this.getTicketsDb();
            const index = tickets.findIndex(t => t.id === ticketId);
            
            if (index !== -1) {
                tickets[index] = { ...tickets[index], ...updatedData, updatedAt: Date.now() };
                this.saveTicketsDb(tickets);
                return true;
            }
            
            return false;
        } catch (error) {
            console.error('Ticket güncelleme hatası:', error);
            return false;
        }
    }
    
    // Ticket DB'yi oku
    getTicketsDb() {
        try {
            if (fs.existsSync(this.ticketsDbPath)) {
                return JSON.parse(fs.readFileSync(this.ticketsDbPath, 'utf8'));
            }
            return [];
        } catch (error) {
            console.error('Tickets DB okuma hatası:', error);
            return [];
        }
    }
    
    // Ticket DB'yi kaydet
    saveTicketsDb(tickets) {
        try {
            fs.writeFileSync(this.ticketsDbPath, JSON.stringify(tickets, null, 2));
            return true;
        } catch (error) {
            console.error('Tickets DB kaydetme hatası:', error);
            return false;
        }
    }
    
    // Ticket ID'sine göre veri bul
    getTicketById(ticketId) {
        const tickets = this.getTicketsDb();
        return tickets.find(t => t.id === ticketId);
    }
    
    // Kanal ID'sine göre ticket bul
    getTicketByChannelId(channelId) {
        const tickets = this.getTicketsDb();
        return tickets.find(t => t.channelId === channelId);
    }
    
    // İyileştirilmiş HTML transkript oluştur
    async createHtmlTranscript(channel, ticketData) {
        try {
            const messages = await channel.messages.fetch({ limit: 100 });
            const sortedMessages = Array.from(messages.values()).sort((a, b) => a.createdTimestamp - b.createdTimestamp);
            
            const config = this.getConfig();
            const ticket = ticketData || this.getTicketByChannelId(channel.id);
            const category = ticket?.categoryId ? this.getCategoryById(ticket.categoryId) : null;
            const priority = ticket?.priorityId ? this.getPriorityById(ticket.priorityId) : null;
            
            let html = `<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Kaydı - ${channel.name}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .ticket-header {
            background-color: ${category?.color || '#3498db'};
            color: white;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .ticket-info {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .info-item {
            flex: 1 1 200px;
        }
        .info-item strong {
            display: block;
        }
        .message {
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 6px;
            background: #f9f9f9;
            position: relative;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 14px;
            color: #666;
        }
        .message-author {
            font-weight: bold;
            color: #3498db;
        }
        .message-content {
            padding-top: 5px;
        }
        .attachment {
            display: block;
            margin-top: 10px;
            background: #eee;
            padding: 5px;
            border-radius: 4px;
        }
        .attachment a {
            color: #3498db;
            text-decoration: none;
        }
        .attachment a:hover {
            text-decoration: underline;
        }
        .tag {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-right: 5px;
        }
        .priority-tag {
            background-color: ${priority?.color || '#f1c40f'};
            color: white;
        }
        .user-tag {
            background-color: #3498db;
            color: white;
        }
        .system-message {
            background-color: #f8f9fa;
            border-left: 3px solid #6c757d;
            font-style: italic;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="ticket-header">
            <h1>Ticket Kaydı</h1>
            <h2>${channel.name}</h2>
        </div>
        
        <div class="ticket-info">
            <div class="info-item">
                <strong>Ticket ID</strong>
                <span>${ticket?.ticketNumber || 'Bilinmiyor'}</span>
            </div>
            <div class="info-item">
                <strong>Kategori</strong>
                <span>${category ? `${category.emoji} ${category.name}` : 'Bilinmiyor'}</span>
            </div>
            <div class="info-item">
                <strong>Öncelik</strong>
                <span>${priority ? `${priority.emoji} ${priority.name}` : 'Normal'}</span>
            </div>
            <div class="info-item">
                <strong>Oluşturulma</strong>
                <span>${new Date(channel.createdTimestamp).toLocaleString('tr-TR')}</span>
            </div>
            <div class="info-item">
                <strong>Kapanma</strong>
                <span>${ticket?.closedAt ? new Date(ticket.closedAt).toLocaleString('tr-TR') : 'Aktif'}</span>
            </div>
        </div>
        
        <h3>Mesaj Geçmişi</h3>
        <div class="messages">`;
            
            for (const message of sortedMessages) {
                const isSystemMessage = message.author.bot && !message.content;
                const timestamp = new Date(message.createdTimestamp).toLocaleString('tr-TR');
                
                html += `<div class="message ${isSystemMessage ? 'system-message' : ''}">
                <div class="message-header">
                    <span class="message-author">${message.author.tag}</span>
                    <span class="message-time">${timestamp}</span>
                </div>
                <div class="message-content">`;
                
                if (message.content) {
                    html += `<p>${sanitizeHtml(message.content).replace(/\n/g, '<br>')}</p>`;
                }
                
                if (message.attachments.size > 0) {
                    html += `<div class="attachments">`;
                    message.attachments.forEach(attachment => {
                        html += `<div class="attachment">
                            <a href="${attachment.url}" target="_blank">${attachment.name || 'Ek'}</a>
                        </div>`;
                    });
                    html += `</div>`;
                }
                
                // Basitleştirilmiş embed içeriği
                if (message.embeds.length > 0) {
                    message.embeds.forEach(embed => {
                        if (embed.title || embed.description) {
                            html += `<div class="embed" style="border-left: 4px solid ${embed.color || '#3498db'}; padding-left: 10px;">`;
                            if (embed.title) {
                                html += `<strong>${sanitizeHtml(embed.title)}</strong><br>`;
                            }
                            if (embed.description) {
                                html += `${sanitizeHtml(embed.description).replace(/\n/g, '<br>')}`;
                            }
                            html += `</div>`;
                        }
                    });
                }
                
                html += `</div></div>`;
            }
            
            html += `</div>
        <div class="footer">
            <p>Bu transcript ${new Date().toLocaleString('tr-TR')} tarihinde oluşturulmuştur.</p>
        </div>
    </div>
</body>
</html>`;
            
            // Dosya olarak kaydet
            const fileName = `transcript-${channel.id}-${Date.now()}.html`;
            const filePath = path.join(this.transcriptsDir, fileName);
            fs.writeFileSync(filePath, html);
            
            // Ayrıca TXT versiyonunu da kaydet
            const txtFileName = `transcript-${channel.id}-${Date.now()}.txt`;
            const txtFilePath = path.join(this.transcriptsDir, txtFileName);
            
            let textContent = `# Ticket Kaydı: ${channel.name}\n\n`;
            textContent += `Ticket ID: ${ticket?.ticketNumber || 'Bilinmiyor'}\n`;
            textContent += `Kategori: ${category ? `${category.emoji} ${category.name}` : 'Bilinmiyor'}\n`;
            textContent += `Öncelik: ${priority ? `${priority.emoji} ${priority.name}` : 'Normal'}\n`;
            textContent += `Oluşturulma: ${new Date(channel.createdTimestamp).toLocaleString('tr-TR')}\n`;
            textContent += `Kapanma: ${ticket?.closedAt ? new Date(ticket.closedAt).toLocaleString('tr-TR') : 'Aktif'}\n\n`;
            textContent += `--- Mesaj Geçmişi ---\n\n`;
            
            for (const message of sortedMessages) {
                const timestamp = new Date(message.createdTimestamp).toLocaleString('tr-TR');
                textContent += `[${timestamp}] ${message.author.tag}:\n`;
                
                if (message.content) {
                    textContent += `${message.content}\n`;
                }
                
                if (message.attachments.size > 0) {
                    textContent += `Ekler: ${message.attachments.map(a => a.url).join(', ')}\n`;
                }
                
                if (message.embeds.length > 0) {
                    textContent += `[Embed içeriği var]\n`;
                }
                
                textContent += `\n---\n\n`;
            }
            
            fs.writeFileSync(txtFilePath, textContent);
            
            return {
                html: {
                    path: filePath,
                    name: fileName
                },
                txt: {
                    path: txtFilePath,
                    name: txtFileName
                }
            };
        } catch (error) {
            console.error('HTML Transcript oluşturma hatası:', error);
            return null;
        }
    }
    
    // Ticket sahibini bul
    getTicketOwner(channel) {
        if (channel.topic) {
            const match = channel.topic.match(/Talep Eden: (\d+)/);
            return match ? match[1] : null;
        }
        return null;
    }
    
    // Ticket kategorisini bul
    getTicketCategory(channel) {
        if (channel.topic) {
            const match = channel.topic.match(/Kategori: ([^|]+)/);
            return match ? match[1].trim() : null;
        }
        return null;
    }
    
    // Ticket paneliyle kullanılacak butonları oluştur
    createTicketPanelButtons() {
        const categories = this.getCategories().slice(0, 5); // En fazla 5 kategori gösteriyoruz
        
        const rows = [];
        const currentRow = new ActionRowBuilder();
        
        categories.forEach((category, index) => {
            currentRow.addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticket_create_${category.id}`)
                    .setLabel(category.name)
                    .setEmoji(category.emoji)
                    .setStyle(ButtonStyle.Primary)
            );
        });
        
        rows.push(currentRow);
        return rows;
    }
    
    // Ticket yönetim butonlarını oluştur
    createTicketManagementButtons(isClosed = false) {
        const row1 = new ActionRowBuilder();
        
        if (!isClosed) {
            row1.addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_kapat')
                    .setLabel('Talebi Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('Talebe Bak')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('👋')
            );
        } else {
            row1.addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_delete')
                    .setLabel('Talebi Sil')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️')
            );
        }
        
        row1.addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_transcript')
                .setLabel('Kaydı İndir')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('📝')
        );
        
        if (!isClosed) {
            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('ticket_set_priority')
                        .setLabel('Öncelik Ayarla')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🔄'),
                    new ButtonBuilder()
                        .setCustomId('ticket_set_tag')
                        .setLabel('Etiket Ayarla')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🏷️')
                );
                
            return [row1, row2];
        }
        
        return [row1];
    }
    
    // Öncelik seçim menüsü oluştur
    createPrioritySelectMenu() {
        const priorities = this.getPriorities();
        
        return new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('priority_select')
                    .setPlaceholder('Talep önceliğini seçin')
                    .addOptions(priorities.map(p => ({
                        label: p.name,
                        value: p.id,
                        description: `${p.name} öncelik seviyesi`,
                        emoji: p.emoji
                    })))
            );
    }
    
    // Etiket seçim menüsü oluştur
    createTagSelectMenu() {
        const tags = this.getTags();
        
        return new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('tag_select')
                    .setPlaceholder('Talep etiketini seçin')
                    .addOptions(tags.map(t => ({
                        label: t.name,
                        value: t.id,
                        description: `${t.name} etiketi`,
                        emoji: t.emoji
                    })))
            );
    }
    
    // Rating butonları oluştur
    createRatingButtons() {
        return new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_rate_1')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('1️⃣'),
                new ButtonBuilder()
                    .setCustomId('ticket_rate_2')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('2️⃣'),
                new ButtonBuilder()
                    .setCustomId('ticket_rate_3')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('3️⃣'),
                new ButtonBuilder()
                    .setCustomId('ticket_rate_4')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('4️⃣'),
                new ButtonBuilder()
                    .setCustomId('ticket_rate_5')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('5️⃣')
            );
    }
    
    // Transcript dosyalarını güvenli temizleme
    cleanupTranscriptFiles(files) {
        setTimeout(() => {
            try {
                if (files.html && fs.existsSync(files.html.path)) {
                    fs.unlinkSync(files.html.path);
                    console.log(`HTML transcript temizlendi: ${files.html.name}`);
                }
                if (files.txt && fs.existsSync(files.txt.path)) {
                    fs.unlinkSync(files.txt.path);
                    console.log(`TXT transcript temizlendi: ${files.txt.name}`);
                }
            } catch (error) {
                console.error('Transcript temizleme hatası:', error);
            }
        }, 60000); // 1 dakika sonra temizle
    }
    
    // Kanal verilerini güvenli al
    async safeGetChannel(guild, channelId) {
        try {
            // Önce cache'den kontrol et
            const cachedChannel = guild.channels.cache.get(channelId);
            if (cachedChannel) return cachedChannel;
            
            // Cache'de yoksa API'den çek
            const fetchedChannel = await guild.channels.fetch(channelId).catch(() => null);
            return fetchedChannel;
        } catch (error) {
            console.error(`Kanal alınırken hata (${channelId}):`, error);
            return null;
        }
    }
}

module.exports = new TicketUtil();




