// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * Komut İyileştirme Utilityleri
 * Rate limiting, caching, advanced error handling ve logging
 */

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Rate Limiting
class RateLimiter {
    constructor(maxRequests = 5, windowMs = 60000) {
        this.maxRequests = maxRequests;
        this.windowMs = windowMs;
        this.requests = new Map();
    }

    check(userId) {
        const now = Date.now();
        if (!this.requests.has(userId)) {
            this.requests.set(userId, []);
        }

        const userRequests = this.requests.get(userId);
        const recentRequests = userRequests.filter(time => now - time < this.windowMs);

        if (recentRequests.length >= this.maxRequests) {
            const oldestRequest = recentRequests[0];
            const resetTime = oldestRequest + this.windowMs;
            return {
                limited: true,
                resetTime: resetTime,
                secondsLeft: Math.ceil((resetTime - now) / 1000)
            };
        }

        recentRequests.push(now);
        this.requests.set(userId, recentRequests);
        return { limited: false };
    }

    getRemainingRequests(userId) {
        const now = Date.now();
        if (!this.requests.has(userId)) return this.maxRequests;
        
        const userRequests = this.requests.get(userId);
        const recentRequests = userRequests.filter(time => now - time < this.windowMs);
        return Math.max(0, this.maxRequests - recentRequests.length);
    }
}

// Command Logger
class CommandLogger {
    constructor(logDir = './logs') {
        this.logDir = logDir;
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir, { recursive: true });
        }
    }

    log(commandName, userId, userName, status, details = {}) {
        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp,
            command: commandName,
            userId,
            userName,
            status,
            ...details
        };

        const logFile = path.join(this.logDir, `commands-${new Date().toISOString().split('T')[0]}.log`);
        fs.appendFileSync(logFile, JSON.stringify(logEntry) + '\n');
    }

    getStats(commandName, days = 7) {
        const stats = {
            success: 0,
            error: 0,
            users: new Set(),
            avgResponseTime: 0,
            totalTime: 0
        };

        for (let i = 0; i < days; i++) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const logFile = path.join(this.logDir, `commands-${date.toISOString().split('T')[0]}.log`);

            if (fs.existsSync(logFile)) {
                const logs = fs.readFileSync(logFile, 'utf8').split('\n').filter(l => l);
                
                logs.forEach(line => {
                    try {
                        const entry = JSON.parse(line);
                        if (entry.command === commandName) {
                            if (entry.status === 'success') stats.success++;
                            else if (entry.status === 'error') stats.error++;
                            
                            stats.users.add(entry.userId);
                            if (entry.responseTime) {
                                stats.totalTime += entry.responseTime;
                            }
                        }
                    } catch (e) {
                        // Hatalı log satırı
                    }
                });
            }
        }

        stats.avgResponseTime = stats.success > 0 ? 
            Math.round(stats.totalTime / stats.success) : 0;
        stats.uniqueUsers = stats.users.size;
        delete stats.users;
        delete stats.totalTime;

        return stats;
    }
}

// Command Cache
class CommandCache {
    constructor(ttl = 300000) { // 5 dakika default
        this.cache = new Map();
        this.ttl = ttl;
    }

    set(key, value) {
        const expiresAt = Date.now() + this.ttl;
        this.cache.set(key, { value, expiresAt });
    }

    get(key) {
        if (!this.cache.has(key)) return null;

        const item = this.cache.get(key);
        if (Date.now() > item.expiresAt) {
            this.cache.delete(key);
            return null;
        }

        return item.value;
    }

    clear() {
        this.cache.clear();
    }

    getStats() {
        return {
            size: this.cache.size,
            ttl: this.ttl
        };
    }
}

// Advanced Error Handler
class CommandErrorHandler {
    static createErrorEmbed(error, commandName) {
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('❌ Komut Hatası')
            .setDescription(`**Komut:** \`${commandName}\`\n**Hata:** ${error.message}`)
            .addFields(
                { name: '🔍 Hata Türü', value: error.name || 'Unknown', inline: true },
                { name: '⏱️ Zaman', value: new Date().toLocaleString('tr-TR'), inline: true }
            )
            .setFooter({ text: 'Hatayı yöneticiye bildirebilirsiniz' })
            .setTimestamp();

        if (error.stack) {
            const stackLines = error.stack.split('\n').slice(0, 3);
            embed.addFields({ 
                name: '📍 Stack Trace', 
                value: '```\n' + stackLines.join('\n') + '\n```', 
                inline: false 
            });
        }

        return embed;
    }

    static getErrorMessage(error) {
        const messages = {
            'MISSING_PERMISSIONS': '❌ Yetersiz yetkiniz!',
            'MISSING_BOT_PERMISSIONS': '❌ Botun yetkileri yetersiz!',
            'INVALID_ARGUMENTS': '❌ Geçersiz argümanlar!',
            'USER_NOT_FOUND': '❌ Kullanıcı bulunamadı!',
            'COMMAND_COOLDOWN': '⏱️ Lütfen biraz bekleyin ve tekrar deneyin!',
            'DATABASE_ERROR': '❌ Veritabanı hatası oluştu!',
            'API_ERROR': '❌ Discord API hatası oluştu!',
            'TIMEOUT': '⏱️ İşlem zaman aşımına uğradı!'
        };

        return messages[error.code] || `❌ Hata: ${error.message}`;
    }
}

// Performance Monitor
class PerformanceMonitor {
    constructor() {
        this.metrics = new Map();
    }

    startTimer(commandName) {
        if (!this.metrics.has(commandName)) {
            this.metrics.set(commandName, {
                executions: 0,
                totalTime: 0,
                minTime: Infinity,
                maxTime: 0,
                errors: 0
            });
        }
        return Date.now();
    }

    endTimer(commandName, startTime, success = true) {
        const duration = Date.now() - startTime;
        const metric = this.metrics.get(commandName);

        metric.executions++;
        metric.totalTime += duration;
        metric.minTime = Math.min(metric.minTime, duration);
        metric.maxTime = Math.max(metric.maxTime, duration);
        
        if (!success) metric.errors++;
    }

    getMetrics(commandName) {
        const metric = this.metrics.get(commandName);
        if (!metric) return null;

        return {
            executions: metric.executions,
            avgTime: Math.round(metric.totalTime / metric.executions),
            minTime: metric.minTime,
            maxTime: metric.maxTime,
            successRate: Math.round(((metric.executions - metric.errors) / metric.executions) * 100)
        };
    }

    getAllMetrics() {
        const all = {};
        for (const [cmd, metric] of this.metrics.entries()) {
            all[cmd] = {
                executions: metric.executions,
                avgTime: Math.round(metric.totalTime / metric.executions),
                successRate: Math.round(((metric.executions - metric.errors) / metric.executions) * 100)
            };
        }
        return all;
    }

    reset() {
        this.metrics.clear();
    }
}

// Autocomplete Helper
class AutocompleteHelper {
    static async getUserOptions(guild, filter = '') {
        if (!guild) return [];
        
        const members = await guild.members.fetch().catch(() => null);
        if (!members) return [];

        return members
            .filter(m => m.user.username.toLowerCase().includes(filter.toLowerCase()))
            .map(m => ({
                name: m.user.username.substring(0, 100),
                value: m.user.id
            }))
            .slice(0, 25);
    }

    static async getRoleOptions(guild, filter = '') {
        if (!guild) return [];

        return guild.roles.cache
            .filter(r => r.name.toLowerCase().includes(filter.toLowerCase()) && r.id !== guild.id)
            .map(r => ({
                name: r.name.substring(0, 100),
                value: r.id
            }))
            .slice(0, 25);
    }

    static async getChannelOptions(guild, type = 'GUILD_TEXT', filter = '') {
        if (!guild) return [];

        return guild.channels.cache
            .filter(c => c.type === type && c.name.toLowerCase().includes(filter.toLowerCase()))
            .map(c => ({
                name: c.name.substring(0, 100),
                value: c.id
            }))
            .slice(0, 25);
    }
}

// Interaction Response Helper
class InteractionHelper {
    static async safeReply(interaction, options, ephemeral = true) {
        try {
            if (interaction.replied || interaction.deferred) {
                return await interaction.editReply({ ...options, flags: ephemeral ? 64 : undefined });
            } else {
                return await interaction.reply({ ...options, ephemeral });
            }
        } catch (error) {
            console.error('Interaction reply error:', error);
        }
    }

    static async deferIfNeeded(interaction, ephemeral = true) {
        try {
            if (!interaction.deferred && !interaction.replied) {
                await interaction.deferReply({ ephemeral });
            }
        } catch (error) {
            console.error('Defer error:', error);
        }
    }

    static createSuccessEmbed(title, description, details = []) {
        const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle(`✅ ${title}`)
            .setDescription(description);

        if (details.length > 0) {
            embed.addFields(details);
        }

        return embed;
    }

    static createWarningEmbed(title, description, details = []) {
        const embed = new EmbedBuilder()
            .setColor(0xFFAA00)
            .setTitle(`⚠️ ${title}`)
            .setDescription(description);

        if (details.length > 0) {
            embed.addFields(details);
        }

        return embed;
    }

    static createErrorEmbed(title, description, details = []) {
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle(`❌ ${title}`)
            .setDescription(description);

        if (details.length > 0) {
            embed.addFields(details);
        }

        return embed;
    }
}

// Permission helper for commands
class PermissionHelper {
    /**
     * Check member permissions and roles.
     * options = { perms: [PermissionFlagsBits.*], roles: [roleId, ...] }
     */
    static check(member, options = {}) {
        const missing = [];
        const { perms = [], roles = [] } = options;

        try {
            for (const p of perms) {
                if (!member.permissions.has(p)) missing.push(p);
            }

            for (const r of roles) {
                if (!member.roles.cache.has(r)) missing.push(`role:${r}`);
            }
        } catch (e) {
            return { ok: false, missing: ['unknown'] };
        }

        return { ok: missing.length === 0, missing };
    }
}

// Simple pagination helper for embeds (Next / Prev)
class PaginationHelper {
    static async paginate(interaction, embeds = [], options = {}) {
        if (!Array.isArray(embeds) || embeds.length === 0) return null;

        const ephemeral = options.ephemeral ?? true;
        let index = 0;

        const prevButton = new ButtonBuilder().setCustomId('prev_page').setLabel('◀️').setStyle(ButtonStyle.Secondary);
        const nextButton = new ButtonBuilder().setCustomId('next_page').setLabel('▶️').setStyle(ButtonStyle.Secondary);
        const row = new ActionRowBuilder().addComponents(prevButton, nextButton);

        await interaction.reply({ embeds: [embeds[index]], components: [row], ephemeral });

        const message = await interaction.fetchReply();

        const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: options.time || 60000 });

        collector.on('collect', async i => {
            if (i.user.id !== interaction.user.id) return i.reply({ content: 'Bu sayfayı sadece komutu kullanan kişi değiştirebilir.', ephemeral: true });

            if (i.customId === 'prev_page') {
                index = (index - 1 + embeds.length) % embeds.length;
            } else if (i.customId === 'next_page') {
                index = (index + 1) % embeds.length;
            }

            await i.update({ embeds: [embeds[index]], components: [row] });
        });

        collector.on('end', async () => {
            try {
                const disabledRow = new ActionRowBuilder().addComponents(
                    prevButton.setDisabled(true),
                    nextButton.setDisabled(true)
                );
                await message.edit({ components: [disabledRow] });
            } catch (e) { /* ignore */ }
        });

        return message;
    }
}

// Convenience wrapper to apply cooldown using RateLimiter class
function applyCooldown(rateLimiter, userId) {
    if (!rateLimiter) return { limited: false };
    return rateLimiter.check(userId);
}

module.exports = {
    RateLimiter,
    CommandLogger,
    CommandCache,
    CommandErrorHandler,
    PerformanceMonitor,
    AutocompleteHelper,
    InteractionHelper,
    PermissionHelper,
    PaginationHelper,
    applyCooldown
};





