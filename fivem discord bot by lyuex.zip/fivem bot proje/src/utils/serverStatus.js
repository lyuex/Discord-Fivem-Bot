// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { GameDig } = require('gamedig');
const { EmbedBuilder } = require('discord.js');

class ServerStatusManager {
  constructor(client) {
    this.client = client;
    this.serverIp = '179.61.147.231';
    this.serverPort = 30120; // FiveM default port
    this.updateInterval = null;
    this.lastPlayerCount = -1;
    this.serverLogo = 'https://cdn.discordapp.com/attachments/1432060322163851265/1432741855455350954/lyuex.png?ex=69022855&is=6900d6d5&hm=3b88eaafd8da882d4a98236b3217388e52df5151ff288f29b90776fd51c9b660&';
  }

  async queryServer() {
    try {
      const state = await GameDig.query({
        type: 'gta5f',
        host: this.serverIp,
        port: this.serverPort,
        timeout: 15000, // 15 saniye timeout
        attemptTimeout: 8000, // Her deneme için 8 saniye
        maxAttempts: 2 // Maksimum 2 deneme
      });

      return {
        online: true,
        players: state.players ? state.players.length : 0,
        maxPlayers: state.maxplayers || 64,
        name: state.name || 'LYUEX',
        map: state.map || 'Los Santos',
        version: state.version || 'Unknown',
        ping: state.ping || 0,
        playerList: state.players || []
      };
    } catch (error) {
      // Daha az spammy hata mesajı - sadece önemli durumları logla
      if (error.message.includes('Failed all') || error.message.includes('timeout')) {
        console.log('[ServerStatus] Sunucu şu anda erişilemez (offline/maintenance)');
      } else {
        console.error('[ServerStatus] Beklenmeyen hata:', error.message);
      }
      
      return {
        online: false,
        players: 0,
        maxPlayers: 64,
        name: 'LYUEX',
        map: 'Los Santos',
        version: 'Unknown',
        ping: 0,
        playerList: []
      };
    }
  }

  async updateBotStatus() {
    const serverData = await this.queryServer();
    
    try {
      if (serverData.online) {
        // Bot durumunu güncelle
        await this.client.user.setPresence({
          activities: [{
            name: `LYUEX | ${serverData.players}/${serverData.maxPlayers} Oyuncu`,
            type: 0 // PLAYING
          }],
          status: 'online'
        });
        
        this.lastPlayerCount = serverData.players;
        // Sadece oyuncu sayısı değiştiyse logla
        if (this.lastPlayerCount !== serverData.players) {
          console.log(`[ServerStatus] Bot durumu güncellendi: ${serverData.players}/${serverData.maxPlayers} oyuncu`);
        }
      } else {
        // Sunucu offline
        await this.client.user.setPresence({
          activities: [{
            name: 'LYUEX | Sunucu Offline',
            type: 0
          }],
          status: 'dnd'
        });
        
        // Sadece durumda değişiklik varsa logla
        if (this.lastPlayerCount !== -1) {
          console.log('[ServerStatus] Sunucu offline - Bot durumu güncellendi');
          this.lastPlayerCount = -1;
        }
      }
    } catch (error) {
      console.error('[ServerStatus] Bot durumu güncelleme hatası:', error.message);
    }
    
    return serverData;
  }

  createServerEmbed(serverData) {
    const embed = new EmbedBuilder()
      .setColor(serverData.online ? '#00ff00' : '#ff0000')
      .setTitle('🎮 LYUEX Sunucu Durumu')
      .setThumbnail(this.serverLogo)
      .setTimestamp();

    if (serverData.online) {
      embed.setDescription('🟢 **Sunucu Aktif**')
        .addFields(
          {
            name: '👥 Oyuncu Sayısı',
            value: `**${serverData.players}**/${serverData.maxPlayers}`,
            inline: true
          },
          {
            name: '🗺️ Harita',
            value: serverData.map,
            inline: true
          },
          {
            name: '📡 Ping',
            value: `${serverData.ping}ms`,
            inline: true
          },
          {
            name: '🔗 Sunucu IP',
            value: `\`${this.serverIp}:${this.serverPort}\``,
            inline: true
          },
          {
            name: '🎯 Connect',
            value: `[Sunucuya Katıl](fivem://connect/${this.serverIp}:${this.serverPort})`,
            inline: true
          },
          {
            name: '📊 Versiyon',
            value: serverData.version,
            inline: true
          }
        );

      // Eğer oyuncu listesi varsa ilk 10'unu göster
      if (serverData.playerList && serverData.playerList.length > 0) {
        const playerNames = serverData.playerList
          .slice(0, 10)
          .map(player => player.name || 'Bilinmeyen')
          .join('\n');
        
        embed.addFields({
          name: `🎮 Aktif Oyuncular (${Math.min(serverData.playerList.length, 10)}/${serverData.playerList.length})`,
          value: playerNames || 'Oyuncu listesi alınamadı',
          inline: false
        });
      }
    } else {
      embed.setDescription('🔴 **Sunucu Offline**')
        .addFields(
          {
            name: '❌ Durum',
            value: 'Sunucu şu anda kapalı veya erişilemez durumda',
            inline: false
          },
          {
            name: '🔗 Sunucu IP',
            value: `\`${this.serverIp}:${this.serverPort}\``,
            inline: true
          },
          {
            name: '🔄 Son Kontrol',
            value: `<t:${Math.floor(Date.now() / 1000)}:R>`,
            inline: true
          }
        );
    }

    embed.setFooter({
      text: `Son güncelleme: ${new Date().toLocaleString('tr-TR')}`,
      iconURL: this.client.user.displayAvatarURL()
    });

    return embed;
  }

  startStatusUpdater(intervalMinutes = 1) {
    // Varolan interval'ı temizle
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }

    // İlk güncellemeyi hemen yap
    this.updateBotStatus();

    // Periyodik güncellemeyi başlat
    this.updateInterval = setInterval(() => {
      this.updateBotStatus();
    }, intervalMinutes * 60 * 1000);

    // Global interval listesine ekle
    if (global.activeIntervals) {
      global.activeIntervals.push(this.updateInterval);
    }

    console.log(`[ServerStatus] Durum güncelleyici başlatıldı (${intervalMinutes} dakika aralıkla)`);
  }

  stopStatusUpdater() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
      console.log('[ServerStatus] Durum güncelleyici durduruldu');
    }
  }

  async getServerStatus() {
    return await this.queryServer();
  }
}

module.exports = ServerStatusManager;