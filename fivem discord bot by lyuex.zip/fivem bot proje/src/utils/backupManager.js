// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const lyuex = require('../../lyuex.json');
const { EmbedBuilder } = require('discord.js');

class BackupManager {
    constructor(client) {
        this.client = client;
        this.config = lyuex.backup;
        this.backupPath = path.resolve(this.config.backupPath);
        this.ensureBackupDirectory();
    }

    ensureBackupDirectory() {
        if (!fs.existsSync(this.backupPath)) {
            fs.mkdirSync(this.backupPath, { recursive: true });
            console.log(`📁 Backup dizini oluşturuldu: ${this.backupPath}`);
        }
    }

    async createBackup(manual = false) {
        if (!this.config.enabled && !manual) {
            console.log('⚠️ Otomatik backup devre dışı');
            return;
        }

        // Sunucu ismini al ve temizle
        const lyuexConfig = require('../../lyuex.json');
        const serverName = lyuexConfig.server?.serverismi || 'FiveM-Server';
        const cleanServerName = serverName.replace(/[^a-zA-Z0-9-_]/g, '_'); // Özel karakterleri temizle
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupName = `${cleanServerName}_backup_${timestamp}`;
        const backupDir = path.join(this.backupPath, backupName);
        
        try {
            console.log(`🔄 Backup başlatılıyor: ${backupName}`);
            
            // Backup dizini oluştur
            fs.mkdirSync(backupDir, { recursive: true });

            // Database backup
            if (this.config.items.database) {
                await this.backupDatabase(backupDir);
            }

            // Configuration files backup
            if (this.config.items.configurations) {
                await this.backupConfigurations(backupDir);
            }

            // User data backup
            if (this.config.items.userdata) {
                await this.backupUserData(backupDir);
            }

            // Compress if enabled
            if (this.config.compression) {
                await this.compressBackup(backupDir, backupName);
                // Remove uncompressed folder
                this.removeDirectory(backupDir);
            }

            // Clean old backups
            await this.cleanOldBackups();

            // Send success notification
            if (this.config.notifications.success) {
                await this.sendNotification('success', backupName, manual);
            }

            console.log(`✅ Backup tamamlandı: ${backupName}`);
            return { success: true, backupName, path: this.config.compression ? `${backupDir}.zip` : backupDir };

        } catch (error) {
            console.error(`❌ Backup hatası: ${error.message}`);
            
            // Send failure notification
            if (this.config.notifications.failure) {
                await this.sendNotification('failure', backupName, manual, error.message);
            }

            return { success: false, error: error.message };
        }
    }

    async backupDatabase(backupDir) {
        console.log('📊 Database backup başlatılıyor...');
        
        const dbDir = path.join(backupDir, 'database');
        fs.mkdirSync(dbDir, { recursive: true });

        try {
            // SQLite veritabanları
            const dbFiles = ['ekip.sqlite', 'json.sqlite'];
            for (const dbFile of dbFiles) {
                const sourcePath = path.resolve(dbFile);
                if (fs.existsSync(sourcePath)) {
                    const destPath = path.join(dbDir, dbFile);
                    fs.copyFileSync(sourcePath, destPath);
                    console.log(`  ✓ ${dbFile} yedeklendi`);
                }
            }

            // CroxyDB
            const croxyDbPath = path.resolve('croxydb');
            if (fs.existsSync(croxyDbPath)) {
                const destPath = path.join(dbDir, 'croxydb');
                this.copyDirectory(croxyDbPath, destPath);
                console.log('  ✓ CroxyDB yedeklendi');
            }

            // DB klasörü
            const dbDirPath = path.resolve('db');
            if (fs.existsSync(dbDirPath)) {
                const destPath = path.join(dbDir, 'db');
                this.copyDirectory(dbDirPath, destPath);
                console.log('  ✓ DB klasörü yedeklendi');
            }

        } catch (error) {
            throw new Error(`Database backup hatası: ${error.message}`);
        }
    }

    async backupConfigurations(backupDir) {
        console.log('⚙️ Configuration backup başlatılıyor...');
        
        const configDir = path.join(backupDir, 'configurations');
        fs.mkdirSync(configDir, { recursive: true });

        try {
            // Ana konfigürasyon dosyaları
            const configFiles = ['lyuex.json', 'package.json', 'config.json'];
            for (const configFile of configFiles) {
                const sourcePath = path.resolve(configFile);
                if (fs.existsSync(sourcePath)) {
                    const destPath = path.join(configDir, configFile);
                    fs.copyFileSync(sourcePath, destPath);
                    console.log(`  ✓ ${configFile} yedeklendi`);
                }
            }

            // Data klasörü konfigürasyonları
            const dataPath = path.resolve('data');
            if (fs.existsSync(dataPath)) {
                const destPath = path.join(configDir, 'data');
                this.copyDirectory(dataPath, destPath);
                console.log('  ✓ Data klasörü yedeklendi');
            }

            // Src/data klasörü
            const srcDataPath = path.resolve('src/data');
            if (fs.existsSync(srcDataPath)) {
                const destPath = path.join(configDir, 'src_data');
                this.copyDirectory(srcDataPath, destPath);
                console.log('  ✓ Src/data klasörü yedeklendi');
            }

        } catch (error) {
            throw new Error(`Configuration backup hatası: ${error.message}`);
        }
    }

    async backupUserData(backupDir) {
        console.log('👥 User data backup başlatılıyor...');
        
        const userDataDir = path.join(backupDir, 'userdata');
        fs.mkdirSync(userDataDir, { recursive: true });

        try {
            // Schemas klasörü
            const schemasPath = path.resolve('src/Schemas');
            if (fs.existsSync(schemasPath)) {
                const destPath = path.join(userDataDir, 'Schemas');
                this.copyDirectory(schemasPath, destPath);
                console.log('  ✓ Schemas yedeklendi');
            }

            // JSON veritabanı dosyaları
            const jsonFiles = ['lyuex_database.json', 'lyuex.json'];
            for (const jsonFile of jsonFiles) {
                const sourcePath = path.resolve(jsonFile);
                if (fs.existsSync(sourcePath)) {
                    const destPath = path.join(userDataDir, jsonFile);
                    fs.copyFileSync(sourcePath, destPath);
                    console.log(`  ✓ ${jsonFile} yedeklendi`);
                }
            }

        } catch (error) {
            throw new Error(`User data backup hatası: ${error.message}`);
        }
    }

    async compressBackup(backupDir, backupName) {
        return new Promise((resolve, reject) => {
            console.log('📦 Backup sıkıştırılıyor...');
            
            const output = fs.createWriteStream(`${backupDir}.zip`);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', () => {
                console.log(`  ✓ Backup sıkıştırıldı: ${archive.pointer()} bytes`);
                resolve();
            });

            archive.on('error', (err) => {
                reject(err);
            });

            archive.pipe(output);
            archive.directory(backupDir, false);
            archive.finalize();
        });
    }

    async cleanOldBackups() {
        if (this.config.maxBackups <= 0) return;

        try {
            const files = fs.readdirSync(this.backupPath);
            const backupFiles = files
                .filter(file => file.startsWith('backup_'))
                .map(file => ({
                    name: file,
                    path: path.join(this.backupPath, file),
                    stat: fs.statSync(path.join(this.backupPath, file))
                }))
                .sort((a, b) => b.stat.mtime - a.stat.mtime);

            if (backupFiles.length > this.config.maxBackups) {
                const filesToDelete = backupFiles.slice(this.config.maxBackups);
                
                for (const file of filesToDelete) {
                    if (file.stat.isDirectory()) {
                        this.removeDirectory(file.path);
                    } else {
                        fs.unlinkSync(file.path);
                    }
                    console.log(`🗑️ Eski backup silindi: ${file.name}`);
                }
            }
        } catch (error) {
            console.error(`Eski backup temizleme hatası: ${error.message}`);
        }
    }

    async sendNotification(type, backupName, manual, errorMessage = null) {
        try {
            const channel = this.client.channels.cache.get(this.config.notifications.channelId);
            if (!channel) return;

            let embed;
            
            if (type === 'success') {
                embed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('✅ Backup Başarılı')
                    .setDescription(`Backup işlemi başarıyla tamamlandı!`)
                    .addFields(
                        { name: '📁 Backup Adı', value: backupName, inline: true },
                        { name: '🔧 Tip', value: manual ? 'Manuel' : 'Otomatik', inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    )
                    .setThumbnail('https://cdn.discordapp.com/emojis/755161665392386058.png')
                    .setFooter({ text: 'Backup Sistemi', iconURL: this.client.user.displayAvatarURL() })
                    .setTimestamp();
            } else {
                embed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Backup Başarısız')
                    .setDescription(`Backup işlemi sırasında hata oluştu!`)
                    .addFields(
                        { name: '📁 Backup Adı', value: backupName, inline: true },
                        { name: '🔧 Tip', value: manual ? 'Manuel' : 'Otomatik', inline: true },
                        { name: '❌ Hata', value: errorMessage || 'Bilinmeyen hata', inline: false },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    )
                    .setThumbnail('https://cdn.discordapp.com/emojis/755161665392386058.png')
                    .setFooter({ text: 'Backup Sistemi', iconURL: this.client.user.displayAvatarURL() })
                    .setTimestamp();
            }

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(`Backup bildirimi gönderme hatası: ${error.message}`);
        }
    }

    copyDirectory(src, dest) {
        if (!fs.existsSync(dest)) {
            fs.mkdirSync(dest, { recursive: true });
        }

        const files = fs.readdirSync(src);
        for (const file of files) {
            const srcPath = path.join(src, file);
            const destPath = path.join(dest, file);
            
            if (fs.statSync(srcPath).isDirectory()) {
                this.copyDirectory(srcPath, destPath);
            } else {
                fs.copyFileSync(srcPath, destPath);
            }
        }
    }

    removeDirectory(dir) {
        if (fs.existsSync(dir)) {
            fs.rmSync(dir, { recursive: true, force: true });
        }
    }

    listBackups() {
        try {
            if (!fs.existsSync(this.backupPath)) {
                return [];
            }
            
            const files = fs.readdirSync(this.backupPath);
            return files
                .filter(file => file.includes('backup') && (file.endsWith('.zip') || fs.statSync(path.join(this.backupPath, file)).isDirectory()))
                .map(file => {
                    const filePath = path.join(this.backupPath, file);
                    const stat = fs.statSync(filePath);
                    return {
                        name: file,
                        path: filePath,
                        size: this.formatBytes(stat.size),
                        created: stat.birthtime,
                        isCompressed: file.endsWith('.zip')
                    };
                })
                .sort((a, b) => b.created - a.created);
        } catch (error) {
            console.error(`Backup listesi alma hatası: ${error.message}`);
            return [];
        }
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async restoreBackup(backupName) {
        const startTime = Date.now();
        const backupFile = path.join(this.backupPath, backupName);

        if (!fs.existsSync(backupFile)) {
            throw new Error(`Backup dosyası bulunamadı: ${backupName}`);
        }

        console.log(`🔄 Backup geri yükleme başlatılıyor: ${backupName}`);

        try {
            const extract = require('extract-zip');
            const tempRestoreDir = path.join(this.backupPath, 'temp_restore');

            // Geçici restore dizinini temizle
            if (fs.existsSync(tempRestoreDir)) {
                fs.rmSync(tempRestoreDir, { recursive: true, force: true });
            }
            fs.mkdirSync(tempRestoreDir, { recursive: true });

            // Backup'ı geçici dizine çıkart
            await extract(backupFile, { dir: tempRestoreDir });

            let restoredFiles = 0;

            // Dosyaları geri yükle
            for (const [sourceDir, targetDir] of Object.entries(this.config.paths)) {
                const sourceBackupPath = path.join(tempRestoreDir, path.basename(sourceDir));
                const targetPath = path.resolve(targetDir);

                if (fs.existsSync(sourceBackupPath)) {
                    // Hedef dizini yedekle (güvenlik için)
                    const backupTargetDir = `${targetPath}_backup_${Date.now()}`;
                    if (fs.existsSync(targetPath)) {
                        fs.renameSync(targetPath, backupTargetDir);
                        console.log(`💾 Güvenlik yedeği: ${backupTargetDir}`);
                    }

                    // Yeni dosyaları kopyala
                    this.copyRecursive(sourceBackupPath, targetPath);
                    restoredFiles += this.countFiles(targetPath);
                    console.log(`✅ Geri yüklendi: ${sourceDir} -> ${targetDir}`);
                }
            }

            // Geçici dizini temizle
            fs.rmSync(tempRestoreDir, { recursive: true, force: true });

            const duration = Date.now() - startTime;
            console.log(`✅ Backup başarıyla geri yüklendi: ${restoredFiles} dosya, ${duration}ms`);

            return {
                success: true,
                backupName,
                restoredFiles,
                duration
            };

        } catch (error) {
            console.error('❌ Backup geri yükleme hatası:', error);
            throw new Error(`Backup geri yüklenemedi: ${error.message}`);
        }
    }

    async deleteBackup(backupName) {
        const backupFile = path.join(this.backupPath, backupName);

        if (!fs.existsSync(backupFile)) {
            throw new Error(`Backup dosyası bulunamadı: ${backupName}`);
        }

        try {
            // Dosya boyutunu al (log için)
            const stats = fs.statSync(backupFile);
            const fileSize = this.formatBytes(stats.size);

            // Backup'ı sil
            fs.unlinkSync(backupFile);
            console.log(`🗑️ Backup silindi: ${backupName} (${fileSize})`);

            return {
                success: true,
                backupName,
                freedSpace: fileSize
            };

        } catch (error) {
            console.error('❌ Backup silme hatası:', error);
            throw new Error(`Backup silinemedi: ${error.message}`);
        }
    }

    copyRecursive(source, target) {
        if (!fs.existsSync(source)) return;

        // Hedef dizini oluştur
        if (!fs.existsSync(target)) {
            fs.mkdirSync(target, { recursive: true });
        }

        const files = fs.readdirSync(source);
        
        for (const file of files) {
            const sourcePath = path.join(source, file);
            const targetPath = path.join(target, file);
            
            if (fs.statSync(sourcePath).isDirectory()) {
                this.copyRecursive(sourcePath, targetPath);
            } else {
                fs.copyFileSync(sourcePath, targetPath);
            }
        }
    }

    countFiles(dir) {
        if (!fs.existsSync(dir)) return 0;

        let count = 0;
        const files = fs.readdirSync(dir);

        for (const file of files) {
            const filePath = path.join(dir, file);
            if (fs.statSync(filePath).isDirectory()) {
                count += this.countFiles(filePath);
            } else {
                count++;
            }
        }

        return count;
    }
}

module.exports = BackupManager;




