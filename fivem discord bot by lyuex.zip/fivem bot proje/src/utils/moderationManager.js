// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Moderation, Mute, TempBan } = require('../Schemas/ModerationSchema');
const { EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

/**
 * Moderasyon yönetimi için yardımcı fonksiyonlar
 */
class ModerationManager {
  
  /**
   * Yeni case ID oluşturur
   * @param {String} guildId - Sunucu ID
   * @returns {Promise<String>} Case ID
   */
  static async generateCaseId(guildId) {
    try {
      const lastCase = await Moderation.findOne({ guildId })
        .sort({ createdAt: -1 })
        .select('caseId');
      
      if (!lastCase) {
        return `${guildId}-1`;
      }
      
      const lastNumber = parseInt(lastCase.caseId.split('-')[1]) || 0;
      return `${guildId}-${lastNumber + 1}`;
    } catch (error) {
      console.error('Case ID oluşturma hatası:', error);
      return `${guildId}-${Date.now()}`;
    }
  }

  /**
   * Mute rolü ID'sini alır veya oluşturur
   * @param {Object} guild - Discord guild objesi
   * @returns {Promise<String>} Mute rol ID
   */
  static async getMuteRole(guild) {
    try {
      // Önce mevcut mute rolünü ara
      let muteRole = guild.roles.cache.find(role => 
        role.name === 'Muted' || 
        role.name === 'Susturuldu' ||
        role.id === lyuex.roles?.muted
      );

      if (!muteRole) {
        // Mute rolü yoksa oluştur
        muteRole = await guild.roles.create({
          name: 'Muted',
          color: '#818386', // Gri renk
          permissions: [],
          reason: 'Otomatik mute rolü oluşturuldu'
        });

        // Tüm kanallarda konuşma izinlerini kapat
        const channels = guild.channels.cache;
        for (const channel of channels.values()) {
          if (channel.isTextBased()) {
            try {
              await channel.permissionOverwrites.create(muteRole, {
                SendMessages: false,
                AddReactions: false,
                CreatePublicThreads: false,
                CreatePrivateThreads: false,
                SendMessagesInThreads: false,
                UseApplicationCommands: false
              });
            } catch (permError) {
              console.error(`Kanal izin hatası (${channel.name}):`, permError.message);
            }
          } else if (channel.isVoiceBased()) {
            try {
              await channel.permissionOverwrites.create(muteRole, {
                Speak: false,
                Stream: false,
                UseVAD: false
              });
            } catch (permError) {
              console.error(`Ses kanalı izin hatası (${channel.name}):`, permError.message);
            }
          }
        }

        console.log(`✅ Mute rolü oluşturuldu: ${muteRole.name} (${muteRole.id})`);
      }

      return muteRole.id;
    } catch (error) {
      console.error('Mute rolü alma/oluşturma hatası:', error);
      throw new Error('Mute rolü oluşturulamadı');
    }
  }

  /**
   * Kullanıcıya DM gönderir
   * @param {Object} user - Discord kullanıcı objesi
   * @param {Object} embed - Gönderilecek embed
   * @returns {Promise<Boolean>} Başarı durumu
   */
  static async sendDM(user, embed) {
    try {
      await user.send({ embeds: [embed] });
      return true;
    } catch (error) {
      console.error(`DM gönderilemedi (${user.tag}):`, error.message);
      return false;
    }
  }

  /**
   * Log kanalına moderasyon işlemini gönderir
   * @param {Object} guild - Discord guild objesi
   * @param {Object} embed - Log embed'i
   */
  static async sendToLogChannel(guild, embed) {
    try {
      const logChannelId = lyuex.channels?.moderation_log || lyuex.channels?.log;
      if (!logChannelId) return;

      const logChannel = guild.channels.cache.get(logChannelId);
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error('Log kanalına gönderme hatası:', error);
    }
  }

  /**
   * Kullanıcıyı banlar
   * @param {Object} options - Ban seçenekleri
   * @returns {Promise<Object>} Ban sonucu
   */
  static async banUser(options) {
    const { 
      guild, 
      user, 
      moderator, 
      reason = 'Sebep belirtilmedi', 
      duration = null, 
      deleteMessages = 1 
    } = options;

    try {
      const caseId = await this.generateCaseId(guild.id);
      const banType = duration ? 'tempban' : 'ban';
      const expiresAt = duration ? new Date(Date.now() + duration * 60000) : null;

      // Discord'da banla
      await guild.members.ban(user, { 
        reason: `${reason} | Moderatör: ${moderator.tag} | Case: ${caseId}`,
        deleteMessageDays: deleteMessages 
      });

      // Veritabanına kaydet
      const moderationRecord = new Moderation({
        caseId,
        guildId: guild.id,
        type: banType,
        userId: user.id,
        username: user.username,
        userTag: user.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        duration,
        expiresAt,
        active: true
      });

      await moderationRecord.save();

      // Geçici ban ise ayrı tabloya da kaydet
      if (duration) {
        const tempBan = new TempBan({
          userId: user.id,
          guildId: guild.id,
          moderatorId: moderator.id,
          reason,
          endTime: expiresAt,
          caseId
        });
        await tempBan.save();
      }

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle(`🔨 ${guild.name} Sunucusundan ${duration ? 'Geçici ' : ''}Banlandınız`)
        .setDescription(
          `**Sebep:** ${reason}\n` +
          `**Moderatör:** ${moderator.tag}\n` +
          `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          (duration ? `**Süre:** ${this.formatDuration(duration)}\n` : '') +
          (duration ? `**Bitiş:** <t:${Math.floor(expiresAt.getTime() / 1000)}:F>\n` : '') +
          `**Case ID:** ${caseId}`
        )
        .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
        .setTimestamp();

      const dmSent = await this.sendDM(user, dmEmbed);
      if (dmSent) {
        moderationRecord.dmSent = true;
        await moderationRecord.save();
      }

      // Log embed'i
      const logEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle(`🔨 ${duration ? 'Geçici ' : ''}Ban`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user.tag} (${user.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📋 Case ID', value: caseId, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true }
        )
        .setFooter({ text: `${guild.name} • Moderasyon Log` })
        .setTimestamp();

      if (duration) {
        logEmbed.addFields(
          { name: '⏰ Süre', value: this.formatDuration(duration), inline: true },
          { name: '🏁 Bitiş', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:F>`, inline: true }
        );
      }

      await this.sendToLogChannel(guild, logEmbed);

      return {
        success: true,
        caseId,
        dmSent,
        record: moderationRecord
      };

    } catch (error) {
      console.error('Ban hatası:', error);
      throw error;
    }
  }

  /**
   * Kullanıcıyı kick'ler
   * @param {Object} options - Kick seçenekleri
   * @returns {Promise<Object>} Kick sonucu
   */
  static async kickUser(options) {
    const { guild, member, moderator, reason = 'Sebep belirtilmedi' } = options;

    try {
      const caseId = await this.generateCaseId(guild.id);
      const user = member.user;

      // Veritabanına kaydet
      const moderationRecord = new Moderation({
        caseId,
        guildId: guild.id,
        type: 'kick',
        userId: user.id,
        username: user.username,
        userTag: user.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        active: true
      });

      await moderationRecord.save();

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor(0xFF8C00)
        .setTitle(`👢 ${guild.name} Sunucusundan Atıldınız`)
        .setDescription(
          `**Sebep:** ${reason}\n` +
          `**Moderatör:** ${moderator.tag}\n` +
          `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          `**Case ID:** ${caseId}`
        )
        .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
        .setTimestamp();

      const dmSent = await this.sendDM(user, dmEmbed);

      // Discord'dan kick'le
      await member.kick(`${reason} | Moderatör: ${moderator.tag} | Case: ${caseId}`);

      if (dmSent) {
        moderationRecord.dmSent = true;
        await moderationRecord.save();
      }

      // Log embed'i
      const logEmbed = new EmbedBuilder()
        .setColor(0xFF8C00)
        .setTitle('👢 Kick')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user.tag} (${user.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📋 Case ID', value: caseId, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true }
        )
        .setFooter({ text: `${guild.name} • Moderasyon Log` })
        .setTimestamp();

      await this.sendToLogChannel(guild, logEmbed);

      return {
        success: true,
        caseId,
        dmSent,
        record: moderationRecord
      };

    } catch (error) {
      console.error('Kick hatası:', error);
      throw error;
    }
  }

  /**
   * Kullanıcıyı mute'lar
   * @param {Object} options - Mute seçenekleri
   * @returns {Promise<Object>} Mute sonucu
   */
  static async muteUser(options) {
    const { 
      guild, 
      member, 
      moderator, 
      reason = 'Sebep belirtilmedi', 
      duration = null 
    } = options;

    try {
      const caseId = await this.generateCaseId(guild.id);
      const user = member.user;
      const muteRoleId = await this.getMuteRole(guild);
      const muteRole = guild.roles.cache.get(muteRoleId);

      if (!muteRole) {
        throw new Error('Mute rolü bulunamadı');
      }

      // Kullanıcının mevcut rollerini kaydet (mute rolü hariç)
      const originalRoles = member.roles.cache
        .filter(role => role.id !== guild.id && role.id !== muteRoleId)
        .map(role => role.id);

      const muteType = duration ? 'tempmute' : 'mute';
      const expiresAt = duration ? new Date(Date.now() + duration * 60000) : null;

      // Kullanıcının rollerini temizle ve mute rolünü ver
      await member.roles.set([muteRoleId], 
        `Mute işlemi | Moderatör: ${moderator.tag} | Case: ${caseId}`
      );

      // Veritabanına kaydet
      const moderationRecord = new Moderation({
        caseId,
        guildId: guild.id,
        type: muteType,
        userId: user.id,
        username: user.username,
        userTag: user.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        duration,
        expiresAt,
        active: true
      });

      await moderationRecord.save();

      // Aktif mute kaydı oluştur
      const muteRecord = new Mute({
        userId: user.id,
        guildId: guild.id,
        moderatorId: moderator.id,
        reason,
        muteRoleId,
        originalRoles,
        endTime: expiresAt,
        caseId
      });

      await muteRecord.save();

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle(`🔇 ${guild.name} Sunucusunda ${duration ? 'Geçici ' : ''}Susturuldunuz`)
        .setDescription(
          `**Sebep:** ${reason}\n` +
          `**Moderatör:** ${moderator.tag}\n` +
          `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          (duration ? `**Süre:** ${this.formatDuration(duration)}\n` : '') +
          (duration ? `**Bitiş:** <t:${Math.floor(expiresAt.getTime() / 1000)}:F>\n` : '') +
          `**Case ID:** ${caseId}`
        )
        .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
        .setTimestamp();

      const dmSent = await this.sendDM(user, dmEmbed);
      if (dmSent) {
        moderationRecord.dmSent = true;
        await moderationRecord.save();
      }

      // Log embed'i
      const logEmbed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle(`🔇 ${duration ? 'Geçici ' : ''}Mute`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user.tag} (${user.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📋 Case ID', value: caseId, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true }
        )
        .setFooter({ text: `${guild.name} • Moderasyon Log` })
        .setTimestamp();

      if (duration) {
        logEmbed.addFields(
          { name: '⏰ Süre', value: this.formatDuration(duration), inline: true },
          { name: '🏁 Bitiş', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:F>`, inline: true }
        );
      }

      await this.sendToLogChannel(guild, logEmbed);

      return {
        success: true,
        caseId,
        dmSent,
        record: moderationRecord,
        muteRecord
      };

    } catch (error) {
      console.error('Mute hatası:', error);
      throw error;
    }
  }

  /**
   * Kullanıcının mute'unu kaldırır
   * @param {Object} options - Unmute seçenekleri
   * @returns {Promise<Object>} Unmute sonucu
   */
  static async unmuteUser(options) {
    const { guild, member, moderator, reason = 'Manuel unmute' } = options;

    try {
      const user = member.user;
      
      // Aktif mute kaydını bul
      const muteRecord = await Mute.findOne({
        userId: user.id,
        guildId: guild.id,
        active: true
      });

      if (!muteRecord) {
        throw new Error('Bu kullanıcı susturulmamış');
      }

      const caseId = await this.generateCaseId(guild.id);

      // Orijinal rolleri geri ver
      const rolesToAdd = muteRecord.originalRoles.filter(roleId => 
        guild.roles.cache.has(roleId)
      );

      if (rolesToAdd.length > 0) {
        await member.roles.set(rolesToAdd, 
          `Unmute işlemi | Moderatör: ${moderator.tag} | Case: ${caseId}`
        );
      } else {
        // Eğer orijinal rol yoksa sadece mute rolünü kaldır
        const muteRole = guild.roles.cache.get(muteRecord.muteRoleId);
        if (muteRole && member.roles.cache.has(muteRole.id)) {
          await member.roles.remove(muteRole);
        }
      }

      // Mute kaydını pasif yap
      muteRecord.active = false;
      await muteRecord.save();

      // Orijinal mute kaydını güncelle
      await Moderation.updateOne(
        { caseId: muteRecord.caseId },
        { active: false }
      );

      // Yeni unmute kaydı oluştur
      const moderationRecord = new Moderation({
        caseId,
        guildId: guild.id,
        type: 'unmute',
        userId: user.id,
        username: user.username,
        userTag: user.tag,
        moderatorId: moderator.id,
        moderatorTag: moderator.tag,
        reason,
        active: true
      });

      await moderationRecord.save();

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle(`🔊 ${guild.name} Sunucusunda Susturmanız Kaldırıldı`)
        .setDescription(
          `**Sebep:** ${reason}\n` +
          `**Moderatör:** ${moderator.tag}\n` +
          `**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          `**Case ID:** ${caseId}`
        )
        .setFooter({ text: `${guild.name} • Moderasyon Sistemi` })
        .setTimestamp();

      const dmSent = await this.sendDM(user, dmEmbed);
      if (dmSent) {
        moderationRecord.dmSent = true;
        await moderationRecord.save();
      }

      // Log embed'i
      const logEmbed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🔊 Unmute')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user.tag} (${user.id})`, inline: true },
          { name: '👮 Moderatör', value: `${moderator.tag}`, inline: true },
          { name: '📋 Case ID', value: caseId, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '📱 DM', value: dmSent ? '✅ Gönderildi' : '❌ Gönderilemedi', inline: true }
        )
        .setFooter({ text: `${guild.name} • Moderasyon Log` })
        .setTimestamp();

      await this.sendToLogChannel(guild, logEmbed);

      return {
        success: true,
        caseId,
        dmSent,
        record: moderationRecord
      };

    } catch (error) {
      console.error('Unmute hatası:', error);
      throw error;
    }
  }

  /**
   * Süre formatını düzenler
   * @param {Number} minutes - Dakika cinsinden süre
   * @returns {String} Formatlanmış süre
   */
  static formatDuration(minutes) {
    if (minutes < 60) {
      return `${minutes} dakika`;
    } else if (minutes < 1440) {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      return remainingMinutes > 0 ? `${hours} saat ${remainingMinutes} dakika` : `${hours} saat`;
    } else {
      const days = Math.floor(minutes / 1440);
      const remainingHours = Math.floor((minutes % 1440) / 60);
      let result = `${days} gün`;
      if (remainingHours > 0) result += ` ${remainingHours} saat`;
      return result;
    }
  }

  /**
   * Süresi dolan mute'ları kontrol eder
   * @param {Object} client - Discord client
   */
  static async checkExpiredMutes(client) {
    try {
      const expiredMutes = await Mute.find({
        active: true,
        endTime: { $lte: new Date(), $ne: null }
      });

      for (const muteRecord of expiredMutes) {
        try {
          const guild = client.guilds.cache.get(muteRecord.guildId);
          if (!guild) continue;

          const member = await guild.members.fetch(muteRecord.userId).catch(() => null);
          if (!member) {
            // Kullanıcı sunucuda değil, kaydı pasif yap
            muteRecord.active = false;
            await muteRecord.save();
            continue;
          }

          // Otomatik unmute yap
          await this.unmuteUser({
            guild,
            member,
            moderator: client.user, // Bot olarak unmute
            reason: 'Süre doldu (Otomatik)'
          });

          console.log(`🔊 Otomatik unmute: ${member.user.tag} (${muteRecord.caseId})`);

        } catch (error) {
          console.error(`Otomatik unmute hatası (${muteRecord.caseId}):`, error);
        }
      }
    } catch (error) {
      console.error('Expired mute kontrolü hatası:', error);
    }
  }

  /**
   * Süresi dolan ban'ları kontrol eder
   * @param {Object} client - Discord client
   */
  static async checkExpiredBans(client) {
    try {
      const expiredBans = await TempBan.find({
        active: true,
        endTime: { $lte: new Date() }
      });

      for (const banRecord of expiredBans) {
        try {
          const guild = client.guilds.cache.get(banRecord.guildId);
          if (!guild) continue;

          // Ban'ı kaldır
          await guild.members.unban(banRecord.userId, 'Geçici ban süresi doldu');

          // Kayıtları güncelle
          banRecord.active = false;
          await banRecord.save();

          await Moderation.updateOne(
            { caseId: banRecord.caseId },
            { active: false }
          );

          // Yeni unban kaydı oluştur
          const caseId = await this.generateCaseId(guild.id);
          const unbanRecord = new Moderation({
            caseId,
            guildId: guild.id,
            type: 'unban',
            userId: banRecord.userId,
            username: 'Bilinmeyen Kullanıcı',
            userTag: 'Bilinmeyen#0000',
            moderatorId: client.user.id,
            moderatorTag: client.user.tag,
            reason: 'Geçici ban süresi doldu (Otomatik)',
            active: true
          });

          await unbanRecord.save();

          console.log(`🔓 Otomatik unban: ${banRecord.userId} (${banRecord.caseId})`);

        } catch (error) {
          console.error(`Otomatik unban hatası (${banRecord.caseId}):`, error);
        }
      }
    } catch (error) {
      console.error('Expired ban kontrolü hatası:', error);
    }
  }
}

module.exports = ModerationManager;




