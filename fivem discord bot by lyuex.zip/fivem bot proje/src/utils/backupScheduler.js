// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const cron = require('node-cron');
const BackupManager = require('../utils/backupManager');
const lyuex = require('../../lyuex.json');

class BackupScheduler {
    constructor(client) {
        this.client = client;
        this.backupManager = new BackupManager(client);
        this.config = lyuex.backup;
        this.scheduledTask = null;
        
        if (this.config.enabled) {
            this.startScheduler();
        }
    }

    startScheduler() {
        if (this.scheduledTask) {
            this.scheduledTask.stop();
        }

        const cronExpression = this.getCronExpression();
        
        console.log(`⏰ Backup scheduler başlatılıyor: ${this.config.interval} (${this.config.time})`);
        console.log(`📅 Cron expression: ${cronExpression}`);
        
        this.scheduledTask = cron.schedule(cronExpression, async () => {
            console.log(`🔄 Zamanlanmış backup başlatılıyor...`);
            await this.backupManager.createBackup(false);
        }, {
            scheduled: true,
            timezone: "Europe/Istanbul"
        });

        console.log(`✅ Backup scheduler aktif edildi`);
    }

    stopScheduler() {
        if (this.scheduledTask) {
            this.scheduledTask.stop();
            this.scheduledTask = null;
            console.log(`⏹️ Backup scheduler durduruldu`);
        }
    }

    getCronExpression() {
        const [hour, minute] = this.config.time.split(':').map(num => parseInt(num));
        
        switch (this.config.interval) {
            case 'hourly':
                return `${minute} * * * *`; // Her saat belirtilen dakikada
            
            case 'daily':
                return `${minute} ${hour} * * *`; // Her gün belirtilen saatte
            
            case 'weekly':
                return `${minute} ${hour} * * 0`; // Her hafta pazar günü belirtilen saatte
            
            case 'monthly':
                return `${minute} ${hour} 1 * *`; // Her ayın 1'inde belirtilen saatte
            
            default:
                return `${minute} ${hour} * * *`; // Varsayılan: günlük
        }
    }

    updateSchedule(interval, time) {
        this.config.interval = interval;
        this.config.time = time;
        
        if (this.config.enabled) {
            this.startScheduler();
        }
    }

    getNextBackupTime() {
        if (!this.scheduledTask) return null;
        
        // Basit hesaplama - sonraki gün saat 03:00
        const now = new Date();
        const nextBackup = new Date(now);
        nextBackup.setHours(3, 0, 0, 0); // 03:00:00
        
        // Eğer şu anki saat 03:00'ı geçtiyse, ertesi gün
        if (now.getHours() >= 3) {
            nextBackup.setDate(nextBackup.getDate() + 1);
        }
        
        return nextBackup;
    }

    toggleScheduler() {
        this.config.enabled = !this.config.enabled;
        
        if (this.config.enabled) {
            this.startScheduler();
            console.log(`✅ Backup scheduler aktif edildi`);
        } else {
            this.stopScheduler();
            console.log(`⏹️ Backup scheduler devre dışı bırakıldı`);
        }
        
        return this.config.enabled;
    }

    getStatus() {
        return {
            enabled: this.config.enabled,
            interval: this.config.interval,
            time: this.config.time,
            isRunning: this.scheduledTask !== null,
            nextBackup: this.getNextBackupTime(),
            maxBackups: this.config.maxBackups,
            compression: this.config.compression
        };
    }
}

module.exports = BackupScheduler;




