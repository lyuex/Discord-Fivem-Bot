// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const Giveaway = require('../Schemas/GiveawaySchema');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

/**
 * Giveaway yönetim fonksiyonları
 */
const GiveawayManager = {
  /**
   * Veritabanına yeni çekiliş kaydeder
   * @param {Object} giveawayData - Çekiliş bilgileri
   * @returns {Promise<Object>} Kaydedilen çekiliş bilgisi
   */
  async createGiveaway(giveawayData) {
    try {
      const newGiveaway = new Giveaway(giveawayData);
      await newGiveaway.save();
      console.log(`✅ Çekiliş veritabanına kaydedildi: ${giveawayData.prize} (${giveawayData.messageId})`);
      return newGiveaway;
    } catch (error) {
      console.error('Çekiliş kaydetme hatası:', error);
      throw error;
    }
  },

  /**
   * Tüm aktif çekilişleri getirir
   * @param {String} guildId - Sunucu ID
   * @returns {Promise<Array>} Aktif çekiliş listesi
   */
  async getActiveGiveaways(guildId) {
    try {
      return await Giveaway.find({ 
        guildId, 
        status: 'active',
        endTime: { $gt: new Date() }
      }).sort({ endTime: 1 });
    } catch (error) {
      console.error('Aktif çekiliş getirme hatası:', error);
      return [];
    }
  },

  /**
   * Bir çekilişin detaylarını getirir
   * @param {String} messageId - Çekiliş mesaj ID
   * @returns {Promise<Object|null>} Çekiliş bilgisi
   */
  async getGiveawayByMessageId(messageId) {
    try {
      return await Giveaway.findOne({ messageId });
    } catch (error) {
      console.error('Çekiliş getirme hatası:', error);
      return null;
    }
  },

  /**
   * Çekiliş katılımcısını günceller
   * @param {String} messageId - Çekiliş mesaj ID
   * @param {String} userId - Kullanıcı ID
   * @param {String} username - Kullanıcı adı
   * @param {Number} multiplier - Katılım çarpanı
   * @param {Boolean} isJoining - Katılma/ayrılma durumu
   * @returns {Promise<Object|null>} Güncellenmiş çekiliş
   */
  async updateParticipant(messageId, userId, username, multiplier = 1, isJoining = true) {
    try {
      const giveaway = await Giveaway.findOne({ messageId });
      if (!giveaway) return null;
      
      if (isJoining) {
        // Kullanıcı zaten katılmışsa, güncelleme yap
        const existingIndex = giveaway.participants.findIndex(p => p.userId === userId);
        if (existingIndex >= 0) {
          giveaway.participants[existingIndex].multiplier = multiplier;
        } else {
          // Yoksa yeni katılımcı ekle
          giveaway.participants.push({ userId, username, multiplier });
        }
      } else {
        // Katılımcıyı çıkar
        giveaway.participants = giveaway.participants.filter(p => p.userId !== userId);
      }
      
      giveaway.lastUpdated = new Date();
      await giveaway.save();
      return giveaway;
    } catch (error) {
      console.error('Katılımcı güncelleme hatası:', error);
      return null;
    }
  },

  /**
   * Çekilişi tamamla ve kazananları belirle
   * @param {String} messageId - Çekiliş mesaj ID
   * @param {Array} winners - Kazananlar listesi
   * @returns {Promise<Object|null>} Güncellenmiş çekiliş
   */
  async completeGiveaway(messageId, winners) {
    try {
      const giveaway = await Giveaway.findOne({ messageId });
      if (!giveaway) return null;
      
      giveaway.status = 'completed';
      giveaway.winners = winners.map(winner => ({
        userId: winner.id,
        username: winner.tag || winner.username || 'Bilinmeyen Kullanıcı'
      }));
      giveaway.lastUpdated = new Date();
      
      await giveaway.save();
      console.log(`✅ Çekiliş tamamlandı: ${giveaway.prize} (${messageId})`);
      return giveaway;
    } catch (error) {
      console.error('Çekiliş tamamlama hatası:', error);
      return null;
    }
  },

  /**
   * Süresi dolmuş aktif çekilişleri getirir
   * @returns {Promise<Array>} Süresi dolmuş çekilişler
   */
  async getEndedGiveaways() {
    try {
      return await Giveaway.find({ 
        status: 'active',
        endTime: { $lte: new Date() }
      });
    } catch (error) {
      console.error('Bitmiş çekiliş getirme hatası:', error);
      return [];
    }
  },

  /**
   * Çekilişi iptal eder
   * @param {String} messageId - Çekiliş mesaj ID
   * @param {String} reason - İptal sebebi
   * @returns {Promise<Object|null>} Güncellenmiş çekiliş
   */
  async cancelGiveaway(messageId, reason = 'Belirsiz') {
    try {
      const giveaway = await Giveaway.findOne({ messageId });
      if (!giveaway) return null;
      
      giveaway.status = 'cancelled';
      giveaway.description = `${giveaway.description || ''}\n\n❌ İptal Edildi: ${reason}`;
      giveaway.lastUpdated = new Date();
      
      await giveaway.save();
      console.log(`❌ Çekiliş iptal edildi: ${giveaway.prize} (${messageId})`);
      return giveaway;
    } catch (error) {
      console.error('Çekiliş iptal hatası:', error);
      return null;
    }
  },

  /**
   * Kazananları yeniden belirler
   * @param {String} messageId - Çekiliş mesaj ID
   * @param {Array} newWinners - Yeni kazananlar
   * @returns {Promise<Object|null>} Güncellenmiş çekiliş
   */
  async rerollGiveaway(messageId, newWinners) {
    try {
      const giveaway = await Giveaway.findOne({ messageId });
      if (!giveaway) return null;
      
      // Önceki kazananları sakla
      const previousWinners = [...giveaway.winners];
      
      // Yeni kazananları ekle
      giveaway.winners = newWinners.map(winner => ({
        userId: winner.id,
        username: winner.tag || winner.username || 'Bilinmeyen Kullanıcı'
      }));
      
      giveaway.lastUpdated = new Date();
      await giveaway.save();
      
      console.log(`🔄 Çekiliş yeniden çekildi: ${giveaway.prize} (${messageId})`);
      return { giveaway, previousWinners };
    } catch (error) {
      console.error('Çekiliş yeniden çekme hatası:', error);
      return null;
    }
  },

  /**
   * Çekilişi siler
   * @param {String} messageId - Çekiliş mesaj ID
   * @returns {Promise<Boolean>} Başarı durumu
   */
  async deleteGiveaway(messageId) {
    try {
      const result = await Giveaway.deleteOne({ messageId });
      return result.deletedCount > 0;
    } catch (error) {
      console.error('Çekiliş silme hatası:', error);
      return false;
    }
  },

  /**
   * Bitmiş çekilişleri günceller
   * @param {Object} client - Discord client
   * @returns {Promise<void>}
   */
  async checkEndedGiveaways(client) {
    try {
      const endedGiveaways = await this.getEndedGiveaways();
      
      for (const giveaway of endedGiveaways) {
        try {
          const guild = client.guilds.cache.get(giveaway.guildId);
          if (!guild) continue;
          
          const channel = guild.channels.cache.get(giveaway.channelId);
          if (!channel) continue;
          
          const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
          if (!message) continue;
          
          // Eğer çekiliş mesajı hala aktif durumdaysa (tamamlanmamışsa), manuel olarak sonlandır
          if (giveaway.status === 'active') {
            console.log(`🕒 Süresi dolmuş çekiliş sonlandırılıyor: ${giveaway.prize} (${giveaway.messageId})`);
            
            // TODO: Burada çekilişi sonlandırma mantığını eklemelisiniz
            // Bu işlemler içerisinde kazananların seçilmesi, mesajın güncellenmesi ve database kaydı yer alır
            // Bu örnekte yalnızca database güncellemesi yapılacak
            
            await this.completeGiveaway(giveaway.messageId, []); // Boş kazananlar listesi
          }
        } catch (giveawayError) {
          console.error(`Çekiliş işleme hatası (${giveaway.messageId}):`, giveawayError);
          continue;
        }
      }
    } catch (error) {
      console.error('Bitmiş çekiliş kontrolü hatası:', error);
    }
  }
};

module.exports = GiveawayManager;




