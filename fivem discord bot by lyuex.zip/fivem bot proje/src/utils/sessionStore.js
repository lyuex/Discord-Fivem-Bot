// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿// Shared session store to avoid duplicate module instances across commands and events
// Use this to keep ekip uyarı temporary data consistent

const ekipUyariSessions = new Map();

module.exports = {
  ekipUyariSessions,
};




