// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿/**
 * ADMIN KONTROL SİSTEMİ
 * 
 * Sadece sunucu sahibi + bot sahibi işlem yapabilecek
 * LYUEX için özel ayar
 */

class AdminControl {
  /**
   * BOT SAHİBİ IDLERİ
   * Buraya bot sahibi ID'lerini ekle
   */
  static BOT_OWNERS = [
    '384385365815066624', // Bot sahibi ID - Kendi ID'n
    // Diğer bot sahibi IDs...
  ];

  /**
   * ADMIN KONTROLÜ YAP
   */
  static isAdmin(userId, guildOwnerId) {
    // Bot sahibi mi?
    if (this.BOT_OWNERS.includes(userId)) {
      return { success: true, role: 'BOT_OWNER' };
    }

    // Sunucu sahibi mi?
    if (userId === guildOwnerId) {
      return { success: true, role: 'GUILD_OWNER' };
    }

    return { success: false, role: 'NONE' };
  }



  /**
   * ERROR EMBEDİ OLUŞTUR
   */
  static createAccessDeniedEmbed() {
    const { EmbedBuilder } = require('discord.js');
    
    return new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('❌ ERIŞIM REDDEDİLDİ')
      .setDescription('Bu işlem sadece **Sunucu Sahibi** veya **Bot Sahibi** tarafından yapılabilir!')
      .addFields(
        { name: '🔐 Sebep', value: 'Sistem konfigürasyonu', inline: false },
        { name: '📝 Not', value: '`LYUEX` sadece kurucuları tarafından yönetilir', inline: false }
      )
      .setFooter({ text: 'LYUEX • Admin Sistemi' })
      .setTimestamp();
  }


}

module.exports = AdminControl;





