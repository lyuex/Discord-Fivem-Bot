// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');

module.exports = (client) => {
    const eventFiles = fs.readdirSync('./src/events').filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        // Skip interaction handler files as they are not Discord events
        if (file.includes('InteractionHandler') || file.includes('Handler')) {
            continue;
        }
        
        const eventModule = require(`../events/${file}`);
        
        // Some files export arrays of events, others export single events
        const events = Array.isArray(eventModule) ? eventModule : [eventModule];
        
        for (const event of events) {
            if (!event.name) {
                console.log(`Warning: Event in ${file} has no name property`);
                continue;
            }
            
            if (event.once) {
                client.once(event.name, (...args) => {
                    event.execute(...args, client);
                });
            } else {
                client.on(event.name, (...args) => {
                    event.execute(...args, client);
                });
            }
            console.log(`[LYUEX] ✅ Event yüklendi: ${event.name}`);
        }
    }
};





