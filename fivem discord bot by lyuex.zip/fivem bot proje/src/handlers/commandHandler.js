// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Collection, EmbedBuilder } = require('discord.js');
const fs = require('fs'); 
const path = require('path');
const { useCmd } = require('../functions/usecmd');
const enhancements = require('../utils/commandEnhancements');

// Create shared enhancement instances
const globalRateLimiter = new enhancements.RateLimiter(5, 60000);
const globalLogger = new enhancements.CommandLogger('./logs');
const globalCache = new enhancements.CommandCache();
const globalPerf = new enhancements.PerformanceMonitor();

const commandMap = new Collection();

// Read commands directory
const commandsPath = path.join(__dirname, '../commands');
let commandFiles;
try {
    commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
} catch (error) {
    console.error('Commands dizini okunamadı:', error);
    commandFiles = [];
}

for (const file of commandFiles) {
    try {
        const filePath = path.join(commandsPath, file);
        
        // Clear require cache to ensure fresh load
        delete require.cache[require.resolve(filePath)];
        const command = require(filePath);
        
        if (command.data && command.data.name) {
            // attach enhancements to command for convenient usage
            command.enhancements = {
                rateLimiter: globalRateLimiter,
                logger: globalLogger,
                cache: globalCache,
                perf: globalPerf,
                helpers: {
                    AutocompleteHelper: enhancements.AutocompleteHelper,
                    InteractionHelper: enhancements.InteractionHelper,
                    PermissionHelper: enhancements.PermissionHelper,
                    PaginationHelper: enhancements.PaginationHelper,
                    applyCooldown: enhancements.applyCooldown
                }
            };

            commandMap.set(command.data.name, command);
            console.log(`[LYUEX] ✅ Komut yüklendi: ${command.data.name}`);
        } else {
            console.log(`Hata: ${file} dosyasında komut bilgileri eksik.`);
        }
    } catch (error) {
        console.log(`Hata: ${file} dosyası yüklenirken hata oluştu:`, error.message);
    }
}

console.log(`Toplam ${commandMap.size} komut yüklendi.`);

module.exports = {
    commandMap: commandMap,
    handleCommand: async (interaction) => {
        if (!interaction.isCommand()) return;
        const { commandName } = interaction;
        const command = commandMap.get(commandName);
        try {
            if (command) {
                await command.execute(interaction);
            } else {
                await interaction.reply({ content: 'Unknown command!', ephemeral: true });
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
        }
    }
};





