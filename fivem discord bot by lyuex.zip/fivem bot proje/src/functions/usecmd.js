// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

function useCmd(client, commandName, interaction) {
    const lyuexinlogu = client.channels.cache.get(lyuex.log.komut);
    const lyuexinembedi = new EmbedBuilder()
        .setColor(0x00FF2F)
        .setTitle('Komut Kullanıldı')
        .setDescription(`Kişi: ${interaction.member.id}\nKomut adı: \`${commandName}\``);

    lyuexinlogu.send({ embeds: [lyuexinembedi] })
        .catch(err => console.error('Komut logu atılırken bir hata oluştu!', err));
}

module.exports = { useCmd };




