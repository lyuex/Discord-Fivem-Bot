// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('@discordjs/builders');
const lyuex = require('../../lyuex.json');

function catchError(client, commandName, errorMessage) {
    // Yeni log sistemi için kanal ID'si al
    const logChannelId = lyuex.log?.channels?.system_logs || lyuex.botSettings?.LOG_CHANNEL_ID;
    const log = client.channels.cache.get(logChannelId);
    
    if (!log) {
        console.error('Log kanalı bulunamadı (ID:', logChannelId, ')');
        return;
    }

    const errorEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('⚠️ Sistem Hatası')
        .setDescription(`**Dosya:** ${commandName}\n**Hata:** \`\`\`${errorMessage}\`\`\``)
        .addFields(
            { name: '📁 Dosya', value: commandName, inline: true },
            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '🔍 Detay', value: errorMessage.length > 100 ? errorMessage.substring(0, 100) + '...' : errorMessage, inline: false }
        )
        .setFooter({ 
            text: `LYUEX Hata Sistemi`,
            iconURL: client.user.displayAvatarURL({ dynamic: true })
        })
        .setTimestamp();

    log.send({ embeds: [errorEmbed] })
        .catch((err) => console.error('Hata mesajı gönderirken bir hata meydana geldi', err));
}

module.exports = { catchError };




