// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿module.exports.checkDB = async (id, guild) => {
    !(await UserModel.findOne({ userId: id, guildId: guild })) ? UserModel.create({ userId: id, guildId: guild }) : null
}




