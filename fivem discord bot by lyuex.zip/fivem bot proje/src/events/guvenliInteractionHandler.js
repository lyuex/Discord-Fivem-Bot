// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿// src/events/guvenliInteractionHandler.js
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const db = require('croxydb');

module.exports = {
  async execute(interaction) {
    const customId = interaction.customId;

    try {
      // Quick Add modal submit işlemleri
      if (interaction.isModalSubmit() && customId === 'guvenli_quick_add_role_modal') {
        return this.handleQuickAddRoleModal(interaction);
      }
      if (interaction.isModalSubmit() && customId === 'guvenli_quick_add_user_modal') {
        return this.handleQuickAddUserModal(interaction);
      }

      // Ana güvenli sistem butonları
      if (customId === 'guvenli_add_menu') {
        return this.showAddMenu(interaction);
      }
      // Komutta kullanılan hızlı ekleme butonları
      if (customId === 'guvenli_quick_add_role' || customId === 'guvenli_quick_add_user') {
        if (customId === 'guvenli_quick_add_role') return this.openQuickAddRoleModal(interaction);
        return this.openQuickAddUserModal(interaction);
      }
      // Komutta kullanılan "daha fazla ekle" butonu
      if (customId === 'guvenli_add_more') {
        return this.showAddMenu(interaction);
      }
      
      if (customId === 'guvenli_view_menu' || customId === 'guvenli_view_list') {
        return this.showViewMenu(interaction);
      }
      
      if (customId === 'guvenli_remove_menu') {
        return this.showRemoveMenu(interaction);
      }
      
      if (customId === 'guvenli_panel') {
        return this.showMainPanel(interaction);
      }
      // Komutta kullanılan toplu işlem menüsü
      if (customId === 'guvenli_bulk_menu') {
        return this.showBulkMenu(interaction);
      }

      // Görünüm butonları
      if (customId === 'guvenli_summary_view') {
        return this.showSummaryView(interaction);
      }
      
      if (customId === 'guvenli_detailed_view') {
        return this.showDetailedView(interaction);
      }
      
      if (customId === 'guvenli_roles_only') {
        return this.showRolesOnly(interaction);
      }
      
      if (customId === 'guvenli_users_only') {
        return this.showUsersOnly(interaction);
      }

      // Hızlı işlem butonları
      if (customId === 'guvenli_quick_add') {
        return this.showQuickAddModal(interaction);
      }
      
      if (customId === 'guvenli_refresh' || customId === 'guvenli_refresh_list') {
        return this.refreshCurrentView(interaction);
      }

      // Export/Import butonları
      if (customId === 'guvenli_export_menu') {
        // Şimdilik direkt export yapalım; ileride menüleştirilebilir
        return this.exportSafeList(interaction);
      }
      if (customId === 'guvenli_export' || customId === 'guvenli_export_list') {
        return this.exportSafeList(interaction);
      }
      
      if (customId === 'guvenli_import_menu') {
        return this.showImportMenu(interaction);
      }

      // Ayarlar menüsü (placeholder)
      if (customId === 'guvenli_settings') {
        return this.showSettingsMenu(interaction);
      }

      // Onay butonları (rol/kullanıcı kaldırma)
      if (customId.startsWith('guvenli_confirm_remove_role_')) {
        const roleId = customId.replace('guvenli_confirm_remove_role_', '');
        return this.confirmRoleRemoval(interaction, roleId);
      }
      
      if (customId.startsWith('guvenli_confirm_remove_user_')) {
        const userId = customId.replace('guvenli_confirm_remove_user_', '');
        return this.confirmUserRemoval(interaction, userId);
      }

      // İptal butonları
      if (customId === 'guvenli_cancel_remove' || customId === 'guvenli_cancel') {
        return this.cancelOperation(interaction);
      }

      // Yardım ve bilgi butonları
      if (customId === 'guvenli_help' || customId === 'guvenli_quick_help') {
        return this.showHelpMenu(interaction);
      }
      
      if (customId === 'guvenli_analytics') {
        return this.showAnalytics(interaction);
      }

      // Toplu işlem butonları
      if (customId === 'guvenli_bulk_add') {
        return this.showBulkAddMenu(interaction);
      }
      
      if (customId === 'guvenli_bulk_remove') {
        return this.showBulkRemoveMenu(interaction);
      }

      // Geri ekleme butonları
      if (customId.startsWith('guvenli_readd_role_')) {
        const roleId = customId.replace('guvenli_readd_role_', '');
        return this.readdRole(interaction, roleId);
      }
      
      if (customId.startsWith('guvenli_readd_user_')) {
        const userId = customId.replace('guvenli_readd_user_', '');
        return this.readdUser(interaction, userId);
      }

      // Backup butonları
      if (customId === 'guvenli_backup_before_remove' || customId === 'guvenli_backup_now') {
        return this.createBackup(interaction);
      }

      // Sayfa navigation butonları
      if (customId.startsWith('guvenli_detail_page_')) {
        const page = parseInt(customId.replace('guvenli_detail_page_', ''));
        return this.showDetailedViewPage(interaction, page);
      }

    } catch (error) {
      console.error('Güvenli interaction handler hatası:', error);
      
      if (interaction.replied || interaction.deferred) {
        try {
          await interaction.followUp({
            content: '❌ İşlem sırasında bir hata oluştu!',
            ephemeral: true
          });
        } catch (followUpError) {
          console.error('FollowUp hatası:', followUpError);
        }
      } else {
        try {
          await interaction.reply({
            content: '❌ İşlem sırasında bir hata oluştu!',
            ephemeral: true
          });
        } catch (replyError) {
          console.error('Reply hatası:', replyError);
        }
      }
    }
  },

  // Görünüm menüsü göster
  async showViewMenu(interaction) {
    return this.showSummaryView(interaction);
  },

  // Ekleme menüsü göster
  async showAddMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle('➕ Güvenli Ekleme Menüsü')
      .setDescription('Bu özellik henüz geliştirilmiyor. Lütfen `/güvenli ekle` komutunu kullanın.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Kaldırma menüsü göster
  async showRemoveMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xFF6B6B)
      .setTitle('🗑️ Güvenli Kaldırma Menüsü')
      .setDescription('Bu özellik henüz geliştirilmiyor. Lütfen `/güvenli sil` komutunu kullanın.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Detaylı görünüm göster
  async showDetailedView(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle('📋 Detaylı Görünüm')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Sadece roller göster
  async showRolesOnly(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle('🏷️ Sadece Roller')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Sadece kullanıcılar göster
  async showUsersOnly(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle('👥 Sadece Kullanıcılar')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Hızlı ekleme modalı göster
  async openQuickAddRoleModal(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('guvenli_quick_add_role_modal')
      .setTitle('🏷️ Hızlı Rol Ekle');

    const input = new TextInputBuilder()
      .setCustomId('role_input')
      .setLabel('Rol (@rol, ID veya isim)')
      .setRequired(true)
      .setPlaceholder('@Moderatör veya 123456789012345678 veya Rol Adı')
      .setStyle(TextInputStyle.Short);

    const row = new ActionRowBuilder().addComponents(input);
    modal.addComponents(row);
    return interaction.showModal(modal);
  },

  async openQuickAddUserModal(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('guvenli_quick_add_user_modal')
      .setTitle('👤 Hızlı Kullanıcı Ekle');

    const input = new TextInputBuilder()
      .setCustomId('user_input')
      .setLabel('Kullanıcı (@kullanıcı veya ID)')
      .setRequired(true)
      .setPlaceholder('@Kullanıcı veya 123456789012345678')
      .setStyle(TextInputStyle.Short);

    const row = new ActionRowBuilder().addComponents(input);
    modal.addComponents(row);
    return interaction.showModal(modal);
  },

  // Mevcut görünümü yenile
  async refreshCurrentView(interaction) {
    return this.showSummaryView(interaction);
  },

  // Import menüsü göster
  async showImportMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x2196F3)
      .setTitle('📥 Import Menüsü')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Yardım menüsü göster
  async showHelpMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xFF9800)
      .setTitle('❓ Yardım Menüsü')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Analitik göster
  async showAnalytics(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x9C27B0)
      .setTitle('📈 Analitik')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Toplu ekleme menüsü göster
  async showBulkAddMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle('📦 Toplu Ekleme')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Toplu kaldırma menüsü göster
  async showBulkRemoveMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xF44336)
      .setTitle('🗑️ Toplu Kaldırma')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Toplu işlem ana menüsü (komuttaki guvenli_bulk_menu için)
  async showBulkMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x607D8B)
      .setTitle('📦 Toplu İşlem Menüsü')
      .setDescription('Toplu ekleme veya toplu kaldırma için bir seçenek seçin.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_bulk_add')
          .setLabel('➕ Toplu Ekle')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('guvenli_bulk_remove')
          .setLabel('🗑️ Toplu Kaldır')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('guvenli_panel')
          .setLabel('↩️ Geri (Panel)')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({ embeds: [embed], components: [buttons] });
  },

  // Rolü geri ekle
  async readdRole(interaction, roleId) {
    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle('🔄 Rol Geri Eklendi')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Kullanıcıyı geri ekle
  async readdUser(interaction, userId) {
    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle('🔄 Kullanıcı Geri Eklendi')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Backup oluştur
  async createBackup(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xFF9800)
      .setTitle('💾 Backup Oluşturuldu')
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Detaylı görünüm sayfası göster
  async showDetailedViewPage(interaction, page) {
    const embed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setTitle(`📋 Detaylı Görünüm - Sayfa ${page}`)
      .setDescription('Bu özellik henüz geliştirilmiyor.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    await interaction.update({ embeds: [embed], components: [] });
  },

  // Ayarlar menüsü (placeholder)
  async showSettingsMenu(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x9E9E9E)
      .setTitle('⚙️ Ayarlar')
      .setDescription('Ayarlar bölümü henüz geliştirilmiyor. Yakında burada gelişmiş seçenekler olacak.')
      .setFooter({ text: 'Güvenli Sistem v3.0' });

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_panel')
          .setLabel('↩️ Geri (Panel)')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_view_list')
          .setLabel('📋 Listeyi Gör')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({ embeds: [embed], components: [buttons] });
  },

  // Modal submit handler: rol ekleme
  async handleQuickAddRoleModal(interaction) {
    const raw = interaction.fields.getTextInputValue('role_input').trim();

    // mention veya ID çıkar
    const idMatch = raw.match(/^(?:<@&)?(\d{17,20})>?$/);
    let role = null;
    if (idMatch) {
      role = interaction.guild.roles.cache.get(idMatch[1]);
    }
    if (!role) {
      // İsimle dene (yaklaşık eşleşme)
      const lower = raw.toLowerCase();
      role = interaction.guild.roles.cache.find(r => r.name.toLowerCase() === lower) ||
             interaction.guild.roles.cache.find(r => r.name.toLowerCase().includes(lower));
    }

    if (!role) {
      return interaction.reply({ content: '❌ Rol bulunamadı. Lütfen @rol, ID veya doğru isim girin.', ephemeral: true });
    }

    const roleKey = `güvenli_roller_${interaction.guild.id}`;
    let safeRoles = db.get(roleKey) || [];

    if (safeRoles.includes(role.id)) {
      return interaction.reply({ content: `⚠️ ${role} zaten güvenli listede.`, ephemeral: true });
    }

    safeRoles.push(role.id);
    db.set(roleKey, safeRoles);

    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle('✅ Rol Güvenli Listeye Eklendi')
      .addFields(
        { name: 'Rol', value: `${role} \`${role.id}\``, inline: true },
        { name: 'Toplam Güvenli Rol', value: `${safeRoles.length}`, inline: true }
      )
      .setFooter({ text: 'Güvenli Sistem v3.0' })
      .setTimestamp();

    const actions = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('guvenli_view_list').setLabel('📋 Listeyi Gör').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('guvenli_add_more').setLabel('➕ Daha Fazla Ekle').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('guvenli_panel').setLabel('🎛️ Panel').setStyle(ButtonStyle.Primary)
    );

    return interaction.reply({ embeds: [embed], components: [actions], ephemeral: true });
  },

  // Modal submit handler: kullanıcı ekleme
  async handleQuickAddUserModal(interaction) {
    const raw = interaction.fields.getTextInputValue('user_input').trim();
    const idMatch = raw.match(/^(?:<@!?)?(\d{17,20})>?$/);
    let userId = idMatch ? idMatch[1] : null;

    let user = null;
    if (userId) {
      user = interaction.client.users.cache.get(userId) || await interaction.client.users.fetch(userId).catch(() => null);
    }

    if (!user) {
      return interaction.reply({ content: '❌ Kullanıcı bulunamadı. Lütfen @kullanıcı veya ID girin.', ephemeral: true });
    }

    const userKey = `güvenli_kullanıcılar_${interaction.guild.id}`;
    let safeUsers = db.get(userKey) || [];

    if (safeUsers.includes(user.id)) {
      return interaction.reply({ content: `⚠️ ${user.tag} zaten güvenli listede.`, ephemeral: true });
    }

    safeUsers.push(user.id);
    db.set(userKey, safeUsers);

    const embed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setTitle('✅ Kullanıcı Güvenli Listeye Eklendi')
      .addFields(
        { name: 'Kullanıcı', value: `${user.tag} \`${user.id}\``, inline: true },
        { name: 'Toplam Güvenli Kullanıcı', value: `${safeUsers.length}`, inline: true }
      )
      .setFooter({ text: 'Güvenli Sistem v3.0' })
      .setTimestamp();

    const actions = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('guvenli_view_list').setLabel('📋 Listeyi Gör').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('guvenli_add_more').setLabel('➕ Daha Fazla Ekle').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('guvenli_panel').setLabel('🎛️ Panel').setStyle(ButtonStyle.Primary)
    );

    return interaction.reply({ embeds: [embed], components: [actions], ephemeral: true });
  },

  // Ana panel göster
  async showMainPanel(interaction) {
    const safeRoles = db.get(`güvenli_roller_${interaction.guild.id}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${interaction.guild.id}`) || [];
    const totalProtected = safeRoles.length + safeUsers.length;

    const panelEmbed = new EmbedBuilder()
      .setColor(0x6A1B9A)
      .setAuthor({ 
        name: '🎛️ Güvenli Sistem • Yönetim Merkezi'
      })
      .setTitle('🎛️ Güvenli Yönetim Paneli')
      .setDescription(`
╭─────────────────────────────────╮
│  🎯 **KONTROL MERKEZİ**          │
│  Güvenli sisteminizi buradan    │
│  tam olarak yönetin             │
╰─────────────────────────────────╯

**Hoşgeldiniz ${interaction.user}!**
Aşağıdaki seçeneklerle güvenli sisteminizi yönetin.`)
      .addFields(
        { 
          name: '📊 Sistem Durumu', 
          value: `
\`\`\`yaml
Güvenli Rol: ${safeRoles.length}
Güvenli Kullanıcı: ${safeUsers.length}
Toplam Korumalı: ${totalProtected}
Güvenlik Seviyesi: ${this.getSecurityLevel(totalProtected)}
\`\`\``, 
          inline: true 
        },
        { 
          name: '⚡ Hızlı İstatistik', 
          value: `
\`\`\`yaml
Son Güncelleme: Az önce
Sistem Durumu: Online 🟢
Performans: Optimal
Uptime: ${this.getUptime()}
\`\`\``, 
          inline: true 
        }
      )
      .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 128 }))
      .setFooter({ 
        text: `${interaction.guild.name} • Güvenli Sistem v3.0`, 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    const mainButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_add_menu')
          .setLabel('➕ Ekle')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('guvenli_view_menu')
          .setLabel('📋 Görüntüle')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_remove_menu')
          .setLabel('🗑️ Kaldır')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('guvenli_analytics')
          .setLabel('📈 Analitik')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({ 
      embeds: [panelEmbed], 
      components: [mainButtons]
    });
  },

  // Özet görünüm göster
  async showSummaryView(interaction) {
    const safeRoles = db.get(`güvenli_roller_${interaction.guild.id}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${interaction.guild.id}`) || [];
    const totalProtected = safeRoles.length + safeUsers.length;

    const summaryEmbed = new EmbedBuilder()
      .setColor(0x00D4FF)
      .setAuthor({ 
        name: '📊 Güvenli Sistem • Özet Görünüm'
      })
      .setTitle('🛡️ Güvenli Liste Özeti')
      .setDescription(`
╭─────────────────────────────────╮
│  📊 **SİSTEM ÖZETİ**            │
│  Güvenli listenizin genel       │
│  durumu ve istatistikleri       │
╰─────────────────────────────────╯`)
      .addFields(
        { 
          name: '📈 Ana İstatistikler', 
          value: `
\`\`\`yaml
Güvenli Roller: ${safeRoles.length}
Güvenli Kullanıcılar: ${safeUsers.length}
Toplam Korumalı: ${totalProtected}
Güvenlik Seviyesi: ${this.getSecurityLevel(totalProtected)}
\`\`\``, 
          inline: true 
        },
        { 
          name: '⚡ Sistem Durumu', 
          value: `
\`\`\`yaml
Durum: Aktif 🟢
Son Güncelleme: Az önce
Performans: Optimal
\`\`\``, 
          inline: true 
        }
      )
      .setFooter({ 
        text: `${interaction.guild.name} • Güvenli Sistem Özeti`, 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    const viewButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_detailed_view')
          .setLabel('📋 Detaylı Görünüm')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_refresh')
          .setLabel('🔄 Yenile')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('guvenli_panel')
          .setLabel('🎛️ Panel')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({ 
      embeds: [summaryEmbed], 
      components: [viewButtons]
    });
  },

  // Export işlemi
  async exportSafeList(interaction) {
    const safeRoles = db.get(`güvenli_roller_${interaction.guild.id}`) || [];
    const safeUsers = db.get(`güvenli_kullanıcılar_${interaction.guild.id}`) || [];

    const exportData = {
      guildId: interaction.guild.id,
      guildName: interaction.guild.name,
      exportDate: new Date().toISOString(),
      data: {
        roles: safeRoles,
        users: safeUsers,
        total: safeRoles.length + safeUsers.length
      }
    };

    const exportText = JSON.stringify(exportData, null, 2);

    const exportEmbed = new EmbedBuilder()
      .setColor(0x4CAF50)
      .setAuthor({ 
        name: '📤 Güvenli Sistem • Export Tamamlandı'
      })
      .setTitle('📤 Liste Export Edildi!')
      .setDescription(`
╭─────────────────────────────────╮
│  📤 **EXPORT TAMAMLANDI**       │
│  Güvenli listeniz başarıyla     │
│  dışa aktarıldı                 │
╰─────────────────────────────────╯`)
      .addFields(
        { 
          name: '📊 Export İstatistikleri', 
          value: `
**Roller:** ${safeRoles.length}
**Kullanıcılar:** ${safeUsers.length}
**Toplam:** ${safeRoles.length + safeUsers.length}
**Tarih:** ${new Date().toLocaleString('tr-TR')}
          `, 
          inline: true 
        }
      )
      .setFooter({ 
        text: 'Export dosyasını güvenli bir yerde saklayın', 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    await interaction.update({ 
      embeds: [exportEmbed], 
      files: [{
        attachment: Buffer.from(exportText),
        name: `guvenli-liste-${interaction.guild.id}-${Date.now()}.json`
      }],
      components: []
    });
  },

  // Onay için kullanıcı kaldırma
  async confirmUserRemoval(interaction, userId) {
    const userKey = `güvenli_kullanıcılar_${interaction.guild.id}`;
    let safeUsers = db.get(userKey) || [];
    
    safeUsers = safeUsers.filter(id => id !== userId);
    db.set(userKey, safeUsers);

    const user = await interaction.client.users.fetch(userId).catch(() => null);
    
    const successEmbed = new EmbedBuilder()
      .setColor(0x00D4AA)
      .setAuthor({ 
        name: '✅ Güvenli Sistem • Kullanıcı Kaldırıldı'
      })
      .setTitle('✅ Kullanıcı Başarıyla Kaldırıldı!')
      .setDescription(`
╭─────────────────────────────────╮
│  ✅ **İŞLEM TAMAMLANDI**        │
│  Kullanıcı güvenli listeden     │
│  başarıyla kaldırıldı           │
╰─────────────────────────────────╯`)
      .addFields(
        { 
          name: '👤 Kaldırılan Kullanıcı', 
          value: user ? `${user.tag}` : `\`${userId}\``, 
          inline: true 
        },
        { 
          name: '📊 Güncel Durum', 
          value: `**Kalan Kullanıcılar:** ${safeUsers.length}`, 
          inline: true 
        }
      )
      .setFooter({ 
        text: 'İşlem başarıyla tamamlandı', 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    const actionButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`guvenli_readd_user_${userId}`)
          .setLabel('🔄 Geri Ekle')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('guvenli_view_list')
          .setLabel('📋 Listeyi Gör')
          .setStyle(ButtonStyle.Primary)
      );

    await interaction.update({ 
      embeds: [successEmbed], 
      components: [actionButtons]
    });
  },

  // İptal işlemi
  async cancelOperation(interaction) {
    const cancelEmbed = new EmbedBuilder()
      .setColor(0xFF9800)
      .setAuthor({ 
        name: '❌ Güvenli Sistem • İşlem İptal'
      })
      .setTitle('❌ İşlem İptal Edildi')
      .setDescription(`
╭─────────────────────────────────╮
│  ❌ **İŞLEM İPTAL**             │
│  İşlem kullanıcı tarafından     │
│  iptal edildi                   │
╰─────────────────────────────────╯`)
      .setFooter({ 
        text: 'Hiçbir değişiklik yapılmadı', 
        iconURL: interaction.client.user.displayAvatarURL() 
      })
      .setTimestamp();

    const returnButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('guvenli_panel')
          .setLabel('🎛️ Ana Panel')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('guvenli_view_list')
          .setLabel('📋 Listeyi Gör')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({ 
      embeds: [cancelEmbed], 
      components: [returnButtons]
    });
  },

  // Yardımcı metodlar
  getSecurityLevel(count) {
    if (count >= 20) return '🔴 Maksimum';
    if (count >= 10) return '🟡 Yüksek';
    if (count >= 5) return '🟢 Orta';
    if (count >= 1) return '🔵 Düşük';
    return '⚪ Yok';
  },

  getUptime() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    return `${hours}s ${minutes}d`;
  }
};




