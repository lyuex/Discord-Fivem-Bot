// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, PermissionFlagsBits, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { saveSteamHex, checkSteamHexExists } = require('../utils/steamHexManager');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton() && !interaction.isModalSubmit()) return;

        const customId = interaction.customId || '';

        // Steam ID onay butonları
        if (
            customId.startsWith('steam_onayla_') ||
            customId.startsWith('steam_uygunsuz_') ||
            customId.startsWith('steam_gecersiz_') ||
            customId.startsWith('steam_ozel_')
        ) {
            try {
                // Yetkili kontrolü
                const yetkiliRoller = lyuex.hex_sistem?.yetkili_rol || [];
                const hasPermission = yetkiliRoller.some(roleId => interaction.member.roles.cache.has(roleId)) ||
                    interaction.member.permissions.has(PermissionFlagsBits.Adlyuexstrator);
                if (!hasPermission) {
                    return interaction.reply({
                        content: '❌ Bu işlem için yetkiniz bulunmuyor!',
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Custom ID parçaları: steam_action_userId_messageId
                const parts = customId.split('_');
                const action = parts[1];
                const userId = parts[2];
                const messageId = parts[3];

                const targetUser = await interaction.client.users.fetch(userId).catch(() => null);
                if (!targetUser) {
                    return interaction.reply({
                        content: '❌ Kullanıcı bulunamadı!',
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);

                // Embed'den Steam ID'yi çek
                const panelEmbed = interaction.message.embeds?.[0];
                const steamField = panelEmbed?.fields?.find(f => f.name && f.name.toLowerCase().includes('steam id'));
                const steamId = steamField ? steamField.value.replace(/```/g, '').trim() : 'Bilinmeyen Steam ID';

                // Özel sebep için modal aç
                if (action === 'ozel') {
                    const modal = new ModalBuilder()
                        .setCustomId(`steam_ozel_modal_${userId}_${messageId}`)
                        .setTitle('Özel Red Sebebi');

                    const sebepInput = new TextInputBuilder()
                        .setCustomId('red_sebebi')
                        .setLabel('Red sebebinizi yazın:')
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder('Örn: Steam ID kurallara uygun değil çünkü...')
                        .setRequired(true)
                        .setMaxLength(500);

                    modal.addComponents(new ActionRowBuilder().addComponents(sebepInput));
                    return await interaction.showModal(modal);
                }

                await interaction.deferReply();

                let sonucEmbed;
                let redSebebi = '';
                let roleGiven = false;
                let channelMsgAction = 'embedUpdate'; // onay: reactAndDelete, red: embedUpdate

                switch (action) {
                    case 'onayla': {
                        // Steam hex'i data'ya kaydet
                        const hexSaved = saveSteamHex(userId, steamId, interaction.user.id);
                        if (!hexSaved) {
                            return interaction.reply({
                                content: '❌ Steam hex kaydedilirken bir hata oluştu!',
                                flags: [MessageFlags.Ephemeral]
                            });
                        }

                        // Rol verme (varsa)
                        if (targetMember && lyuex.rol?.hex_onay) {
                            try {
                                const steamRole = interaction.guild.roles.cache.get(lyuex.rol.hex_onay);
                                if (steamRole) {
                                    await targetMember.roles.add(steamRole);
                                    roleGiven = true;
                                }
                            } catch (err) {
                                console.error('Steam onay rolü verme hatası:', err);
                            }
                        }

                        // Orijinal mesaja ✅ ekle ve onay embed'i gönder
                        try {
                            if (messageId) {
                                const originalMsg = await interaction.channel.messages.fetch(messageId).catch(() => null);
                                if (originalMsg) {
                                    await originalMsg.react('✅').catch(() => {});
                                    
                                    // Onay embed'ini orijinal mesaja yanıt olarak gönder
                                    const onayEmbed = new EmbedBuilder()
                                        .setColor(0x00FF88)
                                        .setTitle('✅ Steam ID Başarıyla Onaylandı!')
                                        .setDescription(`🎉 **${targetUser}** Steam ID'niz **ONAYLANDI**!`)
                                        .addFields(
                                            { name: '🎮 Onaylanan Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: true },
                                            { name: '👑 Kullanıcı', value: `**${targetUser.tag}**`, inline: true },
                                            { name: '👮 Onaylayan Yetkili', value: `**${interaction.user.tag}**`, inline: true },
                                            { name: '⏰ Onay Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                            { name: '🎯 Son Durum', value: '✅ **ONAYLANDI**', inline: true },
                                            { name: '🏷️ Verilen Rol', value: lyuex.rol?.hex_onay ? `<@&${lyuex.rol.hex_onay}>` : '❌ Rol bulunamadı', inline: true }
                                        )
                                        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                                        .setFooter({ 
                                            text: `Onaylayan: ${interaction.user.tag} • LYUEX ✅`,
                                            iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                                        })
                                        .setTimestamp();
                                    
                                    await originalMsg.reply({ embeds: [onayEmbed] });
                                }
                            }
                        } catch (e) {
                            console.warn('Steam onay: orijinal mesaja tepki/yanıt verilemedi:', e?.message);
                        }
                        try {
                            await interaction.message.delete().catch(() => {});
                        } catch (e) {
                            console.warn('Steam onay: panel mesajı silinemedi:', e?.message);
                        }

                        channelMsgAction = 'reactAndDelete';
                        break;
                    }
                    case 'uygunsuz': {
                        redSebebi = 'Uygunsuz Steam ID - Sunucu kurallarına aykırı';
                        sonucEmbed = new EmbedBuilder()
                            .setColor(0xFF4444)
                            .setTitle('❌ Steam ID Reddedildi!')
                            .setDescription(`🚫 **${targetUser}** tarafından gönderilen Steam ID **REDDEDİLDİ**!`)
                            .addFields(
                                { name: '🎮 Reddedilen Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: true },
                                { name: '👑 Kullanıcı', value: `**${targetUser.tag}**`, inline: true },
                                { name: '👮 Reddeden Yetkili', value: `**${interaction.user.tag}**`, inline: true },
                                { name: '⏰ Red Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                { name: '🎯 Son Durum', value: '❌ **REDDEDİLDİ**', inline: true },
                                { name: '📋 Red Sebebi', value: `**${redSebebi}**`, inline: true },
                                { name: '🎮 Steam Bilgisi', value: `Hex ID: ${steamId.split(':')[1] || 'N/A'}`, inline: true },
                                { name: '🔄 İşlem ID', value: `\`${messageId}\``, inline: true },
                                { name: '📝 Öneri', value: 'Kurallara uygun yeni bir Steam ID deneyin', inline: true }
                            )
                            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                            .setImage('https://cdn.discordapp.com/attachments/1422661295571992576/1423321126733349035/lyuexdevkirmizi_1.png')
                            .setFooter({ 
                                text: `Reddeden: ${interaction.user.tag} • LYUEX ❌`,
                                iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                            })
                            .setTimestamp();
                        break;
                    }
                    case 'gecersiz': {
                        redSebebi = 'Geçersiz Steam ID - Format hatası veya eksik';
                        sonucEmbed = new EmbedBuilder()
                            .setColor(0xFFA500)
                            .setTitle('⚠️ Steam ID Geçersiz!')
                            .setDescription(`⚠️ **${targetUser}** tarafından gönderilen Steam ID **GEÇERSİZ**!`)
                            .addFields(
                                { name: '🎮 Gönderilen Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: true },
                                { name: '👑 Kullanıcı', value: `**${targetUser.tag}**`, inline: true },
                                { name: '👮 İnceleyen Yetkili', value: `**${interaction.user.tag}**`, inline: true },
                                { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                { name: '🎯 Son Durum', value: '⚠️ **GEÇERSİZ**', inline: true },
                                { name: '📋 Açıklama', value: `**${redSebebi}**`, inline: false },
                                { name: '🎮 Steam Bilgisi', value: `Prefix: steam:110000 • Hex: ${steamId.split(':')[1] || 'N/A'}`, inline: false },
                                { name: '🔄 İşlem ID', value: `\`${messageId}\``, inline: true }
                            )
                            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                            .setImage('https://cdn.discordapp.com/attachments/1422661295571992576/1423321126733349035/lyuexdevkirmizi_1.png')
                            .setFooter({ 
                                text: `İnceleyen: ${interaction.user.tag} • LYUEX ⚠️`,
                                iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                            })
                            .setTimestamp();
                        break;
                    }
                    default:
                        break;
                }

                // Red durumlarında panel mesajını güncelle ve butonları kaldır
                if (channelMsgAction !== 'reactAndDelete' && sonucEmbed) {
                    await interaction.message.edit({ embeds: [sonucEmbed], components: [] }).catch(() => {});
                }

                await interaction.editReply({
                    content: action === 'onayla' ? `✅ Steam ID başarıyla onaylandı!` : `❌ Steam ID reddedildi: **${redSebebi}**`
                });

                // Log kanalına detaylı gönderim
                const logKanalId = lyuex.hex_sistem?.log_kanal;
                if (logKanalId) {
                    try {
                        let logKanal = interaction.guild.channels.cache.get(logKanalId);
                        if (!logKanal) {
                            logKanal = await interaction.guild.channels.fetch(logKanalId).catch(() => null);
                        }
                        if (logKanal) {
                            const messageUrl = `https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}/${messageId}`;
                            const detayEmbed = new EmbedBuilder()
                                .setColor(action === 'onayla' ? '#00FF00' : (action === 'gecersiz' ? '#FFA500' : '#FF0000'))
                                .setTitle(`🎮 Steam ID ${action === 'onayla' ? 'Onaylandı' : (action === 'gecersiz' ? 'Geçersiz' : 'Reddedildi')}`)
                                .addFields(
                                    { name: '👤 Kullanıcı', value: `${targetUser} • ${targetUser.tag}\nID: \`${targetUser.id}\``, inline: true },
                                    { name: '👮 Yetkili', value: `${interaction.user} • ${interaction.user.tag}\nID: \`${interaction.user.id}\``, inline: true },
                                    { name: '🎮 Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: false },
                                    { name: '🔧 Hex', value: `\`${steamId.split(':')[1] || 'N/A'}\``, inline: true },
                                    { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                    { name: '🔖 İşlem ID', value: `\`${messageId}\``, inline: true },
                                    { name: '🔗 Mesaj', value: `[Başvuru Mesajı](${messageUrl})`, inline: false },
                                    ...(action === 'onayla'
                                        ? [
                                            { name: '🏷️ Rol Verildi', value: roleGiven ? '✅' : '❌', inline: true },
                                            { name: '💾 Data Kaydedildi', value: '✅', inline: true }
                                        ]
                                        : [{ name: '📋 Sebep', value: redSebebi || 'Belirtilmedi', inline: false }]
                                    )
                                )
                                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                                .setFooter({ text: `${interaction.guild.name} • Steam ID Sistemi` })
                                .setTimestamp();

                            await logKanal.send({ embeds: [detayEmbed] }).catch(() => {});
                        }
                    } catch (error) {
                        console.error('Steam hex log gönderme hatası:', error);
                    }
                }
            } catch (error) {
                console.error('Steam ID onay interaction hatası:', error);
                if (!interaction.deferred) {
                    await interaction.reply({
                        content: '❌ İşlem sırasında bir hata oluştu!',
                        flags: [MessageFlags.Ephemeral]
                    }).catch(() => {});
                } else {
                    await interaction.editReply({ content: '❌ İşlem sırasında bir hata oluştu!' }).catch(() => {});
                }
            }
        }

        // Özel sebep modal submit
        if (customId.startsWith('steam_ozel_modal_') && interaction.isModalSubmit()) {
            try {
                const [, , , userId, messageId] = customId.split('_');
                const targetUser = await interaction.client.users.fetch(userId).catch(() => null);
                const redSebebi = interaction.fields.getTextInputValue('red_sebebi');

                // Panel embed'den Steam ID'yi çek
                const panelEmbed = interaction.message.embeds?.[0];
                const steamField = panelEmbed?.fields?.find(f => f.name && f.name.toLowerCase().includes('steam id'));
                const steamId = steamField ? steamField.value.replace(/```/g, '').trim() : 'Bilinmeyen Steam ID';

                const sonucEmbed = new EmbedBuilder()
                    .setColor(0xAA00FF)
                    .setTitle('🔮 Steam ID Reddedildi! (Özel Sebep)')
                    .setDescription(`🎭 **${targetUser}** tarafından gönderilen Steam ID **ÖZEL SEBEP** ile reddedildi!`)
                    .addFields(
                        { name: '🎮 Reddedilen Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: true },
                        { name: '👑 Kullanıcı', value: `**${targetUser?.tag || 'Bilinmiyor'}**`, inline: true },
                        { name: '👮 Reddeden Yetkili', value: `**${interaction.user.tag}**`, inline: true },
                        { name: '⏰ Red Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '🎯 Son Durum', value: '🔮 **ÖZEL RED**', inline: true },
                        { name: '📋 Red Sebebi', value: `**${redSebebi}**`, inline: false },
                        { name: '🔄 İşlem ID', value: `\`${messageId}\``, inline: true }
                    )
                    .setThumbnail(targetUser?.displayAvatarURL?.({ dynamic: true, size: 256 }))
                    .setImage('https://cdn.discordapp.com/attachments/1422661295571992576/1423321126733349035/lyuexdevkirmizi_1.png')
                    .setFooter({ 
                        text: `Reddeden: ${interaction.user.tag} • LYUEX 🔮`,
                        iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                    })
                    .setTimestamp();

                // Panel mesajını güncelle
                await interaction.message.edit({ embeds: [sonucEmbed], components: [] }).catch(() => {});

                await interaction.reply({
                    content: `⚠️ Steam ID özel sebep ile reddedildi: **${redSebebi}**`,
                    flags: [MessageFlags.Ephemeral]
                }).catch(() => {});

                // Log kanalına gönder
                const logKanalId = lyuex.hex_sistem?.log_kanal;
                if (logKanalId) {
                    try {
                        let logKanal = interaction.guild.channels.cache.get(logKanalId);
                        if (!logKanal) {
                            logKanal = await interaction.guild.channels.fetch(logKanalId).catch(() => null);
                        }
                        if (logKanal) {
                            const messageUrl = `https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}/${messageId}`;
                            const detayEmbed = new EmbedBuilder()
                                .setColor(0xAA00FF)
                                .setTitle('🔮 Steam ID Özel Sebep ile Reddedildi')
                                .addFields(
                                    { name: '👤 Kullanıcı', value: `${targetUser} • ${targetUser?.tag || 'Bilinmiyor'}\nID: \`${targetUser?.id || 'N/A'}\``, inline: true },
                                    { name: '👮 Yetkili', value: `${interaction.user} • ${interaction.user.tag}\nID: \`${interaction.user.id}\``, inline: true },
                                    { name: '🎮 Steam ID', value: `\`\`\`${steamId}\`\`\``, inline: false },
                                    { name: '🔧 Hex', value: `\`${steamId.split(':')[1] || 'N/A'}\``, inline: true },
                                    { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                    { name: '🔖 İşlem ID', value: `\`${messageId}\``, inline: true },
                                    { name: '🔗 Mesaj', value: `[Başvuru Mesajı](${messageUrl})`, inline: false },
                                    { name: '📋 Red Sebebi', value: redSebebi || 'Belirtilmedi', inline: false }
                                )
                                .setThumbnail(targetUser?.displayAvatarURL?.({ dynamic: true }))
                                .setFooter({ text: `${interaction.guild.name} • Steam ID Sistemi` })
                                .setTimestamp();

                            await logKanal.send({ embeds: [detayEmbed] }).catch(() => {});
                        }
                    } catch (err) {
                        console.error('Steam hex özel log gönderme hatası:', err);
                    }
                }
            } catch (error) {
                console.error('Özel sebep modal hatası (steam):', error);
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({
                        content: '❌ İşlem sırasında bir hata oluştu!',
                        flags: [MessageFlags.Ephemeral]
                    }).catch(() => {});
                } else {
                    await interaction.followUp({
                        content: '❌ İşlem sırasında bir hata oluştu!',
                        flags: [MessageFlags.Ephemeral]
                    }).catch(() => {});
                }
            }
        }
    }
};




