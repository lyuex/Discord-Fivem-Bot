// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const { catchError } = require('../functions/hatamesajì');

module.exports = {
    name: Events.MessageUpdate,
    async execute(oldMessage, newMessage, client) {
        try {
            // Partials'ı tamamla
            if (oldMessage?.partial) {
                try { oldMessage = await oldMessage.fetch(); } catch { /* yok say */ }
            }
            if (newMessage?.partial) {
                try { newMessage = await newMessage.fetch(); } catch { /* yok say */ }
            }

            // Temel guard'lar
            if (!oldMessage || !newMessage) return;
            const oldContent = (oldMessage.content ?? '').toString();
            const newContent = (newMessage.content ?? '').toString();

            // Bot mesajlarını atla (mümkün olanı kontrol et)
            const author = oldMessage.author || newMessage.author;
            if (!author) return; // DM/partial durumu çözülemediyse
            if (author.bot) return;

            // İçerik değişimi yoksa atla (sadece basit kontrol)
            if (oldContent === newContent) return;

            // DM kanalları için güvenli değerler
            const guild = oldMessage.guild || newMessage.guild || null;
            const channel = oldMessage.channel || newMessage.channel;
            const channelLabel = guild ? (channel?.toString() || '#bilinmiyor') : 'Özel Mesaj';
            const channelName = guild ? (channel?.name || 'bilinmiyor') : 'DM';

            // İçerikleri kes (embed limitlerini aşmamak için)
            const MAX_SNIPPET = 1000; // description içinde güvenli
            const safe = (txt) => (txt || '').replace(/```/g, '\u0060\u0060\u0060');
            const oldSnippet = safe(oldContent).slice(0, MAX_SNIPPET);
            const newSnippet = safe(newContent).slice(0, MAX_SNIPPET);

            const lyuexembed = new EmbedBuilder()
                .setColor(0xFFA500)
                .setTitle('Mesaj Düzenlendi')
                .setDescription(
                    `Eski Mesaj:\n\n\`\`\`\n${oldSnippet}\n\`\`\`\n\n` +
                    `Yeni Mesaj:\n\n\`\`\`\n${newSnippet}\n\`\`\`\n\n` +
                    `Kişi: <@${author.id}> (${author.id})\nMesaj ID: ${oldMessage.id}`
                )
                .addFields(
                    { name: 'Mesajı Düzenleyen', value: author.tag ? `${author.tag}` : `<@${author.id}>`, inline: true },
                    { name: 'Kanal', value: guild ? `${channelLabel}` : 'DM', inline: true }
                )
                .setThumbnail(guild?.iconURL?.({ dynamic: true }) || null)
                .setFooter({ text: guild ? `Kanal: ${channelName}` : 'Özel Mesaj (DM)' })
                .setTimestamp();

            const lyuex = require('../../lyuex.json');
            const logChannelId = lyuex?.botSettings?.LOG_CHANNEL_ID;
            if (logChannelId) {
                let editMesajLog = client.channels.cache.get(logChannelId);
                if (!editMesajLog) {
                    try { editMesajLog = await client.channels.fetch(logChannelId); } catch { /* yok say */ }
                }
                if (editMesajLog && editMesajLog.isTextBased?.()) {
                    await editMesajLog.send({ embeds: [lyuexembed] }).catch(() => {});
                }
            }
        } catch (error) {
            try {
                catchError(client, 'messageUpdate.js', error?.message || String(error));
            } catch (e) {
                console.error('messageUpdate handler error:', error);
            }
        }
    },
};





