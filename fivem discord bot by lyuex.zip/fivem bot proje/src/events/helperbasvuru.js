// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder, ButtonStyle, ButtonBuilder, ChannelType, ButtonInteraction, ButtonComponent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isButton() && interaction.customId === 'lyuexinhelpermodali') {
            
            const lyuexinhelpermodali = new ModalBuilder()
            .setCustomId('lyuexinhelpermodali')
            .setTitle('For Development');
            
            const lyuexinsordugusoru1 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusoru1')
            .setLabel('Kendinizi Tanıtın')
            .setPlaceholder('isim - yaş - il - platform (pc - tel)')
            .setMinLength(10)
            .setStyle(TextInputStyle.Short);
            
            const lyuexinsordugusoru2 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusoru2')
            .setLabel('Bize ne kadar zaman ayırabilirsiniz?')
            .setPlaceholder('Uzun süre afk kalmanızı gerektiricek bir durum var mı?')
            .setMinLength(10)
            .setStyle(TextInputStyle.Paragraph);

            const lyuexinsordugusoru3 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusoru3')
            .setLabel('Daha önce hiç yetkililik yaptınız mı?')
            .setPlaceholder('Yaptıysanız hangi sunucuda yaptınız?')
            .setStyle(TextInputStyle.Paragraph);

            const lyuexinsordugusoru4 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusoru4')
            .setLabel('Bizden beklentiniz nedir?')
            .setPlaceholder('??')
            .setStyle(TextInputStyle.Paragraph);

            const lyuexinsordugusoru5 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusoru5')
            .setLabel('Sunucu üyeleriyle nasıl iletişim kurarsınız?')
            .setPlaceholder('??')
            .setStyle(TextInputStyle.Paragraph);

            const birincisoru = new ActionRowBuilder()
            .addComponents(lyuexinsordugusoru1);
            const ikincisoru = new ActionRowBuilder()
            .addComponents(lyuexinsordugusoru2);
            const ucuncusoru = new ActionRowBuilder()
            .addComponents(lyuexinsordugusoru3);
            const dorduncusoru = new ActionRowBuilder()
            .addComponents(lyuexinsordugusoru4);
            const besincisoru = new ActionRowBuilder()
            .addComponents(lyuexinsordugusoru5);

            lyuexinhelpermodali.addComponents(birincisoru, ikincisoru, ucuncusoru, dorduncusoru, besincisoru);
            await interaction.showModal(lyuexinhelpermodali);        
        } else if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'lyuexinhelpermodali') {
            // Önce interaction'ı defer et (3 saniye timeout'u önlemek için)
            await interaction.deferReply({ ephemeral: true });
           
            const lyuexinsordugusoru1 = interaction.fields.getTextInputValue('lyuexinsordugusoru1');
            const lyuexinsordugusoru2 = interaction.fields.getTextInputValue('lyuexinsordugusoru2');
            const lyuexinsordugusoru3 = interaction.fields.getTextInputValue('lyuexinsordugusoru3');
            const lyuexinsordugusoru4 = interaction.fields.getTextInputValue('lyuexinsordugusoru4');
            const lyuexinsordugusoru5 = interaction.fields.getTextInputValue('lyuexinsordugusoru5');
       
            const lyuexinhelperembedi = new EmbedBuilder()
            .setTitle('🆘 Yeni Helper Başvurusu')
            .setDescription(`👤 **Başvuran:** <@${interaction.member.id}> (${interaction.member.user.tag})\n🆔 **Kullanıcı ID:** ${interaction.member.id}\n⏰ **Başvuru Tarihi:** <t:${Math.floor(Date.now() / 1000)}:F>`)
            .setColor(0x57F287)
            .setThumbnail(interaction.member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: '👤 Kişisel Bilgiler',
                    value: `\`\`\`${lyuexinsordugusoru1}\`\`\``,
                    inline: false
                },
                {
                    name: '⏰ Zaman Durumu',
                    value: `\`\`\`${lyuexinsordugusoru2}\`\`\``,
                    inline: false
                },
                {
                    name: '💼 Önceki Deneyim',
                    value: `\`\`\`${lyuexinsordugusoru3}\`\`\``,
                    inline: false
                },
                {
                    name: '🎯 Beklentiler',
                    value: `\`\`\`${lyuexinsordugusoru4}\`\`\``,
                    inline: false
                },
                {
                    name: '💬 İletişim Yaklaşımı',
                    value: `\`\`\`${lyuexinsordugusoru5}\`\`\``,
                    inline: false
                },
                {
                    name: '📊 Başvuru Bilgileri',
                    value: `🔄 **Durum:** ⏳ Değerlendiriliyor\n🎭 **Tip:** Helper\n⚡ **Öncelik:** Orta`,
                    inline: false
                }
            )
            .setFooter({ 
                text: `${lyuex.server.serverismi} • Helper Başvuru Sistemi`,
                iconURL: interaction.guild.iconURL({ dynamic: true })
            })
            .setTimestamp()
            .setTimestamp();
            
            const lyuexinhelperactionu = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('lyuexinhelperkabulbutonu')
                .setLabel('✅ Kabul Et')
                .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                .setCustomId('lyuexinhelperredbutonu')
                .setLabel('❌ Reddet')
                .setStyle(ButtonStyle.Danger)
            );
            // Log kanalını al
            const logChannelId = lyuex.botSettings?.LOG_CHANNEL_ID;
            const lyuexinkanali = logChannelId ? interaction.guild.channels.cache.get(logChannelId) : null;
            
            if (!lyuexinkanali) {
                console.error('❌ Helper başvuru - Log kanalı bulunamadı! Kanal ID:', logChannelId);
                return await interaction.editReply({
                    content: '❌ **Hata!** Log kanalı yapılandırılmamış. Lütfen yönetici ile iletişime geçin.'
                });
            }
        
            const lyuexinyetkilirolu = lyuex.basvuru.helperbasvuru;
            const lyuexinhelperatanmali = interaction.member;
            
            // Başvuru mesajını gönder
            const applicationMessage = await lyuexinkanali.send({
                content: `<@&${lyuex.yetkili.kurucu}>, <@${interaction.member.id}> helper başvurusu gönderdi!`, 
                embeds: [lyuexinhelperembedi], 
                components: [lyuexinhelperactionu]
            });
            
            // Button collector oluştur
            const collector = applicationMessage.createMessageComponentCollector({ time: 24 * 60 * 60 * 1000 }); // 24 saat

            collector.on('collect', async buttonInteraction => {
                if (buttonInteraction.customId === 'lyuexinhelperkabulbutonu') {
                    await buttonInteraction.update({ 
                        content: `✅ **Helper başvurusu kabul edildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Kabul Eden:** <@${buttonInteraction.user.id}>\n⏰ **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`, 
                        components: [] 
                    });
                    
                    try {
                        await lyuexinhelperatanmali.roles.add(lyuexinyetkilirolu);
                        
                        // DM bildirimi gönder
                        try {
                            const acceptDM = new EmbedBuilder()
                                .setTitle('🎉 Helper Başvurunuz Kabul Edildi!')
                                .setDescription(`Tebrikler! **${lyuex.server.serverismi}** sunucusundaki **Helper** başvurunuz kabul edildi.`)
                                .setColor(0x00FF00)
                                .addFields(
                                    {
                                        name: '✅ Başvuru Durumu',
                                        value: 'Kabul Edildi',
                                        inline: true
                                    },
                                    {
                                        name: '👑 Kabul Eden',
                                        value: `${buttonInteraction.user.tag}`,
                                        inline: true
                                    },
                                    {
                                        name: '🎭 Verilen Rol',
                                        value: `<@&${lyuexinyetkilirolu}>`,
                                        inline: true
                                    },
                                    {
                                        name: '📝 Helper Görevleri',
                                        value: 'Sunucuya geri dönüp helper görevlerinize başlayabilirsiniz. Başarılar!',
                                        inline: false
                                    }
                                )
                                .setFooter({ 
                                    text: `${lyuex.server.serverismi} • Helper Sistemi`,
                                    iconURL: interaction.guild.iconURL({ dynamic: true })
                                })
                                .setTimestamp();
                            
                            await interaction.member.send({ embeds: [acceptDM] });
                        } catch (dmError) {
                            console.log('Helper DM gönderilemedi (kullanıcı DM kapalı olabilir):', dmError.message);
                        }
                        
                        await lyuexinkanali.send({
                            content: `🎉 **Helper Başvurusu Kabul Edildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Kabul Eden:** <@${buttonInteraction.user.id}>\n📝 **Verilen Rol:** <@&${lyuexinyetkilirolu}>`
                        });
                    } catch (error) {
                        console.error('Helper rol verme hatası:', error);
                        await lyuexinkanali.send('❌ **Hata:** Helper rolü verilemedi!');
                    }
                } else if (buttonInteraction.customId === 'lyuexinhelperredbutonu') {
                    await buttonInteraction.update({ 
                        content: `❌ **Helper başvurusu reddedildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Redden:** <@${buttonInteraction.user.id}>\n⏰ **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`, 
                        components: [] 
                    });
                    
                    // DM bildirimi gönder
                    try {
                        const rejectDM = new EmbedBuilder()
                            .setTitle('❌ Helper Başvurunuz Reddedildi')
                            .setDescription(`Üzgünüz, **${lyuex.server.serverismi}** sunucusundaki **Helper** başvurunuz reddedildi.`)
                            .setColor(0xFF0000)
                            .addFields(
                                {
                                    name: '❌ Başvuru Durumu',
                                    value: 'Reddedildi',
                                    inline: true
                                },
                                {
                                    name: '👑 Redden',
                                    value: `${buttonInteraction.user.tag}`,
                                    inline: true
                                },
                                {
                                    name: '🔄 Tekrar Başvuru',
                                    value: 'Gelecekte tekrar başvurabilirsiniz.',
                                    inline: true
                                },
                                {
                                    name: '💡 Helper İpuçları',
                                    value: 'Daha aktif olmaya çalışın ve sunucu kurallarını daha iyi öğrenin.',
                                    inline: false
                                }
                            )
                            .setFooter({ 
                                text: `${lyuex.server.serverismi} • Helper Sistemi`,
                                iconURL: interaction.guild.iconURL({ dynamic: true })
                            })
                            .setTimestamp();
                        
                        await interaction.member.send({ embeds: [rejectDM] });
                    } catch (dmError) {
                        console.log('Helper DM gönderilemedi (kullanıcı DM kapalı olabilir):', dmError.message);
                    }
                    
                    await lyuexinkanali.send({
                        content: `❌ **Helper Başvurusu Reddedildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Redden:** <@${buttonInteraction.user.id}>`
                    });
                }
            });
            
            collector.on('end', collected => {
                if (collected.size === 0) {
                    applicationMessage.edit({ 
                        content: applicationMessage.content + '\n\n⏰ **Bu başvuru zaman aşımına uğradı.**', 
                        components: [] 
                    }).catch(console.error);
                }
            });
            await interaction.editReply({ 
                content: `✅ **HELPER BAŞVURUNUZ BAŞARIYLA GÖNDERİLDİ!**\n\n` +
                        `📋 **Başvuru Özeti:**\n` +
                        `👤 **Kişisel Bilgiler:** ${lyuexinsordugusoru1}\n` +
                        `⏰ **Zaman Durumu:** ${lyuexinsordugusoru2}\n` +
                        `💼 **Deneyim:** ${lyuexinsordugusoru3}\n` +
                        `🎯 **Beklentiler:** ${lyuexinsordugusoru4}\n` +
                        `💬 **İletişim Yaklaşımı:** ${lyuexinsordugusoru5}\n\n` +
                        `⏰ **Başvurunuz 24-48 saat içinde değerlendirilecektir.**`
            });
        }
    }
}





