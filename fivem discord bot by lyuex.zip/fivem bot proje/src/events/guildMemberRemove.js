// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/protection.json');
const {AuditLogEvent, Events, EmbedBuilder } = require('discord.js');

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(member) {
    const guild = member.guild;
    if (!guild) return;

    // 1. protection.json dosyasını oku
    let data;
    try {
      data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch (err) {
      console.error('protection.json okunamadı veya JSON hatası:', err);
      return;
    }

    // 2. Bu guild için kayıtlı ayarları al
    const guildData = data[guild.id];
    if (!guildData || !guildData.enabled) return;

    // 3. whitelist dizisini al, yoksa boş dizi ata
    const whitelist = Array.isArray(guildData.whitelist) ? guildData.whitelist : [];

    // 4. Son bir audit-log girişi al
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 1 });
    const entry = logs.entries.first();

    // 5. Giriş yoksa veya executor whitelist’teyse çık
    if (!entry || whitelist.includes(entry.executor.id)) return;

    // 6. Gerçekten bu üye mi atıldı diye kontrol et
    if (entry.target.id !== member.id) return;

    // 7. Log kanalı varsa uyarıyı gönder
    const logChannel = guild.channels.cache.get(guildData.logChannel);
    if (logChannel) {
      logChannel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('Guard Sistemi Uyarısı')
            .setDescription(
              `👢 <@${entry.executor.id}> izinsiz olarak <@${member.id}> adlı kullanıcıyı attı.`
            )
            .setTimestamp()
        ]
      });
    }
  }
};





