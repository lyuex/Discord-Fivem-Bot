// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');

const PROTECTION_FILE = path.join(__dirname, '..', 'data', 'protection.json');

// Kullanıcı aksiyon tracker'ı
const userActions = new Map();

async function readProtectionData() {
    try {
        const data = await fs.readFile(PROTECTION_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

async function isUserWhitelisted(guildId, userId) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.whitelistUsers?.includes(userId) || false;
}

async function isProtectionEnabled(guildId, protectionType) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.enabled && protectionData[guildId]?.settings?.[protectionType];
}

async function logAction(guild, embed) {
    const protectionData = await readProtectionData();
    const logChannelId = protectionData[guild.id]?.logChannel;
    
    if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] }).catch(console.error);
        }
    }
}

function trackUserAction(guildId, userId, actionType) {
    const key = `${guildId}_${userId}`;
    const now = Date.now();
    
    if (!userActions.has(key)) {
        userActions.set(key, []);
    }
    
    const actions = userActions.get(key);
    actions.push({ type: actionType, timestamp: now });
    
    // 1 dakikadan eski aksiyonları temizle
    const filteredActions = actions.filter(action => now - action.timestamp < 60000);
    userActions.set(key, filteredActions);
    
    return filteredActions.length;
}

async function handleSuspiciousActivity(guild, userId, actionType, actionCount) {
    const protectionData = await readProtectionData();
    const maxActions = protectionData[guild.id]?.settings?.maxActions || 3;
    
    if (actionCount >= maxActions) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member && !member.permissions.has('Administrator')) {
            try {
                await member.ban({ 
                    reason: `Guard sistemi: Şüpheli aktivite tespit edildi (${actionType} - ${actionCount} kez)`,
                    deleteMessageDays: 1
                });
                
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 Otomatik Yasaklama')
                    .setDescription(`**${member.user.tag}** şüpheli aktivite nedeniyle yasaklandı.`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.id})`, inline: true },
                        { name: '⚠️ Tespit Edilen Aktivite', value: actionType, inline: true },
                        { name: '📊 Aksiyon Sayısı', value: `${actionCount}/${maxActions}`, inline: true }
                    )
                    .setColor(0xF44336)
                    .setTimestamp();
                
                await logAction(guild, logEmbed);
                userActions.delete(`${guild.id}_${userId}`);
                
            } catch (error) {
                console.error('Kullanıcı yasaklanırken hata:', error);
            }
        }
    }
}

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        const guildId = newMember.guild.id;
        
        if (await isProtectionEnabled(guildId, 'antiRole')) {
            // Roller çıkarıldı mı kontrol et
            const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
            const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
            
            if (removedRoles.size > 0) {
                const auditLogs = await newMember.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberRoleUpdate,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const roleLog = auditLogs.entries.first();
                    const executor = roleLog.executor;
                    
                    // Güvenli sistem kontrolü - yeni koruma.js'teki fonksiyonları kullan
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(newMember.guild, executor.id);
                    
                    // Kendi kendine rol çıkarması değilse ve whitelist'te değilse ve güvenli değilse
                    if (executor && executor.id !== newMember.id && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Rol Çıkarma');
                        
                        // Güvenli sistem ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Rol Çıkarma', newMember.guild);
                        
                        const roleList = removedRoles.map(role => `\`${role.name}\``).join(', ');
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('🏷️ Rol Çıkarma Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir üyeden rol çıkardı.`)
                            .addFields(
                                { name: '👤 Etkilenen Üye', value: `${newMember.user.tag} (${newMember.id})`, inline: true },
                                { name: '👤 Rol Çıkaran', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                { name: '🏷️ Çıkarılan Roller', value: roleList.length > 1024 ? `${removedRoles.size} rol çıkarıldı` : roleList, inline: false }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xFF9800)
                            .setTimestamp();
                        
                        await logAction(newMember.guild, logEmbed);
                        await handleSuspiciousActivity(newMember.guild, executor.id, 'Rol Çıkarma', actionCount);
                        
                        // Güvenli sistem ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(newMember.guild, executor.id, 'Rol Çıkarma', violationCount);
                        }
                    }
                }
            }
            
            // Roller eklendi mi kontrol et (ek güvenlik için)
            if (addedRoles.size > 0) {
                const auditLogs = await newMember.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberRoleUpdate,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const roleLog = auditLogs.entries.first();
                    const executor = roleLog.executor;
                    
                    // Güvenli sistem kontrolü - yeni koruma.js'teki fonksiyonları kullan
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(newMember.guild, executor.id);
                    
                    // Kendi kendine rol ekleme değilse ve whitelist'te değilse ve güvenli değilse
                    if (executor && executor.id !== newMember.id && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        
                        // TÜM ROL EKLEME İŞLEMLERİNİ LOGLA
                        const actionCount = trackUserAction(guildId, executor.id, 'Rol Ekleme');
                        
                        // Güvenli sistem ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Rol Ekleme', newMember.guild);
                        
                        // Yüksek yetkili roller kontrol et
                        const dangerousRoles = addedRoles.filter(role => 
                            role.permissions.has('Administrator') || 
                            role.permissions.has('ManageGuild') ||
                            role.permissions.has('ManageRoles') ||
                            role.permissions.has('ManageChannels') ||
                            role.permissions.has('BanMembers') ||
                            role.permissions.has('KickMembers')
                        );
                        
                        const normalRoles = addedRoles.filter(role => 
                            !role.permissions.has('Administrator') && 
                            !role.permissions.has('ManageGuild') &&
                            !role.permissions.has('ManageRoles') &&
                            !role.permissions.has('ManageChannels') &&
                            !role.permissions.has('BanMembers') &&
                            !role.permissions.has('KickMembers')
                        );
                        
                        // Tehlikeli roller varsa
                        if (dangerousRoles.size > 0) {
                            const roleList = dangerousRoles.map(role => `\`${role.name}\``).join(', ');
                            
                            const logEmbed = new EmbedBuilder()
                                .setTitle('🚨 Tehlikeli Rol Verme Tespit Edildi')
                                .setDescription(`**${executor.tag}** bir üyeye yüksek yetkili rol verdi.`)
                                .addFields(
                                    { name: '👤 Etkilenen Üye', value: `${newMember.user.tag} (${newMember.id})`, inline: true },
                                    { name: '👤 Rol Veren', value: `${executor.tag} (${executor.id})`, inline: true },
                                    { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                    { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                    { name: '🚨 Verilen Tehlikeli Roller', value: roleList.length > 1024 ? `${dangerousRoles.size} yüksek yetkili rol` : roleList, inline: false }
                                )
                                .setColor(violationCount >= 3 ? 0xFF0000 : 0xF44336)
                                .setTimestamp();
                            
                            await logAction(newMember.guild, logEmbed);
                            await handleSuspiciousActivity(newMember.guild, executor.id, 'Tehlikeli Rol Verme', actionCount);
                            
                            // Güvenli sistem ihlal limiti kontrolü
                            if (violationCount >= 3) {
                                await korumaCommand.handleViolationLimit(newMember.guild, executor.id, 'Tehlikeli Rol Verme', violationCount);
                            }
                        }
                        
                        // Normal roller de loglanacak
                        if (normalRoles.size > 0) {
                            const roleList = normalRoles.map(role => `\`${role.name}\``).join(', ');
                            
                            const logEmbed = new EmbedBuilder()
                                .setTitle('🏷️ Rol Ekleme Tespit Edildi')
                                .setDescription(`**${executor.tag}** bir üyeye rol ekledi.`)
                                .addFields(
                                    { name: '👤 Etkilenen Üye', value: `${newMember.user.tag} (${newMember.id})`, inline: true },
                                    { name: '👤 Rol Veren', value: `${executor.tag} (${executor.id})`, inline: true },
                                    { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                    { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                    { name: '🏷️ Eklenen Roller', value: roleList.length > 1024 ? `${normalRoles.size} rol eklendi` : roleList, inline: false }
                                )
                                .setColor(violationCount >= 3 ? 0xFF0000 : 0xFF9800)
                                .setTimestamp();
                            
                            await logAction(newMember.guild, logEmbed);
                            await handleSuspiciousActivity(newMember.guild, executor.id, 'Rol Ekleme', actionCount);
                            
                            // Güvenli sistem ihlal limiti kontrolü
                            if (violationCount >= 3) {
                                await korumaCommand.handleViolationLimit(newMember.guild, executor.id, 'Rol Ekleme', violationCount);
                            }
                        }
                    }
                }
            }
        }
    }
};




