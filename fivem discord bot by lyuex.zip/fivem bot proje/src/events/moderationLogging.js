// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = [
    // Ban eklendi
    {
        name: Events.GuildBanAdd,
        async execute(ban) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.ban_add) return;
            
            const logChannel = ban.guild.channels.cache.get(lyuex.log.channels.moderation_logs);
            if (!logChannel) return;

            try {
                // Audit log'dan kim banladığını ve sebebini bul
                const auditLogs = await ban.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanAdd,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;
                const reason = auditEntry ? auditEntry.reason : null;

                const embed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('🔨 Kullanıcı Banlandı')
                    .setDescription(`**${ban.user.tag}** sunucudan banlandı`)
                    .addFields(
                        { name: '👤 Banlanan Kullanıcı', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                        { name: '👮 Banlayan Yetkili', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '📝 Ban Sebebi', value: reason || 'Sebep belirtilmemiş', inline: true },
                        { name: '⏰ Ban Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '🆔 Kullanıcı ID', value: ban.user.id, inline: true },
                        { name: '📊 Ban Durumu', value: '🔴 Aktif', inline: true }
                    )
                    .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Moderasyon Sistemi • LYUEX`,
                        iconURL: ban.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                // Bot tarafından banlanmışsa özel işaret
                if (executor && executor.bot) {
                    embed.addFields({ 
                        name: '🤖 Bot İşlemi', 
                        value: 'Bu ban otomatik sistem tarafından gerçekleştirildi', 
                        inline: false 
                    });
                }

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Ban ekleme log hatası:', error);
            }
        }
    },

    // Ban kaldırıldı
    {
        name: Events.GuildBanRemove,
        async execute(ban) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.ban_remove) return;
            
            const logChannel = ban.guild.channels.cache.get(lyuex.log.channels.moderation_logs);
            if (!logChannel) return;

            try {
                // Audit log'dan kim ban kaldırdığını bul
                const auditLogs = await ban.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanRemove,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;

                const embed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('✅ Ban Kaldırıldı')
                    .setDescription(`**${ban.user.tag}** kullanıcısının banı kaldırıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                        { name: '👮 Ban Kaldıran', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '⏰ Ban Kaldırılma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '🆔 Kullanıcı ID', value: ban.user.id, inline: true },
                        { name: '📊 Ban Durumu', value: '🟢 Kaldırıldı', inline: true },
                        { name: '🔗 Tekrar Katılabilir', value: 'Evet', inline: true }
                    )
                    .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Moderasyon Sistemi • LYUEX`,
                        iconURL: ban.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Ban kaldırma log hatası:', error);
            }
        }
    }
];




