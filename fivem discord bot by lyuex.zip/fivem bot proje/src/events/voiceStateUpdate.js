// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require("discord.js");
const lyuex = require("../../lyuex.json");

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const member = newState.member;
        const guild = member.guild;
        
        const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
        if (!logChannelId) return;
        
        const logChannel = guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        // Ses kanalı değişiklikleri
        if (oldState.channelId !== newState.channelId) {
            let actionType = "";
            let actionColor = "";
            let actionEmoji = "";
            let description = "";

            if (!oldState.channelId && newState.channelId) {
                actionType = "Ses Kanalına Katıldı";
                actionColor = "#00ff00";
                actionEmoji = "";
                description = `${member.user.tag} ses kanalına katıldı!`;
            } else if (oldState.channelId && !newState.channelId) {
                actionType = "Ses Kanalından Ayrıldı";
                actionColor = "#ff4444";
                actionEmoji = "";
                description = `${member.user.tag} ses kanalından ayrıldı!`;
            } else if (oldState.channelId && newState.channelId) {
                actionType = "Ses Kanalı Değiştirdi";
                actionColor = "#ffaa00";
                actionEmoji = "";
                description = `${member.user.tag} ses kanalını değiştirdi!`;
            }

            if (actionType) {
                const voiceEmbed = new EmbedBuilder()
                    .setColor(actionColor)
                    .setTitle(`${actionEmoji} ${actionType}`)
                    .setDescription(description)
                    .addFields(
                        { 
                            name: " Kullanıcı", 
                            value: `${member.user.tag}\n<@${member.id}>`, 
                            inline: true 
                        },
                        { 
                            name: " Zaman", 
                            value: `<t:${Math.floor(Date.now() / 1000)}:F>`, 
                            inline: true 
                        }
                    );

                if (oldState.channelId) {
                    voiceEmbed.addFields({
                        name: " Eski Kanal",
                        value: `${oldState.channel.name}\n<#${oldState.channelId}>`,
                        inline: true
                    });
                }

                if (newState.channelId) {
                    voiceEmbed.addFields({
                        name: " Yeni Kanal",
                        value: `${newState.channel.name}\n<#${newState.channelId}>`,
                        inline: true
                    });
                }

                voiceEmbed
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Ses Sistemi  ${guild.name}`, 
                        iconURL: guild.iconURL({ dynamic: true }) 
                    })
                    .setTimestamp();

                await logChannel.send({ embeds: [voiceEmbed] }).catch(console.error);
            }
        }
    }
};





