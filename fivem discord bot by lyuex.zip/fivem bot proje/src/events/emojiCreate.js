// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, AuditLogEvent, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildEmojiCreate,
    async execute(emoji) {
        if (!lyuex.log?.enabled || !lyuex.log?.events?.emoji_create) return;
        
        const guild = emoji.guild;
        const logChannel = guild.channels.cache.get(lyuex.log.channels.system_logs);

        if (!logChannel) {
            return;
        }

        try {
            const fetchedLogs = await guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.EmojiCreate
            });

            const emojiLog = fetchedLogs.entries.first();
            const { executor, target } = emojiLog;

            const embed = new EmbedBuilder()
                .setColor(0x00FF1A)
                .setTitle('😀 Emoji Oluşturuldu')
                .setThumbnail(emoji.guild.iconURL({ dynamic: true }))
                .setDescription(`**${target.name}** emojisi oluşturuldu`)
                .addFields(
                    { name: '😀 Emoji', value: `${target} **${target.name}** (${target.id})`, inline: true },
                    { name: '👮 Oluşturan', value: `${executor.tag} (<@${executor.id}>)`, inline: true },
                    { name: '⏰ Oluşturulma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setFooter({ 
                    text: `LYUEX Gelişmiş Log Sistemi • Emoji Yönetimi`,
                    iconURL: emoji.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Emoji oluşturma log hatası:', error);
        }
    },
};





