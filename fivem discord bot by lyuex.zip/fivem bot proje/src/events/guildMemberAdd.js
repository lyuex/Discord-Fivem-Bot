// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member, client) {
        if (lyuex.rol.kayıtsız) {
            try {
                const role = member.guild.roles.cache.get(lyuex.rol.kayıtsız);
                if (role) {
                    await member.roles.add(role);
                    
                    // Otomatik rol verme logu
                    const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                    if (logChannelId) {
                        const logChannel = client.channels.cache.get(logChannelId);
                        if (logChannel && logChannel.isTextBased()) {
                            const otorolEmbed = new EmbedBuilder()
                                .setColor(0x00FF1A)
                                .setTitle('🤖 Otomatik Rol Verildi')
                                .setDescription(`Sunucuya katılan kullanıcıya otomatik rol verildi!`)
                                .addFields(
                                    { name: '👤 Kullanıcı', value: `${member.user.tag}\n<@${member.id}>`, inline: true },
                                    { name: '🏷️ Verilen Rol', value: `<@&${lyuex.rol.kayıtsız}>`, inline: true },
                                    { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                                )
                                .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                                .setFooter({ text: `Otomatik Rol Sistemi • ${member.guild.name}`, iconURL: member.guild.iconURL({ dynamic: true }) })
                                .setTimestamp();
                            
                            await logChannel.send({ embeds: [otorolEmbed] }).catch(console.error);
                        }
                    }
                    
                    // Sunucu katılım logu
                    const katilimEmbed = new EmbedBuilder()
                        .setColor(0x07FF73)
                        .setTitle('📥 Sunucuya Yeni Üye Katıldı')
                        .setDescription(`Hoş geldin ${member.user.tag}!`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${member.user.tag}\n<@${member.id}>`, inline: true },
                            { name: '🆔 ID', value: member.id, inline: true },
                            { name: '📅 Hesap Oluşturma', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:F>`, inline: true },
                            { name: '👥 Toplam Üye', value: member.guild.memberCount.toString(), inline: true }
                        )
                        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                        .setFooter({ text: `Üye Sistemi • ${member.guild.name}`, iconURL: member.guild.iconURL({ dynamic: true }) })
                        .setTimestamp();
                    
                    if (logChannelId) {
                        const logChannel = client.channels.cache.get(logChannelId);
                        if (logChannel && logChannel.isTextBased()) {
                            await logChannel.send({ embeds: [katilimEmbed] }).catch(console.error);
                        }
                    }
                }

                // Hoşgeldin mesajları (duyuru ve kurallar kanallarında)
                const duyuruKanali = client.channels.cache.get(lyuex.kanal.duyurular);
                const kurallarKanali = client.channels.cache.get(lyuex.kanal.kurallar);
                
                if (duyuruKanali && duyuruKanali.isTextBased()) {
                    try {
                        const message = await duyuruKanali.send({ content: `${member}` });
                        setTimeout(() => message.delete().catch(() => {}), 2000);
                    } catch (error) {
                        console.error('Duyuru kanalına mesaj gönderme hatası:', error.message);
                    }
                }
                
                if (kurallarKanali && kurallarKanali.isTextBased()) {
                    try {
                        const message = await kurallarKanali.send({ content: `${member}` });
                        setTimeout(() => message.delete().catch(() => {}), 2000);
                    } catch (error) {
                        console.error('Kurallar kanalına mesaj gönderme hatası:', error.message);
                    }
                }

                // Kayıtsız sohbet kanalında hoşgeldin embed mesajı
                const kayitsizSohbetKanali = client.channels.cache.get(lyuex.kanal.kayitsiz_sohbet);
                if (kayitsizSohbetKanali && kayitsizSohbetKanali.isTextBased()) {
                    try {
                        const welcomeEmbed = new EmbedBuilder()
                            .setColor(0x00FF00)
                            .setTitle(`🎉 ${member.guild.name} Sunucusuna Hoş Geldin!`)
                            .setDescription(`${member}, sunucumuza hoş geldin! Whitelist almak için sesli kanallarımıza geçmeniz gerekmektedir. Yetkililerimiz sizinle ilgilenecektir.`)
                            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                            .setFooter({ text: `Hoş Geldin Sistemi • ${member.guild.name}`, iconURL: member.guild.iconURL({ dynamic: true }) })
                            .setTimestamp();
                        
                        await kayitsizSohbetKanali.send({ embeds: [welcomeEmbed] });
                    } catch (error) {
                        console.error('Kayıtsız sohbet kanalına embed gönderme hatası:', error.message);
                    }
                }
        }
    },
};





