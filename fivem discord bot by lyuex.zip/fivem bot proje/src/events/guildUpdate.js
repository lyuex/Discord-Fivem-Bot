// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const guvenli = require('../commands/guvenli');

module.exports = {
   name: Events.GuildUpdate,
    async execute(oldGuild, newGuild, client) {
        try {
            const audit = await newGuild.fetchAuditLogs({ limit: 1 });
            const auditEntry = audit.entries.first();
            const executor = auditEntry ? auditEntry.executor : null;

            // Sunucu ayarlarında bir değişiklik yapılmış mı kontrol et
            let hasChanges = false;
            let changeDescription = [];

            if (oldGuild.name !== newGuild.name) {
                hasChanges = true;
                changeDescription.push(`📝 **Ad:** \`${oldGuild.name}\` → \`${newGuild.name}\``);
            }

            if (oldGuild.vanityURLCode !== newGuild.vanityURLCode) {
                hasChanges = true;
                changeDescription.push(`🔗 **Davet Bağlantısı:** \`${oldGuild.vanityURLCode || 'Yok'}\` → \`${newGuild.vanityURLCode || 'Yok'}\``);
            }

            if (oldGuild.description !== newGuild.description) {
                hasChanges = true;
                changeDescription.push(`📄 **Açıklama:** Değiştirildi`);
            }

            if (oldGuild.icon !== newGuild.icon) {
                hasChanges = true;
                changeDescription.push(`🖼️ **Simge:** Değiştirildi`);
            }

            if (oldGuild.banner !== newGuild.banner) {
                hasChanges = true;
                changeDescription.push(`🎨 **Banner:** Değiştirildi`);
            }

            if (oldGuild.splash !== newGuild.splash) {
                hasChanges = true;
                changeDescription.push(`✨ **Splash:** Değiştirildi`);
            }

            if (oldGuild.premiumTier !== newGuild.premiumTier) {
                hasChanges = true;
                changeDescription.push(`💎 **Boost Seviyesi:** ${oldGuild.premiumTier} → ${newGuild.premiumTier}`);
            }

            if (oldGuild.afkChannelId !== newGuild.afkChannelId) {
                hasChanges = true;
                const oldChannel = oldGuild.afkChannelId ? `<#${oldGuild.afkChannelId}>` : 'Yok';
                const newChannel = newGuild.afkChannelId ? `<#${newGuild.afkChannelId}>` : 'Yok';
                changeDescription.push(`🔇 **AFK Kanalı:** ${oldChannel} → ${newChannel}`);
            }

            if (oldGuild.defaultMessageNotifications !== newGuild.defaultMessageNotifications) {
                hasChanges = true;
                changeDescription.push(`🔔 **Bildirim Ayarı:** Değiştirildi`);
            }

            if (oldGuild.explicitContentFilter !== newGuild.explicitContentFilter) {
                hasChanges = true;
                changeDescription.push(`🚫 **İçerik Filtresi:** Değiştirildi`);
            }

            // Eğer değişiklik varsa ve yapan kişi güvenli değilse
            if (hasChanges && executor && !guvenli.isUserSafe(newGuild.id, executor.id)) {
                // İhlal sayısını artır
                const violationCount = guvenli.trackViolation(newGuild.id, executor.id, 'Sunucu Ayarlarıyla Oynama', newGuild);
                
                // İhlal log embed'i
                const violationEmbed = new EmbedBuilder()
                    .setTitle('🚨 Güvenli Sistem İhlali - Sunucu Ayarları Değişikliği')
                    .setDescription(`**${executor.tag}** sunucu ayarlarını değiştirdi.`)
                    .addFields(
                        { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                        { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
                        { name: '📝 Yapılan Değişiklikler', value: changeDescription.join('\n') || 'Bilinmiyor', inline: false }
                    )
                    .setColor(0xFF9800)
                    .setTimestamp();
                
                // Log kanalına gönder
                const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                if (logChannelId) {
                    const logChannel = client.channels.cache.get(logChannelId);
                    if (logChannel) {
                        await logChannel.send({ embeds: [violationEmbed] });
                    }
                }
                
                // İhlal limitini kontrol et
                await guvenli.handleViolationLimit(newGuild, executor.id, 'Sunucu Ayarlarıyla Oynama', violationCount);
            }

            // Normal loglama
            if (hasChanges) {
                const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                if (logChannelId) {
                    const logChannel = client.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const embed = new EmbedBuilder()
                            .setColor(0x00D4FF)
                            .setTitle('⚙️ Sunucu Ayarları Güncellendi')
                            .setDescription(`Sunucu ayarlarında değişiklik yapıldı.`)
                            .addFields(
                                { name: '👤 Yapan', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                                { name: '🆔 Sunucu ID', value: newGuild.id, inline: true },
                                { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                                { name: '📝 Yapılan Değişiklikler', value: changeDescription.join('\n') || 'Bilinmiyor', inline: false }
                            )
                            .setThumbnail(newGuild.iconURL({ dynamic: true }))
                            .setFooter({ text: `Sunucu Sistemi • ${newGuild.name}`, iconURL: newGuild.iconURL({ dynamic: true }) })
                            .setTimestamp();
                        
                        await logChannel.send({ embeds: [embed] });
                    }
                }
            }
                
        } catch (error) {
            console.error('Sunucu güncelleme log hatası:', error);
            catchError(client, 'guildUpdate.js', error.message);
        }
    }
};





