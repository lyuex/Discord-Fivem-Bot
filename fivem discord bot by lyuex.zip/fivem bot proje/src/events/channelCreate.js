// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const guvenli = require('../commands/guvenli');
const fs = require('fs');
const path = require('path');
const backupPath = path.join(__dirname, '../data/channelBackup.json');

module.exports = {
   name: Events.ChannelCreate,
    async execute(channel, client){
        try {
           const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
           
           const audit = await channel.guild.fetchAuditLogs({type: AuditLogEvent.ChannelCreate});
           const oc = audit.entries.first();
           const executor = oc ? oc.executor : null;

           // Güvenli kontrolü - eğer yapan kişi güvenli değilse ihlal say
           if (executor && !guvenli.isUserSafe(channel.guild.id, executor.id)) {
               // İhlal sayısını artır
               const violationCount = guvenli.trackViolation(channel.guild.id, executor.id, 'Kanal Ekleme', channel.guild);
               
               // İhlal log embed'i
               const violationEmbed = new EmbedBuilder()
                   .setTitle('🚨 Güvenli Sistem İhlali - Kanal Ekleme')
                   .setDescription(`**${executor.tag}** yeni bir kanal oluşturdu.`)
                   .addFields(
                       { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                       { name: '📁 Oluşturulan Kanal', value: `${channel.name} (${channel.id})`, inline: true },
                       { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                       { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                   )
                   .setColor(0xFF9800)
                   .setTimestamp();
               
               // Log kanalına gönder
               if (logChannelId) {
                   const lyuexinchannellogkanali = client.channels.cache.get(logChannelId);
                   if (lyuexinchannellogkanali) {
                       await lyuexinchannellogkanali.send({ embeds: [violationEmbed] });
                   }
               }
               
               // İhlal limitini kontrol et
               await guvenli.handleViolationLimit(channel.guild, executor.id, 'Kanal Ekleme', violationCount);
           }

           if (logChannelId) {
               const lyuexinchannellogkanali = client.channels.cache.get(logChannelId);
               if (lyuexinchannellogkanali) {
                   const lyuexinchannellogembedi = new EmbedBuilder()
                       .setColor(0x00FF1A)
                       .setTitle('📁 Kanal Oluşturuldu!')
                       .setDescription(`Yeni kanal oluşturuldu!`)
                       .addFields(
                           { name: '👤 Oluşturan', value: `<@${oc.executor.id}>\n${oc.executor.tag}`, inline: true },
                           { name: '📁 Kanal', value: `${channel.name}\n<#${channel.id}>`, inline: true },
                           { name: '🆔 Kanal ID', value: channel.id, inline: true },
                           { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                       )
                       .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                       .setFooter({ text: `Kanal Sistemi • ${channel.guild.name}`, iconURL: channel.guild.iconURL({ dynamic: true }) })
                       .setTimestamp();
                   lyuexinchannellogkanali.send({ embeds: [lyuexinchannellogembedi] }).catch(console.error);
               }
           }
        } catch (error) {
            console.error('Kanal oluşturma hatası:', error);
            catchError(client, 'channelCreate.js', error.message);
        }
    },
};








