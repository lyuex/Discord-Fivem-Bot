// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, PermissionFlagsBits } = require('discord.js');

const COLOR_ROLES = new Map([
  ['red', 'Kırmızı'],
  ['blue', 'Mavi'],
  ['green', 'Yeşil'],
  ['white', 'Beyaz'],
  ['black', 'Siyah'],
  ['yellow', 'Sarı'],
  ['pink', 'Pembe'],
  ['purple', 'Mor']
]);

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (!interaction.isStringSelectMenu() || interaction.customId !== 'renkMenu') return;

    const selectedKey = interaction.values[0];
    const roleName = COLOR_ROLES.get(selectedKey);

    if (!roleName) {
      return interaction.reply({ content: '❌ Geçersiz seçim.', ephemeral: true });
    }

    const { guild, member } = interaction;

    // Bot'un ManageRoles izni var mı?
    if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({
        content: '🚫 Rol yönetimi için yetkim yok.',
        ephemeral: true
      });
    }

    // Rolü bul
    const targetRole = guild.roles.cache.find(r => r.name === roleName);
    if (!targetRole) {
      return interaction.reply({ content: '⚠️ Sunucuda bu rol bulunamadı.', ephemeral: true });
    }

    try {
      // Mevcut tüm renk rollerini temizle (seçilen harici)
      const rolesToRemove = member.roles.cache.filter(r =>
        COLOR_ROLES.has(
          [...COLOR_ROLES.entries()].find(([key, val]) => val === r.name)?.[0]
        ) && r.id !== targetRole.id
      );
      if (rolesToRemove.size) await member.roles.remove(rolesToRemove);

      // Seçili rolü ekle (zaten varsa atla)
      if (!member.roles.cache.has(targetRole.id)) {
        await member.roles.add(targetRole);
      }

      return interaction.reply({
        content: `✅ **${roleName}** rolü başarıyla verildi.`,
        ephemeral: true
      });
    } catch (error) {
      console.error('❗ Rol değiştirme hatası:', error);
      if (!interaction.replied) {
        await interaction.reply({
          content: '❌ Rol ayarlanırken bir hata oluştu.',
          ephemeral: true
        });
      }
    }
  }
};





