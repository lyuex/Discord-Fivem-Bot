// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
module.exports = {
    async execute(interaction) {
        try {
            console.log(`[EkipUyariInteractionHandler] Processing: ${interaction.customId}`);
            
            // Ekip uyarı işlemlerini buraya ekleyin
            await interaction.reply({
                content: '⚠️ Ekip uyarı işlemi tamamlandı!',
                ephemeral: true
            });

        } catch (error) {
            console.error('Ekip uyarı interaction handler hatası:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Bir hata oluştu!',
                    ephemeral: true
                }).catch(() => {});
            }
        }
    }
};