// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const ModerationManager = require('../utils/moderationManager');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log('🛡️ Moderasyon sistemi yükleniyor...');
    
    try {
      if (!global.DB_CONNECTED) {
        console.warn('⏭️ Veritabanı bağlantısı yok. Moderasyon kontrolleri başlangıçta atlandı.');
      } else {
        // Bot açıldığında süresi dolmuş mute'ları ve ban'ları kontrol et
        await ModerationManager.checkExpiredMutes(client);
        await ModerationManager.checkExpiredBans(client);
      }
      
      // Periyodik olarak süresi dolmuş moderasyon işlemlerini kontrol et (1 dakikada bir)
      setInterval(async () => {
        try {
          if (!global.DB_CONNECTED) return; // DB yoksa sessizce atla
          await ModerationManager.checkExpiredMutes(client);
          await ModerationManager.checkExpiredBans(client);
        } catch (intervalError) {
          console.error('Periyodik moderasyon kontrolü hatası:', intervalError);
        }
      }, 60000); // 60 saniye
      
      console.log('✅ Moderasyon sistemi başarıyla yüklendi!');
      console.log('   📋 Otomatik unmute kontrolü: Aktif');
      console.log('   📋 Otomatik unban kontrolü: Aktif');
      console.log('   📋 Kontrol sıklığı: 1 dakika');
    } catch (error) {
      console.error('❌ Moderasyon sistemi yükleme hatası:', error);
    }
  }
};




