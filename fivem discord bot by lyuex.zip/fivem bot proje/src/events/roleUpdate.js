// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/protection.json');
module.exports = {
    name: Events.GuildRoleUpdate,
    async execute(oldRole, newRole, client) {
        try {
            if (lyuex.log.rolguncelleme) {
                const lyuexinguncelrolu = client.channels.cache.get(lyuex.botSettings.LOG_CHANNEL_ID);
                oldRole.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate }).then(audit => {
                    const lyuexinallahiyok = audit.entries.first();
                    const lyuexs = lyuexinallahiyok.executor;
                    if (oldRole.id === lyuexinallahiyok.target.id || newRole.id === lyuexinallahiyok.target.id) {
                        const lyuexinrolguncellemeembedi = new EmbedBuilder()
                            .setColor(0xFF0000)
                            .setTitle('Rol Güncellendi')
                            .setDescription(`Eski Rol bilgileri: \n > **${oldRole.name}** - ${oldRole.id} - <@&${oldRole.id}> \nYeni rol bilgileri: \n >**${newRole.name}** - ${newRole.id} - <@&${newRole.id}> \n\n Kişi: ${lyuexs.tag} - ${lyuexs.id} - <@${lyuexs.id}> `)
                            .setThumbnail(newRole.guild.iconURL({ dynamic: true}))
                            .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
                            .setTimestamp();
                        if (lyuexinguncelrolu) {
                            lyuexinguncelrolu.send({ embeds: [lyuexinrolguncellemeembedi]});
                        }
                    }
                });
            }
        }
        catch (error) {
            catchError(client, 'roleUpdate.js', error.message);
        }
    }
};









