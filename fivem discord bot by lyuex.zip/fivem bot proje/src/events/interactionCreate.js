// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { InteractionType } = require("discord.js");

// Interaction handler'ları import et
const modalSubmitHandler = require("./modalSubmitHandler");
const ekipInteractionHandler = require("./ekipInteractionHandler");
const ekipPanelInteractionHandler = require("./ekipPanelInteractionHandler");
const ekipSilInteractionHandler = require("./ekipSilInteractionHandler");
const ekipRolInteractionHandler = require("./ekipRolInteractionHandler");
const ekipProfilInteractionHandler = require("./ekipProfilInteractionHandler");
const ekipYedekInteractionHandler = require("./ekipYedekInteractionHandler");
const ekipYonetimInteractionHandler = require("./ekipYonetimInteractionHandler");
const ekipUyariInteractionHandler = require("./ekipUyariInteractionHandler");
const guvenliInteractionHandler = require("./guvenliInteractionHandler");
const toplurolInteractionHandler = require("./toplurolInteractionHandler");
const uyariInteractionHandler = require("./uyariInteractionHandler");
const uyariYetkiInteractionHandler = require("./uyariYetkiInteractionHandler");
const ticketInteractionHandler = require("./ticketInteractionHandler");

module.exports = {
    name: "interactionCreate",
    async execute(interaction, client) {
        // Özel handler'ları kontrol et
        try {
            // Koruma sistemi handler'ı
            if (interaction.customId && interaction.customId.startsWith("koruma_")) {
                const korumaCommand = require('../commands/koruma');
                await this.handleKorumaButtons(interaction, korumaCommand);
                return;
            }
            
            // IC isim onay sistemi handler'ı
            if (interaction.customId && (interaction.customId.startsWith("ic_onayla_") || 
                interaction.customId.startsWith("ic_uygunsuz_") || 
                interaction.customId.startsWith("ic_unlu_") || 
                interaction.customId.startsWith("ic_ozel_") ||
                interaction.customId.startsWith("ic_ozel_modal_"))) {
                await this.handleIcIsimOnay(interaction);
                return;
            }
            
            // Uyarı yetki sistemi handler'ı
            if (interaction.customId && interaction.customId.startsWith("uyari_yetki_")) {
                await uyariYetkiInteractionHandler.execute(interaction);
                return;
            }
            
            // Uyarı sistemi handler'ı
            if (interaction.customId && interaction.customId.startsWith("uyari_")) {
                await uyariInteractionHandler.execute(interaction);
                return;
            }
            
            // Güvenli sistemi handler'ı
            if (interaction.customId && interaction.customId.startsWith("guvenli_")) {
                await guvenliInteractionHandler.execute(interaction);
                return;
            }
            
            // Ekip sistemi handler'ları
            if (interaction.customId && interaction.customId.startsWith("ekip_") && !interaction.isModalSubmit()) {
                // Ekip temizle butonları - komutun kendi handler'ı işleyecek
                if (interaction.customId === "ekip_temizle_onayla" || interaction.customId === "ekip_temizle_iptal") {
                    return; // Bu butonlar handleTemizle içindeki collector tarafından işlenir
                }
                
                // Ekip panel butonları (ticket kanalındaki yönetim paneli)
                if (interaction.customId.startsWith("ekip_panel_")) {
                    await ekipPanelInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip uyarı sistemi handler'ı
                if (interaction.customId.startsWith("ekip_uyari_") || 
                    interaction.customId.startsWith("ekip_uye_select_") ||
                    interaction.customId.startsWith("ekip_islem_select_") ||
                    interaction.customId.startsWith("ekip_islem_turu_select_") ||
                    interaction.customId.startsWith("ekip_rol_select_") ||
                    interaction.customId.startsWith("ekip_rol_search_") ||
                    interaction.customId.startsWith("ekip_rol_confirm_") ||
                    interaction.customId.startsWith("ekip_rol_cancel_") ||
                    interaction.customId === "team_warnings_select" ||
                    interaction.customId.startsWith("team_warn_")) {
                    await ekipUyariInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip silme işlemleri
                if (interaction.customId.startsWith("ekip_sil_") || 
                    interaction.customId.startsWith("ekip_sec_sil_") ||
                    interaction.customId === "ekip_sil_tumu" ||
                    interaction.customId === "ekip_sil_tumu_final" ||
                    interaction.customId === "ekip_sil_iptal") {
                    await ekipSilInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip rol işlemleri
                if (interaction.customId.startsWith("ekip_rol_") ||
                    interaction.customId.startsWith("ekip_roller_")) {
                    await ekipRolInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip profil işlemleri
                if (interaction.customId.startsWith("ekip_profil_")) {
                    await ekipProfilInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip yedek işlemleri
                if (interaction.customId.startsWith("ekip_yedek_") ||
                    interaction.customId.startsWith("ekip_backup_")) {
                    await ekipYedekInteractionHandler.execute(interaction);
                    return;
                }
                
                // Ekip yönetim işlemleri
                if (interaction.customId.startsWith("ekip_yonetim_") ||
                    interaction.customId.startsWith("ekip_xp_") ||
                    interaction.customId.startsWith("ekip_fix_") ||
                    interaction.customId.startsWith("ekip_detay_") ||
                    interaction.customId.startsWith("ekip_uyeler_") ||
                    interaction.customId.startsWith("ekip_duzelt_")) {
                    await ekipYonetimInteractionHandler.execute(interaction);
                    return;
                }
                
                // Genel ekip sistemi handler'ı
                await ekipInteractionHandler.execute(interaction);
                return;
            }
            
            // Toplurol sistemi handler'ı
            if (interaction.customId && interaction.customId.startsWith("toplurol_")) {
                await toplurolInteractionHandler.execute(interaction);
                return;
            }
            
            // Ticket sistemi handler'ı
            if (interaction.customId && 
                (interaction.customId.startsWith("tc_") || 
                 interaction.customId.startsWith("ticket_create_"))) {
                await ticketInteractionHandler.execute(interaction);
                return;
            }

        } catch (handlerError) {
            console.error("Özel handler hatası:", handlerError);
            
            if (interaction.replied || interaction.deferred) {
                return;
            }
            
            try {
                await interaction.reply({
                    content: "❌ Bir hata oluştu! Lütfen tekrar deneyin.",
                    ephemeral: true
                });
            } catch (replyError) {
                console.error("Reply hatası:", replyError);
            }
            return;
        }

        // Genel komut işleme
        if (interaction.isChatInputCommand()) {
            const { commandMap } = require('../handlers/commandHandler');
            const command = commandMap.get(interaction.commandName);
            if (!command) {
                console.log(`Komut bulunamadı: ${interaction.commandName}`);
                return;
            }
            
            try {
                await command.execute(interaction, client);
            } catch (error) {
                console.log("Komut hatası:", error);
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({
                            content: "Komut çalıştırılırken bir hata oluştu!",
                            ephemeral: true
                        });
                    } catch (replyError) {
                        console.error("Reply hatası:", replyError);
                    }
                }
            }
        } else if (interaction.isButton()) {
            // Yardım sistemi butonları
            if (interaction.customId && (interaction.customId.startsWith("help_") || 
                interaction.customId.startsWith("help_command_detail_") ||
                interaction.customId.startsWith("help_examples_") ||
                interaction.customId === "help_guide_practice" ||
                interaction.customId === "help_back_main" ||
                interaction.customId === "help_close")) {
                
                const yardimCommand = require('../commands/yardım');
                try {
                    await yardimCommand.handleButtonInteraction(interaction);
                } catch (error) {
                    console.error("Yardım button hatası:", error);
                    if (!interaction.replied && !interaction.deferred) {
                        try {
                            await interaction.reply({
                                content: "❌ Yardım sistemi hatası!",
                                ephemeral: true
                            });
                        } catch (replyError) {
                            console.error("Reply hatası:", replyError);
                        }
                    }
                }
                return;
            }
            
            const Button = client.buttons?.get(interaction.customId);
            if (!Button) return;
            
            try {
                await Button.execute(interaction, client);
            } catch (error) {
                console.log("Button hatası:", error);
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({
                            content: "Buton etkileşiminde hata oluştu!",
                            ephemeral: true
                        });
                    } catch (replyError) {
                        console.error("Reply hatası:", replyError);
                    }
                }
            }
        } else if (interaction.isStringSelectMenu() || interaction.isUserSelectMenu() || interaction.isRoleSelectMenu()) {
            // Yardım sistemi select menu'ları
            if (interaction.customId && (interaction.customId === "help_category_select" || 
                interaction.customId === "help_command_detail")) {
                
                const yardimCommand = require('../commands/yardım');
                try {
                    await yardimCommand.setupCollector(interaction);
                } catch (error) {
                    console.error("Yardım select menu hatası:", error);
                    if (!interaction.replied && !interaction.deferred) {
                        try {
                            await interaction.reply({
                                content: "❌ Yardım sistemi hatası!",
                                ephemeral: true
                            });
                        } catch (replyError) {
                            console.error("Reply hatası:", replyError);
                        }
                    }
                }
                return;
            }
            
            const menu = client.selectMenus?.get(interaction.customId);
            if (!menu) return;
            
            try {
                await menu.execute(interaction, client);
            } catch (error) {
                console.log("SelectMenu hatası:", error);
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({
                            content: "Menü etkileşiminde hata oluştu!",
                            ephemeral: true
                        });
                    } catch (replyError) {
                        console.error("Reply hatası:", replyError);
                    }
                }
            }
        } else if (interaction.type === InteractionType.ModalSubmit) {
            // Use dedicated modal submit handler
            await modalSubmitHandler.execute(interaction, client);
        } else if (interaction.isContextMenuCommand()) {
            const contextCommand = client.commands?.get(interaction.commandName);
            if (!contextCommand) return;
            
            try {
                await contextCommand.execute(interaction, client);
            } catch (error) {
                console.log("Context menu hatası:", error);
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({
                            content: "Bağlam menüsünde hata oluştu!",
                            ephemeral: true
                        });
                    } catch (replyError) {
                        console.error("Reply hatası:", replyError);
                    }
                }
            }
        }
    },

    // Koruma sistemi buton handler'ı
    async handleKorumaButtons(interaction, korumaCommand) {
        try {
            const customId = interaction.customId;
            
            switch (customId) {
                case 'koruma_ayarlar':
                    await korumaCommand.handleSettings(interaction);
                    break;
                case 'koruma_guvenli_ekle':
                    await interaction.reply({
                        content: '➕ **Güvenli ekleme için:**\n\n🏷️ Rol eklemek için: `/koruma güvenli-ekle rol:@RolAdı`\n👤 Kullanıcı eklemek için: `/koruma güvenli-ekle kullanıcı:@Kullanıcı`',
                        ephemeral: true
                    });
                    break;
                case 'koruma_durum':
                    await korumaCommand.handleStatus(interaction);
                    break;
                case 'koruma_liste':
                    await korumaCommand.handleList(interaction);
                    break;
                case 'koruma_logs':
                    await interaction.reply({
                        content: '📊 **Log sistemi** henüz geliştiriliyor. Şu an için log kanalını kontrol edebilirsiniz.',
                        ephemeral: true
                    });
                    break;
                case 'koruma_toggle_role':
                case 'koruma_toggle_channel':
                case 'koruma_toggle_ban':
                    await this.handleProtectionToggle(interaction, customId);
                    break;
                default:
                    await interaction.reply({
                        content: '❌ Bilinmeyen koruma sistemi butonuna basıldı!',
                        ephemeral: true
                    });
            }
        } catch (error) {
            console.error('Koruma buton hatası:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Koruma sistemi hatası oluştu!',
                    ephemeral: true
                });
            }
        }
    },

    // Koruma ayarları toggle handler'ı
    async handleProtectionToggle(interaction, customId) {
        const { EmbedBuilder } = require('discord.js');
        const fs = require('fs').promises;
        const path = require('path');
        
        const PROTECTION_FILE = path.join(__dirname, '..', 'data', 'protection.json');
        const guildId = interaction.guild.id;
        
        try {
            let protectionData = {};
            try {
                const data = await fs.readFile(PROTECTION_FILE, 'utf8');
                protectionData = JSON.parse(data);
            } catch (error) {
                protectionData = {};
            }
            
            if (!protectionData[guildId]) {
                protectionData[guildId] = {
                    enabled: false,
                    settings: {
                        antiRole: true,
                        antiChannel: true,
                        antiBan: true,
                        antiBot: true,
                        antiRaid: true,
                        maxActions: 3
                    }
                };
            }
            
            const settings = protectionData[guildId].settings;
            
            switch (customId) {
                case 'koruma_toggle_role':
                    settings.antiRole = !settings.antiRole;
                    break;
                case 'koruma_toggle_channel':
                    settings.antiChannel = !settings.antiChannel;
                    break;
                case 'koruma_toggle_ban':
                    settings.antiBan = !settings.antiBan;
                    break;
            }
            
            await fs.writeFile(PROTECTION_FILE, JSON.stringify(protectionData, null, 2));
            
            const embed = new EmbedBuilder()
                .setColor(0x4CAF50)
                .setTitle('✅ Ayar Güncellendi!')
                .setDescription('Koruma ayarı başarıyla değiştirildi.')
                .addFields(
                    { name: '🏷️ Rol Koruması', value: settings.antiRole ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                    { name: '📢 Kanal Koruması', value: settings.antiChannel ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true },
                    { name: '🔨 Ban Koruması', value: settings.antiBan ? '🟢 **Aktif**' : '🔴 **Kapalı**', inline: true }
                )
                .setTimestamp();
            
            await interaction.update({ embeds: [embed] });
            
        } catch (error) {
            console.error('Protection toggle hatası:', error);
            await interaction.reply({
                content: '❌ Ayar güncellenirken bir hata oluştu!',
                ephemeral: true
            });
        }
    },

    // IC isim onay sistemi handler'ı
    async handleIcIsimOnay(interaction) {
        const { EmbedBuilder, PermissionFlagsBits, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
        const lyuex = require('../../lyuex.json');
        
        try {
            const customId = interaction.customId;
            
            // IC isim onay butonları kontrolü
            if (customId.startsWith('ic_onayla_') || customId.startsWith('ic_uygunsuz_') || 
                customId.startsWith('ic_unlu_') || customId.startsWith('ic_ozel_')) {
                
                // Yetkili kontrolü
                const yetkiliRoller = lyuex.ic_isim?.yetkili_rol || [];
                const hasYetkiliRole = Array.isArray(yetkiliRoller) && yetkiliRoller.length > 0 && 
                    yetkiliRoller.some(roleId => interaction.member?.roles?.cache?.has(roleId));
                const hasAdminPermission = interaction.member?.permissions?.has(PermissionFlagsBits.Administrator);
                const hasPermission = hasYetkiliRole || hasAdminPermission;
                
                if (!hasPermission) {
                    return interaction.reply({
                        content: '❌ Bu işlem için yetkiniz bulunmuyor! Sadece yetkili kişiler bu butonları kullanabilir.',
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Custom ID'den bilgileri çıkar
                const [action, userId, messageId] = customId.split('_').slice(1);
                const targetUser = await interaction.client.users.fetch(userId).catch(() => null);
                
                if (!targetUser) {
                    return interaction.reply({
                        content: '❌ Kullanıcı bulunamadı!',
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);
                
                // Embed'den IC ismini çıkar
                const embed = interaction.message.embeds[0];
                const icIsimField = embed.fields.find(field => field.name === '💎 IC İsim');
                const icIsim = icIsimField ? icIsimField.value.replace(/`/g, '') : 'Bilinmeyen İsim';

                // Özel sebep için modal aç
                if (action === 'ozel') {
                    const modal = new ModalBuilder()
                        .setCustomId(`ic_ozel_modal_${userId}_${messageId}`)
                        .setTitle('Özel Red Sebebi');
                    
                    const sebepInput = new TextInputBuilder()
                        .setCustomId('red_sebebi')
                        .setLabel('Red sebebinizi yazın:')
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder('Örn: İsim kurallara uygun değil çünkü...')
                        .setRequired(true)
                        .setMaxLength(500);
                    
                    const actionRow = new ActionRowBuilder().addComponents(sebepInput);
                    modal.addComponents(actionRow);
                    
                    return await interaction.showModal(modal);
                }
                
                await interaction.deferReply();
                
                let sonucEmbed;
                let redSebebi = '';
                
                switch (action) {
                    case 'onayla':
                        sonucEmbed = new EmbedBuilder()
                            .setColor(0x00FF88)
                            .setTitle('✅ IC İsim Başarıyla Onaylandı!')
                            .setDescription(`🎉 **${targetUser}** tarafından gönderilen IC isim **ONAYLANDI**!`)
                            .addFields(
                                { name: '💎 Onaylanan İsim', value: `\`\`\`${icIsim}\`\`\``, inline: true },
                                { name: '👑 Kullanıcı', value: `**${targetUser.tag}**`, inline: true },
                                { name: '👮 Onaylayan Yetkili', value: `**${interaction.user.tag}**`, inline: true }
                            )
                            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                            .setTimestamp();
                        
                        // Rol verme ve isim değiştirme
                        if (targetMember && lyuex.rol?.ic_onay) {
                            try {
                                const icOnayRol = interaction.guild.roles.cache.get(lyuex.rol.ic_onay);
                                if (icOnayRol) {
                                    await targetMember.roles.add(icOnayRol);
                                }
                                
                                await targetMember.setNickname(icIsim, `IC İsim Onayı - Yetkili: ${interaction.user.tag}`).catch(console.error);
                            } catch (error) {
                                console.error('IC onay rolü verme hatası:', error);
                            }
                        }
                        
                        // Orijinal mesaja tepki ekle
                        try {
                            const originalMsg = await interaction.channel.messages.fetch(messageId).catch(() => null);
                            if (originalMsg) {
                                await originalMsg.react('✅').catch(() => {});
                                await originalMsg.reply({ embeds: [sonucEmbed] });
                            }
                            await interaction.message.delete().catch(() => {});
                        } catch (e) {
                            console.warn('IC mesaj işlemi hatası:', e?.message);
                        }
                        break;
                        
                    case 'uygunsuz':
                        redSebebi = 'Uygunsuz İsim - Sunucu kurallarına aykırı';
                        sonucEmbed = new EmbedBuilder()
                            .setColor(0xFF4444)
                            .setTitle('❌ IC İsim Reddedildi!')
                            .addFields(
                                { name: '💎 Reddedilen İsim', value: `\`\`\`${icIsim}\`\`\``, inline: true },
                                { name: '📋 Red Sebebi', value: `**${redSebebi}**`, inline: true }
                            )
                            .setTimestamp();
                        
                        await interaction.message.edit({
                            embeds: [sonucEmbed],
                            components: []
                        });
                        break;
                        
                    case 'unlu':
                        redSebebi = 'Ünlü/Karakter İsmi - Gerçek kişi veya karakter ismi kullanılamaz';
                        sonucEmbed = new EmbedBuilder()
                            .setColor(0xFF6600)
                            .setTitle('⭐ IC İsim Reddedildi!')
                            .addFields(
                                { name: '💎 Reddedilen İsim', value: `\`\`\`${icIsim}\`\`\``, inline: true },
                                { name: '📋 Red Sebebi', value: `**${redSebebi}**`, inline: true }
                            )
                            .setTimestamp();
                        
                        await interaction.message.edit({
                            embeds: [sonucEmbed],
                            components: []
                        });
                        break;
                }
                
                await interaction.editReply({
                    content: action === 'onayla' ? 
                        `✅ **${icIsim}** ismi başarıyla onaylandı!` : 
                        `❌ **${icIsim}** ismi reddedildi: **${redSebebi}**`
                });
            }
            
            // Özel sebep modal'ı
            if (customId.startsWith('ic_ozel_modal_')) {
                if (!interaction.deferred && !interaction.replied) {
                    await interaction.deferUpdate();
                }
                
                const [, , , userId, messageId] = customId.split('_');
                const targetUser = await interaction.client.users.fetch(userId).catch(() => null);
                const redSebebi = interaction.fields.getTextInputValue('red_sebebi');
                
                const embed = interaction.message.embeds[0];
                const icIsimField = embed.fields.find(field => field.name.includes('İsim'));
                const icIsim = icIsimField ? icIsimField.value.replace(/```/g, '').replace(/`/g, '') : 'Bilinmeyen İsim';
                
                const sonucEmbed = new EmbedBuilder()
                    .setColor(0xAA00FF)
                    .setTitle('🔮 IC İsim Reddedildi!')
                    .addFields(
                        { name: '💎 Reddedilen İsim', value: `\`\`\`${icIsim}\`\`\``, inline: true },
                        { name: '📋 Red Sebebi', value: `**${redSebebi}**`, inline: false }
                    )
                    .setTimestamp();
                
                await interaction.message.edit({
                    embeds: [sonucEmbed],
                    components: []
                });
                
                await interaction.followUp({
                    content: `⚠️ **${icIsim}** ismi özel sebep ile reddedildi: **${redSebebi}**`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
        } catch (error) {
            console.error('IC isim onay interaction hatası:', error);
            
            if (!interaction.deferred && !interaction.replied) {
                await interaction.reply({
                    content: '❌ İşlem sırasında bir hata oluştu!',
                    flags: [MessageFlags.Ephemeral]
                });
            } else {
                await interaction.editReply({
                    content: '❌ İşlem sırasında bir hata oluştu!'
                });
            }
        }
    }
};