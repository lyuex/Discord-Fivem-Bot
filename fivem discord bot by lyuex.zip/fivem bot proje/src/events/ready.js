// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { ActivityType } = require("discord.js");
const lyuex = require(`../../lyuex.json`);
const fs = require(`fs`);
const path = require(`path`);

module.exports = {
    name: `clientReady`,
    once: true,
    async execute(client) {
        console.log('\x1b[36m%s\x1b[0m', '═══════════════════════════════════════════');
        console.log('\x1b[36m%s\x1b[0m', '  LYUEX DEVELOPMENT - Bot Aktif');
        console.log('\x1b[36m%s\x1b[0m', '═══════════════════════════════════════════');
        console.log(`[LYUEX] ✅ ${client.user.tag} olarak giriş yapıldı! | Powered by Lyuex Development`);
        
        // Twitch durumunu kontrol et ve uygula
        const twitchData = getTwitchData();
        
        if (twitchData.isStreaming) {
            // Eğer bot restart edildiğinde hala streaming durumundaysa devam et
            client.user.setPresence({
                activities: [{ 
                    name: twitchData.streamTitle || lyuex.botSettings.oynuyor, 
                    type: ActivityType.Streaming,
                    url: twitchData.twitchUrl || 'https://twitch.tv/lyuex'
                }],
                status: 'online'
            });
            console.log(`[TWITCH] Streaming durumu geri yüklendi: ${twitchData.streamTitle}`);
        } else {
            // Normal durum
            client.user.setPresence({
                activities: [{ 
                    name: lyuex.botSettings.oynuyor, 
                    type: ActivityType.Competing 
                }],
                status: lyuex.botSettings.durum
            });
            console.log(`[BOT DURUM] Normal durum ayarlandı: ${lyuex.botSettings.oynuyor}`);
        }
        
        // Kanal yedekleme işlemi
        try {
            const dataDir = path.join(__dirname, `../../data`);
            if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
            
            const backupPath = path.join(dataDir, `channelBackup.json`);
            if (!fs.existsSync(backupPath)) {
                fs.writeFileSync(backupPath, JSON.stringify({}, null, 2), `utf-8`);
            }
            
            const backup = JSON.parse(fs.readFileSync(backupPath, `utf-8`));
            
            for (const [guildId, guild] of client.guilds.cache) {
                backup[guildId] = backup[guildId] || {};
                
                for (const channel of guild.channels.cache.values()) {
                    if (!channel.guild) continue;
                    
                    backup[guildId][channel.id] = {
                        name: channel.name,
                        type: channel.type,
                        parent: channel.parentId || null,
                        permissions: channel.permissionOverwrites?.cache?.map(po => ({
                            id: po.id,
                            allow: po.allow.toArray(),
                            deny: po.deny.toArray()
                        })) || []
                    };
                }
            }
            
            fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2), `utf-8`);
            console.log(`[LYUEX] Başlangıç yedeği tamamlandı - Tüm mevcut kanallar yedeklendi.`);
            
        } catch (error) {
            console.error(`[HATA] Kanal yedekleme hatası:`, error);
        }
    }
};

// Twitch durumunu oku
function getTwitchData() {
    const dataPath = path.join(__dirname, '../../data/twitchStatus.json');
    try {
        if (fs.existsSync(dataPath)) {
            return JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
        }
    } catch (error) {
        console.error('[TWITCH] Durum okuma hatası:', error);
    }
    return { isStreaming: false };
}





