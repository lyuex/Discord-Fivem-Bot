// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = [
    // Kullanıcı sunucuya katıldı
    {
        name: Events.GuildMemberAdd,
        async execute(member) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.user_join) return;
            
            const logChannel = member.guild.channels.cache.get(lyuex.log.channels.user_logs);
            if (!logChannel) return;

            try {
                const accountAge = Math.floor((Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24));
                const memberCount = member.guild.memberCount;
                const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
                const humanCount = memberCount - botCount;
                
                const embed = new EmbedBuilder()
                    .setColor(accountAge < 7 ? '#FF6600' : '#00FF00')
                    .setTitle('👋 Kullanıcı Sunucuya Katıldı')
                    .setDescription(`**${member.user.tag}** sunucuya katıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı Bilgileri', value: `**İsim:** ${member.user.tag}\n**ID:** ${member.user.id}\n**Mention:** <@${member.user.id}>`, inline: true },
                        { name: '📅 Hesap Detayları', value: `**Oluşturulma:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:F>\n**Yaş:** ${accountAge} gün\n**Tip:** ${member.user.bot ? '🤖 Bot' : '👤 İnsan'}`, inline: true },
                        { name: '📊 Sunucu İstatistikleri', value: `**Toplam Üye:** ${memberCount}\n**İnsan:** ${humanCount}\n**Bot:** ${botCount}\n**Sıra:** #${memberCount}`, inline: true },
                        { name: '⏰ Zaman Bilgileri', value: `**Katılma:** <t:${Math.floor(Date.now() / 1000)}:F>\n**Hesap:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>\n**Yerel:** ${new Date().toLocaleString('tr-TR')}`, inline: true },
                        { name: '🔒 Güvenlik Durumu', value: accountAge < 1 ? '🔴 Çok Yeni Hesap' : accountAge < 7 ? '🟡 Yeni Hesap' : accountAge < 30 ? '🟢 Genç Hesap' : '✅ Güvenilir Hesap', inline: true },
                        { name: '🎭 Avatar Bilgisi', value: member.user.avatar ? '✅ Özel Avatar' : '❌ Varsayılan Avatar', inline: true },
                        { name: '🆔 Teknik Bilgiler', value: `**Kullanıcı ID:** \`${member.user.id}\`\n**Discriminator:** #${member.user.discriminator}\n**Created:** ${member.user.createdTimestamp}`, inline: false }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setImage(member.user.bannerURL({ dynamic: true, size: 1024 }))
                    .setFooter({ 
                        text: `Üye Yönetimi • LYUEX • Toplam Üye: ${memberCount} • ID: ${member.user.id}`,
                        iconURL: member.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                // Şüpheli hesap kontrolü ve ek uyarılar
                if (accountAge < 7) {
                    embed.addFields({ 
                        name: '⚠️ Güvenlik Uyarısı', 
                        value: `🔸 Bu hesap ${accountAge} gün önce oluşturulmuş\n🔸 Potansiyel alt hesap olabilir\n🔸 Moderatörler dikkat etmeli\n🔸 ${accountAge < 1 ? 'ÇOK YENİ HESAP!' : 'Yeni hesap takibi önerilir'}`, 
                        inline: false 
                    });
                }

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kullanıcı katılma log hatası:', error);
            }
        }
    },

    // Kullanıcı sunucudan ayrıldı
    {
        name: Events.GuildMemberRemove,
        async execute(member) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.user_leave) return;
            
            const logChannel = member.guild.channels.cache.get(lyuex.log.channels.user_logs);
            if (!logChannel) return;

            try {
                // Kick mi ban mı kontrol et
                const kickLogs = await member.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberKick,
                    limit: 5
                });
                
                const banLogs = await member.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanAdd,
                    limit: 5
                });

                const kickEntry = kickLogs.entries.find(entry => 
                    entry.target.id === member.user.id && (Date.now() - entry.createdTimestamp) < 10000
                );
                const banEntry = banLogs.entries.find(entry => 
                    entry.target.id === member.user.id && (Date.now() - entry.createdTimestamp) < 10000
                );
                
                let leaveType = '🚪 Ayrıldı';
                let leaveColor = '#FFA500';
                let executor = null;
                let reason = 'Sebep belirtilmemiş';
                
                if (banEntry) {
                    leaveType = '� Banlandı';
                    leaveColor = '#FF0000';
                    executor = banEntry.executor;
                    reason = banEntry.reason || 'Sebep belirtilmemiş';
                } else if (kickEntry) {
                    leaveType = '� Kicklendi';
                    leaveColor = '#FF6600';
                    executor = kickEntry.executor;
                    reason = kickEntry.reason || 'Sebep belirtilmemiş';
                }

                const serverTime = member.joinedTimestamp ? 
                    Math.floor((Date.now() - member.joinedTimestamp) / (1000 * 60 * 60 * 24)) : 0;
                const accountAge = Math.floor((Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24));
                const memberCount = member.guild.memberCount;
                const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
                const humanCount = memberCount - botCount;

                const userRoles = member.roles.cache
                    .filter(r => r.id !== member.guild.id)
                    .sort((a, b) => b.position - a.position)
                    .map(r => r.name);

                const embed = new EmbedBuilder()
                    .setColor(leaveColor)
                    .setTitle(leaveType)
                    .setDescription(`**${member.user.tag}** sunucudan ayrıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı Bilgileri', value: `**İsim:** ${member.user.tag}\n**ID:** ${member.user.id}\n**Mention:** <@${member.user.id}>`, inline: true },
                        { name: '� Sunucu İstatistikleri', value: `**Kalan Üye:** ${memberCount}\n**İnsan:** ${humanCount}\n**Bot:** ${botCount}`, inline: true },
                        { name: '⏱️ Süre Bilgileri', value: `**Sunucuda:** ${serverTime} gün\n**Hesap Yaşı:** ${accountAge} gün\n**Katılma:** ${member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Bilinmiyor'}`, inline: true },
                        { name: '🏷️ Sahip Olduğu Roller', value: userRoles.length > 0 ? userRoles.slice(0, 10).join(', ') + (userRoles.length > 10 ? `\n+${userRoles.length - 10} rol daha...` : '') : 'Rol yoktu', inline: false },
                        { name: '⏰ Ayrılma Detayları', value: `**Zaman:** <t:${Math.floor(Date.now() / 1000)}:F>\n**Tip:** ${leaveType}\n**Yerel:** ${new Date().toLocaleString('tr-TR')}`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setFooter({ 
                        text: `Üye Yönetimi • LYUEX • Kalan Üye: ${memberCount} • ID: ${member.user.id}`,
                        iconURL: member.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                if (executor) {
                    embed.addFields({ 
                        name: '👮 İşlemi Yapan', 
                        value: `**Yetkili:** ${executor.tag}\n**ID:** ${executor.id}\n**Mention:** <@${executor.id}>`, 
                        inline: true 
                    });
                    embed.addFields({ 
                        name: '📝 İşlem Sebebi', 
                        value: reason, 
                        inline: true 
                    });
                }

                // Kısa süre üyelik uyarısı
                if (serverTime < 1) {
                    embed.addFields({
                        name: '⚠️ Kısa Süre Uyarısı',
                        value: `🔸 Kullanıcı sunucuya ${serverTime < 1 ? 'bugün' : `${serverTime} gün önce`} katılmıştı\n🔸 Potansiyel troll/spam hesabı olabilir\n🔸 ${leaveType === '🚪 Ayrıldı' ? 'Hızlı ayrılma' : 'Moderasyon işlemi'}`,
                        inline: false
                    });
                }

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kullanıcı ayrılma log hatası:', error);
            }
        }
    },

    // Kullanıcı güncellendi (isim, avatar vb.)
    {
        name: Events.GuildMemberUpdate,
        async execute(oldMember, newMember) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.user_update) return;
            if (!lyuex.log?.settings?.include_bots && newMember.user.bot) return;
            
            const logChannel = newMember.guild.channels.cache.get(lyuex.log.channels.user_logs);
            if (!logChannel) return;

            try {
                const changes = [];
                
                // İsim değişikliği
                if (oldMember.nickname !== newMember.nickname) {
                    changes.push(`**İsim:** \`${oldMember.nickname || 'Yok'}\` → \`${newMember.nickname || 'Yok'}\``);
                }
                
                // Avatar değişikliği
                if (oldMember.user.avatar !== newMember.user.avatar) {
                    changes.push(`**Avatar:** Değiştirildi`);
                }

                // Timeout durumu
                if (oldMember.communicationDisabledUntil !== newMember.communicationDisabledUntil) {
                    if (newMember.communicationDisabledUntil) {
                        changes.push(`**Timeout:** <t:${Math.floor(newMember.communicationDisabledUntil.getTime() / 1000)}:F> tarihine kadar`);
                    } else {
                        changes.push(`**Timeout:** Kaldırıldı`);
                    }
                }

                if (changes.length === 0) return; // Rol değişiklikleri başka yerde işleniyor

                // Audit log'dan kim yaptığını bul
                const auditLogs = await newMember.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberUpdate,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;

                const embed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle('✏️ Kullanıcı Güncellendi')
                    .setDescription(`**${newMember.user.tag}** kullanıcısında değişiklik yapıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${newMember.user.tag} (${newMember.user.id})`, inline: true },
                        { name: '👮 Güncelleyen', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '⏰ Güncelleme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '📋 Yapılan Değişiklikler', value: changes.join('\n'), inline: false }
                    )
                    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Üye Yönetimi • LYUEX`,
                        iconURL: newMember.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kullanıcı güncelleme log hatası:', error);
            }
        }
    }
];




