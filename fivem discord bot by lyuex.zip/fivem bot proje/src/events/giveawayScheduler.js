// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const GiveawayManager = require('../utils/giveawayManager');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log('🎉 Çekiliş sistemi yükleniyor...');
    
    try {
      if (!global.DB_CONNECTED) {
        console.warn('⏭️ Veritabanı bağlantısı yok. Çekiliş kontrolü başlangıçta atlandı.');
      } else {
        // Bot açıldığında veritabanından süresi dolmuş çekilişleri kontrol et
        await GiveawayManager.checkEndedGiveaways(client);
      }
      
      // Periyodik olarak çekilişleri kontrol et (1 dakikada bir)
      setInterval(async () => {
        if (!global.DB_CONNECTED) return; // DB yoksa sessizce atla
        await GiveawayManager.checkEndedGiveaways(client);
      }, 60000); // 60 saniye
      
      console.log('✅ Çekiliş sistemi başarıyla yüklendi!');
    } catch (error) {
      console.error('❌ Çekiliş sistemi yükleme hatası:', error);
    }
  }
};




