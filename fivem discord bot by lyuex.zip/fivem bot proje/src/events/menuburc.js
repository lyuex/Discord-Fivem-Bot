// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, PermissionFlagsBits } = require('discord.js');

const ZODIAC_ROLES = new Map([
  ['koc', 'Koç'],
  ['boga', 'Boğa'],
  ['ikizler', 'İkizler'],
  ['yengec', 'Yengeç'],
  ['aslan', 'Aslan'],
  ['basak', 'Başak'],
  ['terazi', 'Terazi'],
  ['akrep', 'Akrep'],
  ['yay', 'Yay'],
  ['oglak', 'Oğlak'],
  ['kova', 'Kova'],
  ['balik', 'Balık'],
  ['yilanci', 'Yılancı']
]);

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (!interaction.isStringSelectMenu() || interaction.customId !== 'burcMenu') return;

    const selectedKey = interaction.values[0];
    const roleName = ZODIAC_ROLES.get(selectedKey);

    if (!roleName) {
      return interaction.reply({ content: '❌ Geçersiz seçim.', ephemeral: true });
    }

    const member = interaction.member;
    const guild = interaction.guild;

    // Bot'un rol yönetme yetkisi var mı?
    if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({
        content: '🚫 Rol eklemek/kaldırmak için yetkim yok.',
        ephemeral: true
      });
    }

    // Rol nesnesini bul
    const targetRole = guild.roles.cache.find(r => r.name === roleName);
    if (!targetRole) {
      return interaction.reply({ content: '⚠️ Bu rol sunucuda bulunamadı.', ephemeral: true });
    }

    try {
      // Diğer burç rollerini temizle
      const rolesToRemove = member.roles.cache.filter(r =>
        ZODIAC_ROLES.has(r.name.toLowerCase().replace('ç','c').replace('ğ','g')) &&
        r.id !== targetRole.id
      );
      if (rolesToRemove.size) {
        await member.roles.remove(rolesToRemove);
      }

      // Yeni seçilen rolü ekle (zaten varsa kaldırıp eklemeye gerek yok)
      if (!member.roles.cache.has(targetRole.id)) {
        await member.roles.add(targetRole);
      }

      return interaction.reply({
        content: `✅ **${roleName}** rolü başarıyla verildi.`,
        ephemeral: true
      });
    } catch (err) {
      console.error('❗ Rol değiştirme hatası:', err);
      if (!interaction.replied) {
        await interaction.reply({
          content: '❌ Rol verirken beklenmedik bir hata oluştu.',
          ephemeral: true
        });
      }
    }
  }
};





