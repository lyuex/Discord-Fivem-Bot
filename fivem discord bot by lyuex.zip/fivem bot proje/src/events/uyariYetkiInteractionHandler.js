// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Uyarı yetki veritabanı dosyası
const uyariYetkiDB = path.join(__dirname, '../../db/uyariYetkileri.json');

// Veritabanı okuma/yazma fonksiyonları
function getUyariYetkiData() {
    try {
        const data = fs.readFileSync(uyariYetkiDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveUyariYetkiData(data) {
    fs.writeFileSync(uyariYetkiDB, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'uyariYetkiInteractionHandler',
    async execute(interaction) {
        // Uyarı yetki select menu
        if (interaction.isRoleSelectMenu() && interaction.customId.startsWith('uyari_yetki_select_')) {
            await handleUyariYetkiSelect(interaction);
        }
    }
};

async function handleUyariYetkiSelect(interaction) {
    const guildId = interaction.guild.id;
    const selectedRoles = interaction.values;
    
    try {
        const uyariYetkiData = getUyariYetkiData();
        
        // Guild verisi yoksa oluştur
        if (!uyariYetkiData[guildId]) {
            uyariYetkiData[guildId] = {};
        }
        
        // Rolleri kaydet
        uyariYetkiData[guildId].roller = selectedRoles;
        uyariYetkiData[guildId].ayarlayan = interaction.user.id;
        uyariYetkiData[guildId].ayarlanmaTarihi = Date.now();
        
        saveUyariYetkiData(uyariYetkiData);
        
        // Rol bilgilerini topla
        const roleBilgileri = selectedRoles.map((roleId, index) => {
            const role = interaction.guild.roles.cache.get(roleId);
            return `${index + 1}. <@&${roleId}> (\`${role ? role.name : 'Silinmiş Rol'}\`)`;
        }).join('\n');
        
        const basariliEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Yetki Ayarları`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('✅ **YETKİLER BAŞARIYLA AYARLANDI**')
            .setDescription(`
╭─────────────────────────────────╮
│  🎯 **UYARI YETKİLERİ GÜNCELLEME** │
│  Yeni yetki yapılandırması       │
╰─────────────────────────────────╯

🎊 **Uyarı yetkili rolleri başarıyla ayarlandı!**`)
            .addFields(
                { 
                    name: '👥 **YENİ YETKİLİ ROLLER**', 
                    value: roleBilgileri, 
                    inline: false 
                },
                { 
                    name: '📊 **AYAR BİLGİLERİ**', 
                    value: `
**Toplam Rol:** ${selectedRoles.length}
**Ayarlayan:** ${interaction.user.tag}
**Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>
                    `, 
                    inline: true 
                },
                { 
                    name: 'ℹ️ **ÖNEMLİ HATIRLATMALAR**', 
                    value: `
🔸 Bu roller artık uyarı verebilir
🔸 Yöneticiler her zaman yetkili
🔸 Roller silinirse otomatik çıkar
                    `, 
                    inline: true 
                }
            )
            .setColor(0x4CAF50)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ 
                text: `Uyarı Sistemi • ${selectedRoles.length} rol ayarlandı`, 
                iconURL: interaction.user.displayAvatarURL() 
            })
            .setTimestamp();

        // Orijinal mesajı güncelle
        await interaction.update({
            embeds: [basariliEmbed],
            components: []
        });

        // Log kanalına bildirim gönder (varsa)
        try {
            const lyuex = require('../../lyuex.json');
            if (lyuex.log && lyuex.log.channel) {
                const logChannel = interaction.guild.channels.cache.get(lyuex.log.channel);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('⚙️ **UYARI YETKİ AYARLARI DEĞİŞTİRİLDİ**')
                        .setDescription(`
**Yetkili:** ${interaction.user.tag} (\`${interaction.user.id}\`)
**İşlem:** Uyarı yetkili rolleri güncellendi
**Yeni Rol Sayısı:** ${selectedRoles.length}
**Roller:**
${roleBilgileri}
                        `)
                        .setColor(0x2196F3)
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        } catch (logError) {
            console.error('Log gönderme hatası:', logError);
        }

    } catch (error) {
        console.error('Uyarı yetki ayarlama hatası:', error);
        
        const hataEmbed = new EmbedBuilder()
            .setTitle('❌ **HATA OLUŞTU**')
            .setDescription('Uyarı yetkileri ayarlanırken bir hata meydana geldi.')
            .addFields(
                { name: 'Hata', value: error.message, inline: false },
                { name: 'Çözüm', value: 'Lütfen tekrar deneyin veya yetkili ile iletişime geçin.', inline: false }
            )
            .setColor(0xF44336)
            .setTimestamp();

        await interaction.reply({
            embeds: [hataEmbed],
            ephemeral: true
        });
    }
}




