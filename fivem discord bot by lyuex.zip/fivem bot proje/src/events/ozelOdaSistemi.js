// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { Events, EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const config = require('../../lyuex.json');

// Aktif özel odaları takip etmek için
const activeRooms = new Map();

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        // Sistem kapalıysa çalışma
        if (!config.ozel_oda.enabled) return;

        const guild = newState.guild;
        const member = newState.member;

        try {
            // Kullanıcı ana kanala girdi mi?
            if (newState.channelId === config.ozel_oda.kanal_id && oldState.channelId !== config.ozel_oda.kanal_id) {
                await createPrivateRoom(guild, member);
            }

            // Kullanıcı özel odadan ayrıldı mı?
            if (oldState.channel && oldState.channel.parentId === config.ozel_oda.kategori_id && oldState.channelId !== config.ozel_oda.kanal_id) {
                await handleRoomLeave(oldState.channel, member);
            }

        } catch (error) {
            console.error('Özel oda sistemi hatası:', error);
        }
    }
};

async function createPrivateRoom(guild, member) {
    try {
        // Maksimum oda kontrolü
        const category = guild.channels.cache.get(config.ozel_oda.kategori_id);
        if (!category) return;

        const existingRooms = category.children.cache.filter(ch => 
            ch.type === ChannelType.GuildVoice && ch.id !== config.ozel_oda.kanal_id
        );

        if (existingRooms.size >= config.ozel_oda.max_oda_sayisi) {
            return;
        }

        // Kullanıcının zaten bir odası var mı kontrol et
        const userRoom = existingRooms.find(room => room.name.includes(member.displayName));
        if (userRoom) {
            await member.voice.setChannel(userRoom);
            return;
        }

        // Rastgele oda ismi seç
        const randomName = config.ozel_oda.oda_isimleri[Math.floor(Math.random() * config.ozel_oda.oda_isimleri.length)];
        
        // Yeni özel oda oluştur
        const privateRoom = await guild.channels.create({
            name: `👤 ${member.displayName}'s ${randomName}`,
            type: ChannelType.GuildVoice,
            parent: config.ozel_oda.kategori_id,
            userLimit: config.ozel_oda.varsayilan_limit,
            permissionOverwrites: [
                {
                    id: guild.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect]
                },
                {
                    id: member.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.Connect,
                        PermissionFlagsBits.Speak,
                        PermissionFlagsBits.MuteMembers,
                        PermissionFlagsBits.DeafenMembers,
                        PermissionFlagsBits.MoveMembers
                    ]
                }
            ]
        });

        // Kullanıcıyı yeni odaya taşı
        await member.voice.setChannel(privateRoom);

        // Oda bilgilerini kaydet
        activeRooms.set(privateRoom.id, {
            ownerId: member.id,
            createdAt: Date.now(),
            channelId: privateRoom.id
        });

        // Log gönder
        await sendLog(guild, 'Özel Oda Oluşturuldu', `
        **👤 Kullanıcı:** ${member}
        **🎵 Oda:** ${privateRoom}
        **📅 Oluşturma Zamanı:** <t:${Math.floor(Date.now() / 1000)}:F>
        `, 0x00ff00);

        // Kullanıcıya bilgi mesajı gönder (DM)
        try {
            const dmEmbed = new EmbedBuilder()
                .setTitle('🎵 Özel Odanız Oluşturuldu!')
                .setDescription(`
                **${privateRoom.name}** adlı özel odanız başarıyla oluşturuldu!
                
                **🔧 Yönetim Komutları:**
                • \`/oda-yonet isim\` - Oda ismini değiştir
                • \`/oda-yonet limit\` - Kullanıcı limitini ayarla
                • \`/oda-yonet kilitle\` - Odayı kilitle/aç
                • \`/oda-yonet gizle\` - Odayı gizle/görünür yap
                • \`/oda-yonet yetkiver\` - Kullanıcıya yetki ver
                • \`/oda-yonet at\` - Kullanıcıyı at
                • \`/oda-yonet engelle\` - Kullanıcıyı engelle
                
                **ℹ️ Bilgi:**
                • Odadan herkes ayrıldığında otomatik olarak silinecektir
                • ${config.ozel_oda.bos_kalma_suresi / 1000} saniye boş kaldığında silinir
                `)
                .setColor(0x0099ff)
                .setTimestamp()
                .setFooter({ text: 'LYUEX Özel Oda Sistemi' });

            await member.send({ embeds: [dmEmbed] });
        } catch (dmError) {
            console.log('DM gönderilemedi:', dmError.message);
        }

    } catch (error) {
        console.error('Özel oda oluşturma hatası:', error);
    }
}

async function handleRoomLeave(channel, member) {
    try {
        if (!activeRooms.has(channel.id)) return;

        // Odada kimse kaldı mı kontrol et
        if (channel.members.size === 0) {
            // Belirli bir süre bekle, sonra sil
            setTimeout(async () => {
                try {
                    // Tekrar kontrol et (birisi geri gelmiş olabilir)
                    const updatedChannel = channel.guild.channels.cache.get(channel.id);
                    if (updatedChannel && updatedChannel.members.size === 0) {
                        await deletePrivateRoom(updatedChannel);
                    }
                } catch (error) {
                    console.error('Gecikmeli silme hatası:', error);
                }
            }, config.ozel_oda.bos_kalma_suresi);
        }

    } catch (error) {
        console.error('Oda ayrılma işlemi hatası:', error);
    }
}

async function deletePrivateRoom(channel) {
    try {
        const roomData = activeRooms.get(channel.id);
        if (!roomData) return;

        // Log gönder
        await sendLog(channel.guild, 'Özel Oda Silindi', `
        **🎵 Oda:** ${channel.name}
        **📅 Silinme Zamanı:** <t:${Math.floor(Date.now() / 1000)}:F>
        **⏱️ Yaşam Süresi:** ${Math.floor((Date.now() - roomData.createdAt) / 1000)} saniye
        `, 0xff0000);

        // Oda verilerini temizle
        activeRooms.delete(channel.id);

        // Kanalı sil
        await channel.delete('Özel oda boş kaldığı için silindi');

    } catch (error) {
        console.error('Özel oda silme hatası:', error);
        // Hata durumunda da veriyi temizle
        activeRooms.delete(channel.id);
    }
}

async function sendLog(guild, title, description, color) {
    try {
        if (!config.ozel_oda.log_kanal) return;

        const logChannel = guild.channels.cache.get(config.ozel_oda.log_kanal);
        if (!logChannel) return;

        const embed = new EmbedBuilder()
            .setTitle(`📝 ${title}`)
            .setDescription(description)
            .setColor(color)
            .setTimestamp()
            .setFooter({ text: 'LYUEX Özel Oda Sistemi' });

        await logChannel.send({ embeds: [embed] });
    } catch (error) {
        console.error('Log gönderme hatası:', error);
    }
}