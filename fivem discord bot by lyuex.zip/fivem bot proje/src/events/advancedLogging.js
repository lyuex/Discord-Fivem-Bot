// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        if (!lyuex.log?.enabled) return;
        if (!lyuex.log?.events?.role_add && !lyuex.log?.events?.role_remove) return;
        if (!lyuex.log?.settings?.include_bots && newMember.user.bot) return;

        const logChannel = newMember.guild.channels.cache.get(lyuex.log.channels.role_logs);
        if (!logChannel) return;

        try {
            // Rol değişikliklerini kontrol et
            const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
            const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

            // Audit log'dan kim yaptığını bul
            const auditLogs = await newMember.guild.fetchAuditLogs({
                type: AuditLogEvent.MemberRoleUpdate,
                limit: 1
            });
            
            const auditEntry = auditLogs.entries.first();
            const executor = auditEntry ? auditEntry.executor : null;

            // Eklenen roller için log
            if (addedRoles.size > 0 && lyuex.log.events.role_add) {
                for (const role of addedRoles.values()) {
                    const embed = new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setTitle('🟢 Rol Eklendi')
                        .setDescription(`**${newMember.user.tag}** kullanıcısına **${role.name}** rolü eklendi`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${newMember.user.tag}\n<@${newMember.user.id}>`, inline: true },
                            { name: '🏷️ Eklenen Rol', value: `<@&${role.id}>\n**${role.name}** (${role.id})`, inline: true },
                            { name: '👮 İşlemi Yapan', value: executor ? `${executor.tag}\n<@${executor.id}>` : 'Bilinmiyor', inline: true },
                            { name: '🎨 Rol Rengi', value: `${role.hexColor || '#000000'}`, inline: true },
                            { name: '📊 Rol Pozisyonu', value: `${role.position}`, inline: true },
                            { name: '👥 Rol Üye Sayısı', value: `${role.members.size}`, inline: true },
                            { name: '🔒 Rol İzinleri', value: role.permissions.toArray().length > 0 ? `${role.permissions.toArray().slice(0, 3).join(', ')}${role.permissions.toArray().length > 3 ? '...' : ''}` : 'Özel izin yok', inline: true },
                            { name: '📊 Toplam Rol Sayısı', value: `${newMember.roles.cache.size - 1}`, inline: true },
                            { name: '⏰ İşlem Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                            { name: '🆔 Kullanıcı ID', value: `\`${newMember.user.id}\``, inline: false },
                            { name: '🏷️ Rol ID', value: `\`${role.id}\``, inline: false },
                            { name: '🔍 Ek Bilgiler', value: `• Rol Mentionlanabilir: ${role.mentionable ? '✅' : '❌'}\n• Rol Ayrı Gösterim: ${role.hoist ? '✅' : '❌'}\n• Bot Rolü: ${role.managed ? '✅' : '❌'}`, inline: false }
                        )
                        .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                        .setFooter({ 
                            text: `LYUEX Gelişmiş Log Sistemi • Rol Yönetimi`,
                            iconURL: newMember.guild.iconURL({ dynamic: true })
                        })
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] });
                }
            }

            // Silinen roller için log
            if (removedRoles.size > 0 && lyuex.log.events.role_remove) {
                for (const role of removedRoles.values()) {
                    const embed = new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('🔴 Rol Silindi')
                        .setDescription(`**${newMember.user.tag}** kullanıcısından **${role.name}** rolü silindi`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${newMember.user.tag}\n<@${newMember.user.id}>`, inline: true },
                            { name: '🏷️ Silinen Rol', value: `<@&${role.id}>\n**${role.name}** (${role.id})`, inline: true },
                            { name: '👮 İşlemi Yapan', value: executor ? `${executor.tag}\n<@${executor.id}>` : 'Bilinmiyor', inline: true },
                            { name: '🎨 Rol Rengi', value: `${role.hexColor || '#000000'}`, inline: true },
                            { name: '📊 Rol Pozisyonu', value: `${role.position}`, inline: true },
                            { name: '👥 Rol Üye Sayısı', value: `${role.members.size}`, inline: true },
                            { name: '🔒 Rol İzinleri', value: role.permissions.toArray().length > 0 ? `${role.permissions.toArray().slice(0, 3).join(', ')}${role.permissions.toArray().length > 3 ? '...' : ''}` : 'Özel izin yok', inline: true },
                            { name: '📊 Kalan Rol Sayısı', value: `${newMember.roles.cache.size - 1}`, inline: true },
                            { name: '⏰ İşlem Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                            { name: '🆔 Kullanıcı ID', value: `\`${newMember.user.id}\``, inline: false },
                            { name: '🏷️ Rol ID', value: `\`${role.id}\``, inline: false },
                            { name: '📜 Rol Geçmişi', value: `• Rol sahiplik süresi tahmini: Bilinmiyor\n• Rol mentionlanabilir: ${role.mentionable ? '✅' : '❌'}\n• Rol ayrı gösterim: ${role.hoist ? '✅' : '❌'}`, inline: false }
                        )
                        .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
                        .setFooter({ 
                            text: `LYUEX Gelişmiş Log Sistemi • Rol Yönetimi`,
                            iconURL: newMember.guild.iconURL({ dynamic: true })
                        })
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] });
                }
            }

        } catch (error) {
            console.error('Gelişmiş log sistemi hatası (role update):', error);
        }
    }
};




