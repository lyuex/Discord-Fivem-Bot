// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { Events, ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, SelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const ticketUtil = require('../utils/ticketUtil');
const steamHexManager = require('../utils/steamHexManager');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // DEBUG: Log ALL interactions
        console.log(`[TicketHandler] Interaction received - Type: ${interaction.type}, CustomId: ${interaction.customId || 'N/A'}`);
        
        // Modal submit
        if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith('ticket_create_modal_')) {
                const categoryId = interaction.customId.replace('ticket_create_modal_', '');
                await handleTicketCreation(interaction, categoryId);
            }
            return;
        }
        
        // Select menu
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'priority_select') {
                await handlePrioritySelection(interaction);
            } else if (interaction.customId === 'tag_select') {
                await handleTagSelection(interaction);
            } else if (interaction.customId === 'ticket_category_select') {
                try {
                    const categoryId = interaction.values[0];
                    console.log(`[Ticket Select] ===== SELECT MENU STARTED =====`);
                    console.log(`[Ticket Select] Category ID from menu: ${categoryId}`);
                    console.log(`[Ticket Select] User: ${interaction.user.tag} (${interaction.user.id})`);
                    
                    const cfg = ticketUtil.getConfig();
                    console.log(`[Ticket Select] Config loaded:`, cfg ? `YES - requireDetailsModal: ${cfg.requireDetailsModal}` : 'NO - NULL');
                    
                    if (!cfg) {
                        console.warn(`[Ticket Select] Config is null, creating defaults...`);
                    }
                    
                    // E�er detay modali zorunlu de�ilse, do�rudan ticket olu�tur
                    if (cfg?.requireDetailsModal) {
                        console.log(`[Ticket Select] Modal required � Opening modal`);
                        await handleTicketCreateModal(interaction, categoryId);
                    } else {
                        console.log(`[Ticket Select] Direct creation enabled � Creating ticket directly`);
                        await handleTicketCreateDirect(interaction, categoryId);
                    }
                    console.log(`[Ticket Select] ===== SELECT MENU COMPLETED =====`);
                } catch (err) {
                    console.error(`[Ticket Select] ? CRITICAL ERROR IN SELECT HANDLER:`, err.message);
                    console.error(`[Ticket Select] Stack:`, err.stack);
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: `? Hata: ${err.message}`, ephemeral: true }).catch(e => console.error(`[Ticket Select] Reply error:`, e.message));
                    } else if (interaction.deferred) {
                        await interaction.editReply({ content: `? Hata: ${err.message}` }).catch(e => console.error(`[Ticket Select] EditReply error:`, e.message));
                    }
                }
            }
            return;
        }
        
        // Butonlar
        if (!interaction.isButton()) return;
        
        // Ticket olu�turma
        if (interaction.customId.startsWith('ticket_create_') || 
            ['oyun_ici_destek', 'oyun_disi_destek', 'hata_raporla', 'ekip_acma', 'hesap_destek'].includes(interaction.customId)) {
            let categoryId = interaction.customId.replace('ticket_create_', '');
            
            // Yeni custom panel butonlar� i�in category mapping
            switch (interaction.customId) {
                case 'ticket_create_oyun_ici':
                    categoryId = 'oyun_ici_destek';
                    break;
                case 'ticket_create_oyun_disi':
                    categoryId = 'oyun_disi_destek';
                    break;
                case 'ticket_create_hata_raporlama':
                    categoryId = 'hata_raporla';
                    break;
            }
            
            await handleTicketCreateModal(interaction, categoryId);
            return;
        }
        
        // Di�er ticket i�lemleri
        switch (interaction.customId) {
            case 'ticket_kapat':
                await handleTicketClose(interaction);
                break;
            case 'ticket_confirm_close':
                await handleTicketConfirmClose(interaction);
                break;
            case 'ticket_cancel_close':
                await handleTicketCancelClose(interaction);
                break;
            case 'ticket_delete':
                await handleTicketDelete(interaction);
                break;
            case 'ticket_transcript':
                await handleTicketTranscript(interaction);
                break;
            case 'ticket_claim':
                await handleTicketClaim(interaction);
                break;
            case 'ticket_set_priority':
                await handleTicketPriorityMenu(interaction);
                break;
            case 'ticket_set_tag':
                await handleTicketTagMenu(interaction);
                break;
        }
        
        // Derecelendirme
        if (interaction.customId.startsWith('ticket_rate_')) {
            const rating = parseInt(interaction.customId.replace('ticket_rate_', ''));
            await handleTicketRating(interaction, rating);
        }
    }
};

// Modal g�ster
async function handleTicketCreateModal(interaction, categoryId) {
    try {
        const config = ticketUtil.getConfig();
        if (!config) {
            return await interaction.reply({
                content: 'Ticket sistemi ayarlar� bulunamad�!',
                ephemeral: true
            });
        }
        
        const category = ticketUtil.getCategoryById(categoryId) || { id: categoryId, name: 'Destek', emoji: '??' };
        
        const canCreate = await ticketUtil.canCreateTicket(interaction.guild, interaction.user.id);
        if (!canCreate) {
            return await interaction.reply({
                content: `Maksimum aktif ticket say�s�na ula�t�n�z! (${config.maxActiveTickets || 3})`,
                ephemeral: true
            });
        }
        
        const cooldownCheck = ticketUtil.checkCooldown(interaction.user.id);
        if (cooldownCheck.onCooldown) {
            const minutes = Math.ceil(cooldownCheck.timeLeft / (1000 * 60));
            return await interaction.reply({
                content: `�ok h�zl� ticket a��yorsunuz! ${minutes} dakika bekleyin.`,
                ephemeral: true
            });
        }
        
        const modal = new ModalBuilder()
            .setCustomId(`ticket_create_modal_${categoryId}`)
            .setTitle(`${category.emoji} ${category.name} Destek Talebi`);
            
        const subjectInput = new TextInputBuilder()
            .setCustomId('ticket_subject')
            .setLabel('Konu')
            .setPlaceholder('Talebinizin konusunu k�saca belirtin')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(100);
            
        const detailInput = new TextInputBuilder()
            .setCustomId('ticket_detail')
            .setLabel('Detaylar')
            .setPlaceholder('Sorununuzu detayl� a��klay�n')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);
            
        modal.addComponents(
            new ActionRowBuilder().addComponents(subjectInput),
            new ActionRowBuilder().addComponents(detailInput)
        );
        
        await interaction.showModal(modal);
        
    } catch (error) {
        console.error('Modal hatas�:', error);
        await interaction.reply({
            content: 'Bir hata olu�tu!',
            ephemeral: true
        }).catch(() => {});
    }
}

// Ticket olu�tur
async function handleTicketCreation(interaction, categoryId) {
    try {
        await interaction.deferReply({ ephemeral: true });
        
        const config = ticketUtil.getConfig();
        const category = ticketUtil.getCategoryById(categoryId) || { 
            id: categoryId, 
            name: 'Destek', 
            emoji: '??',
            color: '#3498db'
        };
        
        const subject = interaction.fields.getTextInputValue('ticket_subject');
        const detail = interaction.fields.getTextInputValue('ticket_detail');
        const ticketNumber = ticketUtil.getNextTicketNumber();
        
        const supportRole = interaction.guild.roles.cache.get(config.supportRoleId);
        if (!supportRole) {
            console.error(`Destek rol� bulunamad�: ${config.supportRoleId}`);
            return await interaction.editReply({
                content: '? Destek ekibi rol� bulunamad�! L�tfen `/ticket-yonetim ayarlar` komutu ile sistemi yeniden kurun.',
                ephemeral: true
            });
        }
        
        // Kategori kanal�
        let categoryChannel = null;
        if (config.categoryId) {
            try {
                categoryChannel = await interaction.guild.channels.fetch(config.categoryId).catch(() => null);
            } catch (error) {
                console.error(`Kategori kanal� fetch hatas�: ${error.message}`);
            }
        }
        
        if (!categoryChannel) {
            console.log('Kategori kanal� bulunamad�, yeni kategori olu�turuluyor...');
            try {
                categoryChannel = await interaction.guild.channels.create({
                    name: '?? DESTEK TALEPLER�',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: supportRole.id, allow: [PermissionFlagsBits.ViewChannel] }
                    ]
                });
                
                // Config'i g�ncelle
                config.categoryId = categoryChannel.id;
                ticketUtil.updateConfig(config);
                console.log(`Yeni kategori olu�turuldu: ${categoryChannel.name} (${categoryChannel.id})`);
            } catch (error) {
                console.error('Kategori olu�turma hatas�:', error);
                return await interaction.editReply({
                    content: '? Ticket kategorisi olu�turulamad�! Botun yeterli yetkiye sahip oldu�undan emin olun.',
                    ephemeral: true
                });
            }
        }
        
        // Ticket kanal� olu�tur
        let ticketChannel;
        try {
            ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${ticketNumber}`,
                type: ChannelType.GuildText,
                topic: `${category.emoji} ${category.name} | Talep Eden: ${interaction.user.id} | Ticket #${ticketNumber}`,
                parent: categoryChannel.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { 
                        id: interaction.user.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles
                        ] 
                    },
                    { 
                        id: supportRole.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.ManageMessages
                        ] 
                    }
                ]
            });
            
            console.log(`Ticket kanal� olu�turuldu: ${ticketChannel.name} (${ticketChannel.id})`);
        } catch (error) {
            console.error('Ticket kanal� olu�turma hatas�:', error);
            return await interaction.editReply({
                content: '? Ticket kanal� olu�turulamad�! Botun kanallar olu�turma yetkisine sahip oldu�undan emin olun.',
                ephemeral: true
            });
        }
        
        // Steam hex bilgisini steamHexManager'dan al
        let userSteamHex = null;
        let userSteamLink = null;
        
        try {
            const userHexData = steamHexManager.getUserSteamHex(interaction.user.id);
            if (userHexData) {
                userSteamHex = userHexData.steamHex;
                userSteamLink = userHexData.steamLink;
            }
        } catch (error) {
            console.error('Steam hex veri okuma hatas�:', error);
        }

        // Ticket verisi kaydet
        const ticketData = {
            id: `ticket-${ticketNumber}`,
            ticketNumber: ticketNumber,
            channelId: ticketChannel.id,
            userId: interaction.user.id,
            userTag: interaction.user.tag,
            guildId: interaction.guild.id,
            categoryId: categoryId,
            subject: subject,
            detail: detail,
            status: 'open',
            priority: 'normal',
            steamHex: userSteamHex,
            steamLink: userSteamLink
        };
        
        ticketUtil.saveTicket(ticketData);
        
        // Steam hex bilgilerini haz�rla
        let steamHexField = '';
        if (userSteamHex) {
            steamHexField = `?? **Steam Hex:** \`${userSteamHex}\`\n`;
            if (userSteamLink) {
                steamHexField += `?? **Steam Profil:** [Profili G�r�nt�le](${userSteamLink})\n`;
            }
        } else {
            steamHexField = `?? **Steam Hex:** Kay�tl� de�il\n`;
        }

        // Geli�mi� Ticket embed
        const ticketEmbed = new EmbedBuilder()
            .setColor(category.color || '#3498db')
            .setAuthor({ 
                name: `${interaction.guild.name} - Destek Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle(`${category.emoji} Ticket #${ticketNumber} - ${subject}`)
            .setDescription(`
?? Ho� geldiniz! Destek talebiniz olu�turuldu. A�a��da detaylar yer al�yor.

?? **Talep A��klamas�:**
\`\`\`
${detail}
\`\`\`

?? **Ticket Bilgileri:**
� **Kategori:** ${category.emoji} ${category.name}
� **Durum:** ?? A��k
� **�ncelik:** ? Normal
� **Olu�turulma:** <t:${Math.floor(Date.now() / 1000)}:R>

${steamHexField}?? **Yard�m �pu�lar�:**
� L�tfen sorununuzu detayl� a��klay�n
� Ekran g�r�nt�s� payla�abilirsiniz
� Sab�rl� olun, en k�sa s�rede yan�tlanacak
            `)
            .addFields(
                { 
                    name: '?? Talep Eden', 
                    value: `${interaction.user}\n\`${interaction.user.tag}\`\nID: \`${interaction.user.id}\``, 
                    inline: true 
                },
                { 
                    name: '?? �statistikler', 
                    value: `Ticket ID: \`#${ticketNumber}\`\nKanal: ${ticketChannel}\nSaat: <t:${Math.floor(Date.now() / 1000)}:t>`, 
                    inline: true 
                },
                { 
                    name: '?? Ticket Y�netimi', 
                    value: `?? Kapatmak i�in \`Kapat\` butonuna bas�n\n?? �stlenmek i�in \`�stlen\` butonuna bas�n\n?? Kay�t almak i�in \`Kay�t\` butonuna bas�n`, 
                    inline: false 
                }
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ 
                text: `${interaction.guild.name} Destek Ekibi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();
        
        // Butonlar
        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_kapat')
                    .setLabel('Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('??'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('�stlen')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('??'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Kay�t')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('??')
            );
            
        const buttons2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_set_priority')
                    .setLabel('�ncelik')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('??'),
                new ButtonBuilder()
                    .setCustomId('ticket_set_tag')
                    .setLabel('Etiket')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('???')
            );
        
        const ticketMessage = await ticketChannel.send({
            content: `${interaction.user} | ${supportRole}`,
            embeds: [ticketEmbed],
            components: [buttons, buttons2]
        });
        
        await ticketMessage.pin();
        
        // Log
        if (config.logChannelId) {
            try {
                const logChannel = await interaction.guild.channels.fetch(config.logChannelId).catch(() => null);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(category.color || '#3498db')
                        .setTitle('?? Yeni Ticket')
                        .setDescription(`${category.emoji} **${subject}** konulu ticket a��ld�`)
                        .addFields(
                            { name: 'Talep Eden', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Ticket ID', value: `#${ticketNumber}`, inline: true },
                            { name: 'Kanal', value: `${ticketChannel}`, inline: true }
                        )
                        .setTimestamp();

                    // Steam hex bilgisi varsa ekle
                    if (userSteamHex) {
                        logEmbed.addFields(
                            { name: 'Steam Hex', value: `\`${userSteamHex}\``, inline: true }
                        );
                    }
                        
                    await logChannel.send({ embeds: [logEmbed] });
                } else {
                    console.warn(`Log kanal� bulunamad�: ${config.logChannelId}`);
                }
            } catch (error) {
                console.error('Log g�nderme hatas�:', error);
            }
        }
        
        await interaction.editReply({
            content: `? Ticket olu�turuldu: ${ticketChannel}`,
            ephemeral: true
        });
        
    } catch (error) {
        console.error('Ticket olu�turma hatas�:', error);
        await interaction.editReply({
            content: 'Bir hata olu�tu!',
            ephemeral: true
        }).catch(() => {});
    }
}

// Ticket kapat onay
async function handleTicketClose(interaction) {
    const channel = interaction.channel;
    
    if (!channel.name.startsWith('ticket-')) {
        return await interaction.reply({
            content: 'Bu komut sadece ticket kanallar�nda kullan�labilir!',
            ephemeral: true
        });
    }
    
    const confirmEmbed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setTitle('?? Talep Kapat�lacak')
        .setDescription('Bu destek talebini kapatmak istedi�inize emin misiniz?')
        .setTimestamp();
        
    const confirmButtons = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_confirm_close')
                .setLabel('Kapat')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('?'),
            new ButtonBuilder()
                .setCustomId('ticket_cancel_close')
                .setLabel('�ptal')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('?')
        );
        
    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons]
    });
}

// Ticket kapatma onayla
async function handleTicketConfirmClose(interaction) {
    const channel = interaction.channel;
    
    await interaction.reply({ content: '?? Ticket kapat�l�yor...' });
    
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    const config = ticketUtil.getConfig();
    const ticketCreatorId = ticketData?.userId || ticketUtil.getTicketOwner(channel) || 'Bilinmiyor';
    
    setTimeout(async () => {
        // Transcript olu�tur
        if (config?.autoTranscript) {
            try {
                const transcriptFiles = await ticketUtil.createHtmlTranscript(channel, ticketData);
                if (transcriptFiles && config.logChannelId) {
                    const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
                    if (logChannel) {
                        await logChannel.send({
                            content: `?? Ticket #${ticketData?.ticketNumber || 'Bilinmiyor'} kayd�`,
                            files: [{
                                attachment: transcriptFiles.html.path,
                                name: `ticket-${ticketData?.ticketNumber || 'bilinmiyor'}.html`
                            }]
                        });
                    }
                }
            } catch (error) {
                console.error('Transcript hatas�:', error);
            }
        }
        
        await channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('?? Ticket Kapat�ld�')
                    .setDescription(`Bu ticket ${interaction.user} taraf�ndan kapat�ld�.`)
                    .addFields(
                        { name: 'Talep Eden', value: `<@${ticketCreatorId}>`, inline: true },
                        { name: 'Kapatan', value: `${interaction.user}`, inline: true }
                    )
                    .setTimestamp()
            ]
        });
        
        // Eri�im kald�r
        await channel.permissionOverwrites.edit(ticketCreatorId, {
            ViewChannel: false,
            SendMessages: false
        }).catch(console.error);
        
        await channel.setName(`kapal�-${channel.name.split('ticket-')[1]}`);
        
        // Veri g�ncelle
        if (ticketData) {
            ticketUtil.updateTicket(ticketData.id, {
                status: 'closed',
                closedAt: Date.now(),
                closedBy: interaction.user.id
            });
        }
        
        // Silme butonu
        const deleteButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_delete')
                    .setLabel('Sil')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('???')
            );
            
        await channel.send({
            content: 'Ticket kanal�n� silmek i�in:',
            components: [deleteButton]
        });
        
    }, 1000);
}

// Kapatma iptal
async function handleTicketCancelClose(interaction) {
    await interaction.update({
        content: '? Ticket kapatma iptal edildi.',
        embeds: [],
        components: []
    });
}

// Ticket sil
async function handleTicketDelete(interaction) {
    const channel = interaction.channel;
    
    if (!channel.name.startsWith('kapal�-')) {
        return await interaction.reply({
            content: 'Bu komut sadece kapal� ticketlarda kullan�labilir!',
            ephemeral: true
        });
    }
    
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Ticket silme yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    await interaction.reply({ content: '??? Kanal 5 saniye i�inde silinecek...' });
    
    // Ticket verilerini sil �ncesi al
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    const ticketConfig = ticketUtil.getConfig();
    
    // DM bildirimi g�nder (kanal silinmeden �nce)
    if (ticketData?.userId && ticketConfig?.allowRating) {
        try {
            const user = await interaction.client.users.fetch(ticketData.userId).catch(() => null);
            if (user) {
                const ratingEmbed = new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('??? Destek Talebiniz Silindi')
                    .setDescription(`**${interaction.guild.name}** sunucusundaki destek talebiniz silindi.\n\n**Ticket #${ticketData.ticketNumber}**\n**Konu:** ${ticketData.subject || 'Belirtilmemi�'}\n\nE�er tekrar yard�ma ihtiyac�n�z olursa yeni bir ticket a�abilirsiniz.`)
                    .addFields(
                        { name: '?? Ticket Bilgileri', value: `ID: #${ticketData.ticketNumber}\nSilme Zaman�: <t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '?? Yeni Ticket', value: `Yeni bir destek talebi a�mak i�in sunucuya geri d�n�n ve ticket panelini kullan�n.`, inline: true }
                    )
                    .setFooter({ 
                        text: `${interaction.guild.name} Destek Ekibi`, 
                        iconURL: interaction.guild.iconURL({ dynamic: true }) 
                    })
                    .setTimestamp();
                    
                await user.send({ embeds: [ratingEmbed] }).catch(() => {
                    console.log(`DM g�nderilemedi: ${user.tag}`);
                });
            }
        } catch (error) {
            console.error('Silme bildirimi DM hatas�:', error);
        }
    }
    
    setTimeout(async () => {
        try {
            // Kanal�n hala var olup olmad���n� kontrol et
            const channelExists = interaction.guild.channels.cache.has(channel.id);
            if (!channelExists) {
                console.log(`Kanal ${channel.id} zaten silinmi�.`);
                return;
            }
            
            // Kanal� yeniden al (cache g�ncellemesi i�in)
            const currentChannel = await interaction.guild.channels.fetch(channel.id).catch(() => null);
            if (!currentChannel) {
                console.log(`Kanal ${channel.id} bulunamad�, zaten silinmi� olabilir.`);
                return;
            }
            
            await currentChannel.delete('Ticket silme');
            console.log(`Ticket kanal� ba�ar�yla silindi: ${channel.name}`);
        } catch (error) {
            if (error.code === 10003) {
                console.log(`Kanal ${channel.id} zaten silinmi� (Unknown Channel).`);
            } else if (error.code === 50013) {
                console.error(`Kanal silme izni yok: ${channel.name}`);
            } else {
                console.error('Kanal silme hatas�:', {
                    channelId: channel.id,
                    channelName: channel.name,
                    error: error.message,
                    code: error.code
                });
            }
        }
    }, 5000);
}

// Transcript
async function handleTicketTranscript(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
        const channel = interaction.channel;
        const ticketData = ticketUtil.getTicketByChannelId(channel.id);
        
        const transcriptFiles = await ticketUtil.createHtmlTranscript(channel, ticketData);
        if (!transcriptFiles) {
            throw new Error('Transcript olu�turulamad�');
        }
        
        await interaction.editReply({
            content: '? Transcript haz�rland�!',
            files: [{
                attachment: transcriptFiles.html.path,
                name: `${channel.name}-transcript.html`
            }]
        });
        
        // Dosyalar� g�venli temizle
        ticketUtil.cleanupTranscriptFiles(transcriptFiles);
        
    } catch (error) {
        console.error('Transcript hatas�:', error);
        await interaction.editReply({
            content: 'Transcript olu�turulurken hata olu�tu!',
            ephemeral: true
        });
    }
}

// Ticket �stlen
async function handleTicketClaim(interaction) {
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Ticket �stlenme yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    if (ticketData && ticketData.claimedBy) {
        return await interaction.reply({
            content: `Bu ticket zaten <@${ticketData.claimedBy}> taraf�ndan �stlenilmi�!`,
            ephemeral: true
        });
    }
    
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, {
            claimedBy: interaction.user.id,
            status: 'claimed'
        });
    }
    
    const claimEmbed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('?? Ticket �stlenildi')
        .setDescription(`Bu ticket ${interaction.user} taraf�ndan �stlenildi.`)
        .setTimestamp();
        
    await interaction.reply({ embeds: [claimEmbed] });
}

// �ncelik men�
async function handleTicketPriorityMenu(interaction) {
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: '�ncelik ayarlama yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const priorityMenu = ticketUtil.createPrioritySelectMenu();
    
    await interaction.reply({
        content: '?? �ncelik seviyesi se�in:',
        components: [priorityMenu],
        ephemeral: true
    });
}

// �ncelik se�
async function handlePrioritySelection(interaction) {
    const priorityId = interaction.values[0];
    const priority = ticketUtil.getPriorityById(priorityId);
    
    if (!priority) {
        return await interaction.update({
            content: 'Ge�ersiz �ncelik!',
            components: []
        });
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(interaction.channel.id);
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, { priorityId: priorityId });
    }
    
    const priorityEmbed = new EmbedBuilder()
        .setColor(priority.color)
        .setTitle('?? �ncelik G�ncellendi')
        .setDescription(`�ncelik **${priority.emoji} ${priority.name}** olarak ayarland�.`)
        .setTimestamp();
        
    await interaction.update({
        content: `? �ncelik g�ncellendi!`,
        components: []
    });
    
    await interaction.channel.send({ embeds: [priorityEmbed] });
    
    // Pinned message'� g�ncelle
    try {
        const pinnedMessages = await interaction.channel.messages.fetchPins();
        const messagesArray = Array.from(pinnedMessages.values ? pinnedMessages.values() : pinnedMessages);
        const ticketMessage = messagesArray.find(msg => msg.embeds.length > 0 && msg.embeds[0].title?.includes('Ticket #'));
        
        if (ticketMessage && ticketMessage.embeds.length > 0) {
            const oldEmbed = ticketMessage.embeds[0];
            const newEmbed = EmbedBuilder.from(oldEmbed);
            
            // Description'� g�ncelle - �ncelik bilgisini de�i�tir
            let description = oldEmbed.description || '';
            
            // �ncelik sat�r�n� bul ve g�ncelle
            if (description.includes('� **�ncelik:**')) {
                // Eski �ncelik sat�r�n� yeni �ncelikle de�i�tir
                description = description.replace(
                    /� \*\*�ncelik:\*\* .*?\n/,
                    `� **�ncelik:** ${priority.emoji} ${priority.name}\n`
                );
            } else {
                // �ncelik sat�r� yoksa durum sat�r�ndan sonra ekle
                description = description.replace(
                    /(� \*\*Durum:\*\* .*?\n)/,
                    `$1� **�ncelik:** ${priority.emoji} ${priority.name}\n`
                );
            }
            
            newEmbed.setDescription(description);
            newEmbed.setColor(priority.color);
            
            await ticketMessage.edit({ embeds: [newEmbed] });
            console.log(`[Priority Update] Pinned embed updated with priority: ${priority.name}`);
        }
    } catch (error) {
        console.error(`[Priority Update] Embed g�ncelleme hatas�:`, error.message);
    }
}

// Etiket men�
async function handleTicketTagMenu(interaction) {
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Etiket ayarlama yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const tagMenu = ticketUtil.createTagSelectMenu();
    
    await interaction.reply({
        content: '??? Etiket se�in:',
        components: [tagMenu],
        ephemeral: true
    });
}

// Etiket se�
async function handleTagSelection(interaction) {
    const tagId = interaction.values[0];
    const tag = ticketUtil.getTagById(tagId);
    
    if (!tag) {
        return await interaction.update({
            content: 'Ge�ersiz etiket!',
            components: []
        });
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(interaction.channel.id);
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, { tagId: tagId });
    }
    
    const tagEmbed = new EmbedBuilder()
        .setColor(tag.color)
        .setTitle(`${tag.emoji} ${tag.name}`)
        .setDescription(`Etiket **${tag.emoji} ${tag.name}** olarak g�ncellendi.`)
        .setTimestamp();
        
    await interaction.update({
        content: `? Etiket g�ncellendi!`,
        components: []
    });
    
    await interaction.channel.send({ embeds: [tagEmbed] });
}

// Derecelendirme
async function handleTicketRating(interaction, rating) {
    if (!interaction.guild) {
        const tickets = ticketUtil.getTicketsDb();
        const userTickets = tickets.filter(t => t.userId === interaction.user.id && t.status === 'closed');
        
        if (userTickets.length === 0) {
            return await interaction.reply({
                content: 'Derecelendirebilece�iniz ticket yok!',
                ephemeral: true
            });
        }
        
        const lastTicket = userTickets.sort((a, b) => b.closedAt - a.closedAt)[0];
        
        ticketUtil.updateTicket(lastTicket.id, { rating: rating });
        
        await interaction.update({
            content: `? Te�ekk�rler! **${rating}/5** puan verdiniz.`,
            embeds: [],
            components: []
        });
        
        // Log
        try {
            const config = ticketUtil.getConfig();
            const guild = interaction.client.guilds.cache.get(lastTicket.guildId);
            
            if (guild && config?.logChannelId) {
                const logChannel = guild.channels.cache.get(config.logChannelId);
                
                if (logChannel) {
                    const stars = '?'.repeat(rating);
                    
                    const ratingEmbed = new EmbedBuilder()
                        .setColor(0xF1C40F)
                        .setTitle('? Ticket Derecelendirildi')
                        .setDescription(`Ticket #${lastTicket.ticketNumber} i�in de�erlendirme!`)
                        .addFields(
                            { name: 'De�erlendiren', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Puan', value: `${stars} (${rating}/5)`, inline: true }
                        )
                        .setTimestamp();
                        
                    await logChannel.send({ embeds: [ratingEmbed] });
                }
            }
        } catch (error) {
            console.error('Rating log hatas�:', error);
        }
    }
}

// Modal olmadan do�rudan ticket olu�tur (select men�den)
async function handleTicketCreateDirect(interaction, categoryId) {
    console.log(`[Direct] START - CategoryId: ${categoryId}, User: ${interaction.user.id}`);
    try {
        // FIRST: Defer immediately
        if (!interaction.deferred && !interaction.replied) {
            console.log(`[Direct] Deferring...`);
            await interaction.deferReply({ ephemeral: true });
        }
        console.log(`[Direct] Deferred OK, now processing...`);

        const config = ticketUtil.getConfig();
        console.log(`[Direct] Config: ${config ? 'loaded' : 'null'}`);
        console.log(`[Direct] Support role ID: ${config?.supportRoleId}`);
        console.log(`[Direct] Category ID: ${config?.categoryId}`);
        
        await interaction.editReply({
            content: `? TEST OK - Ticket a��lacak: ${categoryId}`
        });
        console.log(`[Direct] Test mesaj g�nderildi`);
        return;

    } catch (error) {
        console.error(`[Direct] ? ERROR:`, error.message);
        console.error(`[Direct] Stack:`, error.stack);
        
        try {
            if (!interaction.deferred) {
                await interaction.deferReply({ ephemeral: true });
            }
            await interaction.editReply({ content: `? Hata: ${error.message}` });
        } catch (err) {
            console.error(`[Direct] Reply failed:`, err.message);
        }
    }
}




