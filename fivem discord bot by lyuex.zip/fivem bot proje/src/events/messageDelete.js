// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const { catchError } = require('../functions/hatamesajì');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.MessageDelete,
    async execute(message, client) {
        try {
            if (message.author?.bot) return;
            if (!message.content && !message.attachments.size) return;

            const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
            if (!logChannelId) return;
            
            const logChannel = client.channels.cache.get(logChannelId);
            if (!logChannel) return;

            // Audit log'dan kim sildiğini öğren
            let deletedBy = message.author;
            try {
                const auditLogs = await message.guild.fetchAuditLogs({
                    type: AuditLogEvent.MessageDelete,
                    limit: 1
                });
                const deleteLog = auditLogs.entries.first();
                if (deleteLog && deleteLog.createdTimestamp > Date.now() - 5000) {
                    deletedBy = deleteLog.executor;
                }
            } catch (error) {
                // Audit log erişimi yoksa varsayılan olarak mesaj sahibi
            }

            const messageEmbed = new EmbedBuilder()
                .setColor(0xFF4444)
                .setTitle('🗑️ Mesaj Silindi')
                .setDescription(`Bir mesaj silindi!`)
                .addFields(
                    { 
                        name: '📝 Mesaj İçeriği', 
                        value: message.content ? `\`\`\`${message.content.length > 1000 ? message.content.substring(0, 1000) + '...' : message.content}\`\`\`` : '*Mesaj içeriği yok*', 
                        inline: false 
                    },
                    { 
                        name: '👤 Mesaj Sahibi', 
                        value: `${message.author?.tag || 'Bilinmiyor'}\n<@${message.author?.id || 'Bilinmiyor'}>`, 
                        inline: true 
                    },
                    { 
                        name: '🗑️ Silen Kişi', 
                        value: `${deletedBy.tag}\n<@${deletedBy.id}>`, 
                        inline: true 
                    },
                    { 
                        name: '📍 Kanal', 
                        value: `${message.channel.name}\n<#${message.channel.id}>`, 
                        inline: true 
                    },
                    { 
                        name: '🆔 Mesaj ID', 
                        value: message.id, 
                        inline: true 
                    },
                    { 
                        name: '⏰ Silinme Zamanı', 
                        value: `<t:${Math.floor(Date.now() / 1000)}:F>`, 
                        inline: true 
                    }
                );

            if (message.attachments.size > 0) {
                const attachmentList = message.attachments.map(att => `[${att.name}](${att.url})`).join('\n');
                messageEmbed.addFields({
                    name: '📎 Ekler',
                    value: attachmentList,
                    inline: false
                });
            }

            messageEmbed
                .setThumbnail(message.author?.displayAvatarURL({ dynamic: true }) || null)
                .setFooter({ 
                    text: `Mesaj Sistemi • ${message.guild.name}`, 
                    iconURL: message.guild.iconURL({ dynamic: true }) 
                })
                .setTimestamp();

            await logChannel.send({ embeds: [messageEmbed] }).catch(console.error);

        } catch (error) {
            catchError(client, 'messageDelete.js', error.message);
        }
    },
};





