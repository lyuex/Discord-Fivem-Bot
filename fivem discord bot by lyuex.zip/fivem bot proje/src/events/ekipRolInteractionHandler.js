// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
module.exports = {
    async execute(interaction) {
        try {
            console.log(`[EkipRolInteractionHandler] Processing: ${interaction.customId}`);
            
            // Ekip rol işlemlerini buraya ekleyin
            await interaction.reply({
                content: '🎭 Ekip rol işlemi tamamlandı!',
                ephemeral: true
            });

        } catch (error) {
            console.error('Ekip rol interaction handler hatası:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Bir hata oluştu!',
                    ephemeral: true
                }).catch(() => {});
            }
        }
    }
};