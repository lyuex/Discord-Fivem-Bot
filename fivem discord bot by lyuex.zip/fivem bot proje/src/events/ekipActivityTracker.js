// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { Events } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        try {
            if (!interaction.customId || !interaction.customId.startsWith('ekip_')) {
                return;
            }

            console.log(`[EkipActivityTracker] Processing: ${interaction.customId}`);
            
            // Ekip aktivite takip işlemlerini buraya ekleyin
            console.log('Ekip aktivitesi kaydedildi:', {
                user: interaction.user.id,
                action: interaction.customId,
                timestamp: Date.now()
            });

        } catch (error) {
            console.error('Ekip aktivite tracker hatası:', error);
        }
    }
};