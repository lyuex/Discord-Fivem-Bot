// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { Ekip, EkipUyari, EkipYedek } = require('../Schemas/EkipSchema');

module.exports = {
    async execute(interaction, client) {
        if (!interaction.isModalSubmit()) return;

        try {
            // Eski modal
            if (interaction.customId === 'myModal') {
                const name = interaction.fields.getTextInputValue('nameInput');
                const description = interaction.fields.getTextInputValue('descriptionInput');
                const lyuexinodasi = interaction.guild.channels.cache.find(channel => channel.name === 'test');
                const lyuexinembedi = new EmbedBuilder()
                .setColor(0x000000)
                .setTitle(`${name}`)
                .setDescription(`${description}`)
                .setTimestamp(new Date())
                await lyuexinodasi.send( { content: `Yetkili Başvurusu geldi! ${lyuex.yetkili.kurucu}`, embeds: [lyuexinembedi]} );
                await interaction.reply({ content: `${name}\n${description}`, ephemeral: true });
            }
            // Ekip kurma modal'ı
            else if (interaction.customId === 'ekip_kur_modal') {
                await handleEkipKurModal(interaction);
            }
            // Ekip bilgi modal'ı
            else if (interaction.customId === 'ekip_bilgi_modal') {
                await handleEkipBilgiModalSubmit(interaction);
            }
            // Ekip profil modal'ı
            else if (interaction.customId === 'ekip_profil_modal') {
                await handleEkipProfilModalSubmit(interaction);
            }
            // Üye ekleme modal'ı
            else if (interaction.customId === 'uye_ekle_modal') {
                await handleUyeEkleModalSubmit(interaction);
            }
            // Üye çıkarma modal'ı
            else if (interaction.customId === 'uye_cikar_modal') {
                await handleUyeCikarModalSubmit(interaction);
            }
            // Ekip uyarı verme modal'ı
            else if (interaction.customId === 'ekip_uyari_ver_modal') {
                await handleEkipUyariVerModalSubmit(interaction);
            }
            // Uyarı listesi modal'ı
            else if (interaction.customId === 'uyari_liste_modal') {
                await handleUyariListeModalSubmit(interaction);
            }
            // Ekip rol modal'ı
            else if (interaction.customId === 'ekip_rol_modal') {
                await handleEkipRolModalSubmit(interaction);
            }
            // Ekip yedek alma modal'ı
            else if (interaction.customId === 'ekip_yedek_al_modal') {
                await handleEkipYedekAlModalSubmit(interaction);
            }
            // Yedek yükleme modal'ı
            else if (interaction.customId === 'yedek_yukle_modal') {
                await handleYedekYukleModalSubmit(interaction);
            }
            // Ekip silme modal'ı
            else if (interaction.customId === 'ekip_sil_modal') {
                await handleEkipSilModalSubmit(interaction);
            }
            // Ekip panel - Üye ekleme submit
            else if (interaction.customId.startsWith('ekip_panel_uye_ekle_submit_')) {
                await handleEkipPanelUyeEkleSubmit(interaction);
            }
            // Ekip panel - Üye çıkarma submit
            else if (interaction.customId.startsWith('ekip_panel_uye_cikar_submit_')) {
                await handleEkipPanelUyeCikarSubmit(interaction);
            }

        } catch (error) {
            console.error('Modal submit hatası:', error);
            
            // Interaction zaten kullanılmış olabilir, kontrol et
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Modal işlenirken bir hata oluştu!',
                    ephemeral: true
                }).catch(err => {
                    console.error('Reply gönderilemedi:', err.message);
                });
            } else if (interaction.deferred) {
                await interaction.editReply({
                    content: '❌ Modal işlenirken bir hata oluştu!'
                }).catch(err => {
                    console.error('EditReply gönderilemedi:', err.message);
                });
            }
        }
    },
};

// Ekip kurma modal submit
async function handleEkipKurModal(interaction) {
    try {
        // IMMEDIATELY defer to prevent timeout
        await interaction.deferReply({ ephemeral: true });

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
        const ekipAciklama = interaction.fields.getTextInputValue('ekip_aciklama') || 'Açıklama eklenmedi';
        const ekipLiderInput = interaction.fields.getTextInputValue('ekip_lider') || null;
        const ekipRenk = interaction.fields.getTextInputValue('ekip_renk') || '5865F2';

        // Aynı isimde ekip var mı kontrol et
        const mevcutEkip = await Ekip.findOne({ 
            guildId: interaction.guild.id, 
            ekipIsim: ekipIsim,
            aktif: true 
        });

        if (mevcutEkip) {
            return await interaction.editReply({
                content: `❌ **${ekipIsim}** isimli bir ekip zaten mevcut! Lütfen farklı bir isim seçin.`,
            });
        }

        // Renk formatını düzelt
        const renkHex = ekipRenk.replace('#', '');
        const renkInt = parseInt(renkHex, 16) || 0x5865F2;

        // Lider belirle
        let lider = interaction.user;
        if (ekipLiderInput) {
            try {
                const member = await interaction.guild.members.fetch(ekipLiderInput.trim());
                lider = member.user;
            } catch (error) {
                console.log('Lider bulunamadı, varsayılan kullanıcı seçildi');
            }
        }

        // Veritabanına kaydet
        const yeniEkip = new Ekip({
            guildId: interaction.guild.id,
            ekipIsim: ekipIsim,
            ekipAciklama: ekipAciklama,
            liderId: lider.id,
            liderTag: lider.tag,
            uyeler: [{
                userId: lider.id,
                userTag: lider.tag,
                eklenmetarihi: new Date(),
                ekleyenId: interaction.user.id,
                not: 'Ekip lideri'
            }],
            renk: renkHex,
            olusturulmaTarihi: new Date(),
            seviye: 1,
            puan: 0,
            durum: 'Aktif',
            aktif: true
        });

        await yeniEkip.save();

        // Ekip rolü oluştur
        let ekipRol = null;
        try {
            ekipRol = await interaction.guild.roles.create({
                name: `${ekipIsim}`,
                color: renkInt,
                reason: `${ekipIsim} ekibi için otomatik rol oluşturuldu`,
                mentionable: true,
                hoist: false
            });

            // Ekip liderine rolü ver
            const liderMember = await interaction.guild.members.fetch(lider.id);
            await liderMember.roles.add(ekipRol);

            // Rol ID'sini veritabanına kaydet
            yeniEkip.rolId = ekipRol.id;
            await yeniEkip.save();

            console.log(`[EKİP ROL] ${ekipIsim} ekibi için rol oluşturuldu: ${ekipRol.id}`);
        } catch (roleError) {
            console.error('Ekip rolü oluşturma hatası:', roleError);
        }

        // Ticket kanalı oluştur
        let ticketKanal = null;
        try {
            // Kanal ismini düzenle (özel karakterleri temizle)
            const kanalIsim = `${ekipIsim.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-')}`;
            
            // Permission overwrites dizisi
            const permissions = [
                {
                    id: interaction.guild.id,
                    deny: ['ViewChannel']
                },
                {
                    id: lider.id,
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'AttachFiles', 'EmbedLinks']
                }
            ];

            // Eğer rol oluşturulmuşsa rolü de ekle
            if (ekipRol) {
                permissions.push({
                    id: ekipRol.id,
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'AttachFiles', 'EmbedLinks']
                });
            }
            
            ticketKanal = await interaction.guild.channels.create({
                name: kanalIsim,
                type: 0, // Text channel
                parent: '1418690618636636293', // Kategori ID
                topic: `${ekipIsim} ekibi ticket kanalı - Destek talepleriniz için bu kanalı kullanın`,
                permissionOverwrites: permissions
            });

            // Ticket kanalına hoş geldin mesajı gönder
            const { ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
            
            const ticketEmbed = new EmbedBuilder()
                .setColor(renkInt)
                .setAuthor({ name: `${ekipIsim.toUpperCase()} - EKİP YÖNETİM PANELİ`, iconURL: interaction.guild.iconURL() })
                .setDescription(
                    '```ansi\n' +
                    '\u001b[2;36m╔════════════════════════════════════════╗\n' +
                    '\u001b[2;36m║      FiveM Ekip Kontrol Merkezi       ║\n' +
                    '\u001b[2;36m╚════════════════════════════════════════╝\n' +
                    '```\n' +
                    `> **${ekipIsim}** ekibine hoş geldiniz! 🎮\n` +
                    `> Bu kanal ekibinizin özel yönetim merkezidir.\n` +
                    `> Aşağıdaki butonları kullanarak ekibinizi yönetin.\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `### 📋 EKİP BİLGİLERİ\n` +
                    '```yaml\n' +
                    `Ekip Adı    : ${ekipIsim}\n` +
                    `Lider       : ${lider.tag}\n` +
                    `Üye Sayısı  : ${yeniEkip.uyeler.length}\n` +
                    `Seviye      : 1 (Yeni Kurulan)\n` +
                    `Durum       : ✅ Aktif\n` +
                    '```\n\n' +
                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `### 🎯 YÖNETİM İŞLEMLERİ\n\n` +
                    `**� Üye Yönetimi**\n` +
                    `• Ekibe yeni üye ekleyin\n` +
                    `• Üye çıkarın veya uyarı verin\n` +
                    `• Üye listesini görüntüleyin\n\n` +
                    `**⚙️ Ekip Ayarları**\n` +
                    `• Ekip bilgilerini düzenleyin\n` +
                    `• Rol atama ve yönetimi\n` +
                    `• Ekip istatistiklerini görün\n\n` +
                    `**🎫 Destek Sistemi**\n` +
                    `• Vatandaşlar ticket açabilir\n` +
                    `• Şikayet ve başvurular\n` +
                    `• Otomatik log kayıtları\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`
                )
                .addFields(
                    { name: '👑 Ekip Lideri', value: `${lider}\n\`${lider.id}\``, inline: true },
                    { name: '🎨 Ekip Rengi', value: `\`#${renkHex.toUpperCase()}\``, inline: true },
                    { name: '📅 Kuruluş Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🆔 Ekip ID', value: `\`\`\`${yeniEkip._id}\`\`\``, inline: false },
                    { name: '📌 Açıklama', value: `> ${ekipAciklama}`, inline: false }
                )
                .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 256 }))
                .setImage('https://cdn.discordapp.com/attachments/1432827105514885192/1433028128812433458/lyuexdev_banner.jpg?ex=690332f2&is=6901e172&hm=0463e24693b117708889e11e8e844cb186c720b341a6b9b55f41b1cc85c4f1b1&')
                .setFooter({ text: `${ekipIsim} • FiveM Ekip Sistemi`, iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            // Ekip yönetim butonları
            const uyeEkleButton = new ButtonBuilder()
                .setCustomId(`ekip_panel_uye_ekle_${yeniEkip._id}`)
                .setLabel('Üye Ekle')
                .setStyle(ButtonStyle.Success)
                .setEmoji('👤');

            const uyeCikarButton = new ButtonBuilder()
                .setCustomId(`ekip_panel_uye_cikar_${yeniEkip._id}`)
                .setLabel('Üye Çıkar')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🚫');

            const uyeListeButton = new ButtonBuilder()
                .setCustomId(`ekip_panel_uye_liste_${yeniEkip._id}`)
                .setLabel('Üye Listesi')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('📋');

            const ekipAyarButton = new ButtonBuilder()
                .setCustomId(`ekip_panel_ayarlar_${yeniEkip._id}`)
                .setLabel('Ayarlar')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('⚙');

            const ekipIstatistikButton = new ButtonBuilder()
                .setCustomId(`ekip_panel_istatistik_${yeniEkip._id}`)
                .setLabel('İstatistikler')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('📊');

            const row1 = new ActionRowBuilder().addComponents(uyeEkleButton, uyeCikarButton, uyeListeButton);
            const row2 = new ActionRowBuilder().addComponents(ekipAyarButton, ekipIstatistikButton);

            await ticketKanal.send({ 
                content: `${lider}\n**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**\n🎮 **${ekipIsim}** ekip yönetim paneli aktif!\n**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**`,
                embeds: [ticketEmbed], 
                components: [row1, row2] 
            });

            // Ekip veritabanına kanal ID'sini kaydet
            yeniEkip.ticketKanalId = ticketKanal.id;
            await yeniEkip.save();

        } catch (channelError) {
            console.error('Ticket kanalı oluşturma hatası:', channelError);
        }

        const embed = new EmbedBuilder()
            .setColor(renkInt)
            .setTitle('✅ Ekip Başarıyla Oluşturuldu!')
            .setDescription(`**${ekipIsim}** ekibi sisteme kaydedildi.\n\n${ekipAciklama}`)
            .addFields(
                { name: '👑 Ekip Lideri', value: `${lider.tag} (${lider.id})`, inline: true },
                { name: '📅 Oluşturulma Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '👥 Başlangıç Üye Sayısı', value: '1', inline: true },
                { name: '🎨 Ekip Rengi', value: `#${renkHex.toUpperCase()}`, inline: true },
                { name: '🎯 Durum', value: '✅ Aktif', inline: true },
                { name: '⭐ Seviye', value: '🌱 Yeni Kurulan (Lvl 1)', inline: true },
                { name: '�️ Ekip Rolü', value: ekipRol ? `${ekipRol}` : '❌ Oluşturulamadı', inline: true },
                { name: '�🎫 Ticket Kanalı', value: ticketKanal ? `${ticketKanal}` : '❌ Oluşturulamadı', inline: true },
                { name: '🆔 Ekip ID', value: `\`${yeniEkip._id}\``, inline: false }
            )
            .setFooter({ text: `Kayıt Tarihi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kanalına bildirim
        console.log(`[EKİP] ${ekipIsim} ekibi ${interaction.user.tag} tarafından oluşturuldu. (ID: ${yeniEkip._id}, Kanal: ${ticketKanal?.id})`);
    } catch (error) {
        console.error('Ekip kurma modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Ekip oluşturulurken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip bilgi modal submit
async function handleEkipBilgiModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');

        // Veritabanından ekip bilgisini çek
        const ekip = await Ekip.findOne({ 
            guildId: interaction.guild.id,
            ekipIsim: ekipIsim,
            aktif: true
        });

        if (!ekip) {
            return await interaction.editReply({
                content: `❌ **${ekipIsim}** isimli bir ekip bulunamadı!`,
            });
        }

        const renkInt = parseInt(ekip.renk, 16) || 0xF39C12;
        const kurulusTarihi = Math.floor(ekip.olusturulmaTarihi.getTime() / 1000);
        
        // Üye listesi oluştur
        let uyeListesi = ekip.uyeler.slice(0, 10).map((uye, index) => 
            `${index + 1}. ${uye.userTag}`
        ).join('\n');
        
        if (ekip.uyeler.length > 10) {
            uyeListesi += `\n... ve ${ekip.uyeler.length - 10} üye daha`;
        }

        const embed = new EmbedBuilder()
            .setColor(renkInt)
            .setTitle(`ℹ️ ${ekip.ekipIsim} - Ekip Detayları`)
            .setDescription(`**${ekip.ekipAciklama}**\n\n` +
                '> Bu ekip hakkında detaylı bilgiler aşağıda listelenmiştir.\n' +
                '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            .addFields(
                { name: '👑 Ekip Lideri', value: `\`\`\`\n${ekip.liderTag}\n\`\`\``, inline: true },
                { name: '👥 Toplam Üye', value: `\`\`\`\n${ekip.uyeler.length} üye\n\`\`\``, inline: true },
                { name: '📅 Kuruluş Tarihi', value: `<t:${kurulusTarihi}:F>`, inline: true },
                { name: '🏆 Ekip Seviyesi', value: `\`\`\`\n⭐ Level ${ekip.seviye}\n\`\`\``, inline: true },
                { name: '⭐ Toplam Puan', value: `\`\`\`\n${ekip.puan} puan\n\`\`\``, inline: true },
                { name: '🎯 Durum', value: `\`\`\`\n${ekip.durum}\n\`\`\``, inline: true },
                { name: '🎨 Ekip Rengi', value: `\`\`\`\n#${ekip.renk.toUpperCase()}\n\`\`\``, inline: true },
                { name: '🆔 Ekip ID', value: `\`\`\`\n${ekip._id}\n\`\`\``, inline: true },
                { name: '📊 Yaş', value: `\`\`\`\n${Math.floor((Date.now() - ekip.olusturulmaTarihi.getTime()) / (1000 * 60 * 60 * 24))} gün\n\`\`\``, inline: true },
                { name: '📋 Üye Listesi', value: uyeListesi || 'Üye yok', inline: false }
            )
            .setFooter({ text: `Sorgu yapan: ${interaction.user.tag}` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    } catch (error) {
        console.error('Ekip bilgi modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Bilgi alınırken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Üye ekleme modal submit
async function handleUyeEkleModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
        const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
        const eklemeNotu = interaction.fields.getTextInputValue('ekleme_notu') || 'Not belirtilmedi';

        // Ekibi bul
        const ekip = await Ekip.findOne({
            guildId: interaction.guild.id,
            ekipIsim: ekipIsim,
            aktif: true
        });

        if (!ekip) {
            return await interaction.editReply({
                content: `❌ **${ekipIsim}** isimli bir ekip bulunamadı!`,
            });
        }

        let kullanici;
        try {
            kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
        } catch (error) {
            return await interaction.editReply({
                content: '❌ Kullanıcı bulunamadı! Lütfen geçerli bir kullanıcı ID\'si girin.',
            });
        }

        // Kullanıcı zaten ekipte mi kontrol et
        const mevcutMu = ekip.uyeler.some(u => u.userId === kullanici.id);
        if (mevcutMu) {
            return await interaction.editReply({
                content: `❌ **${kullanici.user.tag}** zaten **${ekipIsim}** ekibinde!`,
            });
        }

        // Üyeyi ekle
        ekip.uyeler.push({
            userId: kullanici.id,
            userTag: kullanici.user.tag,
            eklenmetarihi: new Date(),
            ekleyenId: interaction.user.id,
            not: eklemeNotu
        });

        await ekip.save();

        const renkInt = parseInt(ekip.renk, 16) || 0x00FF00;

        const embed = new EmbedBuilder()
            .setColor(renkInt)
            .setTitle('✅ Üye Başarıyla Eklendi!')
            .setDescription(`**${kullanici.user.tag}** kullanıcısı **${ekipIsim}** ekibine eklendi.`)
            .addFields(
                { name: '👤 Eklenen Üye', value: `${kullanici.user.tag}\n\`${kullanici.id}\``, inline: true },
                { name: '🏷️ Ekip', value: ekipIsim, inline: true },
                { name: '👮 Ekleyen Yetkili', value: interaction.user.tag, inline: true },
                { name: '📅 Eklenme Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '👥 Güncel Üye Sayısı', value: `${ekip.uyeler.length} üye`, inline: true },
                { name: '📝 Not', value: eklemeNotu, inline: false }
            )
            .setThumbnail(kullanici.user.displayAvatarURL())
            .setFooter({ text: 'Ekip üyelik sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        console.log(`[EKİP] ${kullanici.user.tag} ${ekipIsim} ekibine ${interaction.user.tag} tarafından eklendi.`);
    } catch (error) {
        console.error('Üye ekleme hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Üye eklenirken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Üye çıkarma modal submit
async function handleUyeCikarModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
        const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
        const cikarmaSebebi = interaction.fields.getTextInputValue('cikarma_sebebi');

        let kullanici;
        try {
            kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
        } catch (error) {
            return await interaction.editReply({
                content: '❌ Kullanıcı bulunamadı! Lütfen geçerli bir kullanıcı ID\'si girin.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('🚫 Üye Ekipten Çıkarıldı')
            .setDescription(`**${kullanici.user.tag}** kullanıcısı **${ekipIsim}** ekibinden çıkarıldı.`)
            .addFields(
                { name: '👤 Çıkarılan Üye', value: `${kullanici.user.tag}\n\`${kullanici.id}\``, inline: true },
                { name: '🏷️ Ekip', value: ekipIsim, inline: true },
                { name: '👮 Çıkaran Yetkili', value: interaction.user.tag, inline: true },
                { name: '📅 Çıkarılma Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '📝 Çıkarılma Sebebi', value: cikarmaSebebi, inline: false }
            )
            .setThumbnail(kullanici.user.displayAvatarURL())
            .setFooter({ text: 'Ekip üyelik sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        console.log(`[EKİP] ${kullanici.user.tag} ${ekipIsim} ekibinden ${interaction.user.tag} tarafından çıkarıldı. Sebep: ${cikarmaSebebi}`);
    } catch (error) {
        console.error('Üye çıkarma modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Üye çıkarılırken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip silme modal submit
async function handleEkipSilModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
        const onay = interaction.fields.getTextInputValue('onay');
        const silmeSebebi = interaction.fields.getTextInputValue('silme_sebebi');

        if (onay.toUpperCase() !== 'EVET') {
            const embed = new EmbedBuilder()
                .setColor(0xF39C12)
                .setTitle('⚠️ İşlem İptal Edildi')
                .setDescription('Silme işlemi onaylanmadı. İşlem iptal edildi.')
                .addFields(
                    { name: '🏷️ Ekip', value: ekipIsim, inline: true },
                    { name: '❌ Onay', value: 'Onaylanmadı', inline: true }
                )
                .setTimestamp();

            return await interaction.editReply({ embeds: [embed] });
        }

        // Ekibi bul
        const ekip = await Ekip.findOne({ 
            guildId: interaction.guild.id, 
            ekipIsim: ekipIsim,
            aktif: true 
        });

        if (!ekip) {
            return await interaction.editReply({ content: `❌ **${ekipIsim}** isimli aktif bir ekip bulunamadı!` });
        }

        // Ticket kanalını sil
        if (ekip.ticketKanalId) {
            try {
                const channel = await interaction.guild.channels.fetch(ekip.ticketKanalId);
                if (channel) {
                    await channel.delete();
                    console.log(`[EKİP SİL] Kanal silindi: ${ekip.ticketKanalId}`);
                }
            } catch (error) {
                console.log(`Kanal silinemedi: ${ekip.ticketKanalId}`, error.message);
            }
        }

        // Ekip rolünü sil
        if (ekip.rolId) {
            try {
                const role = await interaction.guild.roles.fetch(ekip.rolId);
                if (role) {
                    await role.delete();
                    console.log(`[EKİP SİL] Rol silindi: ${ekip.rolId}`);
                }
            } catch (error) {
                console.log(`Rol silinemedi: ${ekip.rolId}`, error.message);
            }
        }

        // Ekibi veritabanından sil
        await Ekip.deleteOne({ _id: ekip._id });

        const embed = new EmbedBuilder()
            .setColor(0x000000)
            .setTitle('🗑️ Ekip Tamamen Silindi')
            .setDescription(`**${ekipIsim}** ekibi sistemden kalıcı olarak kaldırıldı.`)
            .addFields(
                { name: '🏷️ Silinen Ekip', value: ekipIsim, inline: true },
                { name: '👮 Silen Yetkili', value: `${interaction.user.tag}`, inline: true },
                { name: '📅 Silme Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '📝 Silme Sebebi', value: silmeSebebi, inline: false },
                { name: '⚠️ Uyarı', value: 'Bu işlem geri alınamaz. Tüm ekip verileri, kanal ve rol silinmiştir.', inline: false }
            )
            .setFooter({ text: 'Ekip yönetim sistemi' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        console.log(`[EKİP] ${ekipIsim} ekibi ${interaction.user.tag} tarafından silindi. Sebep: ${silmeSebebi}`);
    } catch (error) {
        console.error('Ekip silme modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Ekip silinirken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip profil modal submit
async function handleEkipProfilModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

        const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');

        const embed = new EmbedBuilder()
            .setColor(0x2ECC71)
            .setTitle(`👥 ${ekipIsim} - Ekip Profili`)
            .setDescription('**Detaylı Ekip Profil Bilgileri**')
            .addFields(
                { name: '👑 Ekip Lideri', value: '```\nExampleLeader#1234\nID: 123456789\n```', inline: true },
                { name: '🎯 Durum', value: '```\n✅ Aktif\n```', inline: true },
                { name: '📅 Kuruluş Tarihi', value: '```\n15.10.2024\n```', inline: true },
                { name: '🏆 Ekip Seviyesi', value: '```\nLevel 8\n```', inline: true },
                { name: '⭐ Toplam Puan', value: '```\n850 puan\n```', inline: true },
                { name: '👥 Üye Sayısı', value: '```\n5 üye\n```', inline: true },
                { name: '📋 Üye Listesi', value: '• User1#0001\n• User2#0002\n• User3#0003\n• User4#0004\n• User5#0005', inline: false },
                { name: '🏆 Başarılar', value: '🎖️ İlk Ay Ödülü\n🏅 5 Üye Hedefi\n⭐ Aktif Ekip', inline: false },
                { name: '📝 Ekip Açıklaması', value: 'Bu örnek bir ekip profilidir. Gerçek veritabanı bağlandığında burada ekip açıklaması görünecektir.', inline: false }
            )
            .setFooter({ text: `Sorgu: ${interaction.user.tag}` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    } catch (error) {
        console.error('Ekip profil modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Profil bilgisi alınırken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip uyarı verme modal submit
async function handleEkipUyariVerModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

    const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
    const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
    const uyariSebebi = interaction.fields.getTextInputValue('uyari_sebebi');

    let kullanici;
    try {
        kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
    } catch (error) {
        return await interaction.editReply({
            content: '❌ Kullanıcı bulunamadı! Lütfen geçerli bir kullanıcı ID\'si girin.',
            ephemeral: true
        });
    }

    const embed = new EmbedBuilder()
        .setColor(0xFF9900)
        .setTitle('⚠️ Ekip Uyarısı Verildi')
        .setDescription(`**${kullanici.user.tag}** kullanıcısına ekip uyarısı verildi!`)
        .addFields(
            { name: '👤 Uyarılan Üye', value: `${kullanici.user.tag}\n\`${kullanici.id}\``, inline: true },
            { name: '🏷️ Ekip', value: ekipIsim, inline: true },
            { name: '👨‍💼 Uyarı Veren', value: interaction.user.tag, inline: true },
            { name: '📅 Uyarı Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '🔢 Uyarı Numarası', value: `#${Math.floor(Math.random() * 1000)}`, inline: true },
            { name: '⚡ Uyarı Seviyesi', value: '🟡 Orta', inline: true },
            { name: '📝 Uyarı Sebebi', value: uyariSebebi, inline: false },
            { name: '⚠️ Not', value: 'Bu uyarı ekip kayıtlarına işlenmiştir.', inline: false }
        )
        .setThumbnail(kullanici.user.displayAvatarURL())
        .setFooter({ text: 'Ekip uyarı sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    console.log(`[EKİP UYARI] ${kullanici.user.tag} ${ekipIsim} ekibinde ${interaction.user.tag} tarafından uyarıldı. Sebep: ${uyariSebebi}`);
    } catch (error) {
        console.error('Ekip uyarı verme modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Uyarı verilirken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Uyarı listesi modal submit
async function handleUyariListeModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

    const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');

    let kullanici;
    try {
        kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
    } catch (error) {
        return await interaction.editReply({
            content: '❌ Kullanıcı bulunamadı! Lütfen geçerli bir kullanıcı ID\'si girin.',
            ephemeral: true
        });
    }

    const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle(`📋 ${kullanici.user.tag} - Uyarı Geçmişi`)
        .setDescription('**Ekip Uyarı Kayıtları**\n\n' +
            '> Bu kullanıcının tüm ekip uyarıları aşağıda listelenmiştir.')
        .addFields(
            { 
                name: '⚠️ Uyarı #1', 
                value: '```\n📝 Sebep: Toplantıya geç katılma\n📅 Tarih: 20.10.2024\n🏷️ Ekip: Phoenix Takımı\n👮 Veren: Moderator#1234\n```', 
                inline: false 
            },
            { 
                name: '⚠️ Uyarı #2', 
                value: '```\n📝 Sebep: Görev tamamlamama\n📅 Tarih: 22.10.2024\n🏷️ Ekip: Phoenix Takımı\n👮 Veren: Admin#5678\n```', 
                inline: false 
            },
            { 
                name: '⚠️ Uyarı #3', 
                value: '```\n📝 Sebep: Kurallara uymama\n📅 Tarih: 25.10.2024\n🏷️ Ekip: Phoenix Takımı\n👮 Veren: Moderator#1234\n```', 
                inline: false 
            }
        )
        .addFields(
            { name: '📊 Toplam Uyarı', value: '```\n3 uyarı\n```', inline: true },
            { name: '🎯 Durum', value: '```\n🔴 Kritik\n```', inline: true },
            { name: '⚠️ Son Uyarı', value: '```\n4 gün önce\n```', inline: true }
        )
        .setThumbnail(kullanici.user.displayAvatarURL())
        .setFooter({ text: 'Ekip uyarı kayıt sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
    } catch (error) {
        console.error('Uyarı listesi modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Uyarı listesi alınırken bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip rol modal submit
async function handleEkipRolModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

    const islemTipi = interaction.fields.getTextInputValue('islem_tipi').toLowerCase();
    const ekipIsim = interaction.fields.getTextInputValue('ekip_isim');
    const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
    const rolId = interaction.fields.getTextInputValue('rol_id');

    if (!['ata', 'kaldir', 'kaldır'].includes(islemTipi)) {
        return await interaction.editReply({
            content: '❌ Geçersiz işlem tipi! "ata" veya "kaldir" yazmalısınız.',
            ephemeral: true
        });
    }

    let kullanici, rol;
    try {
        kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
        rol = await interaction.guild.roles.fetch(rolId.trim());
    } catch (error) {
        return await interaction.editReply({
            content: '❌ Kullanıcı veya rol bulunamadı! Lütfen geçerli ID\'ler girin.',
            ephemeral: true
        });
    }

    const isAta = islemTipi === 'ata';
    const embed = new EmbedBuilder()
        .setColor(isAta ? 0x00FF00 : 0xFF0000)
        .setTitle(isAta ? '✅ Rol Atandı' : '❌ Rol Kaldırıldı')
        .setDescription(`**${kullanici.user.tag}** kullanıcısı${isAta ? 'na' : 'ndan'} **${rol.name}** rolü ${isAta ? 'atandı' : 'kaldırıldı'}!`)
        .addFields(
            { name: '👤 Kullanıcı', value: `${kullanici.user.tag}\n\`${kullanici.id}\``, inline: true },
            { name: '🎭 Rol', value: `${rol.name}\n\`${rol.id}\``, inline: true },
            { name: '🏷️ Ekip', value: ekipIsim, inline: true },
            { name: '👮 İşlemi Yapan', value: interaction.user.tag, inline: true },
            { name: '📅 İşlem Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '🔧 İşlem Tipi', value: isAta ? '➕ Rol Atama' : '➖ Rol Kaldırma', inline: true }
        )
        .setFooter({ text: 'Ekip rol yönetim sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    console.log(`[EKİP ROL] ${interaction.user.tag} ${kullanici.user.tag} kullanıcısı${isAta ? 'na' : 'ndan'} ${rol.name} rolünü ${isAta ? 'attı' : 'kaldırdı'} (Ekip: ${ekipIsim})`);
    } catch (error) {
        console.error('Ekip rol modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Rol işlemi sırasında bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Ekip yedek alma modal submit
async function handleEkipYedekAlModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

    const ekipIsim = interaction.fields.getTextInputValue('ekip_isim') || 'Tüm Ekipler';
    const yedekAciklama = interaction.fields.getTextInputValue('yedek_aciklama') || 'Manuel yedekleme';

    const yedekId = `backup_${Date.now()}`;
    const dosyaBoyutu = Math.floor(Math.random() * 5000) + 500; // 500-5500 bytes

    const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('💾 Yedekleme Tamamlandı')
        .setDescription(`**${ekipIsim}** için yedekleme işlemi başarıyla tamamlandı!`)
        .addFields(
            { name: '📦 Yedeklenen', value: `\`\`\`\n${ekipIsim}\n\`\`\``, inline: true },
            { name: '🔒 Yedek ID', value: `\`\`\`\n${yedekId}\n\`\`\``, inline: true },
            { name: '📅 Yedekleme Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '💾 Dosya Boyutu', value: `\`\`\`\n${(dosyaBoyutu / 1024).toFixed(2)} KB\n\`\`\``, inline: true },
            { name: '👤 Yedekleyen', value: `\`\`\`\n${interaction.user.tag}\n\`\`\``, inline: true },
            { name: '✅ Durum', value: '```\n✓ Başarılı\n```', inline: true },
            { name: '📝 Açıklama', value: yedekAciklama, inline: false },
            { name: '💡 Bilgi', value: 'Bu yedek dosyasını "Yedek Yükle" seçeneği ile geri yükleyebilirsiniz.', inline: false }
        )
        .setFooter({ text: 'Ekip yedekleme sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    console.log(`[EKİP YEDEK] ${ekipIsim} ${interaction.user.tag} tarafından yedeklendi. ID: ${yedekId}`);
    } catch (error) {
        console.error('Ekip yedek alma modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Yedekleme sırasında bir hata oluştu!' }).catch(() => {});
        }
    }
}

// Yedek yükleme modal submit
async function handleYedekYukleModalSubmit(interaction) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral: true });
        }

    const yedekId = interaction.fields.getTextInputValue('yedek_id');
    const onay = interaction.fields.getTextInputValue('onay');

    if (onay.toUpperCase() !== 'EVET') {
        const embed = new EmbedBuilder()
            .setColor(0xF39C12)
            .setTitle('⚠️ İşlem İptal Edildi')
            .setDescription('Yedek yükleme işlemi onaylanmadı.')
            .addFields(
                { name: '📁 Yedek ID', value: yedekId, inline: true },
                { name: '❌ Onay', value: 'Onaylanmadı', inline: true }
            )
            .setTimestamp();

        return await interaction.editReply({ embeds: [embed] });
    }

    const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🔄 Yedek Başarıyla Yüklendi')
        .setDescription(`**${yedekId}** yedek dosyası sistemden başarıyla geri yüklendi!`)
        .addFields(
            { name: '📁 Yedek ID', value: `\`\`\`\n${yedekId}\n\`\`\``, inline: true },
            { name: '👤 Yükleyen', value: `\`\`\`\n${interaction.user.tag}\n\`\`\``, inline: true },
            { name: '📅 Yükleme Tarihi', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: '📦 Geri Yüklenen', value: '```\nTüm ekip verileri\n```', inline: true },
            { name: '✅ Durum', value: '```\n✓ Başarılı\n```', inline: true },
            { name: '🔢 Etkilenen Kayıt', value: '```\n12 ekip\n```', inline: true },
            { name: '⚠️ Uyarı', value: 'Mevcut veriler yedekteki verilerle değiştirildi.', inline: false },
            { name: '💡 Bilgi', value: 'Tüm ekip verileri başarıyla geri yüklendi. Değişiklikler hemen aktif oldu.', inline: false }
        )
        .setFooter({ text: 'Ekip yedekleme sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    console.log(`[EKİP YEDEK YÜKLEME] ${yedekId} ${interaction.user.tag} tarafından geri yüklendi.`);
    } catch (error) {
        console.error('Yedek yükleme modal hatası:', error);
        if (interaction.deferred) {
            await interaction.editReply({ content: '❌ Yedek yüklenirken bir hata oluştu!' }).catch(() => {});
        }
    }
}






// Ekip panel - Üye ekleme submit
async function handleEkipPanelUyeEkleSubmit(interaction) {
    try {
        await interaction.deferReply({ ephemeral: true });
        const ekipId = interaction.customId.split('_').pop();
        const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
        const eklemeNotu = interaction.fields.getTextInputValue('ekleme_notu') || 'Panel üzerinden eklendi';
        const ekip = await Ekip.findById(ekipId);
        if (!ekip) return await interaction.editReply({ content: ' Ekip bulunamadı!' });
        let kullanici;
        try {
            kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
        } catch (error) {
            return await interaction.editReply({ content: ' Kullanıcı bulunamadı!' });
        }
        const mevcutMu = ekip.uyeler.some(u => u.userId === kullanici.id);
        if (mevcutMu) return await interaction.editReply({ content: `❌ **${kullanici.user.tag}** zaten ekipte!` });
        ekip.uyeler.push({ userId: kullanici.id, userTag: kullanici.user.tag, eklenmetarihi: new Date(), ekleyenId: interaction.user.id, not: eklemeNotu });
        await ekip.save();
        
        // Ekip rolünü ver
        if (ekip.rolId) {
            try {
                await kullanici.roles.add(ekip.rolId);
                console.log(`[EKİP ROL] ${kullanici.user.tag} kullanıcısına ${ekip.ekipIsim} rolü verildi`);
            } catch (roleError) {
                console.error('Rol verme hatası:', roleError);
            }
        }
        
        const embed = new EmbedBuilder().setColor(parseInt(ekip.renk, 16) || 0x00FF00).setTitle('✅ Üye Eklendi!').setDescription(`**${kullanici.user.tag}** ekibe eklendi.`).addFields({ name: '👤 Eklenen', value: `${kullanici.user.tag}`, inline: true }, { name: '👥 Toplam', value: `${ekip.uyeler.length}`, inline: true }).setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        console.log(`[EKİP PANEL] ${kullanici.user.tag} ${ekip.ekipIsim} ekibine eklendi`);
    } catch (error) {
        console.error('Ekip panel üye ekleme hatası:', error);
        if (interaction.deferred) await interaction.editReply({ content: '❌ Hata!' }).catch(() => {});
    }
}

// Ekip panel - Üye çıkarma submit
async function handleEkipPanelUyeCikarSubmit(interaction) {
    try {
        await interaction.deferReply({ ephemeral: true });
        const ekipId = interaction.customId.split('_').pop();
        const kullaniciId = interaction.fields.getTextInputValue('kullanici_id');
        const cikarmaSebebi = interaction.fields.getTextInputValue('cikarma_sebebi');
        const ekip = await Ekip.findById(ekipId);
        if (!ekip) return await interaction.editReply({ content: '❌ Ekip bulunamadı!' });
        let kullanici;
        try {
            kullanici = await interaction.guild.members.fetch(kullaniciId.trim());
        } catch (error) {
            return await interaction.editReply({ content: '❌ Kullanıcı bulunamadı!' });
        }
        const uyeIndex = ekip.uyeler.findIndex(u => u.userId === kullanici.id);
        if (uyeIndex === -1) return await interaction.editReply({ content: `❌ Üye ekipte değil!` });
        ekip.uyeler.splice(uyeIndex, 1);
        await ekip.save();
        
        // Ekip rolünü al
        if (ekip.rolId) {
            try {
                await kullanici.roles.remove(ekip.rolId);
                console.log(`[EKİP ROL] ${kullanici.user.tag} kullanıcısından ${ekip.ekipIsim} rolü alındı`);
            } catch (roleError) {
                console.error('Rol alma hatası:', roleError);
            }
        }
        
        const embed = new EmbedBuilder().setColor(0xFF0000).setTitle('🚫 Üye Çıkarıldı').setDescription(`**${kullanici.user.tag}** ekipten çıkarıldı.`).addFields({ name: '👤 Çıkarılan', value: `${kullanici.user.tag}`, inline: true }, { name: '📝 Sebep', value: cikarmaSebebi, inline: false }).setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        console.log(`[EKİP PANEL] ${kullanici.user.tag} ${ekip.ekipIsim} ekibinden çıkarıldı`);
    } catch (error) {
        console.error('Ekip panel üye çıkarma hatası:', error);
        if (interaction.deferred) await interaction.editReply({ content: '❌ Hata!' }).catch(() => {});
    }
}
