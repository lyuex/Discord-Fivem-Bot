// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { Ekip, EkipUyari, EkipYedek } = require('../Schemas/EkipSchema');

module.exports = {
    async execute(interaction) {
        try {
            console.log(`[EkipInteractionHandler] Processing: ${interaction.customId}`);
            console.log(`[EkipInteractionHandler] Interaction Type: ${interaction.type}`);
            console.log(`[EkipInteractionHandler] Is StringSelectMenu: ${interaction.isStringSelectMenu()}`);
            
            // Select menu işlemleri
            if (interaction.customId === 'ekip_menu') {
                const selectedValue = interaction.values[0];
                console.log(`[EkipInteractionHandler] Selected value: ${selectedValue}`);
                
                switch (selectedValue) {
                    case 'ekip_kur':
                        await handleEkipKur(interaction);
                        break;
                    case 'ekip_liste':
                        await handleEkipListe(interaction);
                        break;
                    case 'ekip_profil':
                        await handleEkipProfilModal(interaction);
                        break;
                    case 'ekip_bilgi':
                        await handleEkipBilgiModal(interaction);
                        break;
                    case 'uye_ekle':
                        await handleUyeEkleModal(interaction);
                        break;
                    case 'uye_cikar':
                        await handleUyeCikarModal(interaction);
                        break;
                    case 'ekip_uyari_ver':
                        await handleEkipUyariVerModal(interaction);
                        break;
                    case 'uyari_liste':
                        await handleUyariListeModal(interaction);
                        break;
                    case 'ekip_rol':
                        await handleEkipRolModal(interaction);
                        break;
                    case 'ekip_yedek_al':
                        await handleEkipYedekAlModal(interaction);
                        break;
                    case 'yedek_liste':
                        await handleYedekListe(interaction);
                        break;
                    case 'yedek_yukle':
                        await handleYedekYukleModal(interaction);
                        break;
                    case 'ekip_istatistik':
                        await handleEkipIstatistik(interaction);
                        break;
                    case 'ekip_sil':
                        await handleEkipSilModal(interaction);
                        break;
                    case 'secenekleri_sifirla':
                        await handleSecenekleriSifirla(interaction);
                        break;
                    default:
                        await interaction.reply({
                            content: '❌ Bilinmeyen işlem!',
                            ephemeral: true
                        });
                }
            }
            // Eski custom ID'ler için geri uyumluluk
            else if (interaction.customId.startsWith('ekip_create_')) {
                await handleEkipCreate(interaction);
            } else if (interaction.customId.startsWith('ekip_manage_')) {
                await handleEkipManage(interaction);
            } else if (interaction.customId.startsWith('ekip_info_')) {
                await handleEkipInfo(interaction);
            } else {
                await interaction.reply({
                    content: '❌ Bilinmeyen ekip işlemi!',
                    ephemeral: true
                });
            }

        } catch (error) {
            console.error('Ekip interaction handler hatası:', error);
            
            // Modal gösterilmişse veya interaction kullanılmışsa reply yapma
            if (!interaction.replied && !interaction.deferred) {
                // Eğer bu bir select menu interaction ise ve modal açılmışsa
                if (interaction.isStringSelectMenu()) {
                    // Modal açılmış olabilir, o yüzden reply yapma
                    console.log('Modal açılmış, reply atlanıyor');
                    return;
                }
                
                await interaction.reply({
                    content: '❌ Bir hata oluştu!',
                    ephemeral: true
                }).catch(err => {
                    console.error('Reply gönderilemedi:', err.message);
                });
            } else if (interaction.deferred) {
                await interaction.editReply({
                    content: '❌ Bir hata oluştu!'
                }).catch(err => {
                    console.error('EditReply gönderilemedi:', err.message);
                });
            }
        }
    }
};

// Yeni ekip kurma modal'ı
async function handleEkipKur(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_kur_modal')
        .setTitle('🏢 Yeni Ekip Oluştur');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Ekip İsmi')
        .setPlaceholder('Örn: Phoenix Takımı')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(3)
        .setMaxLength(50);

    const ekipAciklamaInput = new TextInputBuilder()
        .setCustomId('ekip_aciklama')
        .setLabel('Ekip Açıklaması')
        .setPlaceholder('Ekibiniz hakkında kısa bir açıklama yazın')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(500);

    const ekipLiderInput = new TextInputBuilder()
        .setCustomId('ekip_lider')
        .setLabel('Ekip Lideri (User ID)')
        .setPlaceholder('Kullanıcı ID girin veya boş bırakın (siz olacaksınız)')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const ekipRenkInput = new TextInputBuilder()
        .setCustomId('ekip_renk')
        .setLabel('Ekip Rengi (Hex Kod)')
        .setPlaceholder('Örn: #5865F2 veya 5865F2')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
        .setMaxLength(7);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(ekipAciklamaInput);
    const thirdRow = new ActionRowBuilder().addComponents(ekipLiderInput);
    const fourthRow = new ActionRowBuilder().addComponents(ekipRenkInput);

    modal.addComponents(firstRow, secondRow, thirdRow, fourthRow);

    await interaction.showModal(modal);
}

// Ekip listesi göster
async function handleEkipListe(interaction) {
    try {
        await interaction.deferReply({ ephemeral: true });

        // Veritabanından tüm aktif ekipleri çek
        const ekipler = await Ekip.find({ 
            guildId: interaction.guild.id,
            aktif: true 
        }).sort({ olusturulmaTarihi: -1 });

        if (ekipler.length === 0) {
            return await interaction.editReply({
                content: '❌ Bu sunucuda henüz hiç ekip oluşturulmamış!',
            });
        }

        const embed = new EmbedBuilder()
            .setColor(0x3498db)
            .setTitle('📋 Ekip Listesi')
            .setDescription(`**Sunucudaki Tüm Ekipler** (${ekipler.length} ekip)\n\n` +
                '> Aşağıda tüm aktif ekipler listelenmiştir.\n' +
                '> Daha fazla bilgi için "Ekip Bilgi" veya "Ekip Profil" seçeneğini kullanın.\n' +
                '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        // İlk 25 ekibi göster (Discord limiti)
        const gosterilecekEkipler = ekipler.slice(0, 25);
        
        for (const ekip of gosterilecekEkipler) {
            const kurulusTarihi = Math.floor(ekip.olusturulmaTarihi.getTime() / 1000);
            const emojiMap = {
                'Aktif': '🟢',
                'Pasif': '🟡',
                'Donduruldu': '🔴'
            };
            const durumEmoji = emojiMap[ekip.durum] || '⚪';
            
            embed.addFields({
                name: `${durumEmoji} ${ekip.ekipIsim}`,
                value: `\`\`\`yaml\n👑 Lider: ${ekip.liderTag}\n👥 Üye: ${ekip.uyeler.length} kişi\n📅 Kuruluş: ${new Date(ekip.olusturulmaTarihi).toLocaleDateString('tr-TR')}\n⭐ Seviye: ${ekip.seviye}\n💎 Puan: ${ekip.puan}\n🎯 Durum: ${ekip.durum}\n\`\`\``,
                inline: true
            });
        }

        if (ekipler.length > 25) {
            embed.addFields({
                name: '� Bilgi',
                value: `Sadece ilk 25 ekip gösteriliyor. Toplam ${ekipler.length} ekip var.`,
                inline: false
            });
        }

        embed.setFooter({ text: `Toplam ${ekipler.length} ekip bulunmaktadır` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    } catch (error) {
        console.error('Ekip liste hatası:', error);
        await interaction.editReply({ content: '❌ Ekip listesi yüklenirken bir hata oluştu!' }).catch(() => {});
    }
}

// Ekip bilgisi için modal
async function handleEkipBilgiModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_bilgi_modal')
        .setTitle('ℹ️ Ekip Bilgileri');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Bilgilerini görmek istediğiniz ekip ismi')
        .setPlaceholder('Ekip ismini girin')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const row = new ActionRowBuilder().addComponents(ekipIsimInput);
    modal.addComponents(row);

    await interaction.showModal(modal);
}

// Ekip profil modal
async function handleEkipProfilModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_profil_modal')
        .setTitle('👥 Ekip Profili');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Profil görmek istediğiniz ekip ismi')
        .setPlaceholder('Ekip ismini girin')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const row = new ActionRowBuilder().addComponents(ekipIsimInput);
    modal.addComponents(row);

    await interaction.showModal(modal);
}

// Ekip uyarı verme modal
async function handleEkipUyariVerModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_uyari_ver_modal')
        .setTitle('⚠️ Ekip Üyesine Uyarı Ver');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Ekip İsmi')
        .setPlaceholder('Uyarı verilecek ekip')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Uyarı verilecek kullanıcının ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const sebepInput = new TextInputBuilder()
        .setCustomId('uyari_sebebi')
        .setLabel('Uyarı Sebebi')
        .setPlaceholder('Uyarı sebebini detaylı açıklayın')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(500);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(kullaniciInput);
    const thirdRow = new ActionRowBuilder().addComponents(sebepInput);

    modal.addComponents(firstRow, secondRow, thirdRow);

    await interaction.showModal(modal);
}

// Uyarı listesi modal
async function handleUyariListeModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('uyari_liste_modal')
        .setTitle('📝 Uyarı Listesi');

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Uyarıları görüntülenecek kullanıcının ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const row = new ActionRowBuilder().addComponents(kullaniciInput);
    modal.addComponents(row);

    await interaction.showModal(modal);
}

// Ekip rol yönetimi modal
async function handleEkipRolModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_rol_modal')
        .setTitle('🎭 Rol Yönetimi');

    const islemTipiInput = new TextInputBuilder()
        .setCustomId('islem_tipi')
        .setLabel('İşlem Tipi (ata/kaldir)')
        .setPlaceholder('ata veya kaldir yazın')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(3)
        .setMaxLength(6);

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Ekip İsmi')
        .setPlaceholder('Ekip ismi')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('İşlem yapılacak kullanıcının ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const rolInput = new TextInputBuilder()
        .setCustomId('rol_id')
        .setLabel('Rol ID')
        .setPlaceholder('Atanacak/Kaldırılacak rol ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const firstRow = new ActionRowBuilder().addComponents(islemTipiInput);
    const secondRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const thirdRow = new ActionRowBuilder().addComponents(kullaniciInput);
    const fourthRow = new ActionRowBuilder().addComponents(rolInput);

    modal.addComponents(firstRow, secondRow, thirdRow, fourthRow);

    await interaction.showModal(modal);
}

// Ekip yedek alma modal
async function handleEkipYedekAlModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_yedek_al_modal')
        .setTitle('💾 Ekip Yedekle');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Yedeklenecek Ekip İsmi (Boş = Tümü)')
        .setPlaceholder('Ekip ismi girin veya boş bırakın')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const aciklamaInput = new TextInputBuilder()
        .setCustomId('yedek_aciklama')
        .setLabel('Yedek Açıklaması')
        .setPlaceholder('Bu yedek hakkında not (opsiyonel)')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(200);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(aciklamaInput);

    modal.addComponents(firstRow, secondRow);

    await interaction.showModal(modal);
}

// Yedek listesi göster
async function handleYedekListe(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('📂 Ekip Yedek Listesi')
        .setDescription('**Mevcut Yedekler**\n\n' +
            '> Aşağıda tüm ekip yedekleri listelenmiştir.')
        .addFields(
            { 
                name: '📄 backup_1730246400', 
                value: '```\n📦 Ekip: Tüm Ekipler\n📅 Tarih: 29.10.2024 15:00\n💾 Boyut: 2.3 KB\n📝 Not: Haftalık yedek\n```', 
                inline: false 
            },
            { 
                name: '📄 backup_1730160000', 
                value: '```\n📦 Ekip: Phoenix Takımı\n📅 Tarih: 28.10.2024 15:00\n💾 Boyut: 1.1 KB\n📝 Not: Güncelleme öncesi\n```', 
                inline: false 
            },
            { 
                name: '📄 backup_1730073600', 
                value: '```\n📦 Ekip: Dragons Squad\n📅 Tarih: 27.10.2024 15:00\n💾 Boyut: 890 B\n📝 Not: Otomatik yedek\n```', 
                inline: false 
            }
        )
        .setFooter({ text: 'Toplam 3 yedek • Yedek yüklemek için "Yedek Yükle" seçeneğini kullanın' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

// Yedek yükleme modal
async function handleYedekYukleModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('yedek_yukle_modal')
        .setTitle('🔄 Yedek Yükle');

    const yedekIdInput = new TextInputBuilder()
        .setCustomId('yedek_id')
        .setLabel('Yedek Dosya ID')
        .setPlaceholder('Örn: backup_1730246400')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const onayInput = new TextInputBuilder()
        .setCustomId('onay')
        .setLabel('Onay (EVET yazın)')
        .setPlaceholder('Mevcut veriler silinecek! "EVET" yazın')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(4)
        .setMaxLength(4);

    const firstRow = new ActionRowBuilder().addComponents(yedekIdInput);
    const secondRow = new ActionRowBuilder().addComponents(onayInput);

    modal.addComponents(firstRow, secondRow);

    await interaction.showModal(modal);
}

// Üye ekleme modal'ı
async function handleUyeEkleModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('uye_ekle_modal')
        .setTitle('👤 Ekibe Üye Ekle');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Ekip İsmi')
        .setPlaceholder('Üye eklenecek ekibin ismi')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Eklenecek kullanıcının ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const notInput = new TextInputBuilder()
        .setCustomId('ekleme_notu')
        .setLabel('Not (Opsiyonel)')
        .setPlaceholder('Ekleme sebebi veya not')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(200);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(kullaniciInput);
    const thirdRow = new ActionRowBuilder().addComponents(notInput);

    modal.addComponents(firstRow, secondRow, thirdRow);

    await interaction.showModal(modal);
}

// Üye çıkarma modal'ı
async function handleUyeCikarModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('uye_cikar_modal')
        .setTitle('👋 Ekipten Üye Çıkar');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Ekip İsmi')
        .setPlaceholder('Üye çıkarılacak ekibin ismi')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Çıkarılacak kullanıcının ID\'si')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const sebekInput = new TextInputBuilder()
        .setCustomId('cikarma_sebebi')
        .setLabel('Çıkarma Sebebi')
        .setPlaceholder('Kullanıcı neden ekipten çıkarılıyor?')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(300);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(kullaniciInput);
    const thirdRow = new ActionRowBuilder().addComponents(sebekInput);

    modal.addComponents(firstRow, secondRow, thirdRow);

    await interaction.showModal(modal);
}

// Ekip silme modal'ı
async function handleEkipSilModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ekip_sil_modal')
        .setTitle('🗑️ Ekip Sil');

    const ekipIsimInput = new TextInputBuilder()
        .setCustomId('ekip_isim')
        .setLabel('Silinecek Ekip İsmi')
        .setPlaceholder('Ekip ismini girin')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const onayInput = new TextInputBuilder()
        .setCustomId('onay')
        .setLabel('Onay (EVET yazın)')
        .setPlaceholder('Silme işlemini onaylamak için "EVET" yazın')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(4)
        .setMaxLength(4);

    const sebekInput = new TextInputBuilder()
        .setCustomId('silme_sebebi')
        .setLabel('Silme Sebebi')
        .setPlaceholder('Ekip neden siliniyor?')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(300);

    const firstRow = new ActionRowBuilder().addComponents(ekipIsimInput);
    const secondRow = new ActionRowBuilder().addComponents(onayInput);
    const thirdRow = new ActionRowBuilder().addComponents(sebekInput);

    modal.addComponents(firstRow, secondRow, thirdRow);

    await interaction.showModal(modal);
}

// İstatistikler göster
async function handleEkipIstatistik(interaction) {
    try {
        await interaction.deferReply({ ephemeral: true });

        // Veritabanından istatistikleri çek
        const tumEkipler = await Ekip.find({ guildId: interaction.guild.id });
        const aktifEkipler = tumEkipler.filter(e => e.aktif && e.durum === 'Aktif');
        
        if (tumEkipler.length === 0) {
            return await interaction.editReply({
                content: '❌ Bu sunucuda henüz hiç ekip oluşturulmamış!',
            });
        }

        // İstatistikleri hesapla
        const toplamEkip = tumEkipler.length;
        const aktifEkipSayisi = aktifEkipler.length;
        const toplamUye = tumEkipler.reduce((sum, ekip) => sum + ekip.uyeler.length, 0);
        const ortalamaUye = (toplamUye / toplamEkip).toFixed(1);
        
        // En büyük ekip
        const enBuyukEkip = tumEkipler.reduce((max, ekip) => 
            ekip.uyeler.length > max.uyeler.length ? ekip : max
        , tumEkipler[0]);
        
        // En yüksek puanlı ekip
        const enAktifEkip = tumEkipler.reduce((max, ekip) => 
            ekip.puan > max.puan ? ekip : max
        , tumEkipler[0]);
        
        // Bu ay kurulan ekipler
        const buAyBaslangic = new Date();
        buAyBaslangic.setDate(1);
        buAyBaslangic.setHours(0, 0, 0, 0);
        const buAyKurulan = tumEkipler.filter(e => new Date(e.olusturulmaTarihi) >= buAyBaslangic).length;
        
        // Ortalama yaş (gün)
        const simdi = Date.now();
        const ortalamaYas = Math.floor(
            tumEkipler.reduce((sum, ekip) => {
                const yas = (simdi - new Date(ekip.olusturulmaTarihi).getTime()) / (1000 * 60 * 60 * 24);
                return sum + yas;
            }, 0) / toplamEkip
        );

        const embed = new EmbedBuilder()
            .setColor(0x9B59B6)
            .setTitle('📊 Ekip İstatistikleri')
            .setDescription('**Sunucu Ekip Analizi**\n\n' +
                '> Tüm ekiplerin gerçek zamanlı performans ve üye istatistikleri.\n' +
                '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            .addFields(
                { name: '🏘️ Toplam Ekip', value: `\`\`\`\n${toplamEkip} ekip\n\`\`\``, inline: true },
                { name: '👥 Toplam Üye', value: `\`\`\`\n${toplamUye} üye\n\`\`\``, inline: true },
                { name: '🎯 Aktif Ekip', value: `\`\`\`\n${aktifEkipSayisi} ekip\n\`\`\``, inline: true },
                { name: '📊 Ortalama Üye/Ekip', value: `\`\`\`\n${ortalamaUye} üye\n\`\`\``, inline: true },
                { name: '⭐ En Büyük Ekip', value: `\`\`\`\n${enBuyukEkip.ekipIsim}\n(${enBuyukEkip.uyeler.length} üye)\n\`\`\``, inline: true },
                { name: '🔥 En Yüksek Puanlı', value: `\`\`\`\n${enAktifEkip.ekipIsim}\n(${enAktifEkip.puan} puan)\n\`\`\``, inline: true },
                { name: '📈 Bu Ay Kurulan', value: `\`\`\`\n${buAyKurulan} yeni ekip\n\`\`\``, inline: true },
                { name: '⏱️ Ortalama Yaş', value: `\`\`\`\n${ortalamaYas} gün\n\`\`\``, inline: true },
                { name: '💎 Toplam Puan', value: `\`\`\`\n${tumEkipler.reduce((sum, e) => sum + e.puan, 0)} puan\n\`\`\``, inline: true }
            )
            .setFooter({ text: `Son güncelleme • ${interaction.guild.name}` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    } catch (error) {
        console.error('Ekip istatistik hatası:', error);
        await interaction.editReply({ content: '❌ İstatistikler yüklenirken bir hata oluştu!' }).catch(() => {});
    }
}

// Seçenekleri sıfırla
async function handleSecenekleriSifirla(interaction) {
    try {
        // Select menüyü varsayılana döndür
        await interaction.update({
            components: interaction.message.components
        });

        // Başarı mesajı gönder
        await interaction.followUp({
            content: '✅ Select menü seçenekleri varsayılana döndürüldü!',
            ephemeral: true
        });
    } catch (error) {
        console.error('Seçenekleri sıfırlama hatası:', error);
        await interaction.reply({
            content: '❌ Seçenekler sıfırlanırken bir hata oluştu!',
            ephemeral: true
        }).catch(() => {});
    }
}

// Eski fonksiyonlar (geri uyumluluk için)
async function handleEkipCreate(interaction) {
    const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Ekip Oluşturma')
        .setDescription('Yeni ekip oluşturma işlemi başlatıldı!')
        .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleEkipManage(interaction) {
    const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('⚙️ Ekip Yönetimi')
        .setDescription('Ekip yönetim paneli açıldı!')
        .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleEkipInfo(interaction) {
    const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('ℹ️ Ekip Bilgileri')
        .setDescription('Ekip detay bilgileri gösteriliyor!')
        .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
}