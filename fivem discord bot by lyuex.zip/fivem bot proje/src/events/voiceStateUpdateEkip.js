// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events } = require('discord.js');
const { QuickDB } = require('quick.db');
const db = new QuickDB({ filePath: './ekip.sqlite' });

// Ses kanalı deneyim puanı sabitleri
const VOICE_XP_AMOUNT = 5; // Her interval için kazanılacak XP
const VOICE_XP_INTERVAL = 10 * 60 * 1000; // 10 dakikada bir XP (milisaniye)

// Aktif ses kullanıcılarını takip etmek için
const activeVoiceUsers = new Map();

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        // Bot ses durumu değişimlerini dikkate almıyoruz
        if (newState.member.user.bot) return;

        const userId = newState.member.id;
        const guildId = newState.guild.id;
        const EKIP_KEY = `ekipler_${guildId}`;
        
        try {
            // Kullanıcının ekibini bul
            let ekipler = await db.get(EKIP_KEY);
            if (!ekipler) return;
            
            const userTeam = ekipler.find(e => e.uyeler.includes(userId));
            if (!userTeam) return; // Kullanıcı herhangi bir ekipte değil
            
            // Ses kanalına katılma
            if (!oldState.channelId && newState.channelId) {
                console.log(`🎤 ${userId} ses kanalına katıldı ve ${userTeam.isim} ekibinde`);
                
                // Kullanıcının ses aktivitesini başlat
                activeVoiceUsers.set(userId, {
                    guildId: guildId,
                    teamId: userTeam.isim,
                    joinTime: Date.now(),
                    lastXpTime: Date.now()
                });
            }
            
            // Ses kanalından ayrılma
            if (oldState.channelId && !newState.channelId) {
                console.log(`🎤 ${userId} ses kanalından ayrıldı`);
                
                if (activeVoiceUsers.has(userId)) {
                    const userData = activeVoiceUsers.get(userId);
                    activeVoiceUsers.delete(userId);
                    
                    // Geçirilen süreyi hesapla (dakika)
                    const timeSpent = Math.floor((Date.now() - userData.joinTime) / 60000);
                    
                    // 2 dakikadan kısa süreler için XP verme (AFK önlemi)
                    if (timeSpent < 2) return;
                    
                    // Ekibi yeniden bul (güncel bilgiler için)
                    ekipler = await db.get(EKIP_KEY);
                    const team = ekipler.find(e => e.isim === userData.teamId);
                    if (!team) return;
                    
                    // Bonus XP hesapla (her tam 10 dakika için)
                    const bonusXp = Math.floor(timeSpent / 10) * VOICE_XP_AMOUNT;
                    if (bonusXp > 0) {
                        team.deneyim += bonusXp;
                        team.sonAktivite = Date.now();
                        
                        await db.set(EKIP_KEY, ekipler);
                        
                        console.log(`💎 ${userData.teamId} ekibine ${bonusXp} XP eklendi (${timeSpent} dk ses)`);
                    }
                }
            }
            
            // Ses kanalını değiştirme (önceki ve sonraki kanal farklı)
            if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
                // Ekip ses kanalları arasında geçiş yaparken süreyi koruyoruz,
                // ama ekibe ait olmayan bir kanala geçerse XP kazanmayı durduruyoruz
                if (activeVoiceUsers.has(userId)) {
                    // Güncellemeye gerek yok, aktivite devam ediyor
                }
            }
            
        } catch (error) {
            console.error('Ses aktivite takip hatası:', error);
        }
    }
};

// Her 10 dakikada bir aktif ses kullanıcılarına XP ver
setInterval(async () => {
    const now = Date.now();
    
    for (const [userId, userData] of activeVoiceUsers.entries()) {
        try {
            // 10 dakika geçtiyse XP ver
            if (now - userData.lastXpTime >= VOICE_XP_INTERVAL) {
                const EKIP_KEY = `ekipler_${userData.guildId}`;
                let ekipler = await db.get(EKIP_KEY);
                
                if (!ekipler) continue;
                
                const team = ekipler.find(e => e.isim === userData.teamId);
                if (!team) continue;
                
                // XP ekle
                team.deneyim += VOICE_XP_AMOUNT;
                team.sonAktivite = now;
                
                // Son XP zamanını güncelle
                userData.lastXpTime = now;
                activeVoiceUsers.set(userId, userData);
                
                await db.set(EKIP_KEY, ekipler);
                
                console.log(`💎 ${userData.teamId} ekibine ${VOICE_XP_AMOUNT} XP eklendi (ses kanalı aktivitesi)`);
            }
        } catch (error) {
            console.error('Periyodik XP verme hatası:', error);
        }
    }
}, 60000); // Her dakika kontrol et




