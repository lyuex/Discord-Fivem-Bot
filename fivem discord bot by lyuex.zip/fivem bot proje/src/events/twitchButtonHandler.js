// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ActivityType } = require('discord.js');
const lyuex = require('../../lyuex.json');
const fs = require('fs');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton()) return;

        // Sadece Twitch ile ilgili butonları handle et
        if (!interaction.customId.startsWith('twitch_')) return;

        // Bot sahipliği kontrolü
        const botOwners = lyuex.botSettings?.botOwners || [];
        if (!botOwners.includes(interaction.user.id)) {
            const yetkisizEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Yetki Hatası')
                .setDescription('Bu butonları sadece **Bot Sahipleri** kullanabilir!')
                .setFooter({ text: 'LYUEX • Yetki Kontrolü' })
                .setTimestamp();

            return interaction.reply({ embeds: [yetkisizEmbed], ephemeral: true });
        }

        try {
            switch (interaction.customId) {
                case 'twitch_stop_stream':
                    await handleStopStream(interaction);
                    break;
                    
                case 'twitch_view_stats':
                    await handleViewStats(interaction);
                    break;
                    
                case 'twitch_start_quick':
                    await handleQuickStart(interaction);
                    break;
                    
                case 'twitch_refresh_panel':
                    await handleRefreshPanel(interaction);
                    break;
                    
                default:
                    await interaction.reply({ 
                        content: '❓ Bilinmeyen buton!', 
                        ephemeral: true 
                    });
            }
        } catch (error) {
            console.error('Twitch buton hatası:', error);
            
            const hataEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('❌ Buton Hatası')
                .setDescription('Buton işlemi sırasında bir hata oluştu!')
                .addFields(
                    { name: '🔍 Hata', value: '```' + error.message + '```', inline: false }
                )
                .setFooter({ text: 'LYUEX • Hata Sistemi' })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [hataEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [hataEmbed], ephemeral: true });
            }
        }
    }
};

// Yayını durdur butonu
async function handleStopStream(interaction) {
    await interaction.deferUpdate();

    try {
        const twitchData = getTwitchData();
        
        if (!twitchData.isStreaming) {
            const uyariEmbed = new EmbedBuilder()
                .setColor(0xFFA500)
                .setTitle('⚠️ Zaten Durdurulmuş')
                .setDescription('Bot zaten yayın yapmıyor!')
                .setFooter({ text: 'LYUEX • Twitch Durum' })
                .setTimestamp();

            return interaction.followUp({ embeds: [uyariEmbed], ephemeral: true });
        }

        // Bot durumunu normal haline döndür
        await interaction.client.user.setPresence({
            activities: [{
                name: lyuex.botSettings.oynuyor,
                type: ActivityType.Competing
            }],
            status: lyuex.botSettings.durum
        });

        const streamDuration = Math.floor((Date.now() - new Date(twitchData.startedAt).getTime()) / 1000);
        clearTwitchData();

        // Orijinal mesajı güncelle
        const basariEmbed = new EmbedBuilder()
            .setColor(0xFF4444)
            .setTitle('⏹️ Yayın Durduruldu!')
            .setDescription(`Twitch yayını **başarıyla durduruldu**!`)
            .addFields(
                { name: '📺 Son Yayın', value: `\`${twitchData.streamTitle}\``, inline: true },
                { name: '👤 Durduran', value: `${interaction.user.tag}`, inline: true },
                { name: '⏱️ Toplam Süre', value: formatDuration(streamDuration), inline: true },
                { name: '🎮 Yeni Durum', value: `🎯 ${lyuex.botSettings.oynuyor}`, inline: false }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'LYUEX • Yayın Sonlandırıldı' })
            .setTimestamp();

        // Yeni butonlar (restart ve panel)
        const newButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('twitch_start_quick')
                    .setLabel('▶️ Yeniden Başlat')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('▶️'),
                new ButtonBuilder()
                    .setCustomId('twitch_refresh_panel')
                    .setLabel('🔄 Panel Yenile')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🔄')
            );

        await interaction.editReply({ 
            embeds: [basariEmbed], 
            components: [newButtons] 
        });

        // Log gönder
        await sendTwitchLog(interaction, 'STREAM_STOP', twitchData.streamTitle, null, streamDuration);

    } catch (error) {
        console.error('Yayın durdurma hatası:', error);
        await interaction.followUp({ 
            content: '❌ Yayın durdurma işlemi başarısız!', 
            ephemeral: true 
        });
    }
}

// İstatistikleri görüntüle butonu
async function handleViewStats(interaction) {
    const twitchData = getTwitchData();
    
    const statsEmbed = new EmbedBuilder()
        .setColor(0x9146FF)
        .setTitle('📊 Twitch Yayın İstatistikleri')
        .setDescription('Mevcut yayın durumu ve detay bilgileri')
        .setThumbnail('https://static-cdn.jtvnw.net/jtv_user_pictures/8a6381c7-d0c0-4576-b179-38bd5ce1d6af-profile_image-300x300.png')
        .setFooter({ text: 'LYUEX • Twitch İstatistikleri' })
        .setTimestamp();

    if (twitchData.isStreaming) {
        const streamDuration = Math.floor((Date.now() - new Date(twitchData.startedAt).getTime()) / 1000);
        
        statsEmbed.addFields(
            { name: '🟢 Yayın Durumu', value: '**CANLI YAYIN**', inline: true },
            { name: '📺 Başlık', value: `\`${twitchData.streamTitle}\``, inline: true },
            { name: '🔗 URL', value: `[Yayına Git](${twitchData.twitchUrl})`, inline: true },
            { name: '⏰ Başlangıç', value: `<t:${Math.floor(new Date(twitchData.startedAt).getTime() / 1000)}:F>`, inline: true },
            { name: '⏱️ Süre', value: formatDuration(streamDuration), inline: true },
            { name: '👤 Başlatan', value: `<@${twitchData.startedBy}>`, inline: true },
            { name: '🎮 Bot Durumu', value: `${getStatusEmoji(interaction.client.user.presence?.status)} ${getStatusText(interaction.client.user.presence?.status)}`, inline: true },
            { name: '📱 Platform', value: 'Twitch.tv', inline: true },
            { name: '🌐 Görünürlük', value: 'Tüm Sunucular', inline: true }
        );
    } else {
        statsEmbed.addFields(
            { name: '🔴 Yayın Durumu', value: '**YAYIN YOK**', inline: true },
            { name: '🎮 Mevcut Aktivite', value: interaction.client.user.presence?.activities[0]?.name || 'Bilinmiyor', inline: true },
            { name: '📊 Aktivite Türü', value: getActivityTypeText(interaction.client.user.presence?.activities[0]?.type), inline: true },
            { name: '🎯 Bot Durumu', value: `${getStatusEmoji(interaction.client.user.presence?.status)} ${getStatusText(interaction.client.user.presence?.status)}`, inline: true },
            { name: '⏰ Son Güncelleme', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
            { name: '💡 Bilgi', value: 'Yayın başlatmak için komut kullanın', inline: true }
        );
    }

    await interaction.reply({ embeds: [statsEmbed], ephemeral: true });
}

// Hızlı başlat butonu
async function handleQuickStart(interaction) {
    await interaction.deferUpdate();

    const defaultTitle = 'LYUEX - Canlı Yayın';
    const defaultUrl = 'https://twitch.tv/lyuex';

    try {
        // Bot durumunu streaming olarak ayarla
        await interaction.client.user.setPresence({
            activities: [{
                name: defaultTitle,
                type: ActivityType.Streaming,
                url: defaultUrl
            }],
            status: 'online'
        });

        // Twitch verilerini kaydet
        const twitchData = {
            isStreaming: true,
            streamTitle: defaultTitle,
            twitchUrl: defaultUrl,
            startedAt: new Date().toISOString(),
            startedBy: interaction.user.id
        };

        saveTwitchData(twitchData);

        // Mesajı güncelle
        const basariEmbed = new EmbedBuilder()
            .setColor(0x9146FF)
            .setTitle('▶️ Hızlı Yayın Başlatıldı!')
            .setDescription(`Bot **varsayılan ayarlarla** yayına başladı!`)
            .addFields(
                { name: '📺 Yayın Başlığı', value: `\`${defaultTitle}\``, inline: true },
                { name: '🔗 Twitch URL', value: `[Yayına Git](${defaultUrl})`, inline: true },
                { name: '👤 Başlatan', value: `${interaction.user.tag}`, inline: true },
                { name: '⏰ Başlangıç', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '🎮 Durum', value: '🟢 **CANLI YAYIN**', inline: true },
                { name: '💡 Not', value: 'Hızlı başlatma kullanıldı', inline: true }
            )
            .setThumbnail('https://static-cdn.jtvnw.net/jtv_user_pictures/8a6381c7-d0c0-4576-b179-38bd5ce1d6af-profile_image-300x300.png')
            .setFooter({ text: 'LYUEX • Hızlı Yayın' })
            .setTimestamp();

        // Kontrol butonları
        const controlButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('twitch_stop_stream')
                    .setLabel('⏹️ Yayını Durdur')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('⏹️'),
                new ButtonBuilder()
                    .setCustomId('twitch_view_stats')
                    .setLabel('📊 İstatistikler')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📊'),
                new ButtonBuilder()
                    .setURL(defaultUrl)
                    .setLabel('🔗 Twitch\'e Git')
                    .setStyle(ButtonStyle.Link)
                    .setEmoji('🔗')
            );

        await interaction.editReply({ 
            embeds: [basariEmbed], 
            components: [controlButtons] 
        });

        // Log gönder
        await sendTwitchLog(interaction, 'STREAM_START', defaultTitle, defaultUrl);

    } catch (error) {
        console.error('Hızlı başlatma hatası:', error);
        await interaction.followUp({ 
            content: '❌ Hızlı yayın başlatma işlemi başarısız!', 
            ephemeral: true 
        });
    }
}

// Panel yenile butonu
async function handleRefreshPanel(interaction) {
    const twitchData = getTwitchData();
    
    const panelEmbed = new EmbedBuilder()
        .setColor(twitchData.isStreaming ? 0x9146FF : 0x36393F)
        .setTitle('🔄 Twitch Panel Yenilendi')
        .setDescription('Güncel durum bilgileri aşağıda gösterilmektedir')
        .addFields(
            { name: '📊 Streaming Durumu', value: twitchData.isStreaming ? '🟢 **CANLI YAYIN**' : '🔴 **YAYIN YOK**', inline: true },
            { name: '📺 Mevcut Aktivite', value: interaction.client.user.presence?.activities[0]?.name || 'Bilinmiyor', inline: true },
            { name: '🎯 Aktivite Türü', value: getActivityTypeText(interaction.client.user.presence?.activities[0]?.type), inline: true },
            { name: '⏰ Son Güncelleme', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
        )
        .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: 'LYUEX • Panel Yenilendi' })
        .setTimestamp();

    if (twitchData.isStreaming) {
        const streamDuration = Math.floor((Date.now() - new Date(twitchData.startedAt).getTime()) / 1000);
        panelEmbed.addFields(
            { name: '📺 Yayın Başlığı', value: `\`${twitchData.streamTitle}\``, inline: true },
            { name: '⏱️ Süre', value: formatDuration(streamDuration), inline: true }
        );
    }

    await interaction.reply({ embeds: [panelEmbed], ephemeral: true });
}

// Yardımcı fonksiyonlar (diğer dosyadan kopyalandı)
function getTwitchData() {
    const dataPath = './data/twitchStatus.json';
    try {
        if (fs.existsSync(dataPath)) {
            return JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
        }
    } catch (error) {
        console.error('Twitch data okuma hatası:', error);
    }
    return { isStreaming: false };
}

function saveTwitchData(data) {
    const dataPath = './data/twitchStatus.json';
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

function clearTwitchData() {
    const dataPath = './data/twitchStatus.json';
    const clearedData = { isStreaming: false };
    fs.writeFileSync(dataPath, JSON.stringify(clearedData, null, 2));
}

function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}s ${minutes}d ${secs}s`;
    } else if (minutes > 0) {
        return `${minutes}d ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

function getActivityTypeText(type) {
    switch (type) {
        case ActivityType.Playing: return '🎮 Oynuyor';
        case ActivityType.Streaming: return '📺 Yayında';
        case ActivityType.Listening: return '🎵 Dinliyor';
        case ActivityType.Watching: return '👀 İzliyor';
        case ActivityType.Competing: return '🏆 Yarışıyor';
        default: return '❓ Bilinmiyor';
    }
}

function getStatusEmoji(status) {
    switch (status) {
        case 'online': return '🟢';
        case 'idle': return '🟡';
        case 'dnd': return '🔴';
        case 'invisible': return '⚫';
        default: return '❓';
    }
}

function getStatusText(status) {
    switch (status) {
        case 'online': return 'Çevrimiçi';
        case 'idle': return 'Boşta';
        case 'dnd': return 'Rahatsız Etmeyin';
        case 'invisible': return 'Görünmez';
        default: return 'Bilinmiyor';
    }
}

async function sendTwitchLog(interaction, action, title, url, duration = null) {
    try {
        const logChannelId = lyuex.log?.channels?.system_logs;
        if (!logChannelId) return;

        const logChannel = interaction.guild.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const logEmbed = new EmbedBuilder()
            .setColor(action === 'STREAM_START' ? 0x9146FF : 0xFF4444)
            .setTitle(`📺 Twitch ${action === 'STREAM_START' ? 'Yayını Başlatıldı' : 'Yayını Durduruldu'}`)
            .addFields(
                { name: '👤 İşlemi Yapan', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                { name: '🔧 İşlem', value: action === 'STREAM_START' ? 'Yayın Başlatma' : 'Yayın Durdurma', inline: true },
                { name: '📺 Başlık', value: title || 'Bilinmiyor', inline: true }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: 'LYUEX • Twitch Log' })
            .setTimestamp();

        if (url && action === 'STREAM_START') {
            logEmbed.addFields({ name: '🔗 Twitch URL', value: `[Yayına Git](${url})`, inline: true });
        }

        if (duration && action === 'STREAM_STOP') {
            logEmbed.addFields({ name: '⏱️ Yayın Süresi', value: formatDuration(duration), inline: true });
        }

        await logChannel.send({ embeds: [logEmbed] });
    } catch (error) {
        console.error('Twitch log mesajı gönderme hatası:', error);
    }
}