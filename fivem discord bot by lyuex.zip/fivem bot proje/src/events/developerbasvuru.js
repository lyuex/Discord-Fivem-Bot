// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder, ButtonStyle, ButtonBuilder, ChannelType, ButtonInteraction, ButtonComponent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isButton() && interaction.customId === 'lyuexinmodali') {
            const lyuexinyetkilimodali = new ModalBuilder()
                .setCustomId('lyuexinmodali')
                .setTitle('For Development');

            const lyuexinsordugusorular1 = new TextInputBuilder()
                .setCustomId('lyuexinsordugusorular1')
                .setLabel('Kendinizi tanıtın')
                .setPlaceholder('isim - yaş - il')
                .setMinLength(10)
                .setStyle(TextInputStyle.Short);

            const lyuexinsordugusorular2 = new TextInputBuilder()
                .setCustomId('lyuexinsordugusorular2')
                .setLabel('Discordu hangi platformdan giriyorsunuz?')
                .setPlaceholder('pc - telefon vb.')
                .setStyle(TextInputStyle.Short);

            const lyuexinsordugusorular3 = new TextInputBuilder()
                .setCustomId('lyuexinsordugusorular3')
                .setLabel('Hangi Yazılım Dillerini biliyorsunuz? ')
                .setPlaceholder('Teste tabi tutulucaksınız. Düz yetkili için boş bırakın.')
                .setMinLength(5)
                .setRequired(false)
                .setStyle(TextInputStyle.Short);

            const lyuexinsordugusorular4 = new TextInputBuilder()
                .setCustomId('lyuexinsordugusorular4')
                .setLabel('Bize ne katabilirsiniz??')
                .setMinLength(35)
                .setStyle(TextInputStyle.Paragraph);
                
            const lyuexinsordugusorular5 = new TextInputBuilder()
            .setCustomId('lyuexinsordugusorular5')
            .setLabel('Bizden beklentiniz nedir?')
            .setPlaceholder('ve Hangi Yazılım Dillerini biliyorsunuz?')
            .setMinLength(35)
            .setPlaceholder('??')
            .setStyle(TextInputStyle.Paragraph);

            const birincisoru = new ActionRowBuilder().addComponents(lyuexinsordugusorular1);
            const ikincisoru = new ActionRowBuilder().addComponents(lyuexinsordugusorular2);
            const ucuncusoru = new ActionRowBuilder().addComponents(lyuexinsordugusorular3);
            const dorduncusoru = new ActionRowBuilder().addComponents(lyuexinsordugusorular4);
            const besincisoru = new ActionRowBuilder().addComponents(lyuexinsordugusorular5);

            lyuexinyetkilimodali.addComponents(birincisoru, ikincisoru, ucuncusoru, dorduncusoru, besincisoru);
            await interaction.showModal(lyuexinyetkilimodali);
 } else if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'lyuexinmodali') {
            // Önce interaction'ı defer et (3 saniye timeout'u önlemek için)
            await interaction.deferReply({ ephemeral: true });
            
            const lyuexinsordugusorular1 = interaction.fields.getTextInputValue('lyuexinsordugusorular1');
            const lyuexinsordugusorular2 = interaction.fields.getTextInputValue('lyuexinsordugusorular2');
            const lyuexinsordugusorular3 = interaction.fields.getTextInputValue('lyuexinsordugusorular3');
            const lyuexinsordugusorular4 = interaction.fields.getTextInputValue('lyuexinsordugusorular4');
            const lyuexinsordugusorular5 = interaction.fields.getTextInputValue('lyuexinsordugusorular5');
            
            // Log kanalını al
            const logChannelId = lyuex.botSettings?.LOG_CHANNEL_ID;
            const lyuexinyetkililogodasi = logChannelId ? interaction.guild.channels.cache.get(logChannelId) : null;
            
            if (!lyuexinyetkililogodasi) {
                console.error('❌ Log kanalı bulunamadı! Kanal ID:', logChannelId);
                return await interaction.editReply({
                    content: '❌ **Hata!** Log kanalı yapılandırılmamış. Lütfen yönetici ile iletişime geçin.'
                });
            }
            
            const lyuexinyetkiliembedi = new EmbedBuilder()
            .setTitle('🚀 Yeni Developer/Yetkili Başvurusu')
            .setDescription(`👤 **Başvuran:** <@${interaction.member.id}> (${interaction.member.user.tag})\n🆔 **Kullanıcı ID:** ${interaction.member.id}\n⏰ **Başvuru Tarihi:** <t:${Math.floor(Date.now() / 1000)}:F>`)
            .setColor(0x5865F2)
            .setThumbnail(interaction.member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: '👤 Kişisel Bilgiler',
                    value: `\`\`\`${lyuexinsordugusorular1}\`\`\``,
                    inline: false
                },
                {
                    name: '💻 Platform',
                    value: `\`\`\`${lyuexinsordugusorular2}\`\`\``,
                    inline: true
                },
                {
                    name: '🔧 Yazılım Dilleri',
                    value: `\`\`\`${lyuexinsordugusorular3 || 'Belirtilmedi'}\`\`\``,
                    inline: true
                },
                {
                    name: '💡 Bize Katkıları',
                    value: `\`\`\`${lyuexinsordugusorular4}\`\`\``,
                    inline: false
                },
                {
                    name: '🎯 Beklentiler',
                    value: `\`\`\`${lyuexinsordugusorular5}\`\`\``,
                    inline: false
                },
                {
                    name: '📊 Başvuru Bilgileri',
                    value: `🔄 **Durum:** ⏳ Değerlendiriliyor\n🎭 **Tip:** Developer/Yetkili\n⚡ **Öncelik:** Yüksek`,
                    inline: false
                }
            )
            .setFooter({ 
                text: `${lyuex.server.serverismi} • Başvuru Sistemi`,
                iconURL: interaction.guild.iconURL({ dynamic: true })
            })
            .setTimestamp()
            .setTimestamp();
            
            const lyuexinyetkilikabulactionu = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('lyuexinyetkilikabulbuttonu')
                    .setLabel('✅ Kabul Et')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('lyuexinyetkiliredbutonu')
                    .setLabel('❌ Reddet')
                    .setStyle(ButtonStyle.Danger)
            );

            const lyuexinyetkilirolleri = lyuex.basvuru.developerbasvuru;
            const lyuexinyetkikbasvurusuatanmali = interaction.member;
            // Başvuru mesajını gönder
            const applicationMessage = await lyuexinyetkililogodasi.send({ 
                content: `<@&${lyuex.yetkili.kurucu}>, <@${interaction.member.id}> yetkili başvurusu gönderdi!`, 
                embeds: [lyuexinyetkiliembedi], 
                components: [lyuexinyetkilikabulactionu]
            });
            
            // Button collector oluştur
            const collector = applicationMessage.createMessageComponentCollector({ time: 24 * 60 * 60 * 1000 }); // 24 saat
            
            collector.on('collect', async buttonInteraction => {
                if (buttonInteraction.customId === 'lyuexinyetkilikabulbuttonu') {
                    await buttonInteraction.update({ 
                        content: `✅ **Yetkili başvurusu kabul edildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Kabul Eden:** <@${buttonInteraction.user.id}>\n⏰ **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`, 
                        components: [] 
                    });
                    
                    try {
                        await lyuexinyetkikbasvurusuatanmali.roles.add(lyuexinyetkilirolleri);
                        
                        // DM bildirimi gönder
                        try {
                            const acceptDM = new EmbedBuilder()
                                .setTitle('🎉 Başvurunuz Kabul Edildi!')
                                .setDescription(`Tebrikler! **${lyuex.server.serverismi}** sunucusundaki **Developer/Yetkili** başvurunuz kabul edildi.`)
                                .setColor(0x00FF00)
                                .addFields(
                                    {
                                        name: '✅ Başvuru Durumu',
                                        value: 'Kabul Edildi',
                                        inline: true
                                    },
                                    {
                                        name: '👑 Kabul Eden',
                                        value: `${buttonInteraction.user.tag}`,
                                        inline: true
                                    },
                                    {
                                        name: '🎭 Verilen Rol',
                                        value: `<@&${lyuexinyetkilirolleri}>`,
                                        inline: true
                                    },
                                    {
                                        name: '📝 Sonraki Adımlar',
                                        value: 'Sunucuya geri dönüp yeni rolünüzü kontrol edebilirsiniz. Hoş geldiniz!',
                                        inline: false
                                    }
                                )
                                .setFooter({ 
                                    text: `${lyuex.server.serverismi} • Başvuru Sistemi`,
                                    iconURL: interaction.guild.iconURL({ dynamic: true })
                                })
                                .setTimestamp();
                            
                            await interaction.member.send({ embeds: [acceptDM] });
                        } catch (dmError) {
                            console.log('DM gönderilemedi (kullanıcı DM kapalı olabilir):', dmError.message);
                        }
                        
                        await lyuexinyetkililogodasi.send({
                            content: `🎉 **Developer/Yetkili Başvurusu Kabul Edildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Kabul Eden:** <@${buttonInteraction.user.id}>\n📝 **Verilen Rol:** <@&${lyuexinyetkilirolleri}>`
                        });
                    } catch (error) {
                        console.error('Developer rol verme hatası:', error);
                        await lyuexinyetkililogodasi.send('❌ **Hata:** Developer rolü verilemedi!');
                    }
                } else if (buttonInteraction.customId === 'lyuexinyetkiliredbutonu') {
                    await buttonInteraction.update({ 
                        content: `❌ **Developer/Yetkili başvurusu reddedildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Redden:** <@${buttonInteraction.user.id}>\n⏰ **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`, 
                        components: [] 
                    });
                    
                    // DM bildirimi gönder
                    try {
                        const rejectDM = new EmbedBuilder()
                            .setTitle('❌ Başvurunuz Reddedildi')
                            .setDescription(`Üzgünüz, **${lyuex.server.serverismi}** sunucusundaki **Developer/Yetkili** başvurunuz reddedildi.`)
                            .setColor(0xFF0000)
                            .addFields(
                                {
                                    name: '❌ Başvuru Durumu',
                                    value: 'Reddedildi',
                                    inline: true
                                },
                                {
                                    name: '👑 Redden',
                                    value: `${buttonInteraction.user.tag}`,
                                    inline: true
                                },
                                {
                                    name: '🔄 Tekrar Başvuru',
                                    value: 'Gelecekte tekrar başvurabilirsiniz.',
                                    inline: true
                                },
                                {
                                    name: '💡 Tavsiye',
                                    value: 'Eksik gördüğünüz alanları geliştirip daha sonra tekrar deneyebilirsiniz.',
                                    inline: false
                                }
                            )
                            .setFooter({ 
                                text: `${lyuex.server.serverismi} • Başvuru Sistemi`,
                                iconURL: interaction.guild.iconURL({ dynamic: true })
                            })
                            .setTimestamp();
                        
                        await interaction.member.send({ embeds: [rejectDM] });
                    } catch (dmError) {
                        console.log('DM gönderilemedi (kullanıcı DM kapalı olabilir):', dmError.message);
                    }
                    
                    await lyuexinyetkililogodasi.send({
                        content: `❌ **Developer/Yetkili Başvurusu Reddedildi!**\n👤 **Başvuran:** <@${interaction.member.id}>\n👑 **Redden:** <@${buttonInteraction.user.id}>`
                    });
                }
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    applicationMessage.edit({ 
                        content: applicationMessage.content + '\n\n⏰ **Bu başvuru zaman aşımına uğradı.**', 
                        components: [] 
                    }).catch(console.error);
                }
            });
            
            await interaction.editReply({ 
                content: `✅ **DEVELOPER/YETKİLİ BAŞVURUNUZ BAŞARIYLA GÖNDERİLDİ!**\n\n` +
                        `📋 **Başvuru Özeti:**\n` +
                        `👤 **Kişisel Bilgiler:** ${lyuexinsordugusorular1}\n` +
                        `💻 **Platform:** ${lyuexinsordugusorular2}\n` +
                        `🔧 **Yazılım Dilleri:** ${lyuexinsordugusorular3 || 'Belirtilmedi'}\n` +
                        `💡 **Katkılarınız:** ${lyuexinsordugusorular4}\n` +
                        `🎯 **Beklentileriniz:** ${lyuexinsordugusorular5}\n\n` +
                        `⏰ **Başvurunuz 24-48 saat içinde değerlendirilecektir.**`
            });
        }
    }
};





