// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, AuditLogEvent, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildEmojiDelete,
    async execute(emoji, client) {
        const guild = emoji.guild;
        const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
        
        if (!logChannelId) return;
        
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        try {
            const fetchedLogs = await guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.EmojiDelete
            });

            const emojiLog = fetchedLogs.entries.first();
            if (!emojiLog) return;

            const { executor } = emojiLog;

            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('Emoji Silindi!')
                .setThumbnail(emoji.guild.iconURL({ dynamic: true }))
                .setDescription(`Kişi: \n > <@${executor.id}> - ${executor.id} \n Emoji Bilgileri: \n > **${emoji.name}** - ${emoji.id}`)
                .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
                .setTimestamp();
            
            await logChannel.send({ embeds: [embed] }).catch(console.error);
        } catch (error) {
            console.error('EmojiDelete event error:', error);
        }
    },
};





