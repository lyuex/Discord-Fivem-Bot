// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildStickerCreate,
    async execute(sticker) {
        if (!lyuex.log?.enabled) return;
        if (!lyuex.log?.events?.emoji_create) return; // Sticker'lar emoji olarak loglanıyor

        const logChannel = sticker.guild.channels.cache.get(lyuex.log.channels.system_logs);
        if (!logChannel) return;

        try {
            const fetchedLogs = await sticker.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.StickerCreate
            });

            const stickerLog = fetchedLogs.entries.first();
            if (!stickerLog) return;

            const { executor } = stickerLog;

            const embed = new EmbedBuilder()
                .setColor(0x00FF1A)
                .setTitle('🏷️ Sticker Oluşturuldu!')
                .setThumbnail(sticker.guild.iconURL({ dynamic: true }))
                .setDescription(`
                    **Oluşturan Kişi:**
                    <@${executor.id}> - ${executor.id}
                    **Oluşturulan Sticker:**
                    > ${sticker.name} - ID: ${sticker.id}
                `)
                .addFields(
                    { name: '🏷️ Sticker Adı', value: `\`${sticker.name}\``, inline: true },
                    { name: '🆔 Sticker ID', value: `\`${sticker.id}\``, inline: true },
                    { name: '👤 Oluşturan', value: `<@${executor.id}>\n${executor.tag}`, inline: true },
                    { name: '📝 Açıklama', value: sticker.description || 'Açıklama yok', inline: false },
                    { name: '🏷️ Etiketler', value: sticker.tags?.length > 0 ? sticker.tags.join(', ') : 'Etiket yok', inline: false },
                    { name: '🎨 Format', value: sticker.format === 1 ? 'PNG' : sticker.format === 2 ? 'APNG' : 'Lottie', inline: true },
                    { name: '📊 Boyut', value: `${sticker.width}x${sticker.height}`, inline: true },
                    { name: '⏰ Oluşturulma', value: `<t:${Math.floor(sticker.createdTimestamp / 1000)}:F>`, inline: true }
                )
                .setImage(sticker.url)
                .setFooter({
                    text: `LYUEX Gelişmiş Log Sistemi • Sticker Yönetimi`,
                    iconURL: sticker.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Sticker oluşturma log hatası:', error);
        }
    },
};





