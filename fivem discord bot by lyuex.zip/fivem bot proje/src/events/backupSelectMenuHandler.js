// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events } = require('discord.js');
const BackupManager = require('../utils/backupManager');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isStringSelectMenu()) return;
        
        if (interaction.customId === 'backup_restore_select') {
            try {
                // Yetki kontrolü - Sadece sunucu sahibi ve bot developer'ı
                const config = require('../../lyuex.json');
                const isOwner = interaction.guild.ownerId === interaction.user.id;
                const isDeveloper = interaction.user.id === '1423320414284943420'; // Bot developer ID
                
                if (!isOwner && !isDeveloper) {
                    return await interaction.reply({
                        content: '❌ **Bu işlemi sadece sunucu sahibi ve bot developer\'ı yapabilir!**',
                        ephemeral: true
                    });
                }

                await interaction.deferReply();

                const backupName = interaction.values[0];
                const backupManager = new BackupManager(interaction.client);

                // Backup geri yükleme işlemi
                const result = await backupManager.restoreBackup(backupName);

                if (result.success) {
                    await interaction.editReply({
                        content: `✅ **Backup başarıyla geri yüklendi!**\n\n` +
                                `📦 **Backup:** \`${backupName}\`\n` +
                                `📂 **Geri yüklenen dosyalar:** ${result.fileCount}\n` +
                                `⏱️ **Süre:** ${result.duration}ms\n\n` +
                                `🔄 Bot yeniden başlatılması öneriliyor.`
                    });
                } else {
                    await interaction.editReply({
                        content: `❌ **Backup geri yükleme hatası:**\n\`\`\`${result.error}\`\`\``
                    });
                }
            } catch (error) {
                console.error('Backup restore select menu error:', error);
                
                const errorMessage = interaction.deferred || interaction.replied ? 
                    { content: `❌ **Backup geri yüklenirken hata oluştu:**\n\`\`\`${error.message}\`\`\`` } :
                    { content: `❌ **Backup geri yüklenirken hata oluştu:**\n\`\`\`${error.message}\`\`\``, ephemeral: true };
                
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply(errorMessage);
                } else {
                    await interaction.reply(errorMessage);
                }
            }
        }
    }
};




