// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const { catchError } = require('../functions/hatamesajì');
const lyuex = require('../../lyuex.json');
const guvenli = require('../commands/guvenli');

module.exports = {
    name: Events.InviteCreate,
    async execute(invite, client) {
        try {
            const guild = invite.guild;
            const inviter = await client.users.fetch(invite.inviter.id);
            
            // Davet oluşturan kişi güvenli değilse kontrol et
            if (inviter && !guvenli.isUserSafe(guild.id, inviter.id)) {
                // İhlal sayısını artır (eğer vanity URL ise)
                if (invite.code && (invite.code === guild.vanityURLCode || guild.vanityURLCode === invite.code)) {
                    const violationCount = guvenli.trackViolation(guild.id, inviter.id, 'Davet Bağlantısı Değişikliği', guild);
                    
                    // İhlal log embed'i
                    const violationEmbed = new EmbedBuilder()
                        .setTitle('🚨 Güvenli Sistem İhlali - Vanity URL Değişikliği')
                        .setDescription(`**${inviter.tag}** vanity URL'ini değiştirdi.`)
                        .addFields(
                            { name: '👤 İhlal Yapan', value: `${inviter.tag} (${inviter.id})`, inline: true },
                            { name: '🔗 Davet Kodu', value: `${invite.code}`, inline: true },
                            { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                        )
                        .setColor(0xFF9800)
                        .setTimestamp();
                    
                    // Log kanalına gönder
                    const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                    if (logChannelId) {
                        const logChannel = client.channels.cache.get(logChannelId);
                        if (logChannel) {
                            await logChannel.send({ embeds: [violationEmbed] });
                        }
                    }
                    
                    // İhlal limitini kontrol et
                    await guvenli.handleViolationLimit(guild, inviter.id, 'Davet Bağlantısı Değişikliği', violationCount);
                }
            }

            // Normal loglama
            const channel = client.channels.cache.get(lyuex.botSettings.LOG_CHANNEL_ID);
            if (channel) {
                const embed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle('Yeni Davet Oluşturuldu')
                    .setDescription(`**Kişi:** \n > <@${inviter.id}> - (${inviter.id})\n **İnvite Kodu:**\n > ${invite.code}`)
                    .addFields(
                        { name: '📁 Hedef Kanal', value: invite.channel ? `<#${invite.channel.id}>` : 'Bilinmiyor', inline: true },
                        { name: '👥 Kullanım Sayısı', value: `${invite.uses || 0}`, inline: true },
                        { name: '⏰ Oluşturulma', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                    .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
                    .setTimestamp();
                channel.send({ embeds: [embed] });
            }
        } catch (error) {
            console.error('Davet oluşturma log hatası:', error);
            catchError(client, 'inviteCreate.js', error.message);
        }
    },
};




