// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton()) return;
        
        const customId = interaction.customId;
        
        // Toplu rol button'ları
        if (customId.startsWith('confirm_give_all_') || 
            customId.startsWith('confirm_remove_all_') || 
            customId.startsWith('confirm_swap_') ||
            customId.startsWith('cancel_')) {
            
            if (customId.startsWith('confirm_give_all_')) {
                const parts = customId.split('_');
                const roleId = parts[3];
                const includeBots = parts[4] === 'true';
                
                await handleGiveToEveryoneConfirm(interaction, roleId, includeBots);
                
            } else if (customId.startsWith('confirm_remove_all_')) {
                const roleId = customId.split('_')[3];
                await handleRemoveFromEveryoneConfirm(interaction, roleId);
                
            } else if (customId.startsWith('confirm_swap_')) {
                const parts = customId.split('_');
                const oldRoleId = parts[2];
                const newRoleId = parts[3];
                await handleRoleSwapConfirm(interaction, oldRoleId, newRoleId);
                
            } else if (customId.startsWith('cancel_')) {
                const cancelEmbed = new EmbedBuilder()
                    .setTitle('❌ **İŞLEM İPTAL EDİLDİ**')
                    .setDescription('Toplu rol işlemi iptal edildi.')
                    .setColor(0x607D8B)
                    .setTimestamp();
                
                await interaction.update({ embeds: [cancelEmbed], components: [] });
            }
        }
    }
};

async function handleGiveToEveryoneConfirm(interaction, roleId, includeBots) {
    const role = interaction.guild.roles.cache.get(roleId);
    
    if (!role) {
        return interaction.update({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **ROL BULUNAMADI**')
                    .setDescription('Belirtilen rol artık mevcut değil.')
                    .setColor(0xFF6B6B)
            ],
            components: []
        });
    }

    const progressEmbed = new EmbedBuilder()
        .setTitle('⏳ **TOPLU ROL VERİLİYOR...**')
        .setDescription(`**${role.name}** rolü ${includeBots ? 'tüm üyelere' : 'tüm gerçek kullanıcılara'} veriliyor...`)
        .addFields(
            { name: '🔄 Durum', value: 'İşlem başlatıldı...', inline: true },
            { name: '⏰ Tahmini Süre', value: '~2-5 dakika', inline: true }
        )
        .setColor(0xFFC107)
        .setTimestamp();

    await interaction.update({ embeds: [progressEmbed], components: [] });

    const members = await interaction.guild.members.fetch();
    const targetMembers = includeBots ? members : members.filter(member => !member.user.bot);
    
    const successfulUsers = [];
    const failedUsers = [];
    let processed = 0;

    for (const [, member] of targetMembers) {
        try {
            if (!member.roles.cache.has(role.id)) {
                await member.roles.add(role);
                successfulUsers.push(member.user);
            }
            
            processed++;
            
            // Her 10 işlemde bir progress güncelle
            if (processed % 10 === 0) {
                const updateEmbed = new EmbedBuilder()
                    .setTitle('⏳ **TOPLU ROL VERİLİYOR...**')
                    .setDescription(`**${role.name}** rolü veriliyor...`)
                    .addFields(
                        { name: '🔄 İlerleme', value: `${processed}/${targetMembers.size} (${Math.round((processed/targetMembers.size)*100)}%)`, inline: true },
                        { name: '✅ Başarılı', value: `${successfulUsers.length}`, inline: true },
                        { name: '❌ Başarısız', value: `${failedUsers.length}`, inline: true }
                    )
                    .setColor(0xFFC107)
                    .setTimestamp();

                await interaction.editReply({ embeds: [updateEmbed] });
            }
            
            // Rate limit için bekleme
            await new Promise(resolve => setTimeout(resolve, 100));
            
        } catch (error) {
            failedUsers.push({ user: member.user, reason: error.message });
        }
    }

    const resultEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Toplu Rol Verme Tamamlandı`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('✅ **TOPLU ROL VERME TAMAMLANDI**')
        .setDescription(`**${role.name}** rolü ${includeBots ? 'tüm üyelere' : 'tüm gerçek kullanıcılara'} verildi.`)
        .addFields(
            { name: '📊 İstatistikler', value: `
**Toplam İşlem:** ${processed}
**Başarılı:** ${successfulUsers.length}
**Başarısız:** ${failedUsers.length}
**Başarı Oranı:** ${Math.round((successfulUsers.length/processed)*100)}%
            `, inline: true },
            { name: '🎭 Rol Bilgileri', value: `
**Rol:** ${role.name}
**Renk:** ${role.hexColor}
**Yeni Üye Sayısı:** ${role.members.size}
            `, inline: true }
        )
        .setColor(0x4CAF50)
        .setFooter({ text: `Toplu Rol Sistemi • ${successfulUsers.length} başarılı işlem`, iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    await interaction.editReply({ embeds: [resultEmbed] });
    
    // Log gönder
    await sendMassRoleLog(interaction, role, successfulUsers, 'TOPLU VERİLDİ', includeBots);
}

async function handleRemoveFromEveryoneConfirm(interaction, roleId) {
    const role = interaction.guild.roles.cache.get(roleId);
    
    if (!role) {
        return interaction.update({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **ROL BULUNAMADI**')
                    .setDescription('Belirtilen rol artık mevcut değil.')
                    .setColor(0xFF6B6B)
            ],
            components: []
        });
    }

    const progressEmbed = new EmbedBuilder()
        .setTitle('⏳ **TOPLU ROL ALINIYOR...**')
        .setDescription(`**${role.name}** rolü tüm üyelerden alınıyor...`)
        .setColor(0xFFC107)
        .setTimestamp();

    await interaction.update({ embeds: [progressEmbed], components: [] });

    const roleMembers = role.members;
    const successfulUsers = [];
    const failedUsers = [];
    let processed = 0;

    for (const [, member] of roleMembers) {
        try {
            await member.roles.remove(role);
            successfulUsers.push(member.user);
            processed++;
            
            if (processed % 5 === 0) {
                const updateEmbed = new EmbedBuilder()
                    .setTitle('⏳ **TOPLU ROL ALINIYOR...**')
                    .setDescription(`**${role.name}** rolü alınıyor...`)
                    .addFields(
                        { name: '🔄 İlerleme', value: `${processed}/${roleMembers.size}`, inline: true },
                        { name: '✅ Başarılı', value: `${successfulUsers.length}`, inline: true }
                    )
                    .setColor(0xFFC107)
                    .setTimestamp();

                await interaction.editReply({ embeds: [updateEmbed] });
            }
            
            await new Promise(resolve => setTimeout(resolve, 100));
            
        } catch (error) {
            failedUsers.push({ user: member.user, reason: error.message });
        }
    }

    const resultEmbed = new EmbedBuilder()
        .setTitle('✅ **TOPLU ROL ALMA TAMAMLANDI**')
        .setDescription(`**${role.name}** rolü tüm üyelerden alındı.`)
        .addFields(
            { name: '📊 Sonuç', value: `**Başarılı:** ${successfulUsers.length}\n**Başarısız:** ${failedUsers.length}`, inline: true }
        )
        .setColor(0xF44336)
        .setTimestamp();

    await interaction.editReply({ embeds: [resultEmbed] });
    await sendMassRoleLog(interaction, role, successfulUsers, 'TOPLU ALINDI', false);
}

async function handleRoleSwapConfirm(interaction, oldRoleId, newRoleId) {
    const oldRole = interaction.guild.roles.cache.get(oldRoleId);
    const newRole = interaction.guild.roles.cache.get(newRoleId);
    
    if (!oldRole || !newRole) {
        return interaction.update({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **ROL BULUNAMADI**')
                    .setDescription('Belirtilen rollerden biri artık mevcut değil.')
                    .setColor(0xFF6B6B)
            ],
            components: []
        });
    }

    const progressEmbed = new EmbedBuilder()
        .setTitle('🔄 **ROL DEĞİŞTİRİLİYOR...**')
        .setDescription(`**${oldRole.name}** rolü **${newRole.name}** ile değiştiriliyor...`)
        .setColor(0xFFC107)
        .setTimestamp();

    await interaction.update({ embeds: [progressEmbed], components: [] });

    const oldRoleMembers = oldRole.members;
    const successfulUsers = [];
    
    for (const [, member] of oldRoleMembers) {
        try {
            await member.roles.remove(oldRole);
            await member.roles.add(newRole);
            successfulUsers.push(member.user);
            
            await new Promise(resolve => setTimeout(resolve, 200));
        } catch (error) {
            console.error(`Rol değiştirme hatası (${member.user.tag}):`, error);
        }
    }

    const resultEmbed = new EmbedBuilder()
        .setTitle('✅ **ROL DEĞİŞTİRME TAMAMLANDI**')
        .setDescription(`**${oldRole.name}** rolündeki ${successfulUsers.length} üyenin rolü **${newRole.name}** ile değiştirildi.`)
        .setColor(0x4CAF50)
        .setTimestamp();

    await interaction.editReply({ embeds: [resultEmbed] });
}

async function sendMassRoleLog(interaction, role, users, action, includeBots) {
    const logChannel = interaction.guild.channels.cache.find(channel => 
        channel.name === 'role-log' || 
        channel.name === 'rol-log' || 
        channel.name === 'toplu-rol-log'
    );
    
    if (!logChannel) return;

    const logEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • ${action}`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle(`🌐 **${action}**`)
        .setDescription(`**${role.name}** rolü toplu olarak işlendi.`)
        .addFields(
            { name: '👤 Yetkili', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
            { name: '🎭 Rol', value: `${role.name} (${role.id})`, inline: true },
            { name: '📊 Etkilenen', value: `${users.length} kullanıcı`, inline: true },
            { name: '🤖 Bot Dahil', value: includeBots ? '✅ Evet' : '❌ Hayır', inline: true },
            { name: '⏰ İşlem Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
        )
        .setColor(role.hexColor || '#2196F3')
        .setFooter({ text: 'Toplu Rol Sistemi • Kitle İşlem Logu', iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

    await logChannel.send({ embeds: [logEmbed] });
}




