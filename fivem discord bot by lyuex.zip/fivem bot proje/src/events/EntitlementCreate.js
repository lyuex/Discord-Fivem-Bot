// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.EntitlementCreate,
    async execute(entitlement) {
        const guild = entitlement.guild;
        
        // lyuex.json'dan log kanalını al
        const logChannelId = lyuex.log?.channels?.system_logs || lyuex.botSettings?.LOG_CHANNEL_ID;
        let logChannel = null;
        
        if (logChannelId) {
            logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        }
        
        if (!logChannel) {
            // Artık hata vermeyeceğiz, sessizce geçeceğiz
            return;
        }
        const executorName = `<@${entitlement.user.id}>`;
        const embed = createEmbed(executorName, guild.iconURL());
        logChannel.send({ embeds: [embed] }).catch(console.error);
    },
};

function createEmbed(executor, iconURL) {
    const embed = new EmbedBuilder()
        .setColor(0xFFF700)
        .setTitle('Üyelik Hakları Oluşturuldu')
        .setDescription(`
            **Kim Tarafından:**
            ${executor}
        `)
        .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
        .setTimestamp();
    return embed;
}




