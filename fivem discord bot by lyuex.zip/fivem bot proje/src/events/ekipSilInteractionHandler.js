// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
module.exports = {
    async execute(interaction) {
        try {
            console.log(`[EkipSilInteractionHandler] Processing: ${interaction.customId}`);
            
            // Ekip silme işlemlerini buraya ekleyin
            await interaction.reply({
                content: '🗑️ Ekip silme işlemi tamamlandı!',
                ephemeral: true
            });

        } catch (error) {
            console.error('Ekip sil interaction handler hatası:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Bir hata oluştu!',
                    ephemeral: true
                }).catch(() => {});
            }
        }
    }
};