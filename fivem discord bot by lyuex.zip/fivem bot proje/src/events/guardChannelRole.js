// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');

const PROTECTION_FILE = path.join(__dirname, '..', 'data', 'protection.json');

// Kullanıcı aksiyon tracker'ı (import from guardProtection.js)
const userActions = new Map();

async function readProtectionData() {
    try {
        const data = await fs.readFile(PROTECTION_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

async function isUserWhitelisted(guildId, userId) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.whitelistUsers?.includes(userId) || false;
}

async function isProtectionEnabled(guildId, protectionType) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.enabled && protectionData[guildId]?.settings?.[protectionType];
}

async function logAction(guild, embed) {
    const protectionData = await readProtectionData();
    const logChannelId = protectionData[guild.id]?.logChannel;
    
    if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] }).catch(console.error);
        }
    }
}

function trackUserAction(guildId, userId, actionType) {
    const key = `${guildId}_${userId}`;
    const now = Date.now();
    
    if (!userActions.has(key)) {
        userActions.set(key, []);
    }
    
    const actions = userActions.get(key);
    actions.push({ type: actionType, timestamp: now });
    
    // 1 dakikadan eski aksiyonları temizle
    const filteredActions = actions.filter(action => now - action.timestamp < 60000);
    userActions.set(key, filteredActions);
    
    return filteredActions.length;
}

async function handleSuspiciousActivity(guild, userId, actionType, actionCount) {
    const protectionData = await readProtectionData();
    const maxActions = protectionData[guild.id]?.settings?.maxActions || 3;
    
    if (actionCount >= maxActions) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member && !member.permissions.has('Adlyuexstrator')) {
            try {
                await member.ban({ 
                    reason: `Guard sistemi: Şüpheli aktivite tespit edildi (${actionType} - ${actionCount} kez)`,
                    deleteMessageDays: 1
                });
                
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 Otomatik Yasaklama')
                    .setDescription(`**${member.user.tag}** şüpheli aktivite nedeniyle yasaklandı.`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.id})`, inline: true },
                        { name: '⚠️ Tespit Edilen Aktivite', value: actionType, inline: true },
                        { name: '📊 Aksiyon Sayısı', value: `${actionCount}/${maxActions}`, inline: true }
                    )
                    .setColor(0xF44336)
                    .setTimestamp();
                
                await logAction(guild, logEmbed);
                userActions.delete(`${guild.id}_${userId}`);
                
            } catch (error) {
                console.error('Kullanıcı yasaklanırken hata:', error);
            }
        }
    }
}

module.exports = [
    // Kanal Silme Koruması
    {
        name: Events.ChannelDelete,
        async execute(channel) {
            const guildId = channel.guild.id;
            
            if (await isProtectionEnabled(guildId, 'antiChannel')) {
                const auditLogs = await channel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelDelete,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const deleteLog = auditLogs.entries.first();
                    const executor = deleteLog.executor;
                    
                    // Yeni koruma sistemi kontrolü
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(channel.guild, executor.id);
                    
                    if (executor && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Kanal Silme');
                        
                        // Koruma sistemi ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Kanal Silme', channel.guild);
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('📢 Kanal Silme Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir kanal sildi.`)
                            .addFields(
                                { name: '📢 Silinen Kanal', value: `#${channel.name} (${channel.id})`, inline: true },
                                { name: '👤 Silen Kişi', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xF44336)
                            .setTimestamp();
                        
                        await logAction(channel.guild, logEmbed);
                        await handleSuspiciousActivity(channel.guild, executor.id, 'Kanal Silme', actionCount);
                        
                        // Koruma sistemi ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(channel.guild, executor.id, 'Kanal Silme', violationCount);
                        }
                    }
                }
            }
        }
    },
    
    // Kanal Oluşturma Koruması
    {
        name: Events.ChannelCreate,
        async execute(channel) {
            const guildId = channel.guild.id;
            
            if (await isProtectionEnabled(guildId, 'antiChannel')) {
                const auditLogs = await channel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelCreate,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const createLog = auditLogs.entries.first();
                    const executor = createLog.executor;
                    
                    // Yeni koruma sistemi kontrolü
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(channel.guild, executor.id);
                    
                    if (executor && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Kanal Oluşturma');
                        
                        // Koruma sistemi ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Kanal Ekleme', channel.guild);
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('📢 Kanal Oluşturma Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir kanal oluşturdu.`)
                            .addFields(
                                { name: '📢 Oluşturulan Kanal', value: `#${channel.name} (${channel.id})`, inline: true },
                                { name: '👤 Oluşturan Kişi', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                { name: '🏷️ Kanal Tipi', value: channel.type === 0 ? 'Metin' : channel.type === 2 ? 'Ses' : 'Diğer', inline: true }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xFF9800)
                            .setTimestamp();
                        
                        await logAction(channel.guild, logEmbed);
                        await handleSuspiciousActivity(channel.guild, executor.id, 'Kanal Oluşturma', actionCount);
                        
                        // Koruma sistemi ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(channel.guild, executor.id, 'Kanal Ekleme', violationCount);
                        }
                    }
                }
            }
        }
    },

    // Rol Silme Koruması
    {
        name: Events.GuildRoleDelete,
        async execute(role) {
            const guildId = role.guild.id;
            
            if (await isProtectionEnabled(guildId, 'antiRole')) {
                const auditLogs = await role.guild.fetchAuditLogs({
                    type: AuditLogEvent.RoleDelete,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const deleteLog = auditLogs.entries.first();
                    const executor = deleteLog.executor;
                    
                    // Yeni koruma sistemi kontrolü
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(role.guild, executor.id);
                    
                    if (executor && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Rol Silme');
                        
                        // Koruma sistemi ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Rol Silme', role.guild);
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('🏷️ Rol Silme Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir rol sildi.`)
                            .addFields(
                                { name: '🏷️ Silinen Rol', value: `${role.name} (${role.id})`, inline: true },
                                { name: '👤 Silen Kişi', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xF44336)
                            .setTimestamp();
                        
                        await logAction(role.guild, logEmbed);
                        await handleSuspiciousActivity(role.guild, executor.id, 'Rol Silme', actionCount);
                        
                        // Koruma sistemi ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(role.guild, executor.id, 'Rol Silme', violationCount);
                        }
                    }
                }
            }
        }
    },
    
    // Rol Oluşturma Koruması
    {
        name: Events.GuildRoleCreate,
        async execute(role) {
            const guildId = role.guild.id;
            
            if (await isProtectionEnabled(guildId, 'antiRole')) {
                const auditLogs = await role.guild.fetchAuditLogs({
                    type: AuditLogEvent.RoleCreate,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const createLog = auditLogs.entries.first();
                    const executor = createLog.executor;
                    
                    // Yeni koruma sistemi kontrolü
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(role.guild, executor.id);
                    
                    if (executor && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Rol Oluşturma');
                        
                        // Koruma sistemi ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Rol Ekleme', role.guild);
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('🏷️ Rol Oluşturma Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir rol oluşturdu.`)
                            .addFields(
                                { name: '🏷️ Oluşturulan Rol', value: `${role.name} (${role.id})`, inline: true },
                                { name: '👤 Oluşturan Kişi', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                { name: '🎨 Rol Rengi', value: role.color ? `#${role.color.toString(16).padStart(6, '0')}` : 'Varsayılan', inline: true }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xFF9800)
                            .setTimestamp();
                        
                        await logAction(role.guild, logEmbed);
                        await handleSuspiciousActivity(role.guild, executor.id, 'Rol Oluşturma', actionCount);
                        
                        // Koruma sistemi ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(role.guild, executor.id, 'Rol Ekleme', violationCount);
                        }
                    }
                }
            }
        }
    },

    // Ban Koruması
    {
        name: Events.GuildBanAdd,
        async execute(ban) {
            const guildId = ban.guild.id;
            
            if (await isProtectionEnabled(guildId, 'antiBan')) {
                const auditLogs = await ban.guild.fetchAuditLogs({
                    type: AuditLogEvent.MemberBanAdd,
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const banLog = auditLogs.entries.first();
                    const executor = banLog.executor;
                    
                    // Yeni koruma sistemi kontrolü
                    const korumaCommand = require('../commands/koruma.js');
                    const isUserSafe = korumaCommand.isUserSafe(guildId, executor.id) || korumaCommand.isUserSafeByRole(ban.guild, executor.id);
                    
                    if (executor && !await isUserWhitelisted(guildId, executor.id) && !isUserSafe) {
                        const actionCount = trackUserAction(guildId, executor.id, 'Üye Yasaklama');
                        
                        // Koruma sistemi ihlal tracker'ını güncelle
                        const violationCount = korumaCommand.trackViolation(guildId, executor.id, 'Üye Yasaklama', ban.guild);
                        
                        const logEmbed = new EmbedBuilder()
                            .setTitle('🔨 Yasaklama Tespit Edildi')
                            .setDescription(`**${executor.tag}** bir üyeyi yasakladı.`)
                            .addFields(
                                { name: '👤 Yasaklanan', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                                { name: '👤 Yasaklayan', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true },
                                { name: '⚠️ İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                { name: '📝 Sebep', value: banLog.reason || 'Belirtilmemiş', inline: false }
                            )
                            .setColor(violationCount >= 3 ? 0xFF0000 : 0xF44336)
                            .setTimestamp();
                        
                        await logAction(ban.guild, logEmbed);
                        await handleSuspiciousActivity(ban.guild, executor.id, 'Üye Yasaklama', actionCount);
                        
                        // Koruma sistemi ihlal limiti kontrolü
                        if (violationCount >= 3) {
                            await korumaCommand.handleViolationLimit(ban.guild, executor.id, 'Üye Yasaklama', violationCount);
                        }
                    }
                }
            }
        }
    }
];




