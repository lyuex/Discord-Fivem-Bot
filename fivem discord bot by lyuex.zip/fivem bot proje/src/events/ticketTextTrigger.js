// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    try {
      if (message.author.bot) return;
      if (!message.guild) return; // DM'de çalışmasın

      const content = (message.content || '').trim().toLowerCase();
      if (content !== 'ticket') return;

      const config = ticketUtil.getConfig();
      if (!config?.enabled) {
        return message.reply({
          content: '❌ Ticket sistemi kapalı.',
          allowedMentions: { repliedUser: false }
        });
      }

      const categories = ticketUtil.getCategories();
      if (!categories || categories.length === 0) {
        return message.reply({
          content: '❌ Ticket kategorileri ayarlanmamış. Yöneticilere bildirin.',
          allowedMentions: { repliedUser: false }
        });
      }

      const embed = new EmbedBuilder()
        .setColor('#3498db')
        .setAuthor({ name: `${message.guild.name} - Destek Sistemi`, iconURL: message.guild.iconURL({ dynamic: true }) })
        .setTitle('🎫 Destek Talebi Oluştur')
        .setDescription('Aşağıdaki menüden bir kategori seçerek ticket oluşturabilirsiniz.')
        .addFields(
          { name: 'Nasıl çalışır?', value: '• Bir kategori seçin\n• Konu ve detayları girin\n• Kanal otomatik oluşturulur', inline: false }
        )
        .setFooter({ text: 'İhtiyacınız olduğunda tekrar yazabilirsiniz: ticket' })
        .setTimestamp();

      // Select menu
      const options = categories.slice(0, 25).map(c => ({
        label: c.name,
        value: c.id,
        description: c.description?.slice(0, 100) || `${c.name} kategorisi`,
        emoji: c.emoji || undefined
      }));

      const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('ticket_category_select')
          .setPlaceholder('Bir ticket kategorisi seçin')
          .addOptions(options)
      );

      await message.reply({ embeds: [embed], components: [row], allowedMentions: { repliedUser: false } });
    } catch (err) {
      console.error('ticketTextTrigger error:', err);
    }
  }
};




