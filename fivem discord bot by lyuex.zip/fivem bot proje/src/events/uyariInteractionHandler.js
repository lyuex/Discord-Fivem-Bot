// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, ActionRowBuilder, RoleSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Veritabanı dosyaları
const uyariDB = path.join(__dirname, '../../db/uyarilar.json');
const lyuex = require('../../lyuex.json');

// Veritabanı fonksiyonları
function getUyariData() {
    try {
        const data = fs.readFileSync(uyariDB, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveUyariData(data) {
    fs.writeFileSync(uyariDB, JSON.stringify(data, null, 2));
}

// Geçici veri depolama (memory)
const tempData = new Map();

// Geçici veriyi otomatik temizle (15 dakika sonra)
setInterval(() => {
    const now = Date.now();
    for (const [sessionId, data] of tempData.entries()) {
        // 15 dakikadan eski verileri sil
        if (now - data.timestamp > 15 * 60 * 1000) {
            tempData.delete(sessionId);
            console.log(`Geçici veri temizlendi: ${sessionId}`);
        }
    }
}, 5 * 60 * 1000); // Her 5 dakikada bir kontrol et

module.exports = {
    name: 'uyariInteractionHandler',
    async execute(interaction) {
        // Kullanıcı seçimi
        if (interaction.isUserSelectMenu() && interaction.customId.startsWith('uyari_user_select_')) {
            await handleUserSelect(interaction);
        }
        
        // Rol seçimi
        if (interaction.isRoleSelectMenu() && interaction.customId.startsWith('uyari_role_select_')) {
            await handleRoleSelect(interaction);
        }
        
        // Buton etkileşimleri
        if (interaction.isButton()) {
            if (interaction.customId.startsWith('uyari_skip_role_')) {
                await handleSkipRole(interaction);
            } else if (interaction.customId.startsWith('uyari_cancel_')) {
                await handleCancel(interaction);
            } else if (interaction.customId.startsWith('uyari_confirm_')) {
                await handleConfirm(interaction);
            }
        }
        
        // Modal gönderimi
        if (interaction.isModalSubmit() && interaction.customId.startsWith('uyari_details_modal_')) {
            await handleModalSubmit(interaction);
        }
    }
};

async function handleUserSelect(interaction) {
    const selectedUserId = interaction.values[0];
    const yetkiliId = interaction.customId.split('_')[3]; // uyari_user_select_USERID format
    
    // Yetki kontrolü
    if (interaction.user.id !== yetkiliId) {
        return interaction.reply({
            content: '❌ Bu işlemi sadece komutu kullanan kişi yapabilir!',
            ephemeral: true
        });
    }
    
    const selectedUser = await interaction.guild.members.fetch(selectedUserId).catch(() => null);
    
    if (!selectedUser) {
        return interaction.update({
            embeds: [
                new EmbedBuilder()
                    .setTitle('❌ **KULLANICI BULUNAMADI**')
                    .setDescription('Seçilen kullanıcı sunucuda bulunamadı!')
                    .setColor(0xF44336)
                    .setTimestamp()
            ],
            components: []
        });
    }
    
    // Geçici veriyi kaydet
    const sessionId = `${interaction.user.id}_${Date.now()}`;
    tempData.set(sessionId, {
        targetUser: {
            id: selectedUserId,
            tag: selectedUser.user.tag,
            avatar: selectedUser.user.displayAvatarURL({ dynamic: true })
        },
        yetkili: {
            id: interaction.user.id,
            tag: interaction.user.tag
        },
        timestamp: Date.now()
    });
    
    // Rol seçim menüsü
    const roleSelectMenu = new RoleSelectMenuBuilder()
        .setCustomId(`uyari_role_select_${sessionId}`)
        .setPlaceholder('🏷️ Uyarıyla birlikte verilecek rolü seçin (opsiyonel)...')
        .setMinValues(0)
        .setMaxValues(1);

    const skipButton = new ButtonBuilder()
        .setCustomId(`uyari_skip_role_${sessionId}`)
        .setLabel('⏭️ Rol Seçimini Atla')
        .setStyle(ButtonStyle.Secondary);

    const cancelButton = new ButtonBuilder()
        .setCustomId(`uyari_cancel_${sessionId}`)
        .setLabel('❌ İptal Et')
        .setStyle(ButtonStyle.Danger);

    const row1 = new ActionRowBuilder().addComponents(roleSelectMenu);
    const row2 = new ActionRowBuilder().addComponents(skipButton, cancelButton);

    const rolSecimEmbed = new EmbedBuilder()
        .setAuthor({ 
            name: `${interaction.guild.name} • Uyarı Sistemi`, 
            iconURL: interaction.guild.iconURL({ dynamic: true }) 
        })
        .setTitle('🏷️ **ROL SEÇİMİ**')
        .setDescription(`
╭─────────────────────────────────╮
│  ✅ **KULLANICI SEÇİLDİ**        │
│  🔹 Adım 2: Rol seçimi           │
╰─────────────────────────────────╯

🎯 **İsterseniz uyarıyla birlikte verilecek rolü seçebilirsiniz**`)
        .addFields(
            { 
                name: '👤 **SEÇİLEN KULLANICI**', 
                value: `<@${selectedUserId}>\n\`${selectedUser.user.tag}\`\nID: \`${selectedUserId}\``, 
                inline: true 
            },
            { 
                name: '👮 **UYARI VEREN**', 
                value: `<@${interaction.user.id}>\n\`${interaction.user.tag}\``, 
                inline: true 
            },
            { 
                name: '⚙️ **ADIM DURUMU**', 
                value: `
✅ Kullanıcı seçildi
🔄 Rol seçimi (opsiyonel)
⏳ Uyarı detayları
                `, 
                inline: true 
            }
        )
        .setColor(0x2196F3)
        .setThumbnail(selectedUser.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ 
            text: 'Uyarı Sistemi • Rol Seçin veya Atlayın', 
            iconURL: interaction.user.displayAvatarURL() 
        })
        .setTimestamp();

    await interaction.update({
        embeds: [rolSecimEmbed],
        components: [row1, row2]
    });
}

async function handleRoleSelect(interaction) {
    try {
        // uyari_role_select_USERID_TIMESTAMP format - get last 2 parts
        const parts = interaction.customId.split('_');
        const sessionId = `${parts[3]}_${parts[4]}`;
        const data = tempData.get(sessionId);
        
        if (!data || data.yetkili.id !== interaction.user.id) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Geçersiz oturum veya yetki!',
                    ephemeral: true
                });
            }
            return;
        }
        
        const selectedRoleId = interaction.values[0];
        const selectedRole = interaction.guild.roles.cache.get(selectedRoleId);
        
        if (!selectedRole) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Seçilen rol bulunamadı!',
                    ephemeral: true
                });
            }
            return;
        }
        
        // Rol bilgisini geçici veriye ekle
        data.selectedRole = {
            id: selectedRoleId,
            name: selectedRole.name
        };
        tempData.set(sessionId, data);
        
        await showDetailsModal(interaction, sessionId, data);
    } catch (error) {
        console.error('Rol seçimi hatası:', error);
        if (!interaction.replied && !interaction.deferred) {
            try {
                await interaction.reply({
                    content: '❌ Rol seçiminde bir hata oluştu!',
                    ephemeral: true
                });
            } catch (replyError) {
                console.error('Reply hatası:', replyError);
            }
        }
    }
}

async function handleSkipRole(interaction) {
    try {
        // uyari_skip_role_USERID_TIMESTAMP format - get last 2 parts
        const parts = interaction.customId.split('_');
        const sessionId = `${parts[3]}_${parts[4]}`;
        const data = tempData.get(sessionId);
        
        if (!data || data.yetkili.id !== interaction.user.id) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Geçersiz oturum veya yetki!',
                    ephemeral: true
                });
            }
            return;
        }
        
        await showDetailsModal(interaction, sessionId, data);
    } catch (error) {
        console.error('Rol atlama hatası:', error);
        if (!interaction.replied && !interaction.deferred) {
            try {
                await interaction.reply({
                    content: '❌ Rol atlama işleminde bir hata oluştu!',
                    ephemeral: true
                });
            } catch (replyError) {
                console.error('Reply hatası:', replyError);
            }
        }
    }
}

async function showDetailsModal(interaction, sessionId, data) {
    try {
        // Interaction'ın süresi dolup dolmadığını kontrol et
        const now = Date.now();
        const interactionTime = interaction.createdTimestamp;
        const timeDiff = now - interactionTime;
        
        // 13 dakikadan fazla geçtiyse (15 dakika limitinden 2 dakika önce)
        if (timeDiff > 13 * 60 * 1000) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ İşlem zaman aşımına uğradı. Lütfen komutu yeniden kullanın.',
                    ephemeral: true
                });
            }
            return;
        }

        const modal = new ModalBuilder()
            .setCustomId(`uyari_details_modal_${sessionId}`)
            .setTitle('⚠️ Uyarı Detayları');

        const sebepInput = new TextInputBuilder()
            .setCustomId('sebep')
            .setLabel('📋 Uyarı Sebebi')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Uyarı sebebini detaylı olarak yazın...')
            .setRequired(true)
            .setMaxLength(500);

        const cezaInput = new TextInputBuilder()
            .setCustomId('ceza')
            .setLabel('⚖️ Verilecek Ceza (Opsiyonel)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Örn: Uyarı, Mute, Ban vs.')
            .setRequired(false)
            .setMaxLength(100)
            .setValue('Uyarı');

        const sebepRow = new ActionRowBuilder().addComponents(sebepInput);
        const cezaRow = new ActionRowBuilder().addComponents(cezaInput);

        modal.addComponents(sebepRow, cezaRow);

        await interaction.showModal(modal);
    } catch (error) {
        console.error('Modal gösterme hatası:', error);
        if (!interaction.replied && !interaction.deferred) {
            try {
                await interaction.reply({
                    content: '❌ Modal gösterilirken bir hata oluştu. Lütfen tekrar deneyin.',
                    ephemeral: true
                });
            } catch (replyError) {
                console.error('Reply hatası:', replyError);
            }
        }
    }
}

async function handleModalSubmit(interaction) {
    try {
        // uyari_details_modal_USERID_TIMESTAMP format - get last 2 parts
        const parts = interaction.customId.split('_');
        const sessionId = `${parts[3]}_${parts[4]}`;
        const data = tempData.get(sessionId);
        
        if (!data || data.yetkili.id !== interaction.user.id) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Geçersiz oturum veya yetki!',
                    ephemeral: true
                });
            }
            return;
        }
        
        const sebep = interaction.fields.getTextInputValue('sebep');
        const ceza = interaction.fields.getTextInputValue('ceza') || 'Uyarı';
        
        data.sebep = sebep;
        data.ceza = ceza;
        
        // Onay embedi
        const confirmEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Uyarı Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('✅ **UYARI ONAY PANELİ**')
            .setDescription(`
╭─────────────────────────────────╮
│  📋 **UYARI BİLGİLERİ HAZIR**    │
│  Son onay için kontrol edin      │
╰─────────────────────────────────╯

🔍 **Aşağıdaki bilgileri kontrol edip onaylayın**`)
            .addFields(
                { 
                    name: '👤 **UYARILACAK KULLANICI**', 
                    value: `<@${data.targetUser.id}>\n\`${data.targetUser.tag}\`\nID: \`${data.targetUser.id}\``, 
                    inline: true 
                },
                { 
                    name: '👮 **UYARI VEREN**', 
                    value: `<@${data.yetkili.id}>\n\`${data.yetkili.tag}\``, 
                    inline: true 
                },
                { 
                    name: '🏷️ **SEÇİLEN ROL**', 
                    value: data.selectedRole ? `<@&${data.selectedRole.id}>\n\`${data.selectedRole.name}\`` : '*Rol seçilmedi*', 
                    inline: true 
                },
                { 
                    name: '📋 **UYARI SEBEBİ**', 
                    value: `\`\`\`${sebep}\`\`\``, 
                    inline: false 
                },
                { 
                    name: '⚖️ **VERILEN CEZA**', 
                    value: `\`${ceza}\``, 
                    inline: true 
                },
                { 
                    name: '⏰ **ZAMAN**', 
                    value: `<t:${Math.floor(Date.now() / 1000)}:F>`, 
                    inline: true 
                }
            )
            .setColor(0xFF9800)
            .setThumbnail(data.targetUser.avatar)
            .setFooter({ 
                text: 'Uyarı Sistemi • Onay Bekliyor', 
                iconURL: interaction.user.displayAvatarURL() 
            })
            .setTimestamp();

        const confirmButton = new ButtonBuilder()
            .setCustomId(`uyari_confirm_${sessionId}`)
            .setLabel('✅ Uyarıyı Onayla')
            .setStyle(ButtonStyle.Success);

        const cancelButton = new ButtonBuilder()
            .setCustomId(`uyari_cancel_${sessionId}`)
            .setLabel('❌ İptal Et')
            .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                embeds: [confirmEmbed],
                components: [row],
                ephemeral: true
            });
        }
    } catch (error) {
        console.error('Modal submit hatası:', error);
        if (!interaction.replied && !interaction.deferred) {
            try {
                await interaction.reply({
                    content: '❌ Form işlenirken bir hata oluştu!',
                    ephemeral: true
                });
            } catch (replyError) {
                console.error('Reply hatası:', replyError);
            }
        }
    }
}

async function handleConfirm(interaction) {
    try {
        // uyari_confirm_USERID_TIMESTAMP format - get last 2 parts
        const parts = interaction.customId.split('_');
        const sessionId = `${parts[2]}_${parts[3]}`;
        const data = tempData.get(sessionId);
        
        if (!data || data.yetkili.id !== interaction.user.id) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Geçersiz oturum veya yetki!',
                    ephemeral: true
                });
            }
            return;
        }
        
        // İşlemi defer et
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferUpdate();
        }
        
        // Uyarı verilerini al
        const uyariData = getUyariData();
        const userId = data.targetUser.id;
        
        if (!uyariData[userId]) {
            uyariData[userId] = {
                kullanici: {
                    id: userId,
                    tag: data.targetUser.tag,
                    avatar: data.targetUser.avatar
                },
                uyarilar: []
            };
        }
        
        // Yeni uyarı oluştur
        const yeniUyari = {
            id: Date.now(),
            sebep: data.sebep,
            ceza: data.ceza,
            rol: data.selectedRole || null,
            yetkili: {
                id: data.yetkili.id,
                tag: data.yetkili.tag
            },
            tarih: new Date().toISOString(),
            timestamp: Math.floor(Date.now() / 1000)
        };
        
        uyariData[userId].uyarilar.push(yeniUyari);
        uyariData[userId].kullanici.tag = data.targetUser.tag;
        
        // Veritabanına kaydet
        saveUyariData(uyariData);
        
        // Eğer rol seçildiyse rolü ver
        let rolVerildi = false;
        if (data.selectedRole) {
            try {
                const targetMember = await interaction.guild.members.fetch(userId);
                const role = interaction.guild.roles.cache.get(data.selectedRole.id);
                
                if (targetMember && role) {
                    await targetMember.roles.add(role);
                    rolVerildi = true;
                }
            } catch (roleError) {
                console.error('Rol verme hatası:', roleError);
            }
        }
        
        // Uyarı sayısı
        const toplamUyari = uyariData[userId].uyarilar.length;
        
        // Başarı embedi
        const basariliEmbed = new EmbedBuilder()
            .setAuthor({ 
                name: `${interaction.guild.name} • Uyarı Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle('✅ **UYARI BAŞARIYLA VERİLDİ**')
            .setDescription(`<@${userId}> kullanıcısına uyarı başarıyla verildi!`)
            .addFields(
                { 
                    name: '👤 **UYARILAN KULLANICI**', 
                    value: `<@${userId}>\n\`${data.targetUser.tag}\`\nID: \`${userId}\``, 
                    inline: true 
                },
                { 
                    name: '👮 **UYARI VEREN**', 
                    value: `<@${data.yetkili.id}>\n\`${data.yetkili.tag}\``, 
                    inline: true 
                },
                { 
                    name: '📊 **UYARI DURUMU**', 
                    value: `**Toplam Uyarı:** ${toplamUyari}\n**Uyarı ID:** \`${yeniUyari.id}\``, 
                    inline: true 
                },
                { 
                    name: '📋 **UYARI DETAYLARI**', 
                    value: `**Sebep:** ${data.sebep}\n**Ceza:** ${data.ceza}`, 
                    inline: false 
                },
                { 
                    name: '🏷️ **ROL BİLGİSİ**', 
                    value: data.selectedRole ? 
                        `<@&${data.selectedRole.id}> ${rolVerildi ? '✅' : '❌'}` : 
                        '*Rol seçilmedi*', 
                    inline: true 
                },
                { 
                    name: '⏰ **ZAMAN**', 
                    value: `<t:${yeniUyari.timestamp}:F>\n<t:${yeniUyari.timestamp}:R>`, 
                    inline: true 
                }
            )
            .setColor(0x4CAF50)
            .setThumbnail(data.targetUser.avatar)
            .setFooter({ 
                text: `Uyarı Sistemi | ${interaction.guild.name}`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();

        if (interaction.deferred) {
            await interaction.editReply({
                embeds: [basariliEmbed],
                components: []
            });
        } else if (!interaction.replied) {
            await interaction.update({
                embeds: [basariliEmbed],
                components: []
            });
        }

        // Log kanalına gönder
        const { sendUyariLog } = require('../commands/uyari.js');
        await sendUyariLog(interaction.client, {
            guild: {
                name: interaction.guild.name,
                iconURL: () => interaction.guild.iconURL({ dynamic: true })
            },
            hedef: {
                id: userId,
                tag: data.targetUser.tag,
                avatar: data.targetUser.avatar
            },
            yetkili: {
                id: data.yetkili.id,
                tag: data.yetkili.tag,
                avatar: interaction.user.displayAvatarURL({ dynamic: true })
            },
            sebep: data.sebep,
            ceza: data.ceza,
            uyariSayisi: toplamUyari,
            uyariId: yeniUyari.id,
            atananRol: data.selectedRole && rolVerildi ? data.selectedRole : null,
            timestamp: yeniUyari.timestamp
        });
        
        // Kullanıcıya DM gönder
        try {
            const targetUser = await interaction.client.users.fetch(userId);
            const dmEmbed = new EmbedBuilder()
                .setTitle(`⚠️ ${interaction.guild.name} - Uyarı Bildirimi`)
                .setDescription(`Size bir uyarı verildi!`)
                .addFields(
                    { name: '📋 Sebep', value: data.sebep, inline: false },
                    { name: '⚖️ Ceza', value: data.ceza, inline: true },
                    { name: '📊 Toplam Uyarınız', value: toplamUyari.toString(), inline: true },
                    { name: '👮 Uyarı Veren', value: data.yetkili.tag, inline: true }
                )
                .setColor(0xFF9800)
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `${interaction.guild.name} | Uyarı Sistemi` })
                .setTimestamp();
            
            if (data.selectedRole && rolVerildi) {
                dmEmbed.addFields({ 
                    name: '🏷️ Verilen Rol', 
                    value: `\`${data.selectedRole.name}\``, 
                    inline: true 
                });
            }
            
            await targetUser.send({ embeds: [dmEmbed] });
        } catch (error) {
            console.log(`DM gönderilemedi: ${data.targetUser.tag}`);
        }
        
        // Geçici veriyi temizle
        tempData.delete(sessionId);
        
    } catch (error) {
        console.error('Uyarı verme hatası:', error);
        
        const hataEmbed = new EmbedBuilder()
            .setTitle('❌ **HATA OLUŞTU**')
            .setDescription('Uyarı verilirken bir hata meydana geldi.')
            .addFields(
                { name: 'Hata', value: error.message, inline: false },
                { name: 'Çözüm', value: 'Lütfen tekrar deneyin veya yetkili ile iletişime geçin.', inline: false }
            )
            .setColor(0xF44336)
            .setTimestamp();

        try {
            if (interaction.deferred) {
                await interaction.editReply({
                    embeds: [hataEmbed],
                    components: []
                });
            } else if (!interaction.replied) {
                await interaction.update({
                    embeds: [hataEmbed],
                    components: []
                });
            }
        } catch (replyError) {
            console.error('Hata mesajı gönderme hatası:', replyError);
        }
    }
}

async function handleCancel(interaction) {
    try {
        // uyari_cancel_USERID_TIMESTAMP format - get last 2 parts
        const parts = interaction.customId.split('_');
        const sessionId = `${parts[2]}_${parts[3]}`;
        const data = tempData.get(sessionId);
        
        if (!data || data.yetkili.id !== interaction.user.id) {
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Geçersiz oturum veya yetki!',
                    ephemeral: true
                });
            }
            return;
        }
        
        // Geçici veriyi temizle
        tempData.delete(sessionId);
        
        const iptalEmbed = new EmbedBuilder()
            .setTitle('❌ **UYARI İŞLEMİ İPTAL EDİLDİ**')
            .setDescription('Uyarı verme işlemi başarıyla iptal edildi.')
            .setColor(0x607D8B)
            .setTimestamp();

        if (!interaction.replied && !interaction.deferred) {
            await interaction.update({
                embeds: [iptalEmbed],
                components: []
            });
        } else if (interaction.deferred) {
            await interaction.editReply({
                embeds: [iptalEmbed],
                components: []
            });
        }
    } catch (error) {
        console.error('İptal işlemi hatası:', error);
        if (!interaction.replied && !interaction.deferred) {
            try {
                await interaction.reply({
                    content: '❌ İptal işleminde bir hata oluştu!',
                    ephemeral: true
                });
            } catch (replyError) {
                console.error('Reply hatası:', replyError);
            }
        }
    }
}




