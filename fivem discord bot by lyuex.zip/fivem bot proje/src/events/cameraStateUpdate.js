// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const member = newState.member;
        const guild = member.guild;
        
        // lyuex.json'dan log kanalını al
        const logChannelId = lyuex.log?.channels?.voice_logs || lyuex.botSettings?.LOG_CHANNEL_ID;
        let logChannel = null;
        
        if (logChannelId) {
            logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        }

        if (!logChannel) {
            // Artık hata vermeyeceğiz, sessizce geçeceğiz
            return;
        }
        if (oldState.selfVideo !== newState.selfVideo) {
            const action = newState.selfVideo ? 'Kamerasını Açtı' : 'Kamerasını Kapattı';
            const embed = createEmbed(member, newState.channel, action);
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }
    },
};

function createEmbed(member, channel, action) {
    const embed = new EmbedBuilder()
        .setColor(0x00FFFF)
        .setTitle(action)
        .setDescription(`
            **Kullanıcı:**
            <@${member.id}> - ${member.id}
            **Kanal:**
            > ${channel ? `${channel.name} (${channel.id})` : 'Bilinmiyor'}
            **Kanalda Bulunan kişiler:**
            ${getMemberList(channel)}
        `)
        .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
        .setTimestamp();
    return embed;
}

function getMemberList(channel) {
    const members = channel ? channel.members : null;
    let memberList = '';
    if (members) {
        members.forEach(member => {
            memberList += `\n> <@${member.id}> - ${member.id}`;
        });
    }
    return memberList || 'Kanalda başka üye bulunmuyor.';
}




