// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildEmojiUpdate,
    async execute(oldEmoji, newEmoji) {
        if (!lyuex.log?.enabled || !lyuex.log?.events?.emoji_update) return;
        
        const guild = newEmoji.guild;
        const logChannel = guild.channels.cache.get(lyuex.log.channels.system_logs);

        if (!logChannel) {
            return;
        }

        try {
            const fetchedLogs = await guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.EmojiUpdate
            });

            const emojiLog = fetchedLogs.entries.first();
            const { executor } = emojiLog;

            const embed = new EmbedBuilder()
                .setColor(0xFFFF00)
                .setTitle('✏️ Emoji Güncellendi')
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .setDescription(`**${oldEmoji.name}** emojisi güncellendi`)
                .addFields(
                    { name: '😀 Emoji', value: `${newEmoji} **${newEmoji.name}** (${newEmoji.id})`, inline: true },
                    { name: '👮 Güncelleyen', value: `${executor.tag} (<@${executor.id}>)`, inline: true },
                    { name: '⏰ Güncelleme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '📝 Değişiklikler', value: `**Eski İsim:** \`${oldEmoji.name}\`\n**Yeni İsim:** \`${newEmoji.name}\``, inline: false }
                )
                .setFooter({ 
                    text: `LYUEX Gelişmiş Log Sistemi • Emoji Yönetimi`,
                    iconURL: guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Emoji güncelleme log hatası:', error);
        }
    },
};




