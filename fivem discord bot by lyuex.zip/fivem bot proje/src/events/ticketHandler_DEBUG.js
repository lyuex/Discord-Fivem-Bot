// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, SelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // Modal submit
        if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith('ticket_create_modal_')) {
                const categoryId = interaction.customId.replace('ticket_create_modal_', '');
                await handleTicketCreation(interaction, categoryId);
            }
            return;
        }
        
        // Select menu
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'priority_select') {
                await handlePrioritySelection(interaction);
            } else if (interaction.customId === 'tag_select') {
                await handleTagSelection(interaction);
            } else if (interaction.customId === 'ticket_category_select') {
                try {
                    const categoryId = interaction.values[0];
                    console.log(`[Ticket] Select menu triggered - Category ID: ${categoryId}`);
                    const cfg = ticketUtil.getConfig();
                    console.log(`[Ticket] Config loaded:`, cfg ? `OK (enabled: ${cfg.enabled})` : 'NULL');
                    // Eğer detay modali zorunlu değilse, doğrudan ticket oluştur
                    if (cfg?.requireDetailsModal) {
                        console.log(`[Ticket] Opening modal`);
                        await handleTicketCreateModal(interaction, categoryId);
                    } else {
                        console.log(`[Ticket] Creating ticket directly`);
                        await handleTicketCreateDirect(interaction, categoryId);
                    }
                } catch (err) {
                    console.error(`[Ticket] Select handler error:`, err.message);
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: `❌ Hata: ${err.message}`, ephemeral: true }).catch(() => {});
                    } else if (interaction.deferred) {
                        await interaction.editReply({ content: `❌ Hata: ${err.message}` }).catch(() => {});
                    }
                }
            }
            return;
        }
        
        // Butonlar
        if (!interaction.isButton()) return;
        
        // Ticket oluşturma
        if (interaction.customId.startsWith('ticket_create_') || 
            ['oyun_ici_destek', 'oyun_disi_destek', 'hata_raporla', 'ekip_acma', 'hesap_destek'].includes(interaction.customId)) {
            let categoryId = interaction.customId.replace('ticket_create_', '');
            
            // Yeni custom panel butonları için category mapping
            switch (interaction.customId) {
                case 'ticket_create_oyun_ici':
                    categoryId = 'oyun_ici_destek';
                    break;
                case 'ticket_create_oyun_disi':
                    categoryId = 'oyun_disi_destek';
                    break;
                case 'ticket_create_hata_raporlama':
                    categoryId = 'hata_raporla';
                    break;
            }
            
            await handleTicketCreateModal(interaction, categoryId);
            return;
        }
        
        // Diğer ticket işlemleri
        switch (interaction.customId) {
            case 'ticket_kapat':
                await handleTicketClose(interaction);
                break;
            case 'ticket_confirm_close':
                await handleTicketConfirmClose(interaction);
                break;
            case 'ticket_cancel_close':
                await handleTicketCancelClose(interaction);
                break;
            case 'ticket_delete':
                await handleTicketDelete(interaction);
                break;
            case 'ticket_transcript':
                await handleTicketTranscript(interaction);
                break;
            case 'ticket_claim':
                await handleTicketClaim(interaction);
                break;
            case 'ticket_set_priority':
                await handleTicketPriorityMenu(interaction);
                break;
            case 'ticket_set_tag':
                await handleTicketTagMenu(interaction);
                break;
        }
        
        // Derecelendirme
        if (interaction.customId.startsWith('ticket_rate_')) {
            const rating = parseInt(interaction.customId.replace('ticket_rate_', ''));
            await handleTicketRating(interaction, rating);
        }
    }
};

// Modal olmadan doğrudan ticket oluştur (select menüden)
async function handleTicketCreateDirect(interaction, categoryId) {
    let ticketChannel = null;
    try {
        console.log(`[handleTicketCreateDirect] Start - CategoryId: ${categoryId}`);

        // Step 1: Defer reply
        if (!interaction.deferred && !interaction.replied) {
            console.log(`[handleTicketCreateDirect] Deferring reply...`);
            await interaction.deferReply({ ephemeral: true });
            console.log(`[handleTicketCreateDirect] Reply deferred`);
        }

        // Step 2: Get config
        console.log(`[handleTicketCreateDirect] Loading config...`);
        const config = ticketUtil.getConfig();
        console.log(`[handleTicketCreateDirect] Config:`, config ? `Loaded (enabled: ${config.enabled})` : 'NULL');
        
        if (!config) {
            console.warn(`[handleTicketCreateDirect] Config is null, using defaults`);
            return await interaction.editReply({
                content: '❌ Ticket sistemi yapılandırılmamış. Yöneticiye haber verin.',
                ephemeral: true
            });
        }

        // Step 3: Get category
        console.log(`[handleTicketCreateDirect] Getting category by ID: ${categoryId}`);
        const category = ticketUtil.getCategoryById(categoryId) || { 
            id: categoryId, 
            name: 'Destek', 
            emoji: '🎫',
            color: '#3498db'
        };
        console.log(`[handleTicketCreateDirect] Category found:`, category.name);

        // Step 4: Check if can create ticket
        console.log(`[handleTicketCreateDirect] Checking if user can create ticket...`);
        const canCreate = await ticketUtil.canCreateTicket(interaction.guild, interaction.user.id);
        console.log(`[handleTicketCreateDirect] Can create:`, canCreate);
        if (!canCreate) {
            return await interaction.editReply({
                content: `❌ Maksimum aktif ticket sayısına ulaştınız! (${config.maxActiveTickets || 3})`,
                ephemeral: true
            });
        }

        // Step 5: Check cooldown
        console.log(`[handleTicketCreateDirect] Checking cooldown...`);
        const cooldownCheck = ticketUtil.checkCooldown(interaction.user.id);
        console.log(`[handleTicketCreateDirect] On cooldown:`, cooldownCheck.onCooldown);
        if (cooldownCheck.onCooldown) {
            const minutes = Math.ceil(cooldownCheck.timeLeft / (1000 * 60));
            return await interaction.editReply({
                content: `⏱️ Çok hızlı ticket açıyorsunuz! ${minutes} dakika bekleyin.`,
                ephemeral: true
            });
        }

        // Step 6: Get ticket number
        console.log(`[handleTicketCreateDirect] Getting ticket number...`);
        const ticketNumber = ticketUtil.getNextTicketNumber();
        console.log(`[handleTicketCreateDirect] Ticket number: ${ticketNumber}`);

        // Step 7: Get support role
        console.log(`[handleTicketCreateDirect] Getting support role: ${config.supportRoleId}`);
        const supportRole = interaction.guild.roles.cache.get(config.supportRoleId);
        console.log(`[handleTicketCreateDirect] Support role:`, supportRole ? supportRole.name : 'NOT FOUND');
        
        if (!supportRole) {
            console.error(`[handleTicketCreateDirect] Support role not found: ${config.supportRoleId}`);
            return await interaction.editReply({
                content: `❌ Destek rolü bulunamadı! (ID: ${config.supportRoleId})\n\nYöneticilere haber verin: /ticket-yonetim → Sistem Ayarları → Yetkili Rolü`,
                ephemeral: true
            });
        }

        // Step 8: Get or create category channel
        console.log(`[handleTicketCreateDirect] Getting category channel: ${config.categoryId}`);
        let categoryChannel = null;
        if (config.categoryId) {
            try {
                categoryChannel = await interaction.guild.channels.fetch(config.categoryId);
                console.log(`[handleTicketCreateDirect] Category channel found: ${categoryChannel.name}`);
            } catch (err) {
                console.warn(`[handleTicketCreateDirect] Category channel not found, will create new one`);
            }
        }

        if (!categoryChannel) {
            console.log(`[handleTicketCreateDirect] Creating new category channel...`);
            try {
                categoryChannel = await interaction.guild.channels.create({
                    name: '📩 DESTEK TALEPLERİ',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: supportRole.id, allow: [PermissionFlagsBits.ViewChannel] }
                    ]
                });
                console.log(`[handleTicketCreateDirect] Category channel created: ${categoryChannel.id}`);
                config.categoryId = categoryChannel.id;
                ticketUtil.updateConfig(config);
                console.log(`[handleTicketCreateDirect] Config updated with new category ID`);
            } catch (error) {
                console.error(`[handleTicketCreateDirect] Failed to create category:`, error.message);
                return await interaction.editReply({
                    content: `❌ Ticket kategorisi oluşturulamadı!\n\nHata: ${error.message}`,
                    ephemeral: true
                });
            }
        }

        // Step 9: Create ticket channel
        console.log(`[handleTicketCreateDirect] Creating ticket channel...`);
        try {
            ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${ticketNumber}`,
                type: ChannelType.GuildText,
                topic: `${category.emoji} ${category.name} | Talep Eden: ${interaction.user.id} | Ticket #${ticketNumber}`,
                parent: categoryChannel.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { 
                        id: interaction.user.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles
                        ] 
                    },
                    { 
                        id: supportRole.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.ManageMessages
                        ] 
                    }
                ]
            });
            console.log(`[handleTicketCreateDirect] Ticket channel created: ${ticketChannel.id} (${ticketChannel.name})`);
        } catch (error) {
            console.error(`[handleTicketCreateDirect] Failed to create ticket channel:`, error.message);
            return await interaction.editReply({
                content: `❌ Ticket kanalı oluşturulamadı!\n\nHata: ${error.message}`,
                ephemeral: true
            });
        }

        // Step 10: Save ticket data
        console.log(`[handleTicketCreateDirect] Saving ticket data...`);
        const subject = `${category.emoji} ${category.name}`;
        const detail = 'Destek talebin için teşekkürler. Ekibimiz en kısa sürede yardımcı olacaktır.';

        const ticketData = {
            id: `ticket-${ticketNumber}`,
            ticketNumber,
            channelId: ticketChannel.id,
            userId: interaction.user.id,
            userTag: interaction.user.tag,
            guildId: interaction.guild.id,
            categoryId,
            subject,
            detail,
            status: 'open',
            priority: 'normal'
        };
        ticketUtil.saveTicket(ticketData);
        console.log(`[handleTicketCreateDirect] Ticket data saved`);

        // Step 11: Create and send welcome embed
        console.log(`[handleTicketCreateDirect] Creating welcome embed...`);
        const ticketEmbed = new EmbedBuilder()
            .setColor(category.color || '#3498db')
            .setAuthor({ 
                name: `${interaction.guild.name} - Destek Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle(`${category.emoji} Ticket #${ticketNumber} - ${subject}`)
            .setDescription(`
👋 Hoş geldiniz! Destek talebiniz oluşturuldu.

📋 **Talep Açıklaması:**
\`\`\`
${detail}
\`\`\`

🎯 **Ticket Bilgileri:**
• **Kategori:** ${category.emoji} ${category.name}
• **Durum:** 🟢 Açık
• **Öncelik:** ⚪ Normal
• **Oluşturulma:** <t:${Math.floor(Date.now() / 1000)}:R>

💡 **Yardım İpuçları:**
• Lütfen sorununuzu detaylı açıklayın
• Ekran görüntüsü paylaşabilirsiniz
• Sabırlı olun, en kısa sürede yanıtlanacak
            `)
            .addFields(
                { 
                    name: '👤 Talep Eden', 
                    value: `${interaction.user}\n\`${interaction.user.tag}\`\nID: \`${interaction.user.id}\``, 
                    inline: true 
                },
                { 
                    name: '📊 İstatistikler', 
                    value: `Ticket ID: \`#${ticketNumber}\`\nKanal: ${ticketChannel}\nSaat: <t:${Math.floor(Date.now() / 1000)}:t>`, 
                    inline: true 
                },
                { 
                    name: '⚙️ Ticket Yönetimi', 
                    value: `🔒 Kapatmak için \`Kapat\` butonuna basın\n👋 Üstlenmek için \`Üstlen\` butonuna basın\n📝 Kayıt almak için \`Kayıt\` butonuna basın`, 
                    inline: false 
                }
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ 
                text: `${interaction.guild.name} Destek Ekibi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_kapat')
                    .setLabel('Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('Üstlen')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('👋'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Kayıt')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📝')
            );

        const buttons2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_set_priority')
                    .setLabel('Öncelik')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🔄'),
                new ButtonBuilder()
                    .setCustomId('ticket_set_tag')
                    .setLabel('Etiket')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🏷️')
            );

        console.log(`[handleTicketCreateDirect] Sending welcome message...`);
        const ticketMessage = await ticketChannel.send({
            content: `${interaction.user} | ${supportRole}`,
            embeds: [ticketEmbed],
            components: [buttons, buttons2]
        });
        await ticketMessage.pin();
        console.log(`[handleTicketCreateDirect] Welcome message sent and pinned`);

        // Step 12: Send log
        if (config.logChannelId) {
            try {
                console.log(`[handleTicketCreateDirect] Sending log to: ${config.logChannelId}`);
                const logChannel = await interaction.guild.channels.fetch(config.logChannelId);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(category.color || '#3498db')
                        .setTitle('📩 Yeni Ticket')
                        .setDescription(`${category.emoji} **${subject}** konulu ticket açıldı`)
                        .addFields(
                            { name: 'Talep Eden', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Ticket ID', value: `#${ticketNumber}`, inline: true },
                            { name: 'Kanal', value: `${ticketChannel}`, inline: true }
                        )
                        .setTimestamp();
                    await logChannel.send({ embeds: [logEmbed] });
                    console.log(`[handleTicketCreateDirect] Log sent`);
                }
            } catch (error) {
                console.warn(`[handleTicketCreateDirect] Log send failed (non-critical):`, error.message);
            }
        }

        // Step 13: Reply to user
        console.log(`[handleTicketCreateDirect] Replying to user...`);
        await interaction.editReply({
            content: `✅ Ticket oluşturuldu: ${ticketChannel}`,
            ephemeral: true
        });
        console.log(`[handleTicketCreateDirect] SUCCESS`);
        
    } catch (error) {
        console.error(`[handleTicketCreateDirect] CRITICAL ERROR:`, error.message);
        console.error(`[handleTicketCreateDirect] Stack:`, error.stack);
        
        try {
            if (interaction.deferred && !interaction.replied) {
                await interaction.editReply({
                    content: `❌ Hata oluştu: ${error.message}`,
                    ephemeral: true
                });
            } else if (!interaction.replied) {
                await interaction.reply({
                    content: `❌ Hata oluştu: ${error.message}`,
                    ephemeral: true
                });
            }
        } catch (replyErr) {
            console.error(`[handleTicketCreateDirect] Could not send error reply:`, replyErr.message);
        }
    }
}

// ... (diğer fonksiyonlar eski handler'dan kopyalanacak)





