// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/protection.json');
const guvenli = require('../commands/guvenli');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    const guild = ban.guild;
    if (!guild) return;

    // Audit loglardan son ban girişini al
    const logs = await guild.fetchAuditLogs({ type: 22, limit: 1 });
    const entry = logs.entries.first();
    if (!entry) return;

    const executor = entry.executor;

    // Güvenli kontrolü - eğer banlayan kişi güvenli değilse ihlal say
    if (!guvenli.isUserSafe(guild.id, executor.id)) {
        // İhlal sayısını artır
        const violationCount = guvenli.trackViolation(guild.id, executor.id, 'İzinsiz Ban', guild);
        
        // İhlal log embed'i
        const violationEmbed = new EmbedBuilder()
            .setTitle('🚨 Güvenli Sistem İhlali - İzinsiz Ban')
            .setDescription(`**${executor.tag}** güvenli olmayan bir üyeyi banladı.`)
            .addFields(
                { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                { name: '🚫 Banlanan Üye', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
                { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
            )
            .setColor(0xFF9800)
            .setTimestamp();
        
        // Log kanalına gönder
        const data = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
        const guildData = data[guild.id];
        const logChannel = guild.channels.cache.get(guildData?.logChannel);
        if (logChannel) {
            await logChannel.send({ embeds: [violationEmbed] });
        }
        
        // İhlal limitini kontrol et
        await guvenli.handleViolationLimit(guild, executor.id, 'İzinsiz Ban', violationCount);
    }
  }
};





