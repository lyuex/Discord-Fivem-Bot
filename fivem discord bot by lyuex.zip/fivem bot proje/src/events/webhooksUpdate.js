// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const guvenli = require('../commands/guvenli');

module.exports = {
   name: Events.WebhooksUpdate,
    async execute(channel, client) {
        try {
            const audit = await channel.guild.fetchAuditLogs({ 
                type: AuditLogEvent.WebhookCreate,
                limit: 1
            });
            
            const auditEntry = audit.entries.first();
            const executor = auditEntry ? auditEntry.executor : null;

            // Eğer webhook yapan kişi güvenli değilse ihlal say
            if (executor && !guvenli.isUserSafe(channel.guild.id, executor.id)) {
                // İhlal sayısını artır
                const violationCount = guvenli.trackViolation(channel.guild.id, executor.id, 'Webhook Oluşturma', channel.guild);
                
                // İhlal log embed'i
                const violationEmbed = new EmbedBuilder()
                    .setTitle('🚨 Güvenli Sistem İhlali - Webhook Oluşturma')
                    .setDescription(`**${executor.tag}** bir webhook oluşturdu.`)
                    .addFields(
                        { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                        { name: '📁 Kanal', value: `${channel.name} (${channel.id})`, inline: true },
                        { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    )
                    .setColor(0xFF9800)
                    .setTimestamp();
                
                // Log kanalına gönder
                const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                if (logChannelId) {
                    const logChannel = client.channels.cache.get(logChannelId);
                    if (logChannel) {
                        await logChannel.send({ embeds: [violationEmbed] });
                    }
                }
                
                // İhlal limitini kontrol et
                await guvenli.handleViolationLimit(channel.guild, executor.id, 'Webhook Oluşturma', violationCount);
            }

            // Normal loglama
            const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
            if (logChannelId && executor) {
                const logChannel = client.channels.cache.get(logChannelId);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor(0x00D4FF)
                        .setTitle('🪝 Webhook Oluşturuldu')
                        .setDescription(`Bir webhook oluşturuldu.`)
                        .addFields(
                            { name: '👤 Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                            { name: '📁 Kanal', value: `${channel.name} (${channel.id})`, inline: true },
                            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        )
                        .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                        .setFooter({ text: `Webhook Sistemi • ${channel.guild.name}`, iconURL: channel.guild.iconURL({ dynamic: true }) })
                        .setTimestamp();
                    
                    await logChannel.send({ embeds: [embed] });
                }
            }
                
        } catch (error) {
            console.error('Webhook güncelleme log hatası:', error);
            catchError(client, 'webhooksUpdate.js', error.message);
        }
    }
};





