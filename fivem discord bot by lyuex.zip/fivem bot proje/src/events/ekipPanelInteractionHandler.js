// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { Ekip } = require('../Schemas/EkipSchema');

module.exports = {
    async execute(interaction) {
        try {
            console.log(`[EkipPanelHandler] Processing: ${interaction.customId}`);

            // Ekip ID'sini customId'den çıkar
            const ekipId = interaction.customId.split('_').pop();

            // Ekibi veritabanından bul
            const ekip = await Ekip.findById(ekipId);
            
            if (!ekip) {
                return await interaction.reply({
                    content: '❌ Ekip bulunamadı!',
                    ephemeral: true
                });
            }

            // Sadece ekip lideri ve yöneticiler kullanabilir
            const isLider = interaction.user.id === ekip.liderId;
            const isAdmin = interaction.member.permissions.has('Administrator');
            
            if (!isLider && !isAdmin) {
                return await interaction.reply({
                    content: '❌ Bu işlemi sadece ekip lideri veya yöneticiler yapabilir!',
                    ephemeral: true
                });
            }

            // Buton işlemleri
            if (interaction.customId.startsWith('ekip_panel_uye_ekle_')) {
                await handleUyeEkle(interaction, ekip);
            } else if (interaction.customId.startsWith('ekip_panel_uye_cikar_')) {
                await handleUyeCikar(interaction, ekip);
            } else if (interaction.customId.startsWith('ekip_panel_uye_liste_')) {
                await handleUyeListe(interaction, ekip);
            } else if (interaction.customId.startsWith('ekip_panel_ayarlar_')) {
                await handleAyarlar(interaction, ekip);
            } else if (interaction.customId.startsWith('ekip_panel_istatistik_')) {
                await handleIstatistik(interaction, ekip);
            }

        } catch (error) {
            console.error('Ekip panel handler hatası:', error);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Bir hata oluştu!',
                    ephemeral: true
                }).catch(() => {});
            }
        }
    }
};

// Üye ekleme modal
async function handleUyeEkle(interaction, ekip) {
    const modal = new ModalBuilder()
        .setCustomId(`ekip_panel_uye_ekle_submit_${ekip._id}`)
        .setTitle(`${ekip.ekipIsim} - Üye Ekle`);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Eklenecek kullanıcının ID\'sini girin')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const notInput = new TextInputBuilder()
        .setCustomId('ekleme_notu')
        .setLabel('Not (Opsiyonel)')
        .setPlaceholder('Ekleme sebebi veya not')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(200);

    const row1 = new ActionRowBuilder().addComponents(kullaniciInput);
    const row2 = new ActionRowBuilder().addComponents(notInput);

    modal.addComponents(row1, row2);
    await interaction.showModal(modal);
}

// Üye çıkarma modal
async function handleUyeCikar(interaction, ekip) {
    const modal = new ModalBuilder()
        .setCustomId(`ekip_panel_uye_cikar_submit_${ekip._id}`)
        .setTitle(`${ekip.ekipIsim} - Üye Çıkar`);

    const kullaniciInput = new TextInputBuilder()
        .setCustomId('kullanici_id')
        .setLabel('Kullanıcı ID')
        .setPlaceholder('Çıkarılacak kullanıcının ID\'sini girin')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

    const sebekInput = new TextInputBuilder()
        .setCustomId('cikarma_sebebi')
        .setLabel('Çıkarma Sebebi')
        .setPlaceholder('Kullanıcı neden ekipten çıkarılıyor?')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(300);

    const row1 = new ActionRowBuilder().addComponents(kullaniciInput);
    const row2 = new ActionRowBuilder().addComponents(sebekInput);

    modal.addComponents(row1, row2);
    await interaction.showModal(modal);
}

// Üye listesi göster
async function handleUyeListe(interaction, ekip) {
    await interaction.deferReply({ ephemeral: true });

    const renkInt = parseInt(ekip.renk, 16) || 0x5865F2;
    
    let uyeListesi = '';
    for (let i = 0; i < ekip.uyeler.length; i++) {
        const uye = ekip.uyeler[i];
        const ikon = uye.userId === ekip.liderId ? '👑' : '👤';
        const tarih = new Date(uye.eklenmetarihi).toLocaleDateString('tr-TR');
        uyeListesi += `${ikon} **${uye.userTag}**\n`;
        uyeListesi += `   └ ID: \`${uye.userId}\`\n`;
        uyeListesi += `   └ Eklenme: ${tarih}\n`;
        if (uye.not) uyeListesi += `   └ Not: ${uye.not}\n`;
        uyeListesi += '\n';
    }

    const embed = new EmbedBuilder()
        .setColor(renkInt)
        .setTitle(`📋 ${ekip.ekipIsim} - Üye Listesi`)
        .setDescription(
            `**Toplam Üye Sayısı:** ${ekip.uyeler.length}\n\n` +
            '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
            (uyeListesi || '*Üye bulunamadı*')
        )
        .setFooter({ text: `Ekip ID: ${ekip._id}` })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

// Ekip ayarları
async function handleAyarlar(interaction, ekip) {
    await interaction.deferReply({ ephemeral: true });

    const renkInt = parseInt(ekip.renk, 16) || 0x5865F2;
    const kurulusTarihi = Math.floor(ekip.olusturulmaTarihi.getTime() / 1000);

    const embed = new EmbedBuilder()
        .setColor(renkInt)
        .setTitle(`⚙️ ${ekip.ekipIsim} - Ekip Ayarları`)
        .setDescription(
            '**Ekip Detaylı Bilgileri**\n\n' +
            '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'
        )
        .addFields(
            { name: '🏷️ Ekip İsmi', value: `\`\`\`${ekip.ekipIsim}\`\`\``, inline: true },
            { name: '👑 Lider', value: `\`\`\`${ekip.liderTag}\`\`\``, inline: true },
            { name: '🆔 Ekip ID', value: `\`\`\`${ekip._id}\`\`\``, inline: true },
            { name: '👥 Üye Sayısı', value: `\`\`\`${ekip.uyeler.length} kişi\`\`\``, inline: true },
            { name: '⭐ Seviye', value: `\`\`\`Level ${ekip.seviye}\`\`\``, inline: true },
            { name: '💎 Puan', value: `\`\`\`${ekip.puan} puan\`\`\``, inline: true },
            { name: '🎨 Renk', value: `\`\`\`#${ekip.renk.toUpperCase()}\`\`\``, inline: true },
            { name: '🎯 Durum', value: `\`\`\`${ekip.durum}\`\`\``, inline: true },
            { name: '📅 Kuruluş', value: `<t:${kurulusTarihi}:F>`, inline: true },
            { name: '📝 Açıklama', value: `> ${ekip.ekipAciklama}`, inline: false }
        )
        .setFooter({ text: 'Ekip Yönetim Sistemi' })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

// İstatistikler
async function handleIstatistik(interaction, ekip) {
    await interaction.deferReply({ ephemeral: true });

    const renkInt = parseInt(ekip.renk, 16) || 0x5865F2;
    const ekipYasi = Math.floor((Date.now() - ekip.olusturulmaTarihi.getTime()) / (1000 * 60 * 60 * 24));

    const embed = new EmbedBuilder()
        .setColor(renkInt)
        .setTitle(`📊 ${ekip.ekipIsim} - Ekip İstatistikleri`)
        .setDescription(
            '**Detaylı Performans Raporu**\n\n' +
            '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'
        )
        .addFields(
            { name: '👥 Toplam Üye', value: `\`\`\`\n${ekip.uyeler.length} kişi\n\`\`\``, inline: true },
            { name: '⭐ Ekip Seviyesi', value: `\`\`\`\nLevel ${ekip.seviye}\n\`\`\``, inline: true },
            { name: '💎 Toplam Puan', value: `\`\`\`\n${ekip.puan} puan\n\`\`\``, inline: true },
            { name: '📅 Ekip Yaşı', value: `\`\`\`\n${ekipYasi} gün\n\`\`\``, inline: true },
            { name: '🎯 Aktiflik', value: `\`\`\`\n${ekip.durum}\n\`\`\``, inline: true },
            { name: '🏆 Başarı', value: `\`\`\`\n${ekip.seviye * 10}%\n\`\`\``, inline: true },
            { name: '📈 Büyüme Hızı', value: `\`\`\`\n${(ekip.uyeler.length / Math.max(ekipYasi, 1)).toFixed(2)} üye/gün\n\`\`\``, inline: true },
            { name: '⏱️ Son Aktivite', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
            { name: '🎨 Renk Kodu', value: `\`\`\`\n#${ekip.renk.toUpperCase()}\n\`\`\``, inline: true }
        )
        .setFooter({ text: `Ekip ID: ${ekip._id}` })
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}
