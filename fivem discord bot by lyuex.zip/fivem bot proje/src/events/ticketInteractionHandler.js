// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const ticketUtil = require('../utils/ticketUtil');

module.exports = {
    async execute(interaction) {
        // Ticket kapama butonu
        if (interaction.customId.startsWith('tc_close_')) {
            const channelId = interaction.customId.replace('tc_close_', '');
            
            // Eğer butonun basıldığı kanal ile channelId eşleşiyorsa
            if (interaction.channel.id === channelId) {
                const ticketData = ticketUtil.getTicketByChannelId(channelId);
                
                const confirmEmbed = new EmbedBuilder()
                    .setColor(0xF39C12)
                    .setTitle('⚠️ Ticket Kapatılacak')
                    .setDescription('Bu ticket\'i kapatmak istediğinize emin misiniz?')
                    .setFooter({ text: 'Bu işlem geri alınamaz!' });
                    
                const confirmButtons = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`tc_confirm_close_${channelId}`)
                            .setLabel('Kapat')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('✅'),
                        new ButtonBuilder()
                            .setCustomId(`tc_cancel_close_${channelId}`)
                            .setLabel('İptal')
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji('❌')
                    );
                    
                await interaction.reply({
                    embeds: [confirmEmbed],
                    components: [confirmButtons]
                });
            }
            return;
        }
        
        // Ticket kapama onayı
        if (interaction.customId.startsWith('tc_confirm_close_')) {
            const channelId = interaction.customId.replace('tc_confirm_close_', '');
            
            await interaction.reply({ content: '🔒 Ticket kapatılıyor...' });
            
            const ticketData = ticketUtil.getTicketByChannelId(channelId);
            if (ticketData) {
                ticketUtil.updateTicket(ticketData.id, {
                    status: 'closed',
                    closedAt: Date.now(),
                    closedBy: interaction.user.id
                });
            }
            
            setTimeout(() => {
                interaction.channel.delete().catch(console.error);
            }, 3000);
            
            return;
        }
        
        // Ticket kapama iptal
        if (interaction.customId.startsWith('tc_cancel_close_')) {
            const channelId = interaction.customId.replace('tc_cancel_close_', '');
            
            await interaction.update({
                content: '✅ Ticket kapatma iptal edildi',
                embeds: [],
                components: []
            });
            
            return;
        }
    }
};




