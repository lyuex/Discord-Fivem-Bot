// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildStickerUpdate,
    async execute(oldSticker, newSticker) {
        if (!lyuex.log?.enabled) return;
        if (!lyuex.log?.events?.emoji_update) return; // Sticker güncellemeleri emoji update olarak loglanıyor

        const logChannel = newSticker.guild.channels.cache.get(lyuex.log.channels.system_logs);
        if (!logChannel) return;

        try {
            const fetchedLogs = await newSticker.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.StickerUpdate
            });

            const stickerLog = fetchedLogs.entries.first();
            if (!stickerLog) return;

            const { executor } = stickerLog;

            // Değişiklikleri tespit et
            const changes = [];
            if (oldSticker.name !== newSticker.name) {
                changes.push(`**İsim:** \`${oldSticker.name}\` → \`${newSticker.name}\``);
            }
            if (oldSticker.description !== newSticker.description) {
                changes.push(`**Açıklama:** \`${oldSticker.description || 'Yok'}\` → \`${newSticker.description || 'Yok'}\``);
            }
            if (oldSticker.tags?.join(', ') !== newSticker.tags?.join(', ')) {
                changes.push(`**Etiketler:** \`${oldSticker.tags?.join(', ') || 'Yok'}\` → \`${newSticker.tags?.join(', ') || 'Yok'}\``);
            }

            const embed = new EmbedBuilder()
                .setColor(0xFFFF00)
                .setTitle('🏷️ Sticker Güncellendi!')
                .setThumbnail(newSticker.guild.iconURL({ dynamic: true }))
                .setDescription(`
                    **Güncelleyen Kişi:**
                    <@${executor.id}> - ${executor.id}
                    **Sticker Bilgileri:**
                    > ${newSticker.name} - ID: ${newSticker.id}
                `)
                .addFields(
                    { name: '🏷️ Sticker Adı', value: `\`${newSticker.name}\``, inline: true },
                    { name: '🆔 Sticker ID', value: `\`${newSticker.id}\``, inline: true },
                    { name: '👤 Güncelleyen', value: `<@${executor.id}>\n${executor.tag}`, inline: true },
                    { name: '📝 Yapılan Değişiklikler', value: changes.length > 0 ? changes.join('\n') : 'Değişiklik tespit edilemedi', inline: false },
                    { name: '🎨 Format', value: newSticker.format === 1 ? 'PNG' : newSticker.format === 2 ? 'APNG' : 'Lottie', inline: true },
                    { name: '📊 Boyut', value: `${newSticker.width}x${newSticker.height}`, inline: true },
                    { name: '⏰ Güncellenme', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setImage(newSticker.url)
                .setFooter({
                    text: `LYUEX Gelişmiş Log Sistemi • Sticker Yönetimi`,
                    iconURL: newSticker.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Sticker güncelleme log hatası:', error);
        }
    },
};





