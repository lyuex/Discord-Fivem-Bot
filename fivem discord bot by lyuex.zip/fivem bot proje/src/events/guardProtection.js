// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');

const PROTECTION_FILE = path.join(__dirname, '..', 'data', 'protection.json');

// Kullanıcı aksiyon tracker'ı
const userActions = new Map();

async function readProtectionData() {
    try {
        const data = await fs.readFile(PROTECTION_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

async function isUserWhitelisted(guildId, userId) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.whitelistUsers?.includes(userId) || false;
}

async function isProtectionEnabled(guildId, protectionType) {
    const protectionData = await readProtectionData();
    return protectionData[guildId]?.enabled && protectionData[guildId]?.settings?.[protectionType];
}

async function logAction(guild, embed) {
    const protectionData = await readProtectionData();
    const logChannelId = protectionData[guild.id]?.logChannel;
    
    if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] }).catch(console.error);
        }
    }
}

function trackUserAction(guildId, userId, actionType) {
    const key = `${guildId}_${userId}`;
    const now = Date.now();
    
    if (!userActions.has(key)) {
        userActions.set(key, []);
    }
    
    const actions = userActions.get(key);
    actions.push({ type: actionType, timestamp: now });
    
    // 1 dakikadan eski aksiyonları temizle
    const filteredActions = actions.filter(action => now - action.timestamp < 60000);
    userActions.set(key, filteredActions);
    
    return filteredActions.length;
}

async function handleSuspiciousActivity(guild, userId, actionType, actionCount) {
    const protectionData = await readProtectionData();
    const maxActions = protectionData[guild.id]?.settings?.maxActions || 3;
    
    if (actionCount >= maxActions) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (member && !member.permissions.has('Adlyuexstrator')) {
            try {
                // Kullanıcıyı yasakla
                await member.ban({ 
                    reason: `Guard sistemi: Şüpheli aktivite tespit edildi (${actionType} - ${actionCount} kez)`,
                    deleteMessageDays: 1
                });
                
                // Log embed'i
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 Otomatik Yasaklama')
                    .setDescription(`**${member.user.tag}** şüpheli aktivite nedeniyle yasaklandı.`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.id})`, inline: true },
                        { name: '⚠️ Tespit Edilen Aktivite', value: actionType, inline: true },
                        { name: '📊 Aksiyon Sayısı', value: `${actionCount}/${maxActions}`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    )
                    .setColor(0xF44336)
                    .setTimestamp();
                
                await logAction(guild, logEmbed);
                
                // Tracker'dan temizle
                userActions.delete(`${guild.id}_${userId}`);
                
            } catch (error) {
                console.error('Kullanıcı yasaklanırken hata:', error);
            }
        }
    }
}

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        const guildId = member.guild.id;
        
        // Anti-raid kontrolü
        if (await isProtectionEnabled(guildId, 'antiRaid')) {
            const recentJoins = member.guild.members.cache
                .filter(m => Date.now() - m.joinedTimestamp < 10000) // Son 10 saniye
                .size;
            
            if (recentJoins > 5) { // 10 saniyede 5'ten fazla üye
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 Raid Tespit Edildi!')
                    .setDescription(`Son 10 saniyede ${recentJoins} üye katıldı. Potansiyel raid saldırısı!`)
                    .addFields(
                        { name: '👤 Son Katılan', value: `${member.user.tag} (${member.id})`, inline: true },
                        { name: '📊 Toplam Yeni Üye', value: `${recentJoins} üye`, inline: true },
                        { name: '⏰ Zaman Aralığı', value: 'Son 10 saniye', inline: true }
                    )
                    .setColor(0xFF9800)
                    .setTimestamp();
                
                await logAction(member.guild, logEmbed);
            }
        }
        
        // Anti-bot kontrolü
        if (await isProtectionEnabled(guildId, 'antiBot') && member.user.bot) {
            // Bot ekleyen kişiyi bul
            const auditLogs = await member.guild.fetchAuditLogs({
                type: AuditLogEvent.BotAdd,
                limit: 1
            }).catch(() => null);
            
            if (auditLogs && auditLogs.entries.size > 0) {
                const botAddLog = auditLogs.entries.first();
                const executor = botAddLog.executor;
                
                if (executor && !await isUserWhitelisted(guildId, executor.id)) {
                    const actionCount = trackUserAction(guildId, executor.id, 'Bot Ekleme');
                    
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🤖 Bot Ekleme Tespit Edildi')
                        .setDescription(`**${executor.tag}** bir bot ekledi.`)
                        .addFields(
                            { name: '🤖 Eklenen Bot', value: `${member.user.tag} (${member.id})`, inline: true },
                            { name: '👤 Ekleyen', value: `${executor.tag} (${executor.id})`, inline: true },
                            { name: '📊 Aksiyon Sayısı', value: `${actionCount}`, inline: true }
                        )
                        .setColor(0xFF9800)
                        .setTimestamp();
                    
                    await logAction(member.guild, logEmbed);
                    await handleSuspiciousActivity(member.guild, executor.id, 'Bot Ekleme', actionCount);
                }
            }
        }
    }
};




