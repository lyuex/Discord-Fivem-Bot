// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { checkSteamHexExists, getUserSteamHex } = require('../utils/steamHexManager');

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        // Bot mesajlarını yok say
        if (message.author.bot) return;
        
        // Sadece hex kanalında çalış
        const hexKanalId = lyuex.hex_sistem?.kanal;
        
        if (!hexKanalId || message.channel.id !== hexKanalId) {
            return;
        }
        
        // Whitelist rolü kontrolü
        const whitelistRoles = lyuex.rol?.whitelist;
        if (whitelistRoles) {
            // String ise array'e çevir, array ise olduğu gibi kullan
            const roleArray = Array.isArray(whitelistRoles) ? whitelistRoles : [whitelistRoles];
            const hasWhitelistRole = roleArray.some(roleId => 
                message.member.roles.cache.has(roleId)
            );
            
            if (hasWhitelistRole) {
                // Kullanıcı mesajını sil
                await message.delete();
                
                // Whitelist engellemesi embed'i
                const whitelistEmbed = new EmbedBuilder()
                    .setColor(0xFF6600)
                    .setTitle('🚫 Whitelist Rolü Tespit Edildi!')
                    .setDescription(`${message.author}, **Whitelist** rolünüz olduğu için bu kanala mesaj gönderemezsiniz!`)
                    .addFields(
                        { name: '⚠️ Sebep', value: 'Whitelist rolü mevcutluğu', inline: true },
                        { name: '🎫 Çözüm', value: 'Ticket açınız', inline: true },
                        { name: '📞 Yardım', value: 'Yetkili desteği alın', inline: true },
                        { name: '💡 Not', value: 'Steam Hex işlemleri için **ticket sistemi** kullanmalısınız', inline: false },
                        { name: '🎯 Ticket Kanalı', value: 'Ticket açma kanalından yardım talep edin', inline: false }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 12 saniye sonra silinecek • LYUEX' })
                    .setTimestamp();
                
                const whitelistMesaj = await message.channel.send({ embeds: [whitelistEmbed] });
                
                // 12 saniye sonra mesajı sil
                setTimeout(() => {
                    whitelistMesaj.delete().catch(() => {});
                }, 12000);
                
                return;
            }
        }

        const hexKodu = message.content.trim();

        try {
            // Steam ID formatını kontrol et (steam:110000xxxxxxxxx) - hex kısmı 8+ karakter olabilir
            const steamIdRegex = /^steam:110000[a-fA-F0-9]+$/;
            if (!steamIdRegex.test(hexKodu)) {
                await message.delete();
                
                const formatUyariEmbed = new EmbedBuilder()
                    .setColor(0xFF4444)
                    .setTitle('⚠️ Geçersiz Steam ID Format')
                    .setDescription(`${message.author}, Steam ID formatınız **yanlış**!`)
                    .addFields(
                        { name: '❌ Sorun', value: 'Geçersiz Steam ID formatı', inline: true },
                        { name: '📝 Doğru Format', value: '`steam:110000xxxxxxxx`', inline: true },
                        { name: '✅ Örnek', value: '`steam:110000115c44f06`', inline: true },
                        { name: '🔍 Format Açıklaması', value: '• `steam:` ile başlamalı\n• `110000` ile devam etmeli\n• Hex karakterler (0-9, A-F)', inline: false },
                        { name: '📏 Uzunluk', value: 'Minimum 17 karakter', inline: true },
                        { name: '🔤 Karakterler', value: 'steam:110000 + hex karakterler', inline: true }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 10 saniye sonra silinecek • LYUEX' })
                    .setTimestamp();
                
                const uyariMesaj = await message.channel.send({ embeds: [formatUyariEmbed] });
                
                // 10 saniye sonra uyarı mesajını sil
                setTimeout(() => {
                    uyariMesaj.delete().catch(() => {});
                }, 10000);
                
                return;
            }

            // Steam ID'yi temizle ve hex kısmını al
            const temizSteamId = hexKodu.toLowerCase();
            const hexKisim = temizSteamId.replace('steam:110000', '').toUpperCase();

            // Data tabanlı Steam hex kontrolü
            const existingHex = checkSteamHexExists(temizSteamId);
            if (existingHex) {
                await message.delete().catch(() => {});
                
                // Eğer aynı kullanıcı ise
                if (existingHex.userId === message.author.id) {
                    const sameuserEmbed = new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setTitle('✅ Steam Hex Zaten Onaylı')
                        .setDescription(`${message.author}, Bu Steam hex zaten **sizin tarafınızdan onaylanmış**!`)
                        .addFields(
                            { name: '🎮 Steam Hex', value: `\`${temizSteamId}\``, inline: true },
                            { name: '✅ Onaylayan', value: `<@${existingHex.approvedBy}>`, inline: true },
                            { name: '📅 Onay Tarihi', value: `<t:${Math.floor(new Date(existingHex.approvedAt).getTime() / 1000)}:F>`, inline: false }
                        )
                        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                        .setFooter({ text: 'Bu mesaj 10 saniye sonra silinecek • LYUEX' })
                        .setTimestamp();
                    
                    const uyariMesaj = await message.channel.send({ embeds: [sameuserEmbed] });
                    setTimeout(() => uyariMesaj.delete().catch(() => {}), 10000);
                    return;
                } else {
                    // Başka kullanıcı tarafından onaylanmış
                    const otherUserEmbed = new EmbedBuilder()
                        .setColor(0xFF4444)
                        .setTitle('❌ Steam Hex Zaten Kullanımda')
                        .setDescription(`${message.author}, Bu Steam hex **başka bir kullanıcı tarafından** zaten onaylanmış!`)
                        .addFields(
                            { name: '🎮 Steam Hex', value: `\`${temizSteamId}\``, inline: true },
                            { name: '👤 Kullanıcı', value: `<@${existingHex.userId}>`, inline: true },
                            { name: '✅ Onaylayan', value: `<@${existingHex.approvedBy}>`, inline: true },
                            { name: '📅 Onay Tarihi', value: `<t:${Math.floor(new Date(existingHex.approvedAt).getTime() / 1000)}:F>`, inline: false },
                            { name: '💡 Çözüm', value: 'Farklı bir Steam hex kullanmanız gerekiyor.', inline: false }
                        )
                        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                        .setFooter({ text: 'Bu mesaj 15 saniye sonra silinecek • LYUEX' })
                        .setTimestamp();
                    
                    const uyariMesaj = await message.channel.send({ embeds: [otherUserEmbed] });
                    setTimeout(() => uyariMesaj.delete().catch(() => {}), 15000);
                    return;
                }
            }

            // Kullanıcının zaten onaylanmış başka bir hex'i var mı kontrol et
            const userExistingHex = getUserSteamHex(message.author.id);
            if (userExistingHex) {
                await message.delete().catch(() => {});
                
                const existingHexEmbed = new EmbedBuilder()
                    .setColor(0xFFA500)
                    .setTitle('⚠️ Zaten Onaylanmış Steam Hex Var')
                    .setDescription(`${message.author}, Sizin zaten **onaylanmış bir Steam hex**'iniz bulunuyor!`)
                    .addFields(
                        { name: '🎮 Mevcut Steam Hex', value: `\`${userExistingHex.steamHex}\``, inline: true },
                        { name: '✅ Onaylayan', value: `<@${userExistingHex.approvedBy}>`, inline: true },
                        { name: '📅 Onay Tarihi', value: `<t:${Math.floor(new Date(userExistingHex.approvedAt).getTime() / 1000)}:F>`, inline: false },
                        { name: '🔄 Yeni Steam Hex', value: `\`${temizSteamId}\``, inline: false },
                        { name: '💡 Bilgi', value: 'Steam hex değiştirmek için yetkililerle iletişime geçin.', inline: false }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 15 saniye sonra silinecek • LYUEX' })
                    .setTimestamp();
                
                const uyariMesaj = await message.channel.send({ embeds: [existingHexEmbed] });
                setTimeout(() => uyariMesaj.delete().catch(() => {}), 15000);
                return;
            }

            // Steam ID onay embed'i oluştur
            // Steam ID onay embed'i oluştur
            const onayEmbed = new EmbedBuilder()
                .setColor(0x1B2838) // Steam rengi
                .setTitle('� Steam ID Onay Paneli')
                .setDescription(`🎯 **${message.author}** tarafından gönderilen Steam ID onay bekliyor!`)
                .addFields(
                    { name: '� Steam ID', value: `\`\`\`${temizSteamId}\`\`\``, inline: true },
                    { name: '👑 Kullanıcı', value: `**${message.author.tag}**`, inline: true },
                    { name: '🆔 Kullanıcı ID', value: `${message.author.id}`, inline: true },
                    { name: '📅 Hesap Yaşı', value: `<t:${Math.floor(message.author.createdAt.getTime() / 1000)}:R>`, inline: true },
                    { name: '📥 Sunucuya Katılım', value: `<t:${Math.floor(message.member.joinedAt.getTime() / 1000)}:R>`, inline: true },
                    { name: '🎯 Durum', value: '⏳ **ONAY BEKLİYOR**', inline: true },
                    { name: '🔍 Steam Bilgisi', value: `Prefix: \`steam:110000\`\nHex: \`${hexKisim}\`\nUzunluk: ${temizSteamId.length} karakter`, inline: false },
                    { name: '⏰ Gönderim Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🔄 Mesaj ID', value: `\`${message.id}\``, inline: true }
                )
                .setThumbnail(message.author.displayAvatarURL({ dynamic: true, size: 256 }))
                .setImage('https://cdn.discordapp.com/attachments/1422661295571992576/1423321126733349035/lyuexdevkirmizi_1.png')
                .setFooter({ 
                    text: `Gönderen: ${message.author.tag} • LYUEX 🎮`,
                    iconURL: message.author.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();

            // Butonları oluştur
            const onayButonlari = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`steam_onayla_${message.author.id}_${message.id}`)
                        .setLabel('✅ Onayla')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅'),
                    new ButtonBuilder()
                        .setCustomId(`steam_uygunsuz_${message.author.id}_${message.id}`)
                        .setLabel('❌ Uygunsuz')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('❌'),
                    new ButtonBuilder()
                        .setCustomId(`steam_gecersiz_${message.author.id}_${message.id}`)
                        .setLabel('⚠️ Geçersiz ID')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('⚠️'),
                    new ButtonBuilder()
                        .setCustomId(`steam_ozel_${message.author.id}_${message.id}`)
                        .setLabel('🔮 Özel Sebep')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🔮')
                );

            // Orijinal mesajı KORU ve onay panelini cevap olarak gönder (onayda ✅ reaksiyon için gerekli)
            await message.reply({
                content: `📢 **Steam ID Onay Sistemi** | Yetkili: ${lyuex.hex_sistem?.yetkili_rol?.map(id => `<@&${id}>`).join(' ')}`,
                embeds: [onayEmbed],
                components: [onayButonlari],
                allowedMentions: { repliedUser: false }
            });

        } catch (error) {
            console.error('Hex onay sistemi hatası:', error);
        }
    },
};

// Renk önizleme fonksiyonu
async function generateColorPreview(hexColor) {
    const hex = hexColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    
    // RGB değerleri
    const rgbText = `RGB(${r}, ${g}, ${b})`;
    
    // Renk parlaklığını hesapla
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    const isDark = brightness < 128;
    
    // Renk kategorisi
    let category = '';
    if (r > 200 && g < 100 && b < 100) category = '🔴 Kırmızı';
    else if (r < 100 && g > 200 && b < 100) category = '🟢 Yeşil';
    else if (r < 100 && g < 100 && b > 200) category = '🔵 Mavi';
    else if (r > 200 && g > 200 && b < 100) category = '🟡 Sarı';
    else if (r > 200 && g < 100 && b > 200) category = '🟣 Mor';
    else if (r < 100 && g > 200 && b > 200) category = '🩵 Cyan';
    else if (r > 200 && g > 200 && b > 200) category = '⚪ Beyaz';
    else if (r < 50 && g < 50 && b < 50) category = '⚫ Siyah';
    else category = '🎨 Karma';
    
    return `**${hexColor}** | ${rgbText}\n${category} | ${isDark ? '🌙 Koyu' : '☀️ Açık'} Ton`;
}




