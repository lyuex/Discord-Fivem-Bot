// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction) {
    // Only process button interactions that match our pattern
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith('çekiliş_reroll_')) return;
    
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Yetki kontrolü
      const member = interaction.member;
      const hasPermission = member.roles.cache.has(lyuex.yetkili.kurucu) || 
                          member.permissions.has('ManageGuild') ||
                          member.permissions.has('Adlyuexstrator');
      
      if (!hasPermission) {
        return await interaction.editReply({ 
          content: '❌ **Yetersiz Yetki!** Bu işlemi gerçekleştirmek için aşağıdaki yetkilerden birine sahip olmalısınız:\n' +
                  '• Kurucu rolü\n' +
                  '• Sunucuyu Yönet yetkisi\n' +
                  '• Yönetici yetkisi',
          ephemeral: true
        });
      }
      
      // Get the giveaway message ID
      const giveawayMessageId = interaction.customId.replace('çekiliş_reroll_', '');
      const giveawayMessage = interaction.message;
      
      if (!giveawayMessage || giveawayMessage.id !== giveawayMessageId) {
        return await interaction.editReply({ 
          content: '❌ **Hata!** Çekiliş mesajı bulunamadı veya silinmiş.',
          ephemeral: true
        });
      }

      // Extract giveaway info from the message embed
      const giveawayEmbed = giveawayMessage.embeds[0];
      if (!giveawayEmbed) {
        return await interaction.editReply({ 
          content: '❌ **Hata!** Çekiliş bilgileri alınamadı.',
          ephemeral: true 
        });
      }
      
      // Parse information from the embed
      let prizeText = "Çekiliş Ödülü";
      let winnerCount = 1;
      
      const description = giveawayEmbed.description;
      if (description) {
        // Try to extract the prize
        const prizeMatch = description.match(/\*\*🎁 Ödül:\*\* (.*?)(?:\n|$)/);
        if (prizeMatch && prizeMatch[1]) {
          prizeText = prizeMatch[1];
        }
        
        // Try to extract winner count
        const winnerMatch = description.match(/\*\*🏆 Kazanan Sayısı:\*\* (\d+)/);
        if (winnerMatch && winnerMatch[1]) {
          winnerCount = parseInt(winnerMatch[1]);
        }
      }

      // Ask user for confirmation and winner count
      await interaction.editReply({
        content: `🔄 **Çekilişi Yeniden Yapma Onayı**

🎁 **Ödül:** ${prizeText}
🏆 **Önerilen Kazanan Sayısı:** ${winnerCount} kişi

Yeniden çekiliş yapmak için "/yeniden-çekiliş" komutunu kullanabilirsiniz:
\`\`\`
/yeniden-çekiliş mesaj_id:${giveawayMessageId} kanal:#${interaction.channel.name} kazanan_sayısı:${winnerCount}
\`\`\`

Komutu kullanarak kazanan sayısını değiştirebilir ve önceki kazananların tekrar seçilmesine izin verebilirsiniz.`,
        ephemeral: true
      });

    } catch (error) {
      console.error('Yeniden çekiliş butonu hatası:', error);
      if (interaction.deferred) {
        await interaction.editReply({ 
          content: `❌ **Hata!** İşlem sırasında bir sorun oluştu: ${error.message}`, 
          ephemeral: true 
        });
      }
    }
  }
};




