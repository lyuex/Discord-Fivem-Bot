// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.GuildStickerDelete,
    async execute(sticker) {
        if (!lyuex.log?.enabled) return;
        if (!lyuex.log?.events?.emoji_delete) return; // Sticker silmeleri emoji delete olarak loglanıyor

        const logChannel = sticker.guild.channels.cache.get(lyuex.log.channels.system_logs);
        if (!logChannel) return;

        try {
            const fetchedLogs = await sticker.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.StickerDelete
            });

            const stickerLog = fetchedLogs.entries.first();
            if (!stickerLog) return;

            const { executor } = stickerLog;

            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('🏷️ Sticker Silindi!')
                .setThumbnail(sticker.guild.iconURL({ dynamic: true }))
                .setDescription(`
                    **Silen Kişi:**
                    <@${executor.id}> - ${executor.id}
                    **Silinen Sticker:**
                    > ${sticker.name} - ID: ${sticker.id}
                `)
                .addFields(
                    { name: '🏷️ Sticker Adı', value: `\`${sticker.name}\``, inline: true },
                    { name: '🆔 Sticker ID', value: `\`${sticker.id}\``, inline: true },
                    { name: '👤 Silen Kişi', value: `<@${executor.id}>\n${executor.tag}`, inline: true },
                    { name: '📝 Son Açıklama', value: sticker.description || 'Açıklama yok', inline: false },
                    { name: '🏷️ Son Etiketler', value: sticker.tags?.length > 0 ? sticker.tags.join(', ') : 'Etiket yok', inline: false },
                    { name: '🎨 Format', value: sticker.format === 1 ? 'PNG' : sticker.format === 2 ? 'APNG' : 'Lottie', inline: true },
                    { name: '📊 Boyut', value: `${sticker.width}x${sticker.height}`, inline: true },
                    { name: '⏰ Silinme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setImage(sticker.url)
                .setFooter({
                    text: `LYUEX Gelişmiş Log Sistemi • Sticker Yönetimi`,
                    iconURL: sticker.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Sticker silme log hatası:', error);
        }
    },
};





