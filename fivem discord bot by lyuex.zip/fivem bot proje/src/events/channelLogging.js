// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, AuditLogEvent, ChannelType } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = [
    // Kanal oluşturma
    {
        name: Events.ChannelCreate,
        async execute(channel) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.channel_create) return;
            
            const logChannel = channel.guild.channels.cache.get(lyuex.log.channels.channel_logs);
            if (!logChannel) return;

            try {
                // Audit log'dan kim oluşturduğunu bul
                const auditLogs = await channel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelCreate,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;

                const channelTypeNames = {
                    [ChannelType.GuildText]: '📝 Metin Kanalı',
                    [ChannelType.GuildVoice]: '🔊 Ses Kanalı',
                    [ChannelType.GuildCategory]: '📁 Kategori',
                    [ChannelType.GuildAnnouncement]: '📢 Duyuru Kanalı',
                    [ChannelType.GuildStageVoice]: '🎭 Sahne Kanalı',
                    [ChannelType.GuildForum]: '💬 Forum Kanalı'
                };

                const embed = new EmbedBuilder()
                    .setColor(0x00FF99)
                    .setTitle('🆕 Kanal Oluşturuldu')
                    .setDescription(`Yeni bir kanal oluşturuldu: **${channel.name}**`)
                    .addFields(
                        { name: '📝 Kanal Adı', value: channel.name, inline: true },
                        { name: '🏷️ Kanal Türü', value: channelTypeNames[channel.type] || 'Bilinmeyen', inline: true },
                        { name: '👮 Oluşturan', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '📍 Kategori', value: channel.parent ? channel.parent.name : 'Kategori yok', inline: true },
                        { name: '🆔 Kanal ID', value: channel.id, inline: true },
                        { name: '⏰ Oluşturulma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Kanal Yönetimi • LYUEX`,
                        iconURL: channel.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                // Kanal açıklaması varsa ekle
                if (channel.topic) {
                    embed.addFields({ name: '📄 Açıklama', value: channel.topic, inline: false });
                }

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kanal oluşturma log hatası:', error);
            }
        }
    },

    // Kanal silme
    {
        name: Events.ChannelDelete,
        async execute(channel) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.channel_delete) return;
            
            const logChannel = channel.guild.channels.cache.get(lyuex.log.channels.channel_logs);
            if (!logChannel) return;

            try {
                // Audit log'dan kim sildiğini bul
                const auditLogs = await channel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelDelete,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;

                const channelTypeNames = {
                    [ChannelType.GuildText]: '📝 Metin Kanalı',
                    [ChannelType.GuildVoice]: '🔊 Ses Kanalı',
                    [ChannelType.GuildCategory]: '📁 Kategori',
                    [ChannelType.GuildAnnouncement]: '📢 Duyuru Kanalı',
                    [ChannelType.GuildStageVoice]: '🎭 Sahne Kanalı',
                    [ChannelType.GuildForum]: '💬 Forum Kanalı'
                };

                const embed = new EmbedBuilder()
                    .setColor(0xFF4444)
                    .setTitle('🗑️ Kanal Silindi')
                    .setDescription(`**${channel.name}** kanalı silindi`)
                    .addFields(
                        { name: '📝 Silinen Kanal', value: channel.name, inline: true },
                        { name: '🏷️ Kanal Türü', value: channelTypeNames[channel.type] || 'Bilinmeyen', inline: true },
                        { name: '👮 Silen Kişi', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '📍 Kategori', value: channel.parent ? channel.parent.name : 'Kategori yok', inline: true },
                        { name: '🆔 Kanal ID', value: channel.id, inline: true },
                        { name: '⏰ Silinme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Kanal Yönetimi • LYUEX`,
                        iconURL: channel.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                // Kanal açıklaması varsa ekle
                if (channel.topic) {
                    embed.addFields({ name: '📄 Son Açıklama', value: channel.topic, inline: false });
                }

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kanal silme log hatası:', error);
            }
        }
    },

    // Kanal güncelleme
    {
        name: Events.ChannelUpdate,
        async execute(oldChannel, newChannel) {
            if (!lyuex.log?.enabled || !lyuex.log?.events?.channel_update) return;
            
            const logChannel = newChannel.guild.channels.cache.get(lyuex.log.channels.channel_logs);
            if (!logChannel) return;

            try {
                // Audit log'dan kim güncellediğini bul
                const auditLogs = await newChannel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelUpdate,
                    limit: 1
                });
                
                const auditEntry = auditLogs.entries.first();
                const executor = auditEntry ? auditEntry.executor : null;

                const changes = [];
                
                // İsim değişikliği
                if (oldChannel.name !== newChannel.name) {
                    changes.push(`**İsim:** \`${oldChannel.name}\` → \`${newChannel.name}\``);
                }
                
                // Açıklama değişikliği
                if (oldChannel.topic !== newChannel.topic) {
                    changes.push(`**Açıklama:** \`${oldChannel.topic || 'Yok'}\` → \`${newChannel.topic || 'Yok'}\``);
                }
                
                // Kategori değişikliği
                if (oldChannel.parentId !== newChannel.parentId) {
                    const oldParent = oldChannel.parent ? oldChannel.parent.name : 'Kategori yok';
                    const newParent = newChannel.parent ? newChannel.parent.name : 'Kategori yok';
                    changes.push(`**Kategori:** \`${oldParent}\` → \`${newParent}\``);
                }

                if (changes.length === 0) return; // Değişiklik yoksa log yapma

                const embed = new EmbedBuilder()
                    .setColor(0xFFA500)
                    .setTitle('✏️ Kanal Güncellendi')
                    .setDescription(`**${newChannel.name}** kanalında değişiklik yapıldı`)
                    .addFields(
                        { name: '📝 Kanal', value: `${newChannel.name} (${newChannel.id})`, inline: true },
                        { name: '👮 Güncelleyen', value: executor ? `${executor.tag} (${executor.id})` : 'Bilinmiyor', inline: true },
                        { name: '⏰ Güncelleme Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '📋 Yapılan Değişiklikler', value: changes.join('\n'), inline: false }
                    )
                    .setThumbnail(newChannel.guild.iconURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Kanal Yönetimi • LYUEX`,
                        iconURL: newChannel.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();

                await logChannel.send({ embeds: [embed] });

            } catch (error) {
                console.error('Kanal güncelleme log hatası:', error);
            }
        }
    }
];




