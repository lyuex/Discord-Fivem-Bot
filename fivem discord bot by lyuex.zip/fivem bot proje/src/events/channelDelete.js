// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const guvenli = require('../commands/guvenli');

module.exports = {
   name: Events.ChannelDelete,
    async execute(channel, client) {
        try {
            const audit = await channel.guild.fetchAuditLogs({type: AuditLogEvent.ChannelDelete});
            const oc = audit.entries.first();
            
            if (oc) {
                const executor = oc.executor;
                
                // Güvenli kontrolü - eğer silen kişi güvenli değilse ihlal say
                if (!guvenli.isUserSafe(channel.guild.id, executor.id)) {
                    // İhlal sayısını artır
                    const violationCount = guvenli.trackViolation(channel.guild.id, executor.id, 'Kanal Silme', channel.guild);
                    
                    // İhlal log embed'i
                    const violationEmbed = new EmbedBuilder()
                        .setTitle('🚨 Güvenli Sistem İhlali - Kanal Silme')
                        .setDescription(`**${executor.tag}** güvenli olmayan bir kanalı sildi.`)
                        .addFields(
                            { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                            { name: '📁 Silinen Kanal', value: `${channel.name} (${channel.id})`, inline: true },
                            { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                        )
                        .setColor(0xFF9800)
                        .setTimestamp();
                    
                    // Log kanalına gönder
                    const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                    if (logChannelId) {
                        const lyuexinchannellogkanali = client.channels.cache.get(logChannelId);
                        if (lyuexinchannellogkanali) {
                            await lyuexinchannellogkanali.send({ embeds: [violationEmbed] });
                        }
                    }
                    
                    // İhlal limitini kontrol et
                    await guvenli.handleViolationLimit(channel.guild, executor.id, 'Kanal Silme', violationCount);
                }
            }
            
            // Normal loglama
            const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
            if (logChannelId) {
                const lyuexinchannellogkanali = client.channels.cache.get(logChannelId);
                if (lyuexinchannellogkanali) {
                    const lyuexinchannellogembedi = new EmbedBuilder()
                        .setColor(0xFF4444)
                        .setTitle('🗑️ Kanal Silindi!')
                        .setDescription(`Bir kanal silindi!`)
                        .addFields(
                            { name: '👤 Silen', value: `<@${oc.executor.id}>\n${oc.executor.tag}`, inline: true },
                            { name: '📁 Silinmiş Kanal', value: `${channel.name}\nID: ${channel.id}`, inline: true },
                            { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                        )
                        .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                        .setFooter({ text: `Kanal Sistemi • ${channel.guild.name}`, iconURL: channel.guild.iconURL({ dynamic: true }) })
                        .setTimestamp();
                    
                    await lyuexinchannellogkanali.send({ embeds: [lyuexinchannellogembedi] }).catch(console.error);
                }
            }
        } catch (error) {
            catchError(client, 'channelDelete.js', error.message);
        }
    }
};





