// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent} = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const fs = require('fs');
const path = require('path');
const {  ChannelType,PermissionsBitField  } = require('discord.js');

const dataPath = path.join(__dirname, '../data/protection.json');

module.exports = {
    name: Events.ChannelUpdate,
    async execute(oldChannel, newChannel, client) {
    try {
        const lyuexinupdatelogu = client.channels.cache.find(channel => channel.name === 'channel_log');
    newChannel.guild.fetchAuditLogs( { type: AuditLogEvent.ChannelUpdate }).then(audit => {
    const lyuexoc = audit.entries.first();
    const lyuexinupdateembedi = new EmbedBuilder()
    .setColor(0x000000)
    .setTitle('Kanal Güncellendi!')
    .setDescription(`kişi: \n <@${lyuexoc.executor.id}> - (${lyuexoc.executor.id})\n Eski Kanal: \n > <#${oldChannel.id}> - ${oldChannel.name} \n Yeni Kanal: \n > <#${newChannel.id}> - ${newChannel.name} `)
    .setThumbnail(newChannel.guild.iconURL({ dynamic: true }))
    .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
    .setTimestamp();
    if (lyuexinupdatelogu) {
        lyuexinupdatelogu.send({ embeds: [lyuexinupdateembedi] });
    }
    });
    }catch (error) {
        catchError(client, 'channelUpdate.js', error.message);
    }
    }
}


//-------------------------------------------------------------------------------








