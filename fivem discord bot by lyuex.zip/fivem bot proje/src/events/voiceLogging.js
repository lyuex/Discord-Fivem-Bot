// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        if (!lyuex.log?.enabled) return;
        if (!lyuex.log?.settings?.include_bots && newState.member.user.bot) return;
        
        const logChannel = newState.guild.channels.cache.get(lyuex.log.channels.user_logs);
        if (!logChannel) return;

        try {
            const member = newState.member;
            let embed;

            // Sesli kanala katıldı
            if (!oldState.channel && newState.channel && lyuex.log.events.voice_join) {
                embed = new EmbedBuilder()
                    .setColor(0x00FF99)
                    .setTitle('🔊 Sesli Kanala Katıldı')
                    .setDescription(`**${member.user.tag}** sesli kanala katıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.user.id})`, inline: true },
                        { name: '🎤 Kanal', value: `${newState.channel.name} (${newState.channel.id})`, inline: true },
                        { name: '👥 Kanaldaki Kişi Sayısı', value: `${newState.channel.members.size}`, inline: true },
                        { name: '⏰ Katılma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '🔇 Mikrofon', value: newState.mute ? '🔇 Kapalı' : '🎤 Açık', inline: true },
                        { name: '🔊 Hoparlör', value: newState.deaf ? '🔇 Kapalı' : '🔊 Açık', inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Sesli Kanal Sistemi • LYUEX`,
                        iconURL: newState.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();
            }
            
            // Sesli kanaldan ayrıldı
            else if (oldState.channel && !newState.channel && lyuex.log.events.voice_leave) {
                embed = new EmbedBuilder()
                    .setColor(0xFF6600)
                    .setTitle('🔊 Sesli Kanala Katıldı')
                    .setDescription(`**${member.user.tag}** sesli kanala katıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.user.id})`, inline: true },
                        { name: '🎤 Katıldığı Kanal', value: `${newState.channel.name} (${newState.channel.id})`, inline: true },
                        { name: '👥 Kanaldaki Kişi Sayısı', value: `${newState.channel.members.size}`, inline: true },
                        { name: '⏰ Katılma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Sesli Kanal Sistemi • LYUEX`,
                        iconURL: newState.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();
            }
            
            // Sesli kanal değiştirdi
            else if (oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id && lyuex.log.events.voice_move) {
                embed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle('🔄 Sesli Kanal Değiştirdi')
                    .setDescription(`**${member.user.tag}** sesli kanal değiştirdi`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${member.user.tag} (${member.user.id})`, inline: true },
                        { name: '🎤 Eski Kanal', value: `${oldState.channel.name}`, inline: true },
                        { name: '🎤 Yeni Kanal', value: `${newState.channel.name}`, inline: true },
                        { name: '👥 Eski Kanaldaki Kişi', value: `${oldState.channel.members.size}`, inline: true },
                        { name: '👥 Yeni Kanaldaki Kişi', value: `${newState.channel.members.size}`, inline: true },
                        { name: '⏰ Taşınma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '🔇 Mikrofon', value: newState.mute ? '🔇 Kapalı' : '🎤 Açık', inline: true },
                        { name: '🔊 Hoparlör', value: newState.deaf ? '🔇 Kapalı' : '🔊 Açık', inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ 
                        text: `Sesli Kanal Sistemi • LYUEX`,
                        iconURL: newState.guild.iconURL({ dynamic: true })
                    })
                    .setTimestamp();
            }

            if (embed) {
                await logChannel.send({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Sesli kanal log hatası:', error);
        }
    }
};




