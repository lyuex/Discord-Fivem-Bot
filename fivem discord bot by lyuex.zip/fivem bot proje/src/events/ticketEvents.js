// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const ticketUtil = require('../utils/ticketUtil');
const steamHexManager = require('../utils/steamHexManager');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // DEBUG: Log ALL interactions
        console.log(`[TicketHandler] Interaction received - Type: ${interaction.type}, CustomId: ${interaction.customId || 'N/A'}`);
        
        // Modal submit
        if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith('ticket_create_modal_')) {
                const categoryId = interaction.customId.replace('ticket_create_modal_', '');
                await handleTicketCreation(interaction, categoryId);
            }
            return;
        }
        
        // Select menu
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'priority_select') {
                await handlePrioritySelection(interaction);
            } else if (interaction.customId === 'tag_select') {
                await handleTagSelection(interaction);
            } else if (interaction.customId === 'ticket_panel_category_select') {
                // Panel oluşturma için kategori seçimi - direkt panel kanalına gönder (collector tarafından işlenir)
                return;
            } else if (interaction.customId === 'ticket_category_select') {
                try {
                    const categoryId = interaction.values[0];
                    console.log(`[Ticket Select] ===== SELECT MENU STARTED =====`);
                    console.log(`[Ticket Select] Category ID from menu: ${categoryId}`);
                    console.log(`[Ticket Select] User: ${interaction.user.tag} (${interaction.user.id})`);
                    
                    const cfg = ticketUtil.getConfig();
                    console.log(`[Ticket Select] Config loaded:`, cfg ? `YES - requireDetailsModal: ${cfg.requireDetailsModal}` : 'NO - NULL');
                    
                    if (!cfg) {
                        console.warn(`[Ticket Select] Config is null, creating defaults...`);
                    }
                    
                    // Eğer detay modali zorunlu değilse, doğrudan ticket oluştur
                    if (cfg?.requireDetailsModal) {
                        console.log(`[Ticket Select] Modal required → Opening modal`);
                        await handleTicketCreateModal(interaction, categoryId);
                    } else {
                        console.log(`[Ticket Select] Direct creation enabled → Creating ticket directly`);
                        await handleTicketCreateDirect(interaction, categoryId);
                    }
                    console.log(`[Ticket Select] ===== SELECT MENU COMPLETED =====`);
                } catch (err) {
                    console.error(`[Ticket Select] ❌ CRITICAL ERROR IN SELECT HANDLER:`, err.message);
                    console.error(`[Ticket Select] Stack:`, err.stack);
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: `❌ Hata: ${err.message}`, ephemeral: true }).catch(e => console.error(`[Ticket Select] Reply error:`, e.message));
                    } else if (interaction.deferred) {
                        await interaction.editReply({ content: `❌ Hata: ${err.message}` }).catch(e => console.error(`[Ticket Select] EditReply error:`, e.message));
                    }
                }
            }
            return;
        }
        
        // Butonlar
        if (!interaction.isButton()) return;
        
        // Ticket oluşturma
        if (interaction.customId.startsWith('ticket_create_') || 
            ['oyun_ici_destek', 'oyun_disi_destek', 'hata_raporla', 'ekip_acma', 'hesap_destek'].includes(interaction.customId)) {
            let categoryId = interaction.customId.replace('ticket_create_', '');
            
            // Yeni custom panel butonları için category mapping
            switch (interaction.customId) {
                case 'ticket_create_oyun_ici':
                    categoryId = 'oyun_ici_destek';
                    break;
                case 'ticket_create_oyun_disi':
                    categoryId = 'oyun_disi_destek';
                    break;
                case 'ticket_create_hata_raporlama':
                    categoryId = 'hata_raporla';
                    break;
            }
            
            await handleTicketCreateModal(interaction, categoryId);
            return;
        }
        
        // Diğer ticket işlemleri
        switch (interaction.customId) {
            case 'ticket_kapat':
                await handleTicketClose(interaction);
                break;
            case 'ticket_confirm_close':
                await handleTicketConfirmClose(interaction);
                break;
            case 'ticket_cancel_close':
                await handleTicketCancelClose(interaction);
                break;
            case 'ticket_delete':
                await handleTicketDelete(interaction);
                break;
            case 'ticket_transcript':
                await handleTicketTranscript(interaction);
                break;
            case 'ticket_claim':
                await handleTicketClaim(interaction);
                break;
            case 'ticket_set_priority':
                await handleTicketPriorityMenu(interaction);
                break;
            case 'ticket_set_tag':
                await handleTicketTagMenu(interaction);
                break;
        }
        
        // Derecelendirme
        if (interaction.customId.startsWith('ticket_rate_')) {
            const rating = parseInt(interaction.customId.replace('ticket_rate_', ''));
            await handleTicketRating(interaction, rating);
        }
    }
};

// Modal göster
async function handleTicketCreateModal(interaction, categoryId) {
    try {
        const config = ticketUtil.getConfig();
        if (!config) {
            return await interaction.reply({
                content: 'Ticket sistemi ayarları bulunamadı!',
                ephemeral: true
            }).catch(() => {});
        }
        
        const category = ticketUtil.getCategoryById(categoryId) || { id: categoryId, name: 'Destek', emoji: '🎫' };
        
        const canCreate = await ticketUtil.canCreateTicket(interaction.guild, interaction.user.id);
        if (!canCreate) {
            return await interaction.reply({
                content: `Maksimum aktif ticket sayısına ulaştınız! (${config.maxActiveTickets || 3})`,
                ephemeral: true
            }).catch(() => {});
        }
        
        const cooldownCheck = ticketUtil.checkCooldown(interaction.user.id);
        if (cooldownCheck.onCooldown) {
            const minutes = Math.ceil(cooldownCheck.timeLeft / (1000 * 60));
            return await interaction.reply({
                content: `Çok hızlı ticket açıyorsunuz! ${minutes} dakika bekleyin.`,
                ephemeral: true
            }).catch(() => {});
        }
        
        const modal = new ModalBuilder()
            .setCustomId(`ticket_create_modal_${categoryId}`)
            .setTitle(`${category.emoji} ${category.name} Destek Talebi`);
            
        const subjectInput = new TextInputBuilder()
            .setCustomId('ticket_subject')
            .setLabel('Konu')
            .setPlaceholder('Talebinizin konusunu kısaca belirtin')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(100);
            
        const detailInput = new TextInputBuilder()
            .setCustomId('ticket_detail')
            .setLabel('Detaylar')
            .setPlaceholder('Sorununuzu detaylı açıklayın')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);
            
        modal.addComponents(
            new ActionRowBuilder().addComponents(subjectInput),
            new ActionRowBuilder().addComponents(detailInput)
        );
        
        // ShowModal'ı try-catch ile sarılı şekilde çağır
        try {
            await interaction.showModal(modal);
        } catch (modalError) {
            console.error('ShowModal hatası (interaction expire):', modalError.message);
            // Interaction expire olmuşsa görmezden gel
        }
        
    } catch (error) {
        console.error('Modal hatası:', error);
        try {
            await interaction.reply({
                content: 'Bir hata oluştu!',
                ephemeral: true
            }).catch(() => {});
        } catch {
            // Interaction already responded
        }
    }
}

// Ticket oluştur
async function handleTicketCreation(interaction, categoryId) {
    try {
        await interaction.deferReply({ ephemeral: true });
        
        const config = ticketUtil.getConfig();
        const category = ticketUtil.getCategoryById(categoryId) || { 
            id: categoryId, 
            name: 'Destek', 
            emoji: '🎫',
            color: '#3498db'
        };
        
        const subject = interaction.fields.getTextInputValue('ticket_subject');
        const detail = interaction.fields.getTextInputValue('ticket_detail');
        const ticketNumber = ticketUtil.getNextTicketNumber();
        
        const supportRole = interaction.guild.roles.cache.get(config.supportRoleId);
        if (!supportRole) {
            console.error(`Destek rolü bulunamadı: ${config.supportRoleId}`);
            return await interaction.editReply({
                content: '❌ Destek ekibi rolü bulunamadı! Lütfen `/ticket-yonetim ayarlar` komutu ile sistemi yeniden kurun.',
                ephemeral: true
            });
        }
        
        // Kategori kanalı
        let categoryChannel = null;
        if (config.categoryId) {
            try {
                categoryChannel = await interaction.guild.channels.fetch(config.categoryId).catch(() => null);
            } catch (error) {
                console.error(`Kategori kanalı fetch hatası: ${error.message}`);
            }
        }
        
        if (!categoryChannel) {
            console.log('Kategori kanalı bulunamadı, yeni kategori oluşturuluyor...');
            try {
                categoryChannel = await interaction.guild.channels.create({
                    name: '📩 DESTEK TALEPLERİ',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: supportRole.id, allow: [PermissionFlagsBits.ViewChannel] }
                    ]
                });
                
                // Config'i güncelle
                config.categoryId = categoryChannel.id;
                ticketUtil.updateConfig(config);
                console.log(`Yeni kategori oluşturuldu: ${categoryChannel.name} (${categoryChannel.id})`);
            } catch (error) {
                console.error('Kategori oluşturma hatası:', error);
                return await interaction.editReply({
                    content: '❌ Ticket kategorisi oluşturulamadı! Botun yeterli yetkiye sahip olduğundan emin olun.',
                    ephemeral: true
                });
            }
        }
        
        // Ticket kanalı oluştur
        let ticketChannel;
        try {
            ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${ticketNumber}`,
                type: ChannelType.GuildText,
                topic: `${category.emoji} ${category.name} | Talep Eden: ${interaction.user.id} | Ticket #${ticketNumber}`,
                parent: categoryChannel.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { 
                        id: interaction.user.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles
                        ] 
                    },
                    { 
                        id: supportRole.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.ManageMessages
                        ] 
                    }
                ]
            });
            
            console.log(`Ticket kanalı oluşturuldu: ${ticketChannel.name} (${ticketChannel.id})`);
        } catch (error) {
            console.error('Ticket kanalı oluşturma hatası:', error);
            return await interaction.editReply({
                content: '❌ Ticket kanalı oluşturulamadı! Botun kanallar oluşturma yetkisine sahip olduğundan emin olun.',
                ephemeral: true
            });
        }
        
        // Ticket verisi kaydet
        const ticketData = {
            id: `ticket-${ticketNumber}`,
            ticketNumber: ticketNumber,
            channelId: ticketChannel.id,
            userId: interaction.user.id,
            userTag: interaction.user.tag,
            guildId: interaction.guild.id,
            categoryId: categoryId,
            subject: subject,
            detail: detail,
            status: 'open',
            priority: 'normal'
        };
        
        ticketUtil.saveTicket(ticketData);
        
        // Gelişmiş Ticket embed
        const ticketEmbed = new EmbedBuilder()
            .setColor(category.color || '#3498db')
            .setAuthor({ 
                name: `${interaction.guild.name} - Destek Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle(`${category.emoji} Ticket #${ticketNumber} - ${subject}`)
            .setDescription(`
👋 Hoş geldiniz! Destek talebiniz oluşturuldu. Aşağıda detaylar yer alıyor.

📋 **Talep Açıklaması:**
\`\`\`
${detail}
\`\`\`

🎯 **Ticket Bilgileri:**
• **Kategori:** ${category.emoji} ${category.name}
• **Durum:** 🟢 Açık
• **Öncelik:** ⚪ Normal
• **Oluşturulma:** <t:${Math.floor(Date.now() / 1000)}:R>

💡 **Yardım İpuçları:**
• Lütfen sorununuzu detaylı açıklayın
• Ekran görüntüsü paylaşabilirsiniz
• Sabırlı olun, en kısa sürede yanıtlanacak
            `)
            .addFields(
                { 
                    name: '👤 Talep Eden', 
                    value: `${interaction.user}\n\`${interaction.user.tag}\`\nID: \`${interaction.user.id}\``, 
                    inline: true 
                },
                { 
                    name: '📊 İstatistikler', 
                    value: `Ticket ID: \`#${ticketNumber}\`\nKanal: ${ticketChannel}\nSaat: <t:${Math.floor(Date.now() / 1000)}:t>`, 
                    inline: true 
                },
                { 
                    name: '⚙️ Ticket Yönetimi', 
                    value: `🔒 Kapatmak için \`Kapat\` butonuna basın\n👋 Üstlenmek için \`Üstlen\` butonuna basın\n📝 Kayıt almak için \`Kayıt\` butonuna basın`, 
                    inline: false 
                }
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ 
                text: `${interaction.guild.name} Destek Ekibi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();
        
        // Butonlar
        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_kapat')
                    .setLabel('Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('Üstlen')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('👋'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Kayıt')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📝')
            );
            
        const buttons2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_set_priority')
                    .setLabel('Öncelik')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🔄'),
                new ButtonBuilder()
                    .setCustomId('ticket_set_tag')
                    .setLabel('Etiket')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🏷️')
            );
        
        const ticketMessage = await ticketChannel.send({
            content: `${interaction.user} | ${supportRole}`,
            embeds: [ticketEmbed],
            components: [buttons, buttons2]
        });
        
        await ticketMessage.pin();
        
        // Log
        if (config.logChannelId) {
            try {
                const logChannel = await interaction.guild.channels.fetch(config.logChannelId).catch(() => null);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(category.color || '#3498db')
                        .setTitle('📩 Yeni Ticket')
                        .setDescription(`${category.emoji} **${subject}** konulu ticket açıldı`)
                        .addFields(
                            { name: 'Talep Eden', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Ticket ID', value: `#${ticketNumber}`, inline: true },
                            { name: 'Kanal', value: `${ticketChannel}`, inline: true }
                        )
                        .setTimestamp();
                        
                    await logChannel.send({ embeds: [logEmbed] });
                } else {
                    console.warn(`Log kanalı bulunamadı: ${config.logChannelId}`);
                }
            } catch (error) {
                console.error('Log gönderme hatası:', error);
            }
        }
        
        await interaction.editReply({
            content: `✅ Ticket oluşturuldu: ${ticketChannel}`,
            ephemeral: true
        });
        
    } catch (error) {
        console.error('Ticket oluşturma hatası:', error);
        await interaction.editReply({
            content: 'Bir hata oluştu!',
            ephemeral: true
        }).catch(() => {});
    }
}

// Ticket kapat onay
async function handleTicketClose(interaction) {
    const channel = interaction.channel;
    
    if (!channel.name.startsWith('ticket-')) {
        return await interaction.reply({
            content: 'Bu komut sadece ticket kanallarında kullanılabilir!',
            ephemeral: true
        });
    }
    
    const confirmEmbed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setTitle('⚠️ Talep Kapatılacak')
        .setDescription('Bu destek talebini kapatmak istediğinize emin misiniz?')
        .setTimestamp();
        
    const confirmButtons = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_confirm_close')
                .setLabel('Kapat')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('✅'),
            new ButtonBuilder()
                .setCustomId('ticket_cancel_close')
                .setLabel('İptal')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('❌')
        );
        
    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons]
    });
}

// Ticket kapatma onayla
async function handleTicketConfirmClose(interaction) {
    const channel = interaction.channel;
    
    await interaction.reply({ content: '🔒 Ticket kapatılıyor...' });
    
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    const config = ticketUtil.getConfig();
    const ticketCreatorId = ticketData?.userId || ticketUtil.getTicketOwner(channel) || 'Bilinmiyor';
    
    setTimeout(async () => {
        // Transcript oluştur
        if (config?.autoTranscript) {
            try {
                const transcriptFiles = await ticketUtil.createHtmlTranscript(channel, ticketData);
                if (transcriptFiles && config.logChannelId) {
                    const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
                    if (logChannel) {
                        await logChannel.send({
                            content: `📝 Ticket #${ticketData?.ticketNumber || 'Bilinmiyor'} kaydı`,
                            files: [{
                                attachment: transcriptFiles.html.path,
                                name: `ticket-${ticketData?.ticketNumber || 'bilinmiyor'}.html`
                            }]
                        });
                    }
                }
            } catch (error) {
                console.error('Transcript hatası:', error);
            }
        }
        
        await channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('🔒 Ticket Kapatıldı')
                    .setDescription(`Bu ticket ${interaction.user} tarafından kapatıldı.`)
                    .addFields(
                        { name: 'Talep Eden', value: `<@${ticketCreatorId}>`, inline: true },
                        { name: 'Kapatan', value: `${interaction.user}`, inline: true }
                    )
                    .setTimestamp()
            ]
        });
        
        // Erişim kaldır
        await channel.permissionOverwrites.edit(ticketCreatorId, {
            ViewChannel: false,
            SendMessages: false
        }).catch(console.error);
        
        await channel.setName(`kapalı-${channel.name.split('ticket-')[1]}`);
        
        // Veri güncelle
        if (ticketData) {
            ticketUtil.updateTicket(ticketData.id, {
                status: 'closed',
                closedAt: Date.now(),
                closedBy: interaction.user.id
            });
        }
        
        // Silme butonu
        const deleteButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_delete')
                    .setLabel('Sil')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️')
            );
            
        await channel.send({
            content: 'Ticket kanalını silmek için:',
            components: [deleteButton]
        });
        
    }, 1000);
}

// Kapatma iptal
async function handleTicketCancelClose(interaction) {
    await interaction.update({
        content: '✅ Ticket kapatma iptal edildi.',
        embeds: [],
        components: []
    });
}

// Ticket sil
async function handleTicketDelete(interaction) {
    const channel = interaction.channel;
    
    if (!channel.name.startsWith('kapalı-')) {
        return await interaction.reply({
            content: 'Bu komut sadece kapalı ticketlarda kullanılabilir!',
            ephemeral: true
        });
    }
    
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Ticket silme yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    await interaction.reply({ content: '🗑️ Kanal 5 saniye içinde silinecek...' });
    
    // Ticket verilerini sil öncesi al
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    const ticketConfig = ticketUtil.getConfig();
    
    // DM bildirimi gönder (kanal silinmeden önce)
    if (ticketData?.userId && ticketConfig?.allowRating) {
        try {
            const user = await interaction.client.users.fetch(ticketData.userId).catch(() => null);
            if (user) {
                const ratingEmbed = new EmbedBuilder()
                    .setColor(0xE74C3C)
                    .setTitle('🗑️ Destek Talebiniz Silindi')
                    .setDescription(`**${interaction.guild.name}** sunucusundaki destek talebiniz silindi.\n\n**Ticket #${ticketData.ticketNumber}**\n**Konu:** ${ticketData.subject || 'Belirtilmemiş'}\n\nEğer tekrar yardıma ihtiyacınız olursa yeni bir ticket açabilirsiniz.`)
                    .addFields(
                        { name: '📊 Ticket Bilgileri', value: `ID: #${ticketData.ticketNumber}\nSilme Zamanı: <t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                        { name: '💡 Yeni Ticket', value: `Yeni bir destek talebi açmak için sunucuya geri dönün ve ticket panelini kullanın.`, inline: true }
                    )
                    .setFooter({ 
                        text: `${interaction.guild.name} Destek Ekibi`, 
                        iconURL: interaction.guild.iconURL({ dynamic: true }) 
                    })
                    .setTimestamp();
                    
                await user.send({ embeds: [ratingEmbed] }).catch(() => {
                    console.log(`DM gönderilemedi: ${user.tag}`);
                });
            }
        } catch (error) {
            console.error('Silme bildirimi DM hatası:', error);
        }
    }
    
    setTimeout(async () => {
        try {
            // Kanalın hala var olup olmadığını kontrol et
            const channelExists = interaction.guild.channels.cache.has(channel.id);
            if (!channelExists) {
                console.log(`Kanal ${channel.id} zaten silinmiş.`);
                return;
            }
            
            // Kanalı yeniden al (cache güncellemesi için)
            const currentChannel = await interaction.guild.channels.fetch(channel.id).catch(() => null);
            if (!currentChannel) {
                console.log(`Kanal ${channel.id} bulunamadı, zaten silinmiş olabilir.`);
                return;
            }
            
            await currentChannel.delete('Ticket silme');
            console.log(`Ticket kanalı başarıyla silindi: ${channel.name}`);
        } catch (error) {
            if (error.code === 10003) {
                console.log(`Kanal ${channel.id} zaten silinmiş (Unknown Channel).`);
            } else if (error.code === 50013) {
                console.error(`Kanal silme izni yok: ${channel.name}`);
            } else {
                console.error('Kanal silme hatası:', {
                    channelId: channel.id,
                    channelName: channel.name,
                    error: error.message,
                    code: error.code
                });
            }
        }
    }, 5000);
}

// Transcript
async function handleTicketTranscript(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
        const channel = interaction.channel;
        const ticketData = ticketUtil.getTicketByChannelId(channel.id);
        
        const transcriptFiles = await ticketUtil.createHtmlTranscript(channel, ticketData);
        if (!transcriptFiles) {
            throw new Error('Transcript oluşturulamadı');
        }
        
        await interaction.editReply({
            content: '✅ Transcript hazırlandı!',
            files: [{
                attachment: transcriptFiles.html.path,
                name: `${channel.name}-transcript.html`
            }]
        });
        
        // Dosyaları güvenli temizle
        ticketUtil.cleanupTranscriptFiles(transcriptFiles);
        
    } catch (error) {
        console.error('Transcript hatası:', error);
        await interaction.editReply({
            content: 'Transcript oluşturulurken hata oluştu!',
            ephemeral: true
        });
    }
}

// Ticket üstlen
async function handleTicketClaim(interaction) {
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Ticket üstlenme yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(channel.id);
    if (ticketData && ticketData.claimedBy) {
        return await interaction.reply({
            content: `Bu ticket zaten <@${ticketData.claimedBy}> tarafından üstlenilmiş!`,
            ephemeral: true
        });
    }
    
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, {
            claimedBy: interaction.user.id,
            status: 'claimed'
        });
    }
    
    const claimEmbed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('👋 Ticket Üstlenildi')
        .setDescription(`Bu ticket ${interaction.user} tarafından üstlenildi.`)
        .setTimestamp();
        
    await interaction.reply({ embeds: [claimEmbed] });
}

// Öncelik menü
async function handleTicketPriorityMenu(interaction) {
    const channel = interaction.channel;
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Öncelik ayarlama yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const priorityMenu = ticketUtil.createPrioritySelectMenu();
    
    await interaction.reply({
        content: '🔄 Öncelik seviyesi seçin:',
        components: [priorityMenu],
        ephemeral: true
    });
}

// Öncelik seç
async function handlePrioritySelection(interaction) {
    const priorityId = interaction.values[0];
    const priority = ticketUtil.getPriorityById(priorityId);
    
    if (!priority) {
        return await interaction.update({
            content: 'Geçersiz öncelik!',
            components: []
        });
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(interaction.channel.id);
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, { priorityId: priorityId });
    }
    
    const priorityEmbed = new EmbedBuilder()
        .setColor(priority.color)
        .setTitle('🔄 Öncelik Güncellendi')
        .setDescription(`Öncelik **${priority.emoji} ${priority.name}** olarak ayarlandı.`)
        .setTimestamp();
        
    const replyMsg = await interaction.update({
        content: `✅ Öncelik güncellendi!`,
        components: []
    });
    
    await interaction.channel.send({ embeds: [priorityEmbed] }).then(msg => {
        // Sistem mesajını 3 saniye sonra sil
        setTimeout(() => msg.delete().catch(() => {}), 3000);
    });
    
    // Pinned message'ı güncelle
    try {
        const pinnedMessages = await interaction.channel.messages.fetchPins();
        const messagesArray = Array.from(pinnedMessages.values ? pinnedMessages.values() : pinnedMessages);
        const ticketMessage = messagesArray.find(msg => msg.embeds.length > 0 && msg.embeds[0].title?.includes('Ticket #'));
        
        if (ticketMessage && ticketMessage.embeds.length > 0) {
            const oldEmbed = ticketMessage.embeds[0];
            const newEmbed = EmbedBuilder.from(oldEmbed);
            
            // Description'ı güncelle - öncelik bilgisini değiştir
            let description = oldEmbed.description || '';
            
            // Öncelik satırını bul ve güncelle
            if (description.includes('• **Öncelik:**')) {
                // Eski öncelik satırını yeni öncelikle değiştir
                description = description.replace(
                    /• \*\*Öncelik:\*\* .*?\n/,
                    `• **Öncelik:** ${priority.emoji} ${priority.name}\n`
                );
            } else {
                // Öncelik satırı yoksa durum satırından sonra ekle
                description = description.replace(
                    /(• \*\*Durum:\*\* .*?\n)/,
                    `$1• **Öncelik:** ${priority.emoji} ${priority.name}\n`
                );
            }
            
            newEmbed.setDescription(description);
            newEmbed.setColor(priority.color);
            
            await ticketMessage.edit({ embeds: [newEmbed] });
            console.log(`[Priority Update] Pinned embed updated with priority: ${priority.name}`);
        }
    } catch (error) {
        console.error(`[Priority Update] Embed güncelleme hatası:`, error.message);
    }
}

// Etiket menü
async function handleTicketTagMenu(interaction) {
    const member = interaction.guild.members.cache.get(interaction.user.id);
    const config = ticketUtil.getConfig();
    
    if (config) {
        const supportRole = config.supportRoleId;
        if (!member.roles.cache.has(supportRole) && !member.permissions.has(PermissionFlagsBits.Adlyuexstrator)) {
            return await interaction.reply({
                content: 'Etiket ayarlama yetkiniz yok!',
                ephemeral: true
            });
        }
    }
    
    const tagMenu = ticketUtil.createTagSelectMenu();
    
    await interaction.reply({
        content: '🏷️ Etiket seçin:',
        components: [tagMenu],
        ephemeral: true
    });
}

// Etiket seç
async function handleTagSelection(interaction) {
    const tagId = interaction.values[0];
    const tag = ticketUtil.getTagById(tagId);
    
    if (!tag) {
        return await interaction.update({
            content: 'Geçersiz etiket!',
            components: []
        });
    }
    
    const ticketData = ticketUtil.getTicketByChannelId(interaction.channel.id);
    if (ticketData) {
        ticketUtil.updateTicket(ticketData.id, { tagId: tagId });
    }
    
    const tagEmbed = new EmbedBuilder()
        .setColor(tag.color)
        .setTitle(`${tag.emoji} ${tag.name}`)
        .setDescription(`Etiket **${tag.emoji} ${tag.name}** olarak güncellendi.`)
        .setTimestamp();
        
    await interaction.update({
        content: `✅ Etiket güncellendi!`,
        components: []
    });
    
    await interaction.channel.send({ embeds: [tagEmbed] }).then(msg => {
        // Sistem mesajını 3 saniye sonra sil
        setTimeout(() => msg.delete().catch(() => {}), 3000);
    });
    
    // Pinned message'ı güncelle
    try {
        const pinnedMessages = await interaction.channel.messages.fetchPins();
        const messagesArray = Array.from(pinnedMessages.values ? pinnedMessages.values() : pinnedMessages);
        const ticketMessage = messagesArray.find(msg => msg.embeds.length > 0 && msg.embeds[0].title?.includes('Ticket #'));
        
        if (ticketMessage && ticketMessage.embeds.length > 0) {
            const oldEmbed = ticketMessage.embeds[0];
            const newEmbed = new EmbedBuilder(oldEmbed.data);
            
            // Tüm alanları güncelle
            const fields = oldEmbed.fields.map(f => {
                if (f.name.includes('📊')) {
                    // İstatistikler alanını güncelle
                    return {
                        name: '📊 İstatistikler',
                        value: `Ticket ID: \`#${ticketData.ticketNumber}\`\nKanal: ${interaction.channel}\nEtiket: ${tag.emoji} ${tag.name}\nSaat: <t:${Math.floor(Date.now() / 1000)}:t>`,
                        inline: true
                    };
                }
                if (f.name.includes('🎯')) {
                    // Durum alanını güncelle
                    return {
                        name: '🎯 Durum',
                        value: `Etiket: ${tag.emoji} ${tag.name}`,
                        inline: true
                    };
                }
                return f;
            });
            
            newEmbed.setFields(fields);
            await ticketMessage.edit({ embeds: [newEmbed] });
            console.log(`[Tag Update] Pinned embed updated with tag: ${tag.name}`);
        }
    } catch (error) {
        console.error(`[Tag Update] Embed güncelleme hatası:`, error.message);
    }
}

// Derecelendirme
async function handleTicketRating(interaction, rating) {
    if (!interaction.guild) {
        const tickets = ticketUtil.getTicketsDb();
        const userTickets = tickets.filter(t => t.userId === interaction.user.id && t.status === 'closed');
        
        if (userTickets.length === 0) {
            return await interaction.reply({
                content: 'Derecelendirebileceğiniz ticket yok!',
                ephemeral: true
            });
        }
        
        const lastTicket = userTickets.sort((a, b) => b.closedAt - a.closedAt)[0];
        
        ticketUtil.updateTicket(lastTicket.id, { rating: rating });
        
        await interaction.update({
            content: `⭐ Teşekkürler! **${rating}/5** puan verdiniz.`,
            embeds: [],
            components: []
        });
        
        // Log
        try {
            const config = ticketUtil.getConfig();
            const guild = interaction.client.guilds.cache.get(lastTicket.guildId);
            
            if (guild && config?.logChannelId) {
                const logChannel = guild.channels.cache.get(config.logChannelId);
                
                if (logChannel) {
                    const stars = '⭐'.repeat(rating);
                    
                    const ratingEmbed = new EmbedBuilder()
                        .setColor(0xF1C40F)
                        .setTitle('⭐ Ticket Derecelendirildi')
                        .setDescription(`Ticket #${lastTicket.ticketNumber} için değerlendirme!`)
                        .addFields(
                            { name: 'Değerlendiren', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Puan', value: `${stars} (${rating}/5)`, inline: true }
                        )
                        .setTimestamp();
                        
                    await logChannel.send({ embeds: [ratingEmbed] });
                }
            }
        } catch (error) {
            console.error('Rating log hatası:', error);
        }
    }
}

// Modal olmadan doğrudan ticket oluştur (select menüden)
async function handleTicketCreateDirect(interaction, categoryId) {
    console.log(`[Direct] START - CategoryId: ${categoryId}, User: ${interaction.user.id}`);
    try {
        // FIRST: Defer immediately
        if (!interaction.deferred && !interaction.replied) {
            console.log(`[Direct] Deferring...`);
            await interaction.deferReply({ ephemeral: true });
        }
        console.log(`[Direct] Deferred OK, now processing...`);

        const config = ticketUtil.getConfig();
        console.log(`[Direct] Config: ${config ? 'loaded' : 'null'}`);
        
        // Get category info
        const category = ticketUtil.getCategoryById(categoryId) || { 
            id: categoryId, 
            name: 'Destek', 
            emoji: '🎫',
            color: '#3498db'
        };
        
        // Default values for direct creation (no modal)
        const subject = `${category.emoji} ${category.name} Destek`;
        const detail = `${interaction.user} tarafından açılmış hızlı destek talebine hoşgeldiniz.`;
        const ticketNumber = ticketUtil.getNextTicketNumber();
        
        console.log(`[Direct] Category: ${category.name}, Ticket #: ${ticketNumber}`);
        
        // Get support role
        const supportRole = interaction.guild.roles.cache.get(config.supportRoleId);
        if (!supportRole) {
            console.error(`[Direct] ❌ Destek rolü bulunamadı: ${config.supportRoleId}`);
            return await interaction.editReply({
                content: '❌ Destek ekibi rolü bulunamadı! Lütfen `/ticket-yonetim ayarlar` komutu ile sistemi yeniden kurun.',
                ephemeral: true
            });
        }
        console.log(`[Direct] Support role: ${supportRole.name}`);
        
        // Get or create category channel
        let categoryChannel = null;
        if (config.categoryId) {
            try {
                categoryChannel = await interaction.guild.channels.fetch(config.categoryId).catch(() => null);
                console.log(`[Direct] Category channel fetched: ${categoryChannel?.name || 'null'}`);
            } catch (error) {
                console.error(`[Direct] Kategori kanalı fetch hatası: ${error.message}`);
            }
        }
        
        if (!categoryChannel) {
            console.log(`[Direct] Creating category channel...`);
            try {
                categoryChannel = await interaction.guild.channels.create({
                    name: '📩 DESTEK TALEPLERİ',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: supportRole.id, allow: [PermissionFlagsBits.ViewChannel] }
                    ]
                });
                
                config.categoryId = categoryChannel.id;
                ticketUtil.updateConfig(config);
                console.log(`[Direct] Category channel created: ${categoryChannel.name}`);
            } catch (error) {
                console.error(`[Direct] ❌ Kategori oluşturma hatası: ${error.message}`);
                return await interaction.editReply({
                    content: '❌ Ticket kategorisi oluşturulamadı! Botun yeterli yetkiye sahip olduğundan emin olun.',
                    ephemeral: true
                });
            }
        }
        
        // Create ticket channel
        console.log(`[Direct] Creating ticket channel: ticket-${ticketNumber}...`);
        let ticketChannel;
        try {
            ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${ticketNumber}`,
                type: ChannelType.GuildText,
                topic: `${category.emoji} ${category.name} | Talep Eden: ${interaction.user.id} | Ticket #${ticketNumber}`,
                parent: categoryChannel.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { 
                        id: interaction.user.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles
                        ] 
                    },
                    { 
                        id: supportRole.id, 
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.ManageMessages
                        ] 
                    }
                ]
            });
            
            console.log(`[Direct] ✅ Ticket channel created: ${ticketChannel.name}`);
        } catch (error) {
            console.error(`[Direct] ❌ Ticket kanalı oluşturma hatası: ${error.message}`);
            return await interaction.editReply({
                content: '❌ Ticket kanalı oluşturulamadı! Botun kanallar oluşturma yetkisine sahip olduğundan emin olun.',
                ephemeral: true
            });
        }
        
        // Save ticket data
        const ticketData = {
            id: `ticket-${ticketNumber}`,
            ticketNumber: ticketNumber,
            channelId: ticketChannel.id,
            userId: interaction.user.id,
            userTag: interaction.user.tag,
            guildId: interaction.guild.id,
            categoryId: categoryId,
            subject: subject,
            detail: detail,
            status: 'open',
            priority: 'normal'
        };
        
        ticketUtil.saveTicket(ticketData);
        console.log(`[Direct] Ticket data saved`);
        
        // Steam Hex'i çek
        // Steam Hex bilgisini steamHexManager'dan al (whitelistLogs.json)
        let steamHex = null;
        try {
            const userHexData = steamHexManager.getUserSteamHex(interaction.user.id);
            if (userHexData && userHexData.steamHex) {
                steamHex = userHexData.steamHex;
                console.log(`[Direct] Steam Hex bulundu: ${steamHex}`);
            } else {
                console.log(`[Direct] Steam Hex bulunamadı`);
            }
        } catch (error) {
            console.warn(`[Direct] Steam Hex çekme hatası: ${error.message}`);
        }
        
        console.log(`[Direct] Steam Hex: ${steamHex || 'Bulunamadı'}`);
        
        // Create embed
        const ticketEmbed = new EmbedBuilder()
            .setColor(category.color || '#3498db')
            .setAuthor({ 
                name: `${interaction.guild.name} - Destek Sistemi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTitle(`${category.emoji} Ticket #${ticketNumber}`)
            .setDescription(`
👋 Hoş geldiniz! Destek talebiniz oluşturuldu.

🎯 **Ticket Bilgileri:**
• **Kategori:** ${category.emoji} ${category.name}
• **Durum:** 🟢 Açık
• **Öncelik:** ⚪ Normal
• **Oluşturulma:** <t:${Math.floor(Date.now() / 1000)}:R>
            `)
            .addFields(
                { 
                    name: '👤 Talep Eden', 
                    value: `${interaction.user}\n\`${interaction.user.tag}\`\nID: \`${interaction.user.id}\`\n🎮 Steam Hex: ${steamHex ? `\`${steamHex}\`` : '❌ Steam Hex bulunamıyor, lütfen steam hexini belirt'}`, 
                    inline: true 
                },
                { 
                    name: '📊 İstatistikler', 
                    value: `Ticket ID: \`#${ticketNumber}\`\nKanal: ${ticketChannel}\nSaat: <t:${Math.floor(Date.now() / 1000)}:t>`, 
                    inline: true 
                },
                { 
                    name: '⚙️ Ticket Yönetimi', 
                    value: `🔒 Kapatmak için \`Kapat\` butonuna basın\n👋 Üstlenmek için \`Üstlen\` butonuna basın\n📝 Kayıt almak için \`Kayıt\` butonuna basın`, 
                    inline: false 
                }
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setImage('https://cdn.discordapp.com/attachments/1432060322163851265/1432741855455350954/lyuex.png?ex=69022855&is=6900d6d5&hm=3b88eaafd8da882d4a98236b3217388e52df5151ff288f29b90776fd51c9b660&')
            .setFooter({ 
                text: `${interaction.guild.name} Destek Ekibi`, 
                iconURL: interaction.guild.iconURL({ dynamic: true }) 
            })
            .setTimestamp();
        
        // Buttons
        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_kapat')
                    .setLabel('Kapat')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('Üstlen')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('👋'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Kayıt')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📝')
            );
            
        const buttons2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_set_priority')
                    .setLabel('Öncelik')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🔄'),
                new ButtonBuilder()
                    .setCustomId('ticket_set_tag')
                    .setLabel('Etiket')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🏷️')
            );
        
        const ticketMessage = await ticketChannel.send({
            content: `${interaction.user} | ${supportRole}`,
            embeds: [ticketEmbed],
            components: [buttons, buttons2]
        });
        
        await ticketMessage.pin();
        console.log(`[Direct] ✅ Embed gönderildi ve pinlendi`);
        
        // Log to log channel
        if (config.logChannelId) {
            try {
                const logChannel = await interaction.guild.channels.fetch(config.logChannelId).catch(() => null);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(category.color || '#3498db')
                        .setTitle('📩 Yeni Ticket')
                        .setDescription(`${category.emoji} Destek talebi açıldı`)
                        .addFields(
                            { name: 'Talep Eden', value: `${interaction.user.tag}`, inline: true },
                            { name: 'Ticket ID', value: `#${ticketNumber}`, inline: true },
                            { name: 'Kanal', value: `${ticketChannel}`, inline: true }
                        )
                        .setTimestamp();
                        
                    await logChannel.send({ embeds: [logEmbed] });
                    console.log(`[Direct] Log kanalına bilgi gönderildi`);
                }
            } catch (error) {
                console.error(`[Direct] Log gönderme hatası: ${error.message}`);
            }
        }
        
        // Reply to user
        await interaction.editReply({
            content: `✅ Ticket oluşturuldu: ${ticketChannel}`,
            ephemeral: true
        });
        console.log(`[Direct] ✅ USER REPLY SENT - Ticket created successfully`);
        
    } catch (error) {
        console.error(`[Direct] ❌ CRITICAL ERROR:`, error.message);
        console.error(`[Direct] Stack:`, error.stack);
        
        try {
            if (!interaction.deferred) {
                await interaction.deferReply({ ephemeral: true });
            }
            await interaction.editReply({ content: `❌ Hata: ${error.message}` });
        } catch (err) {
            console.error(`[Direct] Reply failed:`, err.message);
        }
    }
}




