// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const member = newState.member;
        const guild = member.guild;
        
        // lyuex.json'dan log kanalını al
        const logChannelId = lyuex.log?.channels?.voice_logs || lyuex.botSettings?.LOG_CHANNEL_ID;
        let logChannel = null;
        
        if (logChannelId) {
            logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        }

        if (!logChannel) {
            // Artık hata vermeyeceğiz, sessizce geçeceğiz
            return;
        }

        // Eski ve yeni ses kanallarını al
        const oldChannel = oldState.channel;
        const newChannel = newState.channel;

        // Ses kanalına girme ve çıkma durumu
        if (oldChannel !== newChannel) {
            if (!oldChannel && newChannel) {
                // Kanala katılma durumu
                const action = 'Kanala Katıldı';
                const embed = createEmbed(member, newChannel, action, guild.iconURL());
                logChannel.send({ embeds: [embed] }).catch(console.error);
            } else if (oldChannel && !newChannel) {
                // Kanaldan ayrılma durumu
                const action = 'Kanaldan Ayrıldı';
                const embed = createEmbed(member, oldChannel, action, guild.iconURL());
                logChannel.send({ embeds: [embed] }).catch(console.error);
            }
        }

        // Kamerası ve mikrofonu açıkken odadan çıktıysa
        if (oldState.selfVideo && oldState.streaming && !newChannel) {
            const action = 'Kamerası ve Mikrofonu Açıkken Odadan Çıktı';
            const embed = createEmbed(member, oldChannel, action, guild.iconURL());
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }

        // Kamerası kapalı, mikrofonu açıkken odadan çıktıysa
        if (!oldState.selfVideo && oldState.streaming && !newChannel) {
            const action = 'Mikrofonu Açıkken Odadan Çıktı';
            const embed = createEmbed(member, oldChannel, action, guild.iconURL());
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }

        // Mikrofonu kapalı, kamerası açıkken odadan çıktıysa
        if (oldState.selfVideo && !oldState.streaming && !newChannel) {
            const action = 'Kamerası Açıkken Odadan Çıktı';
            const embed = createEmbed(member, oldChannel, action, guild.iconURL());
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }

        // Yayın durumu değişimi
        if (oldState.streaming !== newState.streaming) {
            const action = newState.streaming ? 'Yayını Açtı' : 'Yayını Kapattı';
            const embed = createEmbed(member, newChannel, action, guild.iconURL());
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }
    },
};

function createEmbed(member, channel, action) {
    const embed = new EmbedBuilder()
        .setColor(0xFFF700)
        .setTitle(action)
        .setDescription(`
            **Kullanıcı:**
            <@${member.id}> - ${member.id}
            **Kanal:**
            > <#${channel ? `${channel.id}> (${channel.id})` : 'Bilinmiyor'}
            **Kanal Üyeleri:**
            ${getMemberList(channel)}
        `)
        .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
        .setTimestamp();
    return embed;
}

function getMemberList(channel) {
    const members = channel ? channel.members : null;
    let memberList = '';
    if (members) {
        members.forEach(member => {
            memberList += `\n> <@${member.id}> - ${member.id}`;
        });
    }
    return memberList || 'Kanalda başka üye bulunmuyor.';
}




