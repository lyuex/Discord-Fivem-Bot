// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '../data/protection.json');
const guvenli = require('../commands/guvenli');

module.exports = {
    name: Events.GuildRoleDelete,
    async execute(role, client) {
        try {
            // Güvenli sistem kontrolü
            const isRoleSafe = guvenli.isRoleSafe(role.guild.id, role.id);
            
            if (!isRoleSafe) {
                // Audit log'dan silen kişiyi bul
                const auditLogs = await role.guild.fetchAuditLogs({
                    type: 32, // ROLE_DELETE
                    limit: 1
                }).catch(() => null);
                
                if (auditLogs && auditLogs.entries.size > 0) {
                    const logEntry = auditLogs.entries.first();
                    const executor = logEntry.executor;
                    
                    if (executor && !guvenli.isUserSafe(role.guild.id, executor.id)) {
                        // İhlal sayısını artır
                        const violationCount = guvenli.trackViolation(role.guild.id, executor.id, 'Rol Silme', role.guild);
                        
                        console.log(`[RoleDelete] Violation tracked for ${executor.tag}: ${violationCount}`);
                        console.log(`[RoleDelete] isUserSafe: false | isRoleSafe: ${isRoleSafe}`);
                        
                        // Log embed'i
                        const violationEmbed = new EmbedBuilder()
                            .setTitle('🚨 Güvenli Sistem İhlali - Rol Silme')
                            .setDescription(`**${executor.tag}** güvenli olmayan bir rolü sildi.`)
                            .addFields(
                                { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: '🏷️ Silinen Rol', value: `${role.name} (${role.id})`, inline: true },
                                { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                                { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                            )
                            .setColor(0xFF9800)
                            .setTimestamp();
                        
                        // Log kanalına gönder
                        const roleLogChannelId = (lyuex.log && lyuex.log.channels && lyuex.log.channels.role_logs) || lyuex.botSettings.LOG_CHANNEL_ID;
                        const roleLogChannel = client.channels.cache.get(roleLogChannelId);
                        if (roleLogChannel) {
                            await roleLogChannel.send({ embeds: [violationEmbed] });
                            console.log(`[RoleDelete] Violation log sent to channel ${roleLogChannelId}`);
                        }
                        
                        // İhlal limitini kontrol et
                        console.log(`[RoleDelete] Calling handleViolationLimit with count: ${violationCount}`);
                        await guvenli.handleViolationLimit(role.guild, executor.id, 'Rol Silme', violationCount);
                    }
                }
            }
            
            // Normal loglama (eğer güvenliyse veya ihlal değilse)
            const roleLogChannelId2 = (lyuex.log && lyuex.log.channels && lyuex.log.channels.role_logs) || lyuex.botSettings.LOG_CHANNEL_ID;
            const roleLogChannel2 = client.channels.cache.get(roleLogChannelId2);
            if (roleLogChannel2) {
                const audit = await role.guild.fetchAuditLogs({ type: 32, limit: 1 }).catch(() => null);
                const entry = audit?.entries?.first();
                const lyuexs = entry?.executor;
                const normalEmbed = new EmbedBuilder()
                  .setColor(0xFF0000)
                  .setTitle('Rol Silindi')
                  .setDescription(`Rol: \n > **${role.name}** - ${role.id}${lyuexs ? `\n\nKişi: \n > ${lyuexs.tag} - ${lyuexs.id} - <@${lyuexs.id}>` : ''}`)
                  .setThumbnail(role.guild.iconURL({ dynamic: true }))
                  .setFooter({ text: lyuex.reklam.lyuexisim, iconURL: lyuex.reklam.lyuexprofile })
                  .setTimestamp();
                await roleLogChannel2.send({ embeds: [normalEmbed] });
            }
        }
        catch (error) {
            catchError(client, 'roleDelete.js', error.message);
        }
    }
}




