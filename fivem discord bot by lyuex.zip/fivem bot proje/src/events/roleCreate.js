// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajì');
const guvenli = require('../commands/guvenli');

module.exports = {
   name: Events.GuildRoleCreate,
    async execute(role, client) {
        try {
            const fetchedLogs = await role.guild.fetchAuditLogs({ 
                type: AuditLogEvent.RoleCreate,
                limit: 1
            });
            
            const auditEntry = fetchedLogs.entries.first();
            const executor = auditEntry ? auditEntry.executor : null;

            // Güvenli kontrolü - eğer yapan kişi güvenli değilse ihlal say
            if (executor && !guvenli.isUserSafe(role.guild.id, executor.id)) {
                // İhlal sayısını artır
                const violationCount = guvenli.trackViolation(role.guild.id, executor.id, 'Rol Ekleme', role.guild);
                
                // İhlal log embed'i
                const violationEmbed = new EmbedBuilder()
                    .setTitle('🚨 Güvenli Sistem İhlali - Rol Ekleme')
                    .setDescription(`**${executor.tag}** yeni bir rol oluşturdu.`)
                    .addFields(
                        { name: '👤 İhlal Yapan', value: `${executor.tag} (${executor.id})`, inline: true },
                        { name: '🏷️ Oluşturulan Rol', value: `${role.name} (${role.id})`, inline: true },
                        { name: '📊 İhlal Sayısı', value: `${violationCount}/3`, inline: true },
                        { name: '⏰ Zaman', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    )
                    .setColor(0xFF9800)
                    .setTimestamp();
                
                // Log kanalına gönder
                const logChannelId = lyuex.botSettings.LOG_CHANNEL_ID;
                if (logChannelId) {
                    const lyuexinchannellogkanali = client.channels.cache.get(logChannelId);
                    if (lyuexinchannellogkanali) {
                        await lyuexinchannellogkanali.send({ embeds: [violationEmbed] });
                    }
                }
                
                // İhlal limitini kontrol et
                await guvenli.handleViolationLimit(role.guild, executor.id, 'Rol Ekleme', violationCount);
            }

            // Normal loglama (eğer aktifse)
            if (!lyuex.log?.enabled || !lyuex.log?.events?.role_create) return;
            
            const logChannel = role.guild.channels.cache.get(lyuex.log.channels.role_logs);
            if (!logChannel) return;
            
            const embed = new EmbedBuilder()
                .setColor(0x00FF1A)
                .setTitle('🏷️ Rol Oluşturuldu')
                .setDescription(`**${role.name}** rolü oluşturuldu`)
                .addFields(
                    { name: '🏷️ Rol', value: `<@&${role.id}>\n**${role.name}** (${role.id})`, inline: true },
                    { name: '👮 Oluşturan', value: executor ? `${executor.tag}\n<@${executor.id}>` : 'Bilinmiyor', inline: true },
                    { name: '⏰ Oluşturulma Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🎨 Rol Rengi', value: `${role.hexColor || '#000000'}`, inline: true },
                    { name: '📊 Pozisyon', value: `${role.position}`, inline: true },
                    { name: '🔒 Özel İzinler', value: role.permissions.toArray().length > 0 ? `${role.permissions.toArray().slice(0, 3).join(', ')}${role.permissions.toArray().length > 3 ? '...' : ''}` : 'Özel izin yok', inline: true },
                    { name: '🔍 Rol Özellikleri', value: `• Mentionlanabilir: ${role.mentionable ? '✅' : '❌'}\n• Ayrı Gösterim: ${role.hoist ? '✅' : '❌'}\n• Bot Rolü: ${role.managed ? '✅' : '❌'}`, inline: false }
                )
                .setThumbnail(role.guild.iconURL({ dynamic: true}))
                .setFooter({ 
                    text: `LYUEX Gelişmiş Log Sistemi • Rol Yönetimi`,
                    iconURL: role.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();

            await logChannel.send({ embeds: [embed] });
                
        } catch (error) {
            console.error('Rol oluşturma log hatası:', error);
            catchError(client, 'roleCreate.js', error.message);
        }
    },
};





