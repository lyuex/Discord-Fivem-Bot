// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const lyuex = require('../../lyuex.json');

// Ünlü isimleri listesi (sadece tam isimler)
const unluIsimler = [
    'Tarkan', 'Sezen Aksu', 'Ajda Pekkan', 'Kenan Doğulu', 'Hadise', 'Sertab Erener', 
    'Aleyna Tilki', 'Zeynep Bastık', 'Murat Boz', 'Demet Akalın', 'Gülşen', 'Sıla', 
    'Yıldız Tilbe', 'Hande Yener', 'Mustafa Sandal', 'Mabel Matiz', 'Derya Uluğ', 'Simge Sağın',
    'Kıvanç Tatlıtuğ', 'Beren Saat', 'Halit Ergenç', 'Bergüzar Korel', 'Engin Akyürek', 
    'Fahriye Evcen', 'Burak Özçivit', 'Neslihan Atagül', 'Serenay Sarıkaya', 'Çağatay Ulusoy',
    'Demet Özdemir', 'Hande Erçel', 'Can Yaman', 'Kenan İmirzalioğlu', 'Özge Özpirinçci', 
    'Hazal Kaya', 'Elçin Sangu', 'Barış Arduç', 'İbrahim Çelikkol', 'Acun Ilıcalı', 'Müge Anlı', 
    'Beyazıt Öztürk', 'Okan Bayülgen', 'Esra Erol', 'Eser Yenenler', 'İbrahim Büyükak', 
    'Enis Arıkan', 'Cem Yılmaz', 'Ata Demirer', 'Şahan Gökbakar', 'Tolga Çevik', 
    'Yılmaz Erdoğan', 'Gülse Birsel', 'Ezgi Mola', 'Hasan Can Kaya', 'Doğu Demirkol',
    'Arda Turan', 'Hakan Şükür', 'Burak Yılmaz', 'Hakan Çalhanoğlu', 'Cengiz Ünder', 
    'Merih Demiral', 'Çağlar Söyüncü', 'Nuri Şahin', 'Rıdvan Dilmen', 'İbrahim Kutluay',
    'Mehmet Okur', 'Hidayet Türkoğlu', 'Orhan Pamuk', 'Elif Şafak', 'Ahmet Ümit', 
    'Zülfü Livaneli', 'Sunay Akın', 'Can Yücel', 'Cemal Süreya', 'Barış Manço', 
    'Zeki Müren', 'Müslüm Gürses', 'İbrahim Tatlıses', 'Neşet Ertaş', 'Cem Karaca',
    'Recep Tayyip Erdoğan', 'Kemal Kılıçdaroğlu', 'Meral Akşener', 'Devlet Bahçeli', 
    'Ekrem İmamoğlu', 'Mansur Yavaş', 'Canan Kaftancıoğlu', 'Mustafa Kemal Atatürk', 
    'İsmet İnönü', 'Celal Bayar', 'Süleyman Demirel', 'Turgut Özal', 'Bülent Ecevit', 
    'Necmettin Erbakan', 'Tansu Çiller', 'Mesut Yılmaz', 'Abdullah Gül', 'Ahmet Necdet Sezer'
];

// Ünlü isim kontrolü fonksiyonu
function unluIsimKontrol(icIsim) {
    const temizIsim = icIsim.toLowerCase().trim();
    
    // Tam eşleşme kontrolü (tam isim eşleşmesi)
    for (const unluIsim of unluIsimler) {
        if (temizIsim === unluIsim.toLowerCase()) {
            return { isUnlu: true, bulunanIsim: unluIsim };
        }
    }
    
    // Çok katı kısmi eşleşme kontrolü (sadece çok belirgin durumlar)
    const isimParcalari = temizIsim.split(' ').filter(parca => parca.length > 3); // 3 harften uzun
    
    // Sadece çok spesifik ünlü isimleri kontrol et
    const spesifikUnluler = [
        'tarkan', 'hadise', 'sıla', 'gülşen', 'atatürk', 'erdoğan', 'kılıçdaroğlu', 
        'beyazıt', 'acun', 'müge', 'ajda', 'sezen', 'aleyna', 'serenay', 'çağatay',
        'bergüzar', 'fahriye', 'neslihan', 'özge', 'elçin', 'kıvanç', 'engin',
        'halit', 'kenan', 'ibrahim', 'burak', 'hande', 'demet'
    ];
    
    for (const parca of isimParcalari) {
        if (spesifikUnluler.includes(parca)) {
            // Eğer tek kelime ise ve ünlü listesinde varsa engelle
            if (isimParcalari.length === 1) {
                const bulunanUnlu = unluIsimler.find(u => u.toLowerCase().includes(parca));
                if (bulunanUnlu) {
                    return { isUnlu: true, bulunanIsim: bulunanUnlu };
                }
            }
            
            // Çift isim durumunda tam kontrol yap
            if (isimParcalari.length === 2) {
                const tamIsim = isimParcalari.join(' ');
                const bulunanUnlu = unluIsimler.find(u => 
                    u.toLowerCase() === tamIsim || 
                    u.toLowerCase().includes(tamIsim)
                );
                if (bulunanUnlu && bulunanUnlu.toLowerCase() === tamIsim) {
                    return { isUnlu: true, bulunanIsim: bulunanUnlu };
                }
            }
        }
    }
    
    return { isUnlu: false, bulunanIsim: null };
}

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        // Bot mesajlarını yok say
        if (message.author.bot) return;
        
        // Sadece belirli kanalda çalış
        const icKanalId = lyuex.ic_isim?.kanal;
        if (!icKanalId || message.channel.id !== icKanalId) return;
        
        // Whitelist rolü kontrolü
        const whitelistRoles = lyuex.rol?.whitelist;
        if (whitelistRoles) {
            // String ise array'e çevir, array ise olduğu gibi kullan
            const roleArray = Array.isArray(whitelistRoles) ? whitelistRoles : [whitelistRoles];
            const hasWhitelistRole = roleArray.some(roleId => 
                message.member.roles.cache.has(roleId)
            );
            
            if (hasWhitelistRole) {
                // Kullanıcı mesajını sil
                await message.delete();
                
                // Whitelist engellemesi embed'i
                const whitelistEmbed = new EmbedBuilder()
                    .setColor(0xFF6600)
                    .setTitle('🚫 Whitelist Rolü Tespit Edildi!')
                    .setDescription(`${message.author}, **Whitelist** rolünüz olduğu için bu kanala mesaj gönderemezsiniz!`)
                    .addFields(
                        { name: '⚠️ Sebep', value: 'Whitelist rolü mevcutluğu', inline: true },
                        { name: '🎫 Çözüm', value: 'Ticket açınız', inline: true },
                        { name: '📞 Yardım', value: 'Yetkili desteği alın', inline: true },
                        { name: '💡 Not', value: 'IC isim işlemleri için **ticket sistemi** kullanmalısınız', inline: false },
                        { name: '🎯 Ticket Kanalı', value: 'Ticket açma kanalından yardım talep edin', inline: false }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 12 saniye sonra silinecek • LYUEX' })
                    .setTimestamp();
                
                const whitelistMesaj = await message.channel.send({ embeds: [whitelistEmbed] });
                
                // 12 saniye sonra mesajı sil
                setTimeout(() => {
                    whitelistMesaj.delete().catch(() => {});
                }, 12000);
                
                return;
            }
        }
        
        try {
            const icIsim = message.content.trim();
            
            // Boş mesaj kontrolü
            if (!icIsim) return;
            
            // Etiket kontrolü (@mention kontrolü)
            if (message.mentions.users.size > 0 || message.mentions.roles.size > 0 || message.mentions.everyone) {
                // Kullanıcı mesajını sil
                await message.delete();
                
                // Uyarı mesajı gönder
                const uyariEmbed = new EmbedBuilder()
                    .setColor(0xFF4444)
                    .setTitle('⚠️ Geçersiz IC İsim')
                    .setDescription(`${message.author}, IC isim başvurunuz **geçersiz**!`)
                    .addFields(
                        { name: '❌ Sorun', value: 'Mesajınızda **etiket** bulunuyor', inline: true },
                        { name: '📝 Çözüm', value: 'Sadece **isim soyisim** yazın', inline: true },
                        { name: '✅ Örnek', value: '`Ahmet Yılmaz`', inline: true }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 8 saniye sonra silinecek' })
                    .setTimestamp();
                
                const uyariMesaj = await message.channel.send({ embeds: [uyariEmbed] });
                
                // 8 saniye sonra uyarı mesajını sil
                setTimeout(() => {
                    uyariMesaj.delete().catch(() => {});
                }, 8000);
                
                return;
            }
            
            // Ünlü isim kontrolü
            const unluKontrol = unluIsimKontrol(icIsim);
            if (unluKontrol.isUnlu) {
                await message.delete();
                
                const unluUyariEmbed = new EmbedBuilder()
                    .setColor(0xFF6600)
                    .setTitle('⭐ Ünlü İsmi Tespit Edildi!')
                    .setDescription(`${message.author}, **ünlü ismi** kullanılamaz!`)
                    .addFields(
                        { name: '❌ Tespit Edilen İsim', value: `**${unluKontrol.bulunanIsim}**`, inline: true },
                        { name: '⭐ Kategori', value: 'Ünlü/Tanınmış Kişi', inline: true },
                        { name: '🚫 Sebep', value: 'Gerçek kişi isimleri yasak', inline: true },
                        { name: '💡 Öneri', value: 'Kendi hayal ürünü isminizi kullanın', inline: true },
                        { name: '✅ Örnek', value: '`Ahmet Demir` `Elif Kaya`', inline: true },
                        { name: '📝 Not', value: 'Bu isim alınamaz!', inline: true }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 10 saniye sonra silinecek • LYUEX' })
                    .setTimestamp();
                
                const unluUyariMesaj = await message.channel.send({ embeds: [unluUyariEmbed] });
                
                // 10 saniye sonra uyarı mesajını sil
                setTimeout(() => {
                    unluUyariMesaj.delete().catch(() => {});
                }, 10000);
                
                return;
            }
            
            // Özel karakter kontrolü (sadece harf, boşluk ve Türkçe karakterler)
            const isimRegex = /^[a-zA-ZğüşıöçĞÜŞİÖÇ\s]+$/;
            if (!isimRegex.test(icIsim)) {
                await message.delete();
                
                const formatUyariEmbed = new EmbedBuilder()
                    .setColor(0xFF4444)
                    .setTitle('⚠️ Geçersiz Format')
                    .setDescription(`${message.author}, IC isim formatınız **yanlış**!`)
                    .addFields(
                        { name: '❌ Sorun', value: 'Sayı veya özel karakter var', inline: true },
                        { name: '📝 Çözüm', value: 'Sadece **harf ve boşluk** kullanın', inline: true },
                        { name: '✅ Doğru', value: '`Mehmet Ali`', inline: true },
                        { name: '❌ Yanlış', value: '`Mehmet123`, `@Mehmet`, `Mehmet!`', inline: false }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 10 saniye sonra silinecek' })
                    .setTimestamp();
                
                const formatMesaj = await message.channel.send({ embeds: [formatUyariEmbed] });
                
                setTimeout(() => {
                    formatMesaj.delete().catch(() => {});
                }, 10000);
                
                return;
            }
            
            // Uzunluk kontrolü
            if (icIsim.length < 3 || icIsim.length > 50) {
                await message.delete();
                
                const uzunlukUyariEmbed = new EmbedBuilder()
                    .setColor(0xFF4444)
                    .setTitle('⚠️ Uzunluk Hatası')
                    .setDescription(`${message.author}, IC isim uzunluğu **hatalı**!`)
                    .addFields(
                        { name: '📏 Gereksinimler', value: '**3-50 karakter** arası olmalı', inline: true },
                        { name: '📊 Mevcut Uzunluk', value: `${icIsim.length} karakter`, inline: true },
                        { name: '✅ Örnek', value: '`Ahmet Yılmaz` (12 karakter)', inline: true }
                    )
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Bu mesaj 8 saniye sonra silinecek' })
                    .setTimestamp();
                
                const uzunlukMesaj = await message.channel.send({ embeds: [uzunlukUyariEmbed] });
                
                setTimeout(() => {
                    uzunlukMesaj.delete().catch(() => {});
                }, 8000);
                
                return;
            }
            
            // Gelişmiş onay paneli oluştur
            const onayEmbed = new EmbedBuilder()
                .setColor(0xFFD700) // Altın rengi
                .setTitle('🛡️ IC İsim Onay Paneli')
                .setDescription(`**${message.author}** tarafından gönderilen IC isim onay bekliyor!`)
                .addFields(
                    { name: '💎 IC İsim', value: `\`\`\`${icIsim}\`\`\``, inline: true },
                    { name: '👑 Kullanıcı', value: `**${message.author.tag}**`, inline: true },
                    { name: '🆔 Kullanıcı ID', value: `\`${message.author.id}\``, inline: true },
                    { name: '📅 Mesaj ID', value: `\`${message.id}\``, inline: true },
                    { name: '⏰ Gönderim Zamanı', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '🎯 Durum', value: '⏳ **Onay Bekleniyor...**', inline: true },
                    { name: '📊 Hesap Yaşı', value: `<t:${Math.floor(message.author.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: '🏠 Sunucuya Katılım', value: `<t:${Math.floor(message.member.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: '📝 İsim Uzunluğu', value: `${icIsim.length} karakter`, inline: true }
                )
                .setThumbnail(message.author.displayAvatarURL({ dynamic: true, size: 256 }))
                .setImage('https://cdn.discordapp.com/attachments/1422661295571992576/1423321126733349035/lyuexdevkirmizi_1.png') // Sunucu banner'ı
                .setFooter({ 
                    text: `Katılış: ${message.member.joinedAt ? message.member.joinedAt.toLocaleDateString('tr-TR') : 'Bilinmiyor'} • LYUEX`,
                    iconURL: message.guild.iconURL({ dynamic: true })
                })
                .setTimestamp();
            
            // Gelişmiş buton sistemi (4 seçenek)
            const buttons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`ic_onayla_${message.author.id}_${message.id}`)
                        .setLabel('✅ IC ismi Onayla')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅'),
                    new ButtonBuilder()
                        .setCustomId(`ic_uygunsuz_${message.author.id}_${message.id}`)
                        .setLabel('❌ Uygunsuz İsim')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('❌'),
                    new ButtonBuilder()
                        .setCustomId(`ic_unlu_${message.author.id}_${message.id}`)
                        .setLabel('⭐ Ünlü İsmi')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('⭐'),
                    new ButtonBuilder()
                        .setCustomId(`ic_ozel_${message.author.id}_${message.id}`)
                        .setLabel('⚠️ Özel Sebep')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('⚠️')
                );
            
            // Onay mesajını gönder (orijinal mesajı reply olarak)
            await message.reply({
                embeds: [onayEmbed],
                components: [buttons]
            });
            
        } catch (error) {
            console.error('IC isim onay hatası:', error);
        }
    }
};




