// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Schema, model } = require('mongoose');

const giveawaySchema = new Schema({
  messageId: { type: String, required: true, unique: true },
  channelId: { type: String, required: true },
  guildId: { type: String, required: true },
  hostId: { type: String, required: true },
  prize: { type: String, required: true },
  winnerCount: { type: Number, required: true, min: 1 },
  startTime: { type: Date, required: true },
  endTime: { type: Date, required: true },
  status: { type: String, enum: ['active', 'completed', 'cancelled'], default: 'active' },
  participants: [{ 
    userId: String, 
    username: String, 
    multiplier: { type: Number, default: 1 } 
  }],
  winners: [{ 
    userId: String, 
    username: String 
  }],
  bonusRoles: [{ 
    roleId: String, 
    roleName: String,
    multiplier: Number
  }],
  requiredRoleId: { type: String, default: null },
  rewardRoleId: { type: String, default: null },
  imageUrl: { type: String, default: null },
  description: { type: String, default: null },
  sponsor: { type: String, default: null },
  dmWinners: { type: Boolean, default: true },
  lastUpdated: { type: Date, default: Date.now }
});

module.exports = model('Giveaway', giveawaySchema);




