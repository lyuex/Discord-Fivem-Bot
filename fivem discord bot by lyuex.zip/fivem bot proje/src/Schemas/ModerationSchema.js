// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
﻿const { Schema, model } = require('mongoose');

// Moderasyon işlemleri için genel şema
const moderationSchema = new Schema({
  // Temel bilgiler
  caseId: { type: String, required: true, unique: true },
  guildId: { type: String, required: true },
  type: { 
    type: String, 
    required: true, 
    enum: ['ban', 'tempban', 'kick', 'mute', 'tempmute', 'unmute', 'unban', 'warn'] 
  },
  
  // Kullanıcı bilgileri
  userId: { type: String, required: true },
  username: { type: String, required: true },
  userTag: { type: String, required: true },
  
  // Moderatör bilgileri
  moderatorId: { type: String, required: true },
  moderatorTag: { type: String, required: true },
  
  // İşlem detayları
  reason: { type: String, default: 'Sebep belirtilmedi' },
  duration: { type: Number, default: null }, // dakika cinsinden, null = kalıcı
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: null },
  
  // Durum bilgileri
  active: { type: Boolean, default: true },
  appealed: { type: Boolean, default: false },
  appealReason: { type: String, default: null },
  revokedBy: { type: String, default: null },
  revokedAt: { type: Date, default: null },
  revokedReason: { type: String, default: null },
  
  // Ek bilgiler
  evidence: [{ type: String }], // Kanıt URL'leri
  notes: { type: String, default: null },
  dmSent: { type: Boolean, default: false },
  
  // Otomatik işlemler için
  autoRemoveJobId: { type: String, default: null }
});

// Aktif mute'lar için ayrı şema
const muteSchema = new Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  moderatorId: { type: String, required: true },
  reason: { type: String, default: 'Sebep belirtilmedi' },
  muteRoleId: { type: String, required: true },
  originalRoles: [{ type: String }], // Kullanıcının orijinal rolleri
  startTime: { type: Date, default: Date.now },
  endTime: { type: Date, default: null },
  active: { type: Boolean, default: true },
  caseId: { type: String, required: true }
});

// Geçici banlar için ayrı şema
const tempBanSchema = new Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  moderatorId: { type: String, required: true },
  reason: { type: String, default: 'Sebep belirtilmedi' },
  startTime: { type: Date, default: Date.now },
  endTime: { type: Date, required: true },
  active: { type: Boolean, default: true },
  caseId: { type: String, required: true }
});

// Index'ler performans için
moderationSchema.index({ guildId: 1, userId: 1 });
moderationSchema.index({ guildId: 1, type: 1 });
moderationSchema.index({ expiresAt: 1 });

muteSchema.index({ userId: 1, guildId: 1 });
muteSchema.index({ endTime: 1, active: 1 });

tempBanSchema.index({ userId: 1, guildId: 1 });
tempBanSchema.index({ endTime: 1, active: 1 });

const Moderation = model('Moderation', moderationSchema);
const Mute = model('Mute', muteSchema);
const TempBan = model('TempBan', tempBanSchema);

module.exports = { Moderation, Mute, TempBan };




