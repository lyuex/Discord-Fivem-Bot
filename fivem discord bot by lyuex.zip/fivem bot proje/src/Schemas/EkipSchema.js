// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { Schema, model } = require('mongoose');

// Ekip Schema
const ekipSchema = new Schema({
    guildId: {
        type: String,
        required: true
    },
    ekipIsim: {
        type: String,
        required: true
    },
    ekipAciklama: {
        type: String,
        default: 'Açıklama eklenmedi'
    },
    liderId: {
        type: String,
        required: true
    },
    liderTag: {
        type: String,
        required: true
    },
    uyeler: [{
        userId: String,
        userTag: String,
        eklenmetarihi: {
            type: Date,
            default: Date.now
        },
        ekleyenId: String,
        not: String
    }],
    renk: {
        type: String,
        default: '5865F2'
    },
    olusturulmaTarihi: {
        type: Date,
        default: Date.now
    },
    seviye: {
        type: Number,
        default: 1
    },
    puan: {
        type: Number,
        default: 0
    },
    durum: {
        type: String,
        enum: ['Aktif', 'Pasif', 'Donduruldu'],
        default: 'Aktif'
    },
    roller: [{
        roleId: String,
        roleName: String,
        atanmaTarihi: Date
    }],
    rolId: {
        type: String,
        default: null
    },
    ticketKanalId: {
        type: String,
        default: null
    },
    aktif: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

// Ekip Uyarı Schema
const ekipUyariSchema = new Schema({
    guildId: {
        type: String,
        required: true
    },
    ekipIsim: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
    userTag: {
        type: String,
        required: true
    },
    sebep: {
        type: String,
        required: true
    },
    veren: {
        verenId: String,
        verenTag: String
    },
    tarih: {
        type: Date,
        default: Date.now
    },
    seviye: {
        type: String,
        enum: ['Düşük', 'Orta', 'Yüksek', 'Kritik'],
        default: 'Orta'
    }
}, {
    timestamps: true
});

// Ekip Yedek Schema
const ekipYedekSchema = new Schema({
    guildId: {
        type: String,
        required: true
    },
    yedekId: {
        type: String,
        required: true,
        unique: true
    },
    ekipIsim: {
        type: String,
        default: 'Tüm Ekipler'
    },
    data: {
        type: Schema.Types.Mixed,
        required: true
    },
    aciklama: {
        type: String,
        default: 'Manuel yedekleme'
    },
    olusturan: {
        userId: String,
        userTag: String
    },
    tarih: {
        type: Date,
        default: Date.now
    },
    boyut: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

// İndeksler
ekipSchema.index({ guildId: 1, ekipIsim: 1 });
ekipSchema.index({ guildId: 1, aktif: 1 });
ekipSchema.index({ liderId: 1 });

ekipUyariSchema.index({ guildId: 1, userId: 1 });
ekipUyariSchema.index({ ekipIsim: 1 });

ekipYedekSchema.index({ guildId: 1, yedekId: 1 });
ekipYedekSchema.index({ tarih: -1 });

module.exports = {
    Ekip: model('Ekip', ekipSchema),
    EkipUyari: model('EkipUyari', ekipUyariSchema),
    EkipYedek: model('EkipYedek', ekipYedekSchema)
};
