// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');

// Kanal koruma sistemi
class KanalKontrol {
    constructor() {
        this.korunanKanallar = new Map();
        this.kanalLoglari = [];
        this.loadConfig();
    }
    
    // Konfigürasyonu yükle
    loadConfig() {
        try {
            if (fs.existsSync('./data/protection.json')) {
                const data = JSON.parse(fs.readFileSync('./data/protection.json', 'utf8'));
                this.korunanKanallar = new Map(data.korunanKanallar || []);
            }
        } catch (error) {
            console.error('Kanal kontrol konfigürasyonu yüklenirken hata:', error);
        }
    }
    
    // Konfigürasyonu kaydet
    saveConfig() {
        try {
            const data = {
                korunanKanallar: Array.from(this.korunanKanallar.entries()),
                lastUpdate: Date.now()
            };
            
            if (!fs.existsSync('./data')) {
                fs.mkdirSync('./data', { recursive: true });
            }
            
            fs.writeFileSync('./data/protection.json', JSON.stringify(data, null, 2));
        } catch (error) {
            console.error('Kanal kontrol konfigürasyonu kaydedilirken hata:', error);
        }
    }
    
    // Kanal korumaya al
    kanalKorumayaAl(kanalId, korumaAyarlari = {}) {
        const varsayilanAyarlar = {
            silmeKorumasi: true,
            isimDegistirmeKorumasi: true,
            yetkiDegistirmeKorumasi: true,
            otomatikYedekleme: true,
            log: true
        };
        
        const ayarlar = { ...varsayilanAyarlar, ...korumaAyarlari };
        this.korunanKanallar.set(kanalId, ayarlar);
        this.saveConfig();
        
        return true;
    }
    
    // Kanal korumasını kaldır
    kanalKorumasiniKaldir(kanalId) {
        const sonuc = this.korunanKanallar.delete(kanalId);
        this.saveConfig();
        return sonuc;
    }
    
    // Kanal korunuyor mu kontrol et
    kanalKorunuyorMu(kanalId) {
        return this.korunanKanallar.has(kanalId);
    }
    
    // Kanal silme koruması
    async kanalSilmeKorumasi(kanal, executor) {
        try {
            if (!this.kanalKorunuyorMu(kanal.id)) return false;
            
            const korumaAyarlari = this.korunanKanallar.get(kanal.id);
            if (!korumaAyarlari.silmeKorumasi) return false;
            
            // Kanalı yeniden oluştur
            const yeniKanal = await kanal.guild.channels.create({
                name: kanal.name,
                type: kanal.type,
                topic: kanal.topic,
                nsfw: kanal.nsfw,
                bitrate: kanal.bitrate,
                userLimit: kanal.userLimit,
                parent: kanal.parent,
                permissionOverwrites: kanal.permissionOverwrites.cache.map(overwrite => ({
                    id: overwrite.id,
                    allow: overwrite.allow.toArray(),
                    deny: overwrite.deny.toArray(),
                    type: overwrite.type
                })),
                position: kanal.position
            });
            
            // Yeni kanalı korumaya al
            this.kanalKorumayaAl(yeniKanal.id, korumaAyarlari);
            
            // Log
            this.logKaydet('Kanal Silme Koruması', {
                kanalId: kanal.id,
                kanalAdi: kanal.name,
                yeniKanalId: yeniKanal.id,
                executor: executor.tag,
                executorId: executor.id,
                zaman: new Date().toISOString()
            });
            
            return yeniKanal;
            
        } catch (error) {
            console.error('Kanal silme koruması hatası:', error);
            return false;
        }
    }
    
    // Kanal güncelleme koruması
    async kanalGuncellemeKorumasi(eskiKanal, yeniKanal, executor) {
        try {
            if (!this.kanalKorunuyorMu(eskiKanal.id)) return false;
            
            const korumaAyarlari = this.korunanKanallar.get(eskiKanal.id);
            
            let geriAlinacaklar = {};
            
            // İsim değişikliği koruması
            if (korumaAyarlari.isimDegistirmeKorumasi && eskiKanal.name !== yeniKanal.name) {
                geriAlinacaklar.name = eskiKanal.name;
            }
            
            // Yetki değişikliği koruması
            if (korumaAyarlari.yetkiDegistirmeKorumasi) {
                // Yetki değişikliklerini kontrol et ve geri al
                const eskiYetkiler = eskiKanal.permissionOverwrites.cache;
                const yeniYetkiler = yeniKanal.permissionOverwrites.cache;
                
                // Basit yetki geri alma (detaylı kontrol yapılabilir)
                if (eskiYetkiler.size !== yeniYetkiler.size) {
                    geriAlinacaklar.permissionOverwrites = eskiKanal.permissionOverwrites.cache.map(overwrite => ({
                        id: overwrite.id,
                        allow: overwrite.allow.toArray(),
                        deny: overwrite.deny.toArray(),
                        type: overwrite.type
                    }));
                }
            }
            
            // Değişiklikleri geri al
            if (Object.keys(geriAlinacaklar).length > 0) {
                await yeniKanal.edit(geriAlinacaklar);
                
                // Log
                this.logKaydet('Kanal Güncelleme Koruması', {
                    kanalId: yeniKanal.id,
                    kanalAdi: yeniKanal.name,
                    geriAlinanlar: geriAlinacaklar,
                    executor: executor.tag,
                    executorId: executor.id,
                    zaman: new Date().toISOString()
                });
                
                return true;
            }
            
            return false;
            
        } catch (error) {
            console.error('Kanal güncelleme koruması hatası:', error);
            return false;
        }
    }
    
    // Kanal yedekleme
    async kanalYedekle(kanal) {
        try {
            const yedekData = {
                id: kanal.id,
                name: kanal.name,
                type: kanal.type,
                topic: kanal.topic,
                nsfw: kanal.nsfw,
                bitrate: kanal.bitrate,
                userLimit: kanal.userLimit,
                parentId: kanal.parentId,
                position: kanal.position,
                permissionOverwrites: kanal.permissionOverwrites.cache.map(overwrite => ({
                    id: overwrite.id,
                    allow: overwrite.allow.toString(),
                    deny: overwrite.deny.toString(),
                    type: overwrite.type
                })),
                yedeklenmeZamani: new Date().toISOString()
            };
            
            // Yedek klasörü oluştur
            if (!fs.existsSync('./data/backups')) {
                fs.mkdirSync('./data/backups', { recursive: true });
            }
            
            // Yedek dosyasını kaydet
            const dosyaAdi = `kanal_${kanal.name}_${kanal.id}_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
            fs.writeFileSync(`./data/backups/${dosyaAdi}`, JSON.stringify(yedekData, null, 2));
            
            return dosyaAdi;
            
        } catch (error) {
            console.error('Kanal yedekleme hatası:', error);
            return false;
        }
    }
    
    // Log kaydet
    logKaydet(tip, veri) {
        const logGirdisi = {
            tip,
            veri,
            zaman: new Date().toISOString()
        };
        
        this.kanalLoglari.push(logGirdisi);
        
        // Log dosyasını güncelle
        try {
            if (!fs.existsSync('./data')) {
                fs.mkdirSync('./data', { recursive: true });
            }
            
            fs.writeFileSync('./data/channelLogs.json', JSON.stringify(this.kanalLoglari, null, 2));
        } catch (error) {
            console.error('Log kaydedilirken hata:', error);
        }
    }
    
    // Korunan kanalları listele
    korunanKanallariListele() {
        return Array.from(this.korunanKanallar.entries()).map(([kanalId, ayarlar]) => ({
            kanalId,
            ayarlar
        }));
    }
    
    // İstatistikler
    getIstatistikler() {
        return {
            toplamKoruma: this.korunanKanallar.size,
            toplamLog: this.kanalLoglari.length,
            aktifKorumalar: this.korunanKanallariListele()
        };
    }
}

// Singleton instance
const kanalKontrol = new KanalKontrol();

module.exports = kanalKontrol;