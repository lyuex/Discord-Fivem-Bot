// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');

// Ticket sistem konfigürasyonu
const ticketConfig = {
    category: null, // Ticket kategorisi ID'si
    staffRole: null, // Staff rol ID'si
    logChannel: null, // Log kanalı ID'si
    maxTickets: 5 // Kullanıcı başına maksimum ticket sayısı
};

// Ticket oluştur
async function createTicket(interaction, type = 'genel') {
    try {
        const guild = interaction.guild;
        const user = interaction.user;
        
        // Kullanıcının mevcut ticket sayısını kontrol et
        const existingTickets = guild.channels.cache.filter(channel => 
            channel.name.startsWith(`ticket-`) && 
            channel.topic && 
            channel.topic.includes(user.id)
        ).size;
        
        if (existingTickets >= ticketConfig.maxTickets) {
            return await interaction.reply({
                content: `❌ Maksimum ${ticketConfig.maxTickets} ticket açabilirsiniz!`,
                ephemeral: true
            });
        }
        
        // Ticket kanalı oluştur
        const ticketChannel = await guild.channels.create({
            name: `ticket-${user.username}`,
            type: 0, // Text channel
            topic: `Ticket sahibi: ${user.tag} (${user.id}) | Tip: ${type}`,
            parent: ticketConfig.category,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
                {
                    id: ticketConfig.staffRole,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.ManageMessages
                    ]
                }
            ]
        });
        
        // Ticket embed'i
        const ticketEmbed = new EmbedBuilder()
            .setTitle('🎫 Destek Talebi')
            .setDescription(`Merhaba ${user}, destek talebiniz oluşturuldu!\n\nLütfen sorununuzu detaylı bir şekilde açıklayın. En kısa sürede size yardımcı olacağız.`)
            .setColor('#00ff00')
            .setTimestamp()
            .addFields(
                { name: '📝 Ticket Tipi', value: type, inline: true },
                { name: '👤 Kullanıcı', value: user.tag, inline: true },
                { name: '🕐 Oluşturulma', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            );
        
        // Ticket butonları
        const ticketButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_close')
                    .setLabel('🔒 Ticket\'ı Kapat')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('✋ Ticket\'ı Sahiplen')
                    .setStyle(ButtonStyle.Primary)
            );
        
        await ticketChannel.send({
            content: `${user} - <@&${ticketConfig.staffRole}>`,
            embeds: [ticketEmbed],
            components: [ticketButtons]
        });
        
        // Veritabanına kaydet
        const ticketData = {
            id: ticketChannel.id,
            userId: user.id,
            type: type,
            createdAt: Date.now(),
            claimed: false,
            claimedBy: null
        };
        
        // Ticket verilerini dosyaya kaydet
        let tickets = {};
        if (fs.existsSync('./data/tickets.json')) {
            tickets = JSON.parse(fs.readFileSync('./data/tickets.json', 'utf8'));
        }
        tickets[ticketChannel.id] = ticketData;
        fs.writeFileSync('./data/tickets.json', JSON.stringify(tickets, null, 2));
        
        await interaction.reply({
            content: `✅ Ticket oluşturuldu: ${ticketChannel}`,
            ephemeral: true
        });
        
    } catch (error) {
        console.error('Ticket oluşturma hatası:', error);
        await interaction.reply({
            content: '❌ Ticket oluşturulurken bir hata oluştu!',
            ephemeral: true
        });
    }
}

// Ticket kapat
async function closeTicket(interaction) {
    try {
        const channel = interaction.channel;
        
        if (!channel.name.startsWith('ticket-')) {
            return await interaction.reply({
                content: '❌ Bu komut sadece ticket kanallarında kullanılabilir!',
                ephemeral: true
            });
        }
        
        const closeEmbed = new EmbedBuilder()
            .setTitle('🔒 Ticket Kapatılıyor')
            .setDescription('Bu ticket 10 saniye içinde kapatılacak...')
            .setColor('#ff0000')
            .setTimestamp();
        
        await interaction.reply({ embeds: [closeEmbed] });
        
        setTimeout(async () => {
            try {
                // Ticket verilerini sil
                let tickets = {};
                if (fs.existsSync('./data/tickets.json')) {
                    tickets = JSON.parse(fs.readFileSync('./data/tickets.json', 'utf8'));
                    delete tickets[channel.id];
                    fs.writeFileSync('./data/tickets.json', JSON.stringify(tickets, null, 2));
                }
                
                await channel.delete('Ticket kapatıldı');
            } catch (error) {
                console.error('Ticket kapatma hatası:', error);
            }
        }, 10000);
        
    } catch (error) {
        console.error('Ticket kapatma hatası:', error);
        await interaction.reply({
            content: '❌ Ticket kapatılırken bir hata oluştu!',
            ephemeral: true
        });
    }
}

// Ticket sahiplen
async function claimTicket(interaction) {
    try {
        const channel = interaction.channel;
        const user = interaction.user;
        
        if (!channel.name.startsWith('ticket-')) {
            return await interaction.reply({
                content: '❌ Bu komut sadece ticket kanallarında kullanılabilir!',
                ephemeral: true
            });
        }
        
        // Ticket verilerini güncelle
        let tickets = {};
        if (fs.existsSync('./data/tickets.json')) {
            tickets = JSON.parse(fs.readFileSync('./data/tickets.json', 'utf8'));
            if (tickets[channel.id]) {
                tickets[channel.id].claimed = true;
                tickets[channel.id].claimedBy = user.id;
                fs.writeFileSync('./data/tickets.json', JSON.stringify(tickets, null, 2));
            }
        }
        
        const claimEmbed = new EmbedBuilder()
            .setTitle('✋ Ticket Sahiplenildi')
            .setDescription(`Bu ticket ${user} tarafından sahiplenildi.`)
            .setColor('#ffff00')
            .setTimestamp();
        
        await interaction.reply({ embeds: [claimEmbed] });
        
    } catch (error) {
        console.error('Ticket sahipleme hatası:', error);
        await interaction.reply({
            content: '❌ Ticket sahiplenirken bir hata oluştu!',
            ephemeral: true
        });
    }
}

// Konfigürasyon ayarla
function setTicketConfig(config) {
    Object.assign(ticketConfig, config);
}

module.exports = {
    createTicket,
    closeTicket,
    claimTicket,
    setTicketConfig,
    ticketConfig
};