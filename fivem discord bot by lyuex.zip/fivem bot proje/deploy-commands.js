// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const lyuex = require('./lyuex.json');

const commands = [];
const commandNames = new Set();
const commandsPath = path.join(__dirname, 'src', 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

console.log('[LYUEX] 🔄 Komutlar yükleniyor... | Lyuex Development');

for (const file of commandFiles) {
    try {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        
        if (command.data && command.data.name) {
            if (commandNames.has(command.data.name)) {
                console.log(`⚠️ ${file} - Duplicate komut ismi: ${command.data.name} (ATLANDI)`);
                continue;
            }
            
            commandNames.add(command.data.name);
            commands.push(command.data.toJSON());
            console.log(`✅ ${command.data.name} yüklendi`);
        } else {
            console.log(`❌ ${file} - Geçersiz komut formatı`);
        }
    } catch (error) {
        console.log(`❌ ${file} - Hata: ${error.message}`);
    }
}

console.log(`\n[LYUEX] 📊 Toplam ${commands.length} komut hazırlandı | Lyuex Development`);

// Deploy to Discord
const deploy = async () => {
    try {
        console.log('\n[LYUEX] ⏳ Discord\'a komutlar kaydediliyor...');
        
        const rest = new REST({ version: '10' }).setToken(lyuex.botSettings.token);
        
        await rest.put(
            Routes.applicationGuildCommands(
                lyuex.botSettings.clientID,
                lyuex.botSettings.ServerID
            ),
            { body: commands }
        );
        
        console.log('[LYUEX] ✅ Komutlar başarıyla Discord\'a kaydedildi! | Lyuex Development');
        console.log(`🎯 Sunucu: ${lyuex.botSettings.ServerID}`);
        console.log(`🤖 Bot ID: ${lyuex.botSettings.clientID}`);
        
    } catch (error) {
        console.error('❌ Deployment hatası:', error);
        
        if (error.code === 50035) {
            console.error('\n🔍 Form Body hatası - Parametre sıralama problemi olabilir:');
            console.error('Required parametreler non-required parametrelerden önce olmalı!');
        }
    }
};

deploy();