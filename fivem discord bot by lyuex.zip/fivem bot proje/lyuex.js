/**
 * ╔══════════════════════════════════════════════════════╗
 * ║                                                      ║
 * ║              LYUEX DEVELOPMENT                       ║
 * ║          Discord Bot Altyapısı v2.0                  ║
 * ║                                                      ║
 * ║   Bu altyapı Lyuex Development tarafından            ║
 * ║   geliştirilmiştir. İzinsiz satışı yasaktır.         ║
 * ║                                                      ║
 * ║   © 2024-2026 Lyuex Development                      ║
 * ║   Tüm hakları saklıdır.                              ║
 * ║                                                      ║
 * ╚══════════════════════════════════════════════════════╝
 */

const fs = require('fs');
const path = require('path');
const dns = require('dns');
const {
  Client,
  Collection,
  GatewayIntentBits,
  Partials,
  ChannelType,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AuditLogEvent
} = require('discord.js');

// ═══════════════════════════════════════════════════════
// LYUEX DEVELOPMENT - Global Embed Branding
// Tüm embed footer'larına otomatik olarak branding ekler
// ═══════════════════════════════════════════════════════
const _originalSetFooter = EmbedBuilder.prototype.setFooter;
EmbedBuilder.prototype.setFooter = function(options) {
  if (options && options.text) {
    if (!options.text.includes('Lyuex') && !options.text.includes('LYUEX') && !options.text.includes('lyuex')) {
      options.text = `${options.text} | Lyuex Development`;
    }
  }
  return _originalSetFooter.call(this, options);
};

const _originalToJSON = EmbedBuilder.prototype.toJSON;
EmbedBuilder.prototype.toJSON = function() {
  const json = _originalToJSON.call(this);
  if (!json.footer || !json.footer.text) {
    json.footer = { text: '© Lyuex Development' };
  }
  return json;
};
const debug = require('./debug');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
const { JsonDatabase } = require('wio.db');
const mongoose = require('mongoose');
const db = require('croxydb');
const TicketAutomation = require('./src/utils/ticketAutomation');
const BackupScheduler = require('./src/utils/backupScheduler');
const ServerStatusManager = require('./src/utils/serverStatus');

// ═══════════════════════════════════════════════════════
// LYUEX DEVELOPMENT - Startup Banner
// ═══════════════════════════════════════════════════════
console.log('\x1b[36m%s\x1b[0m', `
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ██╗     ██╗   ██╗██╗   ██╗███████╗██╗  ██╗             ║
║   ██║     ╚██╗ ██╔╝██║   ██║██╔════╝╚██╗██╔╝             ║
║   ██║      ╚████╔╝ ██║   ██║█████╗   ╚███╔╝              ║
║   ██║       ╚██╔╝  ██║   ██║██╔══╝   ██╔██╗              ║
║   ███████╗   ██║   ╚██████╔╝███████╗██╔╝ ██╗             ║
║   ╚══════╝   ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝             ║
║                                                           ║
║           D E V E L O P M E N T                           ║
║                                                           ║
║   Discord Bot Altyapısı v2.0                              ║
║   © 2024-2026 Lyuex Development                           ║
║   Tüm hakları saklıdır.                                   ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
`);
console.log('\x1b[33m%s\x1b[0m', '[LYUEX] Altyapı başlatılıyor...');
console.log('\x1b[33m%s\x1b[0m', '[LYUEX] Geliştirici: Lyuex Development');
console.log('\x1b[33m%s\x1b[0m', '[LYUEX] ─────────────────────────────────────');

// Configs
const lyuex = require('./lyuex.json');
const configJson = require('./config.json');

// Data directories
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const backupPath = path.join(dataDir, 'channelBackup.json');
if (!fs.existsSync(backupPath)) fs.writeFileSync(backupPath, JSON.stringify({}, null, 2));
const protectionPath = path.join(dataDir, 'protection.json');
if (!fs.existsSync(protectionPath)) fs.writeFileSync(protectionPath, JSON.stringify({}, null, 2));
const protectionConfig = JSON.parse(fs.readFileSync(protectionPath, 'utf-8'));

// Databases
lyuex.db = new JsonDatabase({ databasePath: './lyuex_database.json' });

// Bot token and limits
const BOT_TOKEN = process.env.BOT_TOKEN || lyuex.botSettings.token;

// Token validation
if (!BOT_TOKEN || BOT_TOKEN === '' || BOT_TOKEN === 'YOUR_BOT_TOKEN') {
  console.error('❌ BOT TOKEN HATASI!');
  console.error('Token bulunamadı veya geçersiz. Lütfen lyuex.json dosyasında token ayarını kontrol edin.');
  process.exit(1);
}

console.log('\x1b[32m%s\x1b[0m', '[LYUEX] ✅ Bot token yüklendi.');

const guardLimits = { ...configJson.limit, ...lyuex.limit };

// Client init
const client = new Client({
  intents: Object.values(GatewayIntentBits),
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});
client.commands = new Collection();
client.interactions = new Collection();
client.selectMenus = new Collection();
client.modals = new Collection();

global.client = client;
global.BOT_TOKEN = BOT_TOKEN;
global.lyuex = lyuex;
global.activeIntervals = []; // Tüm interval'ları izlemek için

// Event & command handlers
require('./src/handlers/eventHandler')(client);
const { commandMap } = require('./src/handlers/commandHandler');

// Register slash commands
(async () => {
  try {
    console.log('\x1b[36m%s\x1b[0m', '[LYUEX] ⏳ (/) komutları başlatılıyor...');
    
    if (!BOT_TOKEN) {
      throw new Error('Bot token bulunamadı!');
    }
    
    const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);
    
    console.log(`📊 ${commandMap.size} komut yüklenecek...`);
    
    await rest.put(
      Routes.applicationGuildCommands(
        lyuex.botSettings.clientID,
        lyuex.botSettings.ServerID
      ),
      { body: Array.from(commandMap.values()).map(cmd => cmd.data.toJSON()) }
    );
    
    console.log('\x1b[32m%s\x1b[0m', '[LYUEX] ✅ (/) komutları başarıyla yüklendi!');
  } catch (err) {
    console.error('❌ Slash komut yükleme hatası:', err);
    console.error('Token geçerli mi? ClientID ve ServerID doğru mu?');
  }
})();

// Ready event: backup & DB
client.once('clientReady', async () => {
  console.log('\x1b[32m%s\x1b[0m', `[LYUEX] ✅ ${client.user.tag} olarak giriş yapıldı! | Lyuex Development`);
  debug.trackInfo(`Bot başlatıldı: ${client.user.tag}`);

  // Backup sistemi başlat
  if (lyuex.backup?.enabled) {
    try {
      global.backupScheduler = new BackupScheduler(client);
      console.log('📦 Backup sistemi başlatıldı');
    } catch (error) {
      console.error('❌ Backup sistemi başlatılamadı:', error.message);
    }
  }

  // Ticket otomasyonu başlat
  global.ticketAutomation = new TicketAutomation(client);

  // Sunucu durumu sistemi başlat
  global.serverStatusManager = new ServerStatusManager(client);
  global.serverStatusManager.startStatusUpdater(2); // Her 2 dakikada bir güncelle

  // Kanal yedeği
  const backup = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
  client.guilds.cache.forEach(guild => {
    backup[guild.id] = backup[guild.id] || {};
    guild.channels.cache.forEach(ch => {
      backup[guild.id][ch.id] = {
        name: ch.name,
        type: ch.type,
        parent: ch.parentId || null,
        permissions: ch.permissionOverwrites?.cache.map(po => ({
          id: po.id,
          allow: po.allow.toArray(),
          deny: po.deny.toArray()
        })) || []
      };
    });
  });
  fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));
  console.log('[Başlangıç Yedeği] Kanallar yedeklendi.');

  // Guard whitelist sync: data/protection.json -> croxydb
  try {
    const protPath = path.join(__dirname, 'data', 'protection.json');
    if (fs.existsSync(protPath)) {
      const raw = fs.readFileSync(protPath, 'utf-8');
      const protection = JSON.parse(raw || '{}');
      for (const [gid, cfg] of Object.entries(protection)) {
        const users = Array.isArray(cfg?.whitelistUsers) ? cfg.whitelistUsers : [];
        if (users.length > 0) {
          const key = `güvenli_kullanıcılar_${gid}`;
          const existing = db.get(key) || [];
          const merged = Array.from(new Set([...existing, ...users]));
          db.set(key, merged);
        }
      }
      console.log('[Guard] Whitelist senkronizasyonu tamamlandı.');
    }
  } catch (e) {
    console.warn('[Guard] Whitelist senkron hatası:', e?.message || e);
  }

  // MongoDB bağlan (sağlamlaştırılmış)
  mongoose.set('strictQuery', true);
  const mongoUri = process.env.MONGO_URI || lyuex.botSettings.mongo;
  const connectWithRetry = async (retries = 5) => {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        await mongoose.connect(mongoUri, {
          serverSelectionTimeoutMS: 10000,
          connectTimeoutMS: 10000,
          socketTimeoutMS: 20000,
          family: 4, // IPv4 kullan
          retryWrites: true,
          w: 'majority'
        });
        console.log('[MongoDB API] Bağlandı.');
        global.DB_CONNECTED = true;
        return;
      } catch (err) {
        global.DB_CONNECTED = false;
        console.error(`MongoDB bağlanma denemesi ${attempt}/${retries} başarısız:`, err?.message || err);
        debug.trackError(err, 'MongoDB Bağlantısı');
        // Eğer SRV kaynaklı bir hata ise, non-SRV fallback dene (tek seferlik)
        const isSrvUri = mongoUri.startsWith('mongodb+srv://');
        const isSrvError = /querySrv|ENOTFOUND|ETIMEOUT|SRV/i.test(err?.message || '');
        if (isSrvUri && isSrvError) {
          try {
            const srvHost = mongoUri.replace(/^mongodb\+srv:\/\//, '').split('/')[0].split('@').pop();
            const srvRecords = await dns.promises.resolveSrv(`_mongodb._tcp.${srvHost}`);
            const seeds = srvRecords.map(r => `${r.name}:${r.port}`).join(',');
            // Kimlik bilgilerinin yer aldığı bağlantı kısmını koru
            const credsAndRest = mongoUri.replace(/^mongodb\+srv:\/\//, '').split('@');
            const creds = credsAndRest.length > 1 ? credsAndRest[0] + '@' : '';
            const dbAndParams = mongoUri.split('/').slice(3).join('/'); // db?params
            const nonSrv = `mongodb://${creds}${seeds}/${dbAndParams}${dbAndParams.includes('?') ? '&' : '?'}tls=true`;
            console.warn('SRV hatası için non-SRV fallback deneniyor...');
            await mongoose.connect(nonSrv, {
              serverSelectionTimeoutMS: 10000,
              connectTimeoutMS: 10000,
              socketTimeoutMS: 20000,
              family: 4,
              retryWrites: true,
              w: 'majority'
            });
            console.log('[MongoDB API] SRV fallback ile bağlandı.');
            global.DB_CONNECTED = true;
            return;
          } catch (fallbackErr) {
            console.error('Non-SRV fallback başarısız:', fallbackErr?.message || fallbackErr);
          }
        }

        if (attempt < retries) {
          const backoff = Math.min(30000, 2000 * attempt);
          await new Promise(res => setTimeout(res, backoff));
          continue;
        } else {
          console.error('MongoDB kalıcı olarak bağlanamadı. Veritabanı gerektiren görevler devre dışı.');
        }
      }
    }
  };

  // Mongoose connection state loglama
  mongoose.connection.on('connected', () => {
    global.DB_CONNECTED = true;
    console.log('[MongoDB] connected');
  });
  mongoose.connection.on('disconnected', () => {
    global.DB_CONNECTED = false;
    console.warn('[MongoDB] disconnected');
  });
  mongoose.connection.on('error', (err) => {
    global.DB_CONNECTED = false;
    console.error('[MongoDB] error:', err?.message || err);
  });

  await connectWithRetry(5);
});


// Geçici sesli odalar
const tempRooms = new Set();
client.on('voiceStateUpdate', async (oldState, newState) => {
  const { tempVoiceParent, tempVoiceCategory } = lyuex.botSettings;
  if (newState.channelId === tempVoiceParent) {
    const member = newState.member;
    const newChannel = await newState.guild.channels.create({
      name: `${member.user.username}'s Room`,
      type: ChannelType.GuildVoice,
      parent: tempVoiceCategory,
      permissionOverwrites: [
        { id: member.id, allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak] },
        { id: newState.guild.roles.everyone.id, deny: [PermissionsBitField.Flags.Connect] }
      ]
    });
    tempRooms.add(newChannel.id);
    await newState.setChannel(newChannel.id);
  }
  if (oldState.channelId && tempRooms.has(oldState.channelId)) {
    const left = oldState.guild.channels.cache.get(oldState.channelId);
    if (left && left.members.size === 0) {
      tempRooms.delete(oldState.channelId);
      await left.delete().catch(() => {});
    }
  }
});

// Otomatik rol
let lastRoleWarning = 0; // Son uyarı zamanı
const ROLE_WARNING_COOLDOWN = 300000; // 5 dakika (milliseconds)

client.on('guildMemberAdd', async member => {
  try {
    // Bot guard kontrolü
    if (member.user.bot) {
      const entry = (await member.guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd })).entries.first();
      if (entry?.target.id === member.user.id && !isUserSafe(member.guild, entry.executor.id)) {
        try {
          await member.kick('Sunucuya bot ekledi');
          await member.guild.members.ban(entry.executor.id, { reason: 'Bot ekleme' });
          const eb = new EmbedBuilder().setColor('Red').setTitle('Guard Sistemi Uyarısı').setDescription(`${entry.executor.tag}, bot eklediği için yasaklandı.`);
          await (await member.guild.fetchOwner()).send({ embeds: [eb] });
        } catch (e) { console.error('Bot guard error:', e); }
      }
      return; // Bot ise rol verme
    }

    // Kayıtsız rolü otomatik olarak ver (sadece gerçek kullanıcılara)
    const kayitsizRoleId = lyuex.rol?.kayıtsız;
    
    if (kayitsizRoleId) {
      const guild = member.guild;
      const role = guild.roles.cache.get(kayitsizRoleId);
      
      if (role) {
        await member.roles.add(role);
        console.log(`Otomatik rol atandı: ${member.user.tag} -> ${role.name}`);
      } else {
        const now = Date.now();
        if (now - lastRoleWarning > ROLE_WARNING_COOLDOWN) {
          console.warn(`Kayıtsız rol bulunamadı (ID: ${kayitsizRoleId}). Rol silinmiş olabilir veya ID yanlış olabilir.`);
          lastRoleWarning = now;
        }
        
        // Alternatif rol arama
        const roleByName = guild.roles.cache.find(r => r.name.toLowerCase().includes('kayıtsız') || r.name.toLowerCase().includes('unregistered'));
        if (roleByName) {
          await member.roles.add(roleByName);
          console.log(`Alternatif kayıtsız rol atandı: ${member.user.tag} -> ${roleByName.name}`);
        } else if (now - lastRoleWarning > ROLE_WARNING_COOLDOWN) {
          console.warn('Hiçbir kayıtsız rol bulunamadı. Lütfen rol ID\'sini kontrol edin.');
        }
      }
    } else {
      console.warn('Otomatik rol ID tanımlanmamış (lyuex.rol.kayıtsız)');
    }
  } catch (err) {
    console.error('Otomatik rol hatası:', err);
  }
});

// Guard sistemi
function addToWhitelist(guildId, userId) {
  const list = db.get(`güvenli_kullanıcılar_${guildId}`) || [];
  if (!list.includes(userId)) { list.push(userId); db.set(`güvenli_kullanıcılar_${guildId}`, list); }
}
function isUserSafe(guild, userId) {
  try {
    // Direkt güvenli kullanıcı kontrolü
    const whitelistKey = `güvenli_kullanıcılar_${guild.id}`;
    const safeUsers = db.get(whitelistKey) || [];
    if (safeUsers.includes(userId)) return true;
    
    // Rol bazlı güvenlik kontrolü
    const member = guild.members.cache.get(userId);
    if (!member) return false;
    
    // Sahip her zaman güvenli
    if (guild.ownerId === userId) return true;
    
    // Yönetici yetkileri kontrolü
    if (member.permissions.has('Administrator')) return true;
    
    // Güvenli rol kontrolü
    const safeRolesKey = `güvenli_roller_${guild.id}`;
    const safeRoles = db.get(safeRolesKey) || [];
    return member.roles.cache.some(role => safeRoles.includes(role.id));
  } catch (error) {
    console.error('[GUARD] isUserSafe error:', error?.message || error);
    return false;
  }
}
async function handleGuardEvent(guild, logsPromise, dbKey, limitKey, reason) {
  if (!db.has(`guard_${guild.id}`)) return;
  
  try {
    const entry = (await logsPromise).entries.first();
    if (!entry?.executor || entry.executor.id === client.user.id) return;
    
    if (isUserSafe(guild, entry.executor.id)) return;
    
    const usr = entry.executor;
    let { count, timestamp } = db.get(`${dbKey}_${guild.id}_${usr.id}`) || { count: 0, timestamp: Date.now() };
    const now = Date.now();
    
    if (now - timestamp > 60000) {
      count = 1;
      timestamp = now;
    } else {
      count++;
    }
    
    db.set(`${dbKey}_${guild.id}_${usr.id}`, { count, timestamp });
    
    if (count >= guardLimits[limitKey]) {
      await guild.members.ban(usr.id, { reason });
      const eb = new EmbedBuilder()
        .setColor('Red')
        .setTitle('Guard Sistemi Uyarısı')
        .setDescription(`${usr.tag}, ${reason}.`);
      
      try {
        const owner = await guild.fetchOwner();
        await owner.send({ embeds: [eb] });
      } catch (dmError) {
        console.warn('[GUARD] DM gönderilemedi:', dmError.message);
      }
      
      db.delete(`${dbKey}_${guild.id}_${usr.id}`);
      console.log(`[GUARD] ${usr.tag} yasaklandı: ${reason}`);
    }
  } catch (err) {
    console.error(`[GUARD][${dbKey}] Hata:`, err?.message || err);
  }
}

// Guard event registration
client.on('channelDelete', c => handleGuardEvent(c.guild, c.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete }), 'kanal_silme', 'delete_channels', 'Çok fazla kanal silme'));
client.on('channelCreate', c => handleGuardEvent(c.guild, c.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate }), 'kanal_oluşturma', 'create_channels', 'Çok fazla kanal oluşturma'));
client.on('roleCreate', r => handleGuardEvent(r.guild, r.guild.fetchAuditLogs({ type: AuditLogEvent.RoleCreate }), 'rol_oluşturma', 'create_roles', 'Çok fazla rol oluşturma'));
client.on('roleDelete', r => handleGuardEvent(r.guild, r.guild.fetchAuditLogs({ type: AuditLogEvent.RoleDelete }), 'rol_silme', 'delete_roles', 'Çok fazla rol silme'));
client.on('guildBanAdd', b => handleGuardEvent(b.guild, b.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd }), 'üye_yasaklama', 'ban_members', 'Çok fazla üye yasaklama'));
// Everyone mention guard
client.on('messageCreate', m => {
  if (m.mentions.everyone && !m.author.bot && !isUserSafe(m.guild, m.author.id)) {
    handleGuardEvent(m.guild, Promise.resolve({ entries: new Map([['first', { executor: m.author }]]), entries: { first() { return { executor: m.author }; } }}), 'everyone_atma', 'send_everyone', 'Çok fazla everyone atma');
  }
});
client.on('guildMemberRemove', async m => {
  // Audit log'dan gerçek kick işlemi olup olmadığını kontrol et
  try {
    const auditLogs = await m.guild.fetchAuditLogs({ 
      type: AuditLogEvent.MemberKick,
      limit: 1 
    });
    
    if (auditLogs && auditLogs.entries.size > 0) {
      const kickLog = auditLogs.entries.first();
      // Son 5 saniyede kick log'u varsa ve hedef bu üyeyse gerçek kick
      if (kickLog && 
          kickLog.target?.id === m.user.id && 
          Date.now() - kickLog.createdTimestamp < 5000) {
        
        handleGuardEvent(m.guild, Promise.resolve(auditLogs), 'üye_atma', 'kick_members', 'Çok fazla üye atma');
      }
    }
  } catch (error) {
    console.error('[GUARD] Kick detection error:', error?.message || error);
  }
});
client.on('guildUpdate', (o, n) => handleGuardEvent(n, n.fetchAuditLogs({ type: AuditLogEvent.GuildUpdate }), 'guild_update', 'guild_updates', 'Sunucu ayarları değiştirildi'));





client.on('channelUpdate', (oldChannel, newChannel) => {
  handleGuardEvent(
    newChannel.guild,
    newChannel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelUpdate }),
    'kanal_guncelleme',
    'update_channels',
    'Çok fazla kanal düzenleme'
  );
});

client.on('guildMemberUpdate', async (oldMember, newMember) => {
  // Roller değişti mi?
  const added = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
  const removed = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));
  if (!added.size && !removed.size) return;

  // Guard event'i tetikle
  await handleGuardEvent(
    newMember.guild,
    newMember.guild.fetchAuditLogs({ type: AuditLogEvent.MemberRoleUpdate, limit: 1 }),
    'üye_rol_guncelleme',
    'member_update_roles',
    'Çok fazla üye rol güncelleme'
  );
});

// Kategori oluşturma guard
client.on('channelCreate', channel => {
  if (channel.type === ChannelType.GuildCategory) {
    handleGuardEvent(
      channel.guild,
      channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate }),
      'kategori_olusturma',
      'create_categories',
      'Çok fazla kategori oluşturma'
    );
  }
});

// Kategori silme guard
client.on('channelDelete', channel => {
  if (channel.type === ChannelType.GuildCategory) {
    handleGuardEvent(
      channel.guild,
      channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete }),
      'kategori_silme',
      'delete_categories',
      'Çok fazla kategori silme'
    );
  }
});

// Graceful shutdown handler
process.on('SIGINT', async () => {
  console.log('\x1b[31m%s\x1b[0m', '\n[LYUEX] 🛑 Bot kapatılıyor... | Lyuex Development');
  
  // Tüm interval'ları temizle
  if (global.activeIntervals && global.activeIntervals.length > 0) {
    console.log(`⏹️ ${global.activeIntervals.length} interval temizleniyor...`);
    global.activeIntervals.forEach(id => clearInterval(id));
    global.activeIntervals = [];
  }
  
  if (global.backupScheduler) {
    global.backupScheduler.stopScheduler();
  }
  if (global.ticketAutomation) {
    global.ticketAutomation.stop();
  }
  if (global.serverStatusManager) {
    global.serverStatusManager.stopStatusUpdater();
  }
  
  // Client'ı kapat
  try {
    await client.destroy();
    console.log('✅ Discord bağlantısı kapatıldı');
  } catch (e) {
    console.error('Kapanma hatası:', e.message);
  }
  
  // Mongoose'u kapat
  try {
    await mongoose.connection.close();
    console.log('✅ MongoDB bağlantısı kapatıldı');
  } catch (e) {
    console.error('MongoDB kapanma hatası:', e.message);
  }
  
  process.exit(0);
});

// Handling unhandled rejections (prevent silent crashes)
process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ İşlenmeyen Rejection:', reason);
  if (reason?.message) {
    console.error('  Detay:', reason.message);
  }
});

// Login with enhanced error handling
client.login(BOT_TOKEN)
  .then(() => {
    console.log('\x1b[32m%s\x1b[0m', '[LYUEX] ✅ Bot başarıyla Discord\'a bağlandı! | Powered by Lyuex Development');
  })
  .catch(err => {
    console.error('❌ Login hatası:', err);
    console.error('Bot token geçerli mi? İnternet bağlantınız var mı?');
    process.exit(1);
  });
