// ══════════════════════════════════════════════════
// Lyuex Development - Discord Bot Altyapısı
// © 2024-2026 Lyuex Development | Tüm hakları saklıdır.
// ══════════════════════════════════════════════════
/**
 * Simple debugging and logging utility
 */

const fs = require('fs');
const path = require('path');

// Ensure logs directory exists
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

// Log file paths
const infoLogPath = path.join(logsDir, 'info.log');
const errorLogPath = path.join(logsDir, 'error.log');

/**
 * Format timestamp for logs
 */
function getTimestamp() {
    return new Date().toISOString();
}

/**
 * Write to log file
 */
function writeToFile(filePath, message) {
    try {
        const logEntry = `[${getTimestamp()}] ${message}\n`;
        fs.appendFileSync(filePath, logEntry, 'utf8');
    } catch (err) {
        console.error('Log dosyasına yazma hatası:', err.message);
    }
}

/**
 * Track info messages
 */
function trackInfo(message) {
    const logMessage = `[INFO] ${message}`;
    console.log(logMessage);
    writeToFile(infoLogPath, logMessage);
}

/**
 * Track error messages
 */
function trackError(error, context = '') {
    const errorMessage = error instanceof Error ? error.message : String(error);
    const logMessage = `[ERROR] ${context ? `[${context}] ` : ''}${errorMessage}`;
    
    console.error(logMessage);
    writeToFile(errorLogPath, logMessage);
    
    // Also log the stack trace if available
    if (error instanceof Error && error.stack) {
        const stackMessage = `[ERROR STACK] ${context ? `[${context}] ` : ''}${error.stack}`;
        writeToFile(errorLogPath, stackMessage);
    }
}

/**
 * Track warning messages
 */
function trackWarning(message) {
    const logMessage = `[WARNING] ${message}`;
    console.warn(logMessage);
    writeToFile(infoLogPath, logMessage);
}

module.exports = {
    trackInfo,
    trackError,
    trackWarning
};